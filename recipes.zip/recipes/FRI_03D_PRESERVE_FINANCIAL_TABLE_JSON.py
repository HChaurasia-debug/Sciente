"""Create one lossless canonical JSON document per validated financial table.

Inputs: FRI_VALIDATED_TABLE_ARTIFACTS, FRI_VALIDATED_TABLE_CELLS
Output: FRI_FINANCIAL_TABLE_JSON
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

import dataiku
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "SRC"))
from fsre_capture.table_json import build_table_document, dumps  # noqa: E402


TABLES = os.getenv("FRI_VALIDATED_TABLE_ARTIFACTS", "FRI_VALIDATED_TABLE_ARTIFACTS")
CELLS = os.getenv("FRI_VALIDATED_TABLE_CELLS", "FRI_VALIDATED_TABLE_CELLS")
OUTPUT = os.getenv("FRI_FINANCIAL_TABLE_JSON", "FRI_FINANCIAL_TABLE_JSON")


def read(name):
    try:
        return dataiku.Dataset(name).get_dataframe(infer_with_pandas=False)
    except TypeError:
        return dataiku.Dataset(name).get_dataframe()


def text(value):
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except (TypeError, ValueError):
        pass
    return str(value).strip()


def table_id(row):
    return text(row.get("table_artifact_id") or row.get("source_table_id"))


artifacts = read(TABLES)
cells = read(CELLS)
cells_by_table = {}
for cell in cells.to_dict(orient="records"):
    cells_by_table.setdefault(table_id(cell), []).append(cell)

rows = []
for artifact in artifacts.to_dict(orient="records"):
    key = table_id(artifact)
    document, issues = build_table_document(artifact, cells_by_table.get(key, []))
    rows.append({
        "table_artifact_id": key,
        "source_document_id": text(artifact.get("source_document_id")),
        "statement_type": text(artifact.get("statement_type")),
        "page_number": artifact.get("page_number"),
        "schema_version": document["schema_version"],
        "validation_status": document["validation"]["status"],
        "issue_count": len(issues),
        "cell_count": document["integrity"]["cell_count"],
        "sha256": document["integrity"]["fingerprint"],
        "table_json": dumps(document),
    })

output = pd.DataFrame(rows, columns=[
    "table_artifact_id", "source_document_id", "statement_type",
    "page_number", "schema_version", "validation_status", "issue_count",
    "cell_count", "sha256", "table_json",
])
dataiku.Dataset(OUTPUT).write_with_schema(output)
print(json.dumps({
    "table_count": len(output),
    "invalid_table_count": int((output["validation_status"] == "INVALID").sum()) if not output.empty else 0,
    "output_dataset": OUTPUT,
}, indent=2))
