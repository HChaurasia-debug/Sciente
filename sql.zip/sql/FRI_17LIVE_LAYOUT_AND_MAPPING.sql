-- Reusable mappings for consolidated statements with Group/Company columns
-- and note columns between labels and period values.  These rules are not
-- company-specific; they apply to equivalent labels in future filings.
BEGIN;

INSERT INTO financial_risk_intelligence.financial_concept_aliases
 (concept_key,alias_text,normalized_alias_text,sector_key,priority,active,approval_status,approved_by,approved_at)
SELECT v.concept_key,v.alias_text,
       financial_risk_intelligence.normalize_financial_alias_text(v.alias_text),
       NULL,v.priority,true,'APPROVED','17LIVE_LAYOUT',now()
FROM (VALUES
 ('revenue','Operating revenue',1),
 ('cost_of_goods_sold','Cost of revenue',1),
 ('selling_expense','Selling expenses',1),
 ('administrative_expenses','General and administrative expenses',1),
 ('administrative_expenses','General & administrative expenses',2),
 ('distribution_expense','Research and development expenses',1),
 ('operating_income_ebit','Operating income',1),
 ('operating_income_ebit','Operating profit',2),
 ('interest_expense','Finance costs',1),
 ('net_profit','Loss for the year, attributable to owners of the Company',1),
 ('net_profit','Profit for the year, attributable to owners of the Company',2),
 ('total_current_assets','Total current assets',1),
 ('trade_receivables_net','Trade and other receivables',5),
 ('inventory','Inventory',1),('inventory','Inventories',2),
 ('net_ppe','Property, plant and equipment',1),
 ('total_assets','Total assets',1),
 ('total_current_liabilities','Total current liabilities',1),
 ('long_term_debt','Loans and borrowings',5),
 ('long_term_debt','Lease liabilities',6),
 ('total_liabilities','Total liabilities',1),
 ('retained_earnings','Accumulated deficit',1),
 ('retained_earnings','Accumulated losses',2),
 ('total_shareholders_equity','Equity attributable to owners',1),
 ('total_shareholders_equity','Total equity',2),
 ('depreciation_ppe','Depreciation expense',1),
 ('amortization_intangibles','Amortisation expense',1),
 ('amortization_intangibles','Amortization expense',2),
 ('operating_cash_flow','Net cash flows from/(used in) operating activities',1),
 ('operating_cash_flow','Net cash flows from operating activities',2),
 ('issued_shares','Number of ordinary shares',1),
 ('treasury_shares_count','Treasury shares',1)
) v(concept_key,alias_text,priority)
ON CONFLICT DO NOTHING;

-- Exact primary-statement labels must outrank note-table and intermediate
-- subtotal candidates already present in the shared alias registry.
UPDATE financial_risk_intelligence.financial_concept_aliases
SET priority = CASE
  WHEN alias_text IN ('Operating revenue','Operating income',
                      'Loss for the year, attributable to owners of the Company',
                      'Net cash flows from/(used in) operating activities') THEN 100
  WHEN alias_text IN ('Depreciation expense','Amortisation expense') THEN 90
  ELSE priority
END,
    active = true,
    approval_status = 'APPROVED';

-- This subtotal is not CFO; it is an input to the indirect-method bridge.
-- Keeping it on a separate concept prevents it from satisfying the CFO field.
UPDATE financial_risk_intelligence.financial_concept_aliases
SET active = false
WHERE lower(alias_text) = lower('Operating cash flows before changes in working capital')
  AND concept_key = 'operating_cash_flow';

-- SG&A is the sum of selling, general/administrative and R&D expenses when
-- no single SG&A line is reported.
INSERT INTO financial_risk_intelligence.financial_template_rules
 (rule_key,template_key,target_concept_key,operator,priority,output_sign,active,approval_status)
VALUES
 ('SGA_COMPONENTS','MANUFACTURING_INDUSTRIALS_GENERIC','sg_and_a_expense','LINEAR_COMBINATION',20,'ABSOLUTE',true,'APPROVED'),
 ('DA_COMPONENTS','MANUFACTURING_INDUSTRIALS_GENERIC','depreciation_amortization','LINEAR_COMBINATION',20,'ABSOLUTE',true,'APPROVED'),
 ('LTD_SUM','MANUFACTURING_INDUSTRIALS_GENERIC','long_term_debt','LINEAR_COMBINATION',5,'ABSOLUTE',true,'APPROVED')
ON CONFLICT(template_key,target_concept_key,priority) DO UPDATE
SET rule_key=EXCLUDED.rule_key,
    operator=EXCLUDED.operator,
    output_sign=EXCLUDED.output_sign,
    active=true,
    approval_status='APPROVED';

INSERT INTO financial_risk_intelligence.financial_rule_components
 (rule_key,component_concept_key,coefficient,component_sign,component_order)
VALUES
 ('SGA_COMPONENTS','selling_expense',1,'ABSOLUTE',1),
 ('SGA_COMPONENTS','administrative_expenses',1,'ABSOLUTE',2),
 ('SGA_COMPONENTS','distribution_expense',1,'ABSOLUTE',3),
 ('DA_COMPONENTS','depreciation_ppe',1,'ABSOLUTE',1),
 ('DA_COMPONENTS','amortization_intangibles',1,'ABSOLUTE',2),
 ('LTD_SUM','non_current_borrowings',1,'ABSOLUTE',1),
 ('LTD_SUM','non_current_lease_liabilities',1,'ABSOLUTE',2)
ON CONFLICT(rule_key,component_concept_key) DO UPDATE SET coefficient=EXCLUDED.coefficient,component_sign=EXCLUDED.component_sign;

COMMIT;
