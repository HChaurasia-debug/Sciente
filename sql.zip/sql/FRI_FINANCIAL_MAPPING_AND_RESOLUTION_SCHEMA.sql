-- FSRE governed financial mapping and resolution schema
-- Idempotent migration: creates or extends objects without deleting report data.

BEGIN;

CREATE SCHEMA IF NOT EXISTS financial_risk_intelligence;

-- One active governed mapping per canonical financial concept. New statement
-- labels are appended to aliases_json; customer filenames never belong here.
CREATE TABLE IF NOT EXISTS financial_risk_intelligence.financial_concept_mapping_rules (
    concept_key             TEXT PRIMARY KEY,
    statement_type          TEXT NOT NULL,
    aliases_json            JSONB NOT NULL DEFAULT '[]'::jsonb,
    component_concepts_json JSONB NOT NULL DEFAULT '[]'::jsonb,
    governed_formula        TEXT NOT NULL DEFAULT 'DIRECT_DISCLOSED_VALUE',
    exclusions_json         JSONB NOT NULL DEFAULT '[]'::jsonb,
    validation_json         JSONB NOT NULL DEFAULT '{}'::jsonb,
    output_unit_rule        TEXT NOT NULL DEFAULT 'REPORTING_UNIT',
    priority                INTEGER NOT NULL DEFAULT 100,
    rule_version            TEXT NOT NULL DEFAULT 'FSRE_MAPPING_V1',
    active                  BOOLEAN NOT NULL DEFAULT TRUE,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ck_financial_mapping_statement_type CHECK (
        statement_type IN ('INCOME_STATEMENT', 'BALANCE_SHEET', 'CASH_FLOW_STATEMENT')
    ),
    CONSTRAINT ck_financial_mapping_aliases_array CHECK (jsonb_typeof(aliases_json) = 'array'),
    CONSTRAINT ck_financial_mapping_components_array CHECK (jsonb_typeof(component_concepts_json) = 'array'),
    CONSTRAINT ck_financial_mapping_exclusions_array CHECK (jsonb_typeof(exclusions_json) = 'array'),
    CONSTRAINT ck_financial_mapping_validation_object CHECK (jsonb_typeof(validation_json) = 'object')
);

-- Backward-compatible additions for databases created by earlier migrations.
ALTER TABLE financial_risk_intelligence.financial_concept_mapping_rules
    ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP;

CREATE INDEX IF NOT EXISTS ix_financial_mapping_statement_priority
    ON financial_risk_intelligence.financial_concept_mapping_rules
       (statement_type, active, priority, concept_key);

CREATE INDEX IF NOT EXISTS ix_financial_mapping_aliases_gin
    ON financial_risk_intelligence.financial_concept_mapping_rules
    USING GIN (aliases_json);

-- Immutable mapping history supports audit, rollback and regression diagnosis.
CREATE TABLE IF NOT EXISTS financial_risk_intelligence.financial_concept_mapping_rule_history (
    history_id              BIGSERIAL PRIMARY KEY,
    concept_key             TEXT NOT NULL,
    statement_type          TEXT NOT NULL,
    aliases_json            JSONB NOT NULL,
    component_concepts_json JSONB NOT NULL,
    governed_formula        TEXT NOT NULL,
    exclusions_json         JSONB NOT NULL,
    validation_json         JSONB NOT NULL,
    output_unit_rule        TEXT NOT NULL,
    priority                INTEGER NOT NULL,
    rule_version            TEXT NOT NULL,
    active                  BOOLEAN NOT NULL,
    change_operation        TEXT NOT NULL,
    changed_at              TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    changed_by              TEXT NOT NULL DEFAULT CURRENT_USER,
    CONSTRAINT ck_financial_mapping_history_operation
        CHECK (change_operation IN ('INSERT', 'UPDATE', 'DELETE'))
);

CREATE INDEX IF NOT EXISTS ix_financial_mapping_history_lookup
    ON financial_risk_intelligence.financial_concept_mapping_rule_history
       (concept_key, changed_at DESC);

CREATE OR REPLACE FUNCTION financial_risk_intelligence.audit_financial_mapping_rule()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
    source_row financial_risk_intelligence.financial_concept_mapping_rules%ROWTYPE;
BEGIN
    IF TG_OP = 'DELETE' THEN
        source_row := OLD;
    ELSE
        source_row := NEW;
    END IF;
    INSERT INTO financial_risk_intelligence.financial_concept_mapping_rule_history (
        concept_key, statement_type, aliases_json, component_concepts_json,
        governed_formula, exclusions_json, validation_json, output_unit_rule,
        priority, rule_version, active, change_operation
    ) VALUES (
        source_row.concept_key, source_row.statement_type, source_row.aliases_json,
        source_row.component_concepts_json, source_row.governed_formula,
        source_row.exclusions_json, source_row.validation_json,
        source_row.output_unit_rule, source_row.priority, source_row.rule_version,
        source_row.active, TG_OP
    );
    RETURN CASE WHEN TG_OP = 'DELETE' THEN OLD ELSE NEW END;
END;
$$;

DROP TRIGGER IF EXISTS trg_audit_financial_mapping_rule
    ON financial_risk_intelligence.financial_concept_mapping_rules;
CREATE TRIGGER trg_audit_financial_mapping_rule
AFTER INSERT OR UPDATE OR DELETE
ON financial_risk_intelligence.financial_concept_mapping_rules
FOR EACH ROW EXECUTE FUNCTION financial_risk_intelligence.audit_financial_mapping_rule();

-- Model or deterministic proposals remain separate from approved facts.
CREATE TABLE IF NOT EXISTS financial_risk_intelligence.financial_fact_resolution_proposals (
    proposal_id         TEXT PRIMARY KEY,
    assessment_run_id   TEXT NOT NULL,
    source_document_id  TEXT NOT NULL,
    statement_type      TEXT NOT NULL,
    concept_key         TEXT NOT NULL,
    concept_label       TEXT NOT NULL,
    period_role         TEXT NOT NULL,
    period_label        TEXT NOT NULL,
    proposed_value      NUMERIC NOT NULL,
    currency            TEXT,
    unit                TEXT,
    resolution_method   TEXT NOT NULL,
    formula             TEXT,
    operands_json       JSONB NOT NULL DEFAULT '[]'::jsonb,
    candidate_rows_json JSONB NOT NULL DEFAULT '[]'::jsonb,
    evidence_json       JSONB NOT NULL DEFAULT '[]'::jsonb,
    explanation         TEXT NOT NULL,
    confidence          NUMERIC NOT NULL,
    validation_status   TEXT NOT NULL,
    validation_message  TEXT NOT NULL,
    model_name          TEXT NOT NULL,
    prompt_json         JSONB NOT NULL DEFAULT '{}'::jsonb,
    response_json       JSONB NOT NULL DEFAULT '{}'::jsonb,
    status              TEXT NOT NULL DEFAULT 'PENDING',
    created_at          TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    reviewed_at         TIMESTAMPTZ,
    reviewed_by         TEXT,
    CONSTRAINT ck_financial_proposal_statement_type CHECK (
        statement_type IN ('INCOME_STATEMENT', 'BALANCE_SHEET', 'CASH_FLOW_STATEMENT')
    ),
    CONSTRAINT ck_financial_proposal_period_role CHECK (period_role IN ('current', 'prior')),
    CONSTRAINT ck_financial_proposal_confidence CHECK (confidence >= 0 AND confidence <= 1)
);

CREATE INDEX IF NOT EXISTS ix_financial_proposals_report_target
    ON financial_risk_intelligence.financial_fact_resolution_proposals
       (assessment_run_id, source_document_id, concept_key, period_role, created_at DESC);

CREATE INDEX IF NOT EXISTS ix_financial_proposals_status
    ON financial_risk_intelligence.financial_fact_resolution_proposals
       (status, created_at DESC);

-- Only approved values are overlaid on canonical Dataiku facts.
CREATE TABLE IF NOT EXISTS financial_risk_intelligence.approved_financial_fact_overrides (
    override_id           TEXT PRIMARY KEY,
    proposal_id           TEXT NOT NULL UNIQUE,
    assessment_run_id     TEXT NOT NULL,
    source_document_id    TEXT NOT NULL,
    statement_type        TEXT NOT NULL,
    concept_key           TEXT NOT NULL,
    period_role           TEXT NOT NULL,
    period_label          TEXT NOT NULL,
    numeric_value         NUMERIC NOT NULL,
    currency              TEXT,
    unit                  TEXT,
    resolution_method     TEXT NOT NULL,
    confidence            NUMERIC NOT NULL,
    evidence_json         JSONB NOT NULL DEFAULT '[]'::jsonb,
    validated_rule_version TEXT,
    approved_by           TEXT NOT NULL,
    approved_at           TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    active                BOOLEAN NOT NULL DEFAULT TRUE,
    CONSTRAINT uq_financial_override_report_target
        UNIQUE (assessment_run_id, source_document_id, concept_key, period_role),
    CONSTRAINT ck_financial_override_statement_type CHECK (
        statement_type IN ('INCOME_STATEMENT', 'BALANCE_SHEET', 'CASH_FLOW_STATEMENT')
    ),
    CONSTRAINT ck_financial_override_period_role CHECK (period_role IN ('current', 'prior')),
    CONSTRAINT ck_financial_override_confidence CHECK (confidence >= 0 AND confidence <= 1)
);

ALTER TABLE financial_risk_intelligence.approved_financial_fact_overrides
    ADD COLUMN IF NOT EXISTS validated_rule_version TEXT;

CREATE INDEX IF NOT EXISTS ix_financial_overrides_active_report
    ON financial_risk_intelligence.approved_financial_fact_overrides
       (assessment_run_id, source_document_id, active, concept_key, period_role);

-- One idempotent job row prevents repeated provider calls for the same scope.
CREATE TABLE IF NOT EXISTS financial_risk_intelligence.financial_fact_resolution_jobs (
    job_key            TEXT PRIMARY KEY,
    assessment_run_id  TEXT NOT NULL,
    source_document_id TEXT NOT NULL,
    resolution_scope   TEXT NOT NULL,
    status             TEXT NOT NULL,
    requested_count    INTEGER NOT NULL DEFAULT 0,
    saved_count        INTEGER NOT NULL DEFAULT 0,
    unresolved_count   INTEGER NOT NULL DEFAULT 0,
    result_json        JSONB NOT NULL DEFAULT '{}'::jsonb,
    error_message      TEXT,
    started_at         TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_at       TIMESTAMPTZ,
    updated_at         TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_financial_resolution_job_scope
        UNIQUE (assessment_run_id, source_document_id, resolution_scope),
    CONSTRAINT ck_financial_resolution_counts CHECK (
        requested_count >= 0 AND saved_count >= 0 AND unresolved_count >= 0
    )
);

CREATE INDEX IF NOT EXISTS ix_financial_resolution_jobs_report
    ON financial_risk_intelligence.financial_fact_resolution_jobs
       (assessment_run_id, source_document_id, updated_at DESC);

-- Captures the final validation run, score snapshot and UI refresh contract.
CREATE TABLE IF NOT EXISTS financial_risk_intelligence.financial_input_validation_runs (
    validation_id      TEXT PRIMARY KEY,
    assessment_run_id  TEXT NOT NULL,
    source_document_id TEXT NOT NULL,
    file_name          TEXT NOT NULL,
    validation_mode    TEXT NOT NULL,
    status             TEXT NOT NULL,
    requested_count    INTEGER NOT NULL DEFAULT 0,
    saved_count        INTEGER NOT NULL DEFAULT 0,
    unresolved_count   INTEGER NOT NULL DEFAULT 0,
    values_json        JSONB NOT NULL DEFAULT '[]'::jsonb,
    score_json         JSONB NOT NULL DEFAULT '{}'::jsonb,
    details_json       JSONB NOT NULL DEFAULT '{}'::jsonb,
    backend_build      TEXT NOT NULL,
    saved_at           TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_financial_validation_run
        UNIQUE (assessment_run_id, source_document_id, validation_id),
    CONSTRAINT ck_financial_validation_counts CHECK (
        requested_count >= 0 AND saved_count >= 0 AND unresolved_count >= 0
    )
);

CREATE INDEX IF NOT EXISTS ix_financial_validation_runs_report
    ON financial_risk_intelligence.financial_input_validation_runs
       (assessment_run_id, source_document_id, saved_at DESC);

COMMIT;

-- Run FRI_FINANCIAL_CONCEPT_MAPPING_RULES.sql after this migration to seed or
-- refresh the canonical mappings used by the current backend.

-- Example: append a newly observed label to an existing canonical concept.
-- Replace only the alias text and increment the rule version deliberately.
--
-- UPDATE financial_risk_intelligence.financial_concept_mapping_rules
-- SET aliases_json = (
--         SELECT jsonb_agg(DISTINCT item)
--         FROM jsonb_array_elements(
--             aliases_json || '["new annual statement label"]'::jsonb
--         ) AS item
--     ),
--     rule_version = 'FSRE_MAPPING_V2',
--     updated_at = CURRENT_TIMESTAMP
-- WHERE concept_key = 'revenue';

-- Deployment verification.
SELECT table_name
FROM information_schema.tables
WHERE table_schema = 'financial_risk_intelligence'
  AND table_name IN (
      'financial_concept_mapping_rules',
      'financial_concept_mapping_rule_history',
      'financial_fact_resolution_proposals',
      'approved_financial_fact_overrides',
      'financial_fact_resolution_jobs',
      'financial_input_validation_runs'
  )
ORDER BY table_name;
