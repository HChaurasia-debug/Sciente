from __future__ import annotations

import json
import re
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from typing import Any, Optional
from urllib.parse import urlparse

import requests


@dataclass(frozen=True)
class ExtractionRequest:
    run_id: str
    prompt_id: str
    prompt_version: str
    model_name: str
    model_provider: str
    ollama_base_url: str
    max_chunks: int
    max_context_chars: int
    requested_by: str
    raw_document_id: Optional[str] = None
    ollama_fallback_base_urls: Optional[list[str]] = None
    ollama_timeout_seconds: int = 600

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "ExtractionRequest":
        allowed_fields = set(cls.__dataclass_fields__)
        filtered_payload = {
            key: value
            for key, value in payload.items()
            if key in allowed_fields
        }
        fallback_urls = filtered_payload.get("ollama_fallback_base_urls")
        if isinstance(fallback_urls, str):
            filtered_payload["ollama_fallback_base_urls"] = [
                value.strip()
                for value in fallback_urls.split(",")
                if value.strip()
            ]
        return cls(**filtered_payload)


KEYWORDS = (
    "revenue",
    "turnover",
    "sales",
    "accounts receivable",
    "trade receivables",
    "inventory",
    "inventories",
    "cost of sales",
    "cost of goods sold",
    "net profit",
    "profit for the year",
    "operating cash flow",
    "cash flows from operating",
    "total assets",
    "total liabilities",
    "total equity",
    "statement of financial position",
    "income statement",
    "cash flow statement",
)


def _fetchone(cur: Any, sql: str, params: tuple[Any, ...]) -> Optional[dict[str, Any]]:
    cur.execute(sql, params)
    row = cur.fetchone()
    return dict(row) if row else None


def _fetchall(cur: Any, sql: str, params: tuple[Any, ...]) -> list[dict[str, Any]]:
    cur.execute(sql, params)
    return [dict(row) for row in cur.fetchall()]


def get_raw_document(cur: Any, run_id: str, raw_document_id: Optional[str]) -> dict[str, Any]:
    if raw_document_id:
        row = _fetchone(
            cur,
            """
            SELECT *
            FROM fsre_ingestion.raw_documents
            WHERE run_id = %s
              AND raw_document_id = %s
            """,
            (run_id, raw_document_id),
        )
    else:
        row = _fetchone(
            cur,
            """
            SELECT *
            FROM fsre_ingestion.raw_documents
            WHERE run_id = %s
            ORDER BY created_at DESC
            LIMIT 1
            """,
            (run_id,),
        )

    if not row:
        raise ValueError(
            "No raw document found. Run 02_ingest_annual_report_document first "
            "or create an llm_extraction runtime request with raw_document_id."
        )
    return row


def get_prompt(cur: Any, prompt_id: str, prompt_version: str) -> dict[str, Any]:
    row = _fetchone(
        cur,
        """
        SELECT *
        FROM fsre_config.prompt_registry
        WHERE prompt_id = %s
          AND prompt_version = %s
          AND status = 'active'
        """,
        (prompt_id, prompt_version),
    )
    if not row:
        raise ValueError(f"No active prompt found for {prompt_id}/{prompt_version}")
    return row


def get_relevant_chunks(
    cur: Any,
    run_id: str,
    raw_document_id: str,
    max_chunks: int,
    max_context_chars: int,
) -> list[dict[str, Any]]:
    chunks = _fetchall(
        cur,
        """
        SELECT
            text_chunk_id,
            page_number,
            chunk_index,
            text_content
        FROM fsre_ingestion.document_text_chunks
        WHERE run_id = %s
          AND raw_document_id = %s
        ORDER BY chunk_index
        """,
        (run_id, raw_document_id),
    )
    if not chunks:
        raise ValueError("No text chunks found for selected raw document.")

    def score(chunk: dict[str, Any]) -> int:
        text = chunk["text_content"].lower()
        return sum(1 for keyword in KEYWORDS if keyword in text)

    ranked = sorted(chunks, key=lambda row: (score(row), -row["chunk_index"]), reverse=True)
    selected: list[dict[str, Any]] = []
    total_chars = 0
    for chunk in ranked:
        if len(selected) >= max_chunks:
            break
        text_len = len(chunk["text_content"])
        if selected and total_chars + text_len > max_context_chars:
            break
        selected.append(chunk)
        total_chars += text_len

    selected.sort(key=lambda row: row["chunk_index"])
    return selected


def build_context(chunks: list[dict[str, Any]]) -> str:
    parts = []
    for chunk in chunks:
        parts.append(
            "\n".join(
                [
                    f"[page={chunk['page_number']} chunk={chunk['chunk_index']}]",
                    chunk["text_content"],
                ]
            )
        )
    return "\n\n---\n\n".join(parts)


def build_extraction_prompt(base_prompt: str, raw_document: dict[str, Any], context: str) -> str:
    return f"""
{base_prompt}

Return only JSON. Do not include markdown fences or commentary.

Document metadata:
- entity_id: {raw_document.get("entity_id")}
- document_name: {raw_document.get("document_name")}
- reporting_period_label: {raw_document.get("reporting_period_label")}

Annual report text excerpts:
{context}
""".strip()


def call_ollama(
    base_url: str,
    model_name: str,
    prompt: str,
    model_parameters: Optional[dict[str, Any]] = None,
    fallback_base_urls: Optional[list[str]] = None,
    timeout_seconds: int = 600,
) -> str:
    payload = {
        "model": model_name,
        "prompt": prompt,
        "stream": False,
        "format": "json",
        "options": model_parameters or {},
    }
    errors = []
    for candidate_base_url in resolve_ollama_base_urls(base_url, fallback_base_urls):
        url = candidate_base_url.rstrip("/") + "/api/generate"
        try:
            response = requests.post(url, json=payload, timeout=timeout_seconds)
            response.raise_for_status()
            data = response.json()
            return data.get("response", "")
        except requests.RequestException as exc:
            errors.append(f"{candidate_base_url}: {exc}")

    raise ConnectionError(
        "Unable to connect to Ollama using configured URLs. Tried: "
        + " | ".join(errors)
    )


def resolve_ollama_base_urls(
    base_url: str,
    fallback_base_urls: Optional[list[str]] = None,
) -> list[str]:
    urls = []
    for candidate in [base_url, *(fallback_base_urls or [])]:
        if candidate and candidate not in urls:
            urls.append(candidate)

    parsed = urlparse(base_url)
    if parsed.hostname == "host.docker.internal":
        port = parsed.port or 11434
        scheme = parsed.scheme or "http"
        for host in ("fsre-ollama", "ollama", "host.containers.internal"):
            candidate = f"{scheme}://{host}:{port}"
            if candidate not in urls:
                urls.append(candidate)

    return urls


def parse_json_response(text: str) -> dict[str, Any]:
    stripped = text.strip()
    if stripped.startswith("```"):
        stripped = re.sub(r"^```(?:json)?", "", stripped, flags=re.IGNORECASE).strip()
        stripped = re.sub(r"```$", "", stripped).strip()
    try:
        return json.loads(stripped)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", stripped, flags=re.DOTALL)
        if match:
            return json.loads(match.group(0))
        raise


def normalize_numeric(value: Any) -> Optional[Decimal]:
    if value in (None, ""):
        return None
    if isinstance(value, (int, float, Decimal)):
        try:
            return Decimal(str(value))
        except InvalidOperation:
            return None
    if isinstance(value, str):
        cleaned = value.strip()
        if cleaned.lower() in {"n/a", "na", "nil", "none", "null", "-"}:
            return None
        cleaned = re.sub(r"[,$\s]", "", cleaned)
        negative_match = re.fullmatch(r"\((.+)\)", cleaned)
        if negative_match:
            cleaned = "-" + negative_match.group(1)
        try:
            return Decimal(cleaned)
        except InvalidOperation:
            return None
    return None


def flatten_fields(payload: dict[str, Any]) -> list[dict[str, Any]]:
    fields: list[dict[str, Any]] = []

    def walk(prefix: str, value: Any) -> None:
        if isinstance(value, dict):
            for key, nested in value.items():
                walk(f"{prefix}.{key}" if prefix else key, nested)
            return
        if isinstance(value, list):
            return

        field_name = prefix.split(".")[-1]
        fields.append(
            {
                "field_path": prefix,
                "field_name": field_name,
                "raw_value_text": None if value is None else str(value),
                "normalized_value_numeric": normalize_numeric(value),
                "normalized_value_text": None if value is None else str(value),
            }
        )

    for root_key in ("entity", "reporting_period", "financials", "auditor"):
        if root_key in payload:
            walk(root_key, payload[root_key])

    return fields


def extract_financial_fields(cur: Any, request: ExtractionRequest) -> dict[str, Any]:
    raw_document = get_raw_document(cur, request.run_id, request.raw_document_id)
    prompt = get_prompt(cur, request.prompt_id, request.prompt_version)
    chunks = get_relevant_chunks(
        cur,
        request.run_id,
        str(raw_document["raw_document_id"]),
        request.max_chunks,
        request.max_context_chars,
    )
    context = build_context(chunks)
    final_prompt = build_extraction_prompt(prompt["prompt_text"], raw_document, context)
    model_parameters = prompt.get("model_parameters_json") or {}

    response_text = call_ollama(
        request.ollama_base_url,
        request.model_name or prompt["model_name"],
        final_prompt,
        model_parameters,
        request.ollama_fallback_base_urls,
        request.ollama_timeout_seconds,
    )

    parse_status = "parsed"
    error_message = None
    response_json: Optional[dict[str, Any]]
    try:
        response_json = parse_json_response(response_text)
    except Exception as exc:
        parse_status = "failed"
        error_message = str(exc)
        response_json = None

    cur.execute(
        """
        INSERT INTO fsre_ingestion.extraction_results (
            run_id,
            raw_document_id,
            text_chunk_id,
            prompt_id,
            prompt_version,
            model_provider,
            model_name,
            model_version,
            request_json,
            response_json,
            response_text,
            parse_status,
            confidence_score,
            needs_review,
            error_message
        )
        VALUES (%s, %s, NULL, %s, %s, %s, %s, NULL, %s::jsonb, %s::jsonb, %s, %s, NULL, %s, %s)
        RETURNING extraction_id
        """,
        (
            request.run_id,
            raw_document["raw_document_id"],
            request.prompt_id,
            request.prompt_version,
            request.model_provider,
            request.model_name or prompt["model_name"],
            json.dumps(
                {
                    "chunk_ids": [str(row["text_chunk_id"]) for row in chunks],
                    "chunk_indexes": [row["chunk_index"] for row in chunks],
                    "max_chunks": request.max_chunks,
                    "max_context_chars": request.max_context_chars,
                    "ollama_timeout_seconds": request.ollama_timeout_seconds,
                }
            ),
            json.dumps(response_json) if response_json is not None else None,
            response_text,
            parse_status,
            parse_status != "parsed",
            error_message,
        ),
    )
    extraction_id = cur.fetchone()["extraction_id"]

    inserted_fields = 0
    if response_json is not None:
        period_label = (
            response_json.get("reporting_period", {}).get("fiscal_year")
            if isinstance(response_json.get("reporting_period"), dict)
            else raw_document.get("reporting_period_label")
        )
        for field in flatten_fields(response_json):
            cur.execute(
                """
                INSERT INTO fsre_ingestion.extracted_fields (
                    extraction_id,
                    run_id,
                    raw_document_id,
                    entity_id,
                    field_path,
                    field_name,
                    period_label,
                    raw_value_text,
                    normalized_value_numeric,
                    normalized_value_text,
                    currency,
                    unit,
                    page_number,
                    confidence_score,
                    source_ref_json
                )
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, NULL, NULL, NULL, NULL, '{}'::jsonb)
                """,
                (
                    extraction_id,
                    request.run_id,
                    raw_document["raw_document_id"],
                    raw_document.get("entity_id"),
                    field["field_path"],
                    field["field_name"],
                    str(period_label) if period_label else raw_document.get("reporting_period_label"),
                    field["raw_value_text"],
                    field["normalized_value_numeric"],
                    field["normalized_value_text"],
                ),
            )
            inserted_fields += 1

    cur.execute(
        """
        INSERT INTO fsre_audit.run_events (
            run_id,
            event_stage,
            event_type,
            severity,
            message,
            event_json
        )
        VALUES (%s, 'llm_extraction', 'financial_fields_extracted', %s, %s, %s::jsonb)
        """,
        (
            request.run_id,
            "INFO" if parse_status == "parsed" else "ERROR",
            f"Ollama extraction {parse_status}; inserted {inserted_fields} extracted fields.",
            json.dumps(
                {
                    "raw_document_id": str(raw_document["raw_document_id"]),
                    "extraction_id": str(extraction_id),
                    "prompt_id": request.prompt_id,
                    "prompt_version": request.prompt_version,
                    "model_name": request.model_name,
                    "selected_chunk_count": len(chunks),
                    "inserted_field_count": inserted_fields,
                }
            ),
        ),
    )

    return {
        "run_id": request.run_id,
        "raw_document_id": raw_document["raw_document_id"],
        "extraction_id": extraction_id,
        "parse_status": parse_status,
        "inserted_field_count": inserted_fields,
        "selected_chunk_count": len(chunks),
        "model_name": request.model_name,
        "error_message": error_message,
    }
