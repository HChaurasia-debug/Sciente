"""
Dataiku Scenario Python step: FSRE one-click E2E financial-statement run.

Use this in a Dataiku Scenario, not as a normal Flow recipe.

Scenario name recommendation:
    FSRE_E2E_FINANCIAL_STATEMENT_RUN

Purpose:
    Build the FSRE Flow datasets in the required order so runtime requests are
    created and consumed sequentially.

Before running after a cleanup:
    1. Confirm files exist in the managed folder.
    2. Confirm config is already applied, especially:
       - FIN-CMP-001 input contract version = beneish_proxy_required_fields_v2
       - Batch 4 missing-input policies are active

This script does not run cleanup SQL. Cleanup should remain a deliberate admin
step because it deletes transactional/output data.
"""

from dataiku.scenario import Scenario


scenario = Scenario()


FLOW_DATASET_SEQUENCE = [
    # Intake and run control
    "assessment_run_log",
    "document_ingestion_log",
    # Document understanding
    "03a_build_required_field_manifest_log",
    "03b_build_page_inventory_log",
    "03c_extract_financial_tables_log",
    # Field resolution and narrative extraction
    "03d_resolve_financial_fields_log",
    "03e_extract_narrative_fields_ollama_log",
    # Rule validation and execution
    "03f_validate_rule_inputs_log",
    "04_execute_rules_log",
]


def build_dataset(dataset_name: str) -> None:
    scenario.set_scenario_variables(last_fsre_dataset_started=dataset_name)
    scenario.build_dataset(
        dataset_name,
        build_mode="NON_RECURSIVE_FORCED_BUILD",
    )
    scenario.set_scenario_variables(last_fsre_dataset_completed=dataset_name)


scenario.set_scenario_variables(
    fsre_e2e_status="running",
    fsre_e2e_dataset_count=str(len(FLOW_DATASET_SEQUENCE)),
)

for dataset_name in FLOW_DATASET_SEQUENCE:
    build_dataset(dataset_name)

scenario.set_scenario_variables(
    fsre_e2e_status="completed",
    fsre_e2e_last_dataset=FLOW_DATASET_SEQUENCE[-1],
)
