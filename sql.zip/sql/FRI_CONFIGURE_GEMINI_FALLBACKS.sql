BEGIN;

INSERT INTO financial_risk_intelligence.runtime_settings
    (setting_key, setting_value, is_secret, active, updated_at)
VALUES
    ('fri_llm_provider', 'gemini', FALSE, TRUE, CURRENT_TIMESTAMP),
    ('fri_gemini_base_url', 'https://generativelanguage.googleapis.com/v1beta/openai', FALSE, TRUE, CURRENT_TIMESTAMP),
    ('fri_gemini_model', 'gemini-3.5-flash', FALSE, TRUE, CURRENT_TIMESTAMP),
    ('fri_gemini_fallback_models', 'gemini-3.5-flash-lite,gemini-2.5-flash', FALSE, TRUE, CURRENT_TIMESTAMP),
    ('fri_gemini_timeout_seconds', '180', FALSE, TRUE, CURRENT_TIMESTAMP),
    ('fri_gemini_max_output_tokens', '8192', FALSE, TRUE, CURRENT_TIMESTAMP),
    ('fri_llm_financial_resolution_enabled', 'true', FALSE, TRUE, CURRENT_TIMESTAMP)
ON CONFLICT (setting_key) DO UPDATE SET
    setting_value = EXCLUDED.setting_value,
    is_secret = EXCLUDED.is_secret,
    active = EXCLUDED.active,
    updated_at = CURRENT_TIMESTAMP;

COMMIT;

SELECT setting_key,
       CASE WHEN is_secret THEN '[SECRET PRESENT]' ELSE setting_value END AS effective_value,
       active,
       updated_at
  FROM financial_risk_intelligence.runtime_settings
 WHERE setting_key IN (
    'fri_llm_provider',
    'fri_gemini_base_url',
    'fri_gemini_model',
    'fri_gemini_fallback_models',
    'fri_gemini_timeout_seconds',
    'fri_gemini_max_output_tokens',
    'fri_llm_financial_resolution_enabled'
 )
 ORDER BY setting_key;
