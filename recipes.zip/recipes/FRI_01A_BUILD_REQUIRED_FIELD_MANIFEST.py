"""FRI_01A_BUILD_REQUIRED_FIELD_MANIFEST.

Input:
- FRI_UPLOAD_REGISTRATION_RESULTS

Output:
- FRI_REQUIRED_FIELD_MANIFEST

Required financial fields are loaded from the active database configuration.
No financial concept list, statement list, or period list is hardcoded here.
"""

from __future__ import annotations

import json
from typing import Any, Dict, List

import dataiku
import pandas as pd

from financial_risk_intelligence.database import tenant_connection


INPUT_DATASET = "FRI_UPLOAD_REGISTRATION_RESULTS"
OUTPUT_DATASET = "FRI_REQUIRED_FIELD_MANIFEST"

OUTPUT_COLUMNS = [
    "tenant_id",
    "entity_id",
    "assessment_run_id",
    "run_id",
    "source_document_id",
    "configuration_set_id",
    "configuration_key",
    "configuration_version",
    "configuration_item_id",
    "sequence_number",
    "concept_key",
    "statement_key",
    "period_key",
    "data_type",
    "is_required",
    "extraction_strategy",
    "model_key",
    "validation_definition",
    "configuration_definition",
]


def safe_string(value: Any) -> str:
    if value is None or pd.isna(value):
        return ""
    return str(value).strip()


def safe_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return safe_string(value).lower() in {"true", "1", "yes", "y"}


def required(definition: Dict[str, Any], key: str, item_key: str) -> Any:
    value = definition.get(key)
    if value in (None, ""):
        raise ValueError(
            f"Configuration item '{item_key}' is missing required property '{key}'"
        )
    return value


def validate_input_schema(input_df: pd.DataFrame) -> None:
    required_columns = {
        "tenant_id",
        "entity_id",
        "assessment_run_id",
        "source_document_id",
        "registration_status",
    }
    missing_columns = sorted(required_columns - set(input_df.columns))
    if missing_columns:
        raise ValueError(
            f"{INPUT_DATASET} is missing required columns: "
            + ", ".join(missing_columns)
        )


def select_registered_documents(input_df: pd.DataFrame) -> pd.DataFrame:
    selected = input_df[
        input_df["registration_status"]
        .fillna("")
        .astype(str)
        .str.upper()
        .eq("SUCCESS")
    ].copy()

    if "duplicate_document" in selected.columns:
        selected = selected[
            ~selected["duplicate_document"].apply(safe_bool)
        ]

    for column in (
        "tenant_id",
        "entity_id",
        "assessment_run_id",
        "source_document_id",
    ):
        selected = selected[
            selected[column].fillna("").astype(str).str.strip().ne("")
        ]

    return selected.drop_duplicates(
        subset=[
            "tenant_id",
            "assessment_run_id",
            "source_document_id",
        ],
        keep="last",
    )


def load_active_configuration(cursor, tenant_id: str) -> Dict[str, Any]:
    cursor.execute(
        """
        SELECT
            configuration_set_id,
            configuration_key,
            version,
            definition
        FROM financial_risk_intelligence.configuration_sets
        WHERE tenant_id = %s
          AND LOWER(lifecycle_state) = 'active'
          AND (effective_from IS NULL OR effective_from <= CURRENT_TIMESTAMP)
          AND (effective_to IS NULL OR effective_to > CURRENT_TIMESTAMP)
        ORDER BY effective_from DESC NULLS LAST, created_at DESC
        """,
        (tenant_id,),
    )
    configurations = cursor.fetchall()

    if not configurations:
        raise LookupError(
            f"No active configuration set exists for tenant '{tenant_id}'"
        )

    if len(configurations) > 1:
        configuration_ids = [
            str(item["configuration_set_id"])
            for item in configurations
        ]
        raise LookupError(
            "Multiple active configuration sets exist for tenant "
            f"'{tenant_id}': {configuration_ids}. Configure a binding or leave "
            "only one configuration active for the initial test."
        )

    return configurations[0]


def load_required_field_items(
    cursor,
    tenant_id: str,
    configuration_set_id: str,
    item_type: str,
) -> List[Dict[str, Any]]:
    cursor.execute(
        """
        SELECT
            configuration_item_id,
            item_key,
            display_name,
            sequence_number,
            definition
        FROM financial_risk_intelligence.configuration_items
        WHERE tenant_id = %s
          AND configuration_set_id = %s
          AND item_type = %s
          AND LOWER(lifecycle_state) = 'active'
        ORDER BY sequence_number NULLS LAST, item_key
        """,
        (tenant_id, configuration_set_id, item_type),
    )
    items = cursor.fetchall()

    if not items:
        raise LookupError(
            "No active required-field configuration items exist for "
            f"item_type='{item_type}', configuration_set_id="
            f"'{configuration_set_id}'"
        )

    return items


def period_keys_for_item(
    definition: Dict[str, Any],
    item_key: str,
) -> List[str]:
    configured_periods = definition.get("period_keys")

    if configured_periods is None:
        configured_periods = [definition.get("period_key")]
    elif not isinstance(configured_periods, list):
        raise ValueError(
            f"Configuration item '{item_key}' property 'period_keys' must be a list"
        )

    periods = [
        safe_string(period)
        for period in configured_periods
        if safe_string(period)
    ]

    if not periods:
        raise ValueError(
            f"Configuration item '{item_key}' has no period_key or period_keys"
        )

    # Preserve configured order while removing duplicates.
    return list(dict.fromkeys(periods))


def build_manifest_for_document(document: pd.Series) -> List[Dict[str, Any]]:
    tenant_id = safe_string(document["tenant_id"])
    entity_id = safe_string(document["entity_id"])
    assessment_run_id = safe_string(document["assessment_run_id"])
    source_document_id = safe_string(document["source_document_id"])

    with tenant_connection(tenant_id) as cursor:
        context = load_active_configuration(cursor, tenant_id)
        set_definition = context["definition"] or {}

        if not isinstance(set_definition, dict):
            raise ValueError(
                f"Configuration set '{context['configuration_set_id']}' "
                "definition must be a JSON object"
            )

        item_type = safe_string(
            set_definition.get("required_field_item_type")
        )
        if not item_type:
            raise ValueError(
                f"Configuration set '{context['configuration_set_id']}' does not "
                "define 'required_field_item_type'"
            )

        items = load_required_field_items(
            cursor,
            tenant_id,
            str(context["configuration_set_id"]),
            item_type,
        )

    rows: List[Dict[str, Any]] = []

    for item in items:
        definition = item["definition"] or {}
        if not isinstance(definition, dict):
            raise ValueError(
                f"Configuration item '{item['item_key']}' definition must be a JSON object"
            )

        for period_key in period_keys_for_item(
            definition,
            str(item["item_key"]),
        ):
            rows.append(
                {
                    "tenant_id": tenant_id,
                    "entity_id": entity_id,
                    "assessment_run_id": assessment_run_id,
                    # Compatibility alias for existing downstream datasets.
                    "run_id": assessment_run_id,
                    "source_document_id": source_document_id,
                    "configuration_set_id": str(
                        context["configuration_set_id"]
                    ),
                    "configuration_key": safe_string(
                        context["configuration_key"]
                    ),
                    "configuration_version": safe_string(context["version"]),
                    "configuration_item_id": str(
                        item["configuration_item_id"]
                    ),
                    "sequence_number": item["sequence_number"],
                    "concept_key": safe_string(
                        required(
                            definition,
                            "concept_key",
                            str(item["item_key"]),
                        )
                    ),
                    "statement_key": safe_string(
                        definition.get("statement_key")
                    ),
                    "period_key": period_key,
                    "data_type": safe_string(
                        required(
                            definition,
                            "data_type",
                            str(item["item_key"]),
                        )
                    ),
                    "is_required": bool(
                        definition.get("is_required", True)
                    ),
                    "extraction_strategy": safe_string(
                        definition.get("extraction_strategy")
                    ),
                    "model_key": safe_string(definition.get("model_key")),
                    "validation_definition": json.dumps(
                        definition.get("validation", {}),
                        sort_keys=True,
                    ),
                    "configuration_definition": json.dumps(
                        definition,
                        sort_keys=True,
                    ),
                }
            )

    return rows


def main() -> None:
    input_df = dataiku.Dataset(INPUT_DATASET).get_dataframe()
    validate_input_schema(input_df)
    documents_df = select_registered_documents(input_df)

    manifest_rows: List[Dict[str, Any]] = []
    for _, document in documents_df.iterrows():
        manifest_rows.extend(build_manifest_for_document(document))

    manifest_df = pd.DataFrame(manifest_rows, columns=OUTPUT_COLUMNS)

    if not manifest_df.empty:
        manifest_df = manifest_df.drop_duplicates(
            subset=[
                "tenant_id",
                "assessment_run_id",
                "source_document_id",
                "configuration_item_id",
                "period_key",
            ],
            keep="last",
        ).sort_values(
            by=[
                "tenant_id",
                "assessment_run_id",
                "sequence_number",
                "concept_key",
                "period_key",
            ],
            na_position="last",
        )

    dataiku.Dataset(OUTPUT_DATASET).write_with_schema(manifest_df)

    print(
        json.dumps(
            {
                "registration_rows_read": len(input_df),
                "documents_selected": len(documents_df),
                "manifest_row_count": len(manifest_df),
                "configuration_set_count": (
                    int(manifest_df["configuration_set_id"].nunique())
                    if not manifest_df.empty
                    else 0
                ),
            },
            indent=2,
        )
    )

    if documents_df.empty:
        raise RuntimeError(
            "No successful, non-duplicate registered documents were available "
            "to build the required-field manifest"
        )

    if manifest_df.empty:
        raise RuntimeError(
            "No required-field manifest rows were generated"
        )


main()
