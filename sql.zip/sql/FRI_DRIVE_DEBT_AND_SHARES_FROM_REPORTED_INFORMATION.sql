-- Drive long-term debt and shares outstanding from reported financial
-- information. financial_concept_configuration_v2 is an aggregated read-only
-- view, so this migration updates its underlying governed tables:
-- financial_concepts and financial_concept_aliases.
--
-- No filing-specific values are stored here.

BEGIN;

-- Direct debt values are accepted only from a non-current balance-sheet
-- section by the resolver. This is intentionally separate from lease
-- liabilities, which must not populate long_term_debt.
UPDATE financial_risk_intelligence.financial_concepts
SET statement_type = 'BALANCE_SHEET',
    scope_preference = 'GROUP_THEN_REPORTED_THEN_COMPANY',
    validation_definition = COALESCE(validation_definition, '{}'::jsonb)
        || jsonb_build_object(
            'resolver_statement_type', 'BALANCE_SHEET',
            'selection_rule', 'NON_CURRENT_OR_ZERO_IF_UNREPORTED',
            'resolver_priority', 1
        ),
    active = true,
    updated_at = now()
WHERE concept_key = 'long_term_debt';

UPDATE financial_risk_intelligence.financial_concept_aliases
SET active = false, updated_at = now()
WHERE concept_key = 'long_term_debt';

WITH alias_seed(alias_text, priority) AS (VALUES
    ('Long-term debt', 1),
    ('Non-current borrowings', 3),
    ('Non-current loans and borrowings', 5),
    ('Borrowings', 20), ('Loans and borrowings', 21)
)
UPDATE financial_risk_intelligence.financial_concept_aliases AS target
SET alias_text = seed.alias_text, priority = seed.priority, active = true,
    approval_status = 'APPROVED', approved_by = 'EVIDENCE_DRIVEN_DEBT_AND_SHARES',
    approved_at = now(), updated_at = now()
FROM alias_seed AS seed
WHERE target.concept_key = 'long_term_debt'
  AND target.normalized_alias_text = financial_risk_intelligence.normalize_financial_alias_text(seed.alias_text)
  AND COALESCE(target.sector_key, '') = 'COMMERCIAL'
  AND COALESCE(target.country_code, '') = '';

INSERT INTO financial_risk_intelligence.financial_concept_aliases
    (concept_key, alias_text, normalized_alias_text, sector_key, country_code,
     priority, active, approval_status, approved_by, approved_at)
SELECT 'long_term_debt', seed.alias_text,
       financial_risk_intelligence.normalize_financial_alias_text(seed.alias_text),
       'COMMERCIAL', NULL, seed.priority, true, 'APPROVED',
       'EVIDENCE_DRIVEN_DEBT_AND_SHARES', now()
FROM (VALUES
    ('Long-term debt', 1),
    ('Non-current borrowings', 3),
    ('Non-current loans and borrowings', 5),
    ('Borrowings', 20), ('Loans and borrowings', 21)
) AS seed(alias_text, priority)
WHERE NOT EXISTS (
    SELECT 1
    FROM financial_risk_intelligence.financial_concept_aliases AS existing
    WHERE existing.concept_key = 'long_term_debt'
      AND existing.normalized_alias_text = financial_risk_intelligence.normalize_financial_alias_text(seed.alias_text)
      AND COALESCE(existing.sector_key, '') = 'COMMERCIAL'
      AND COALESCE(existing.country_code, '') = ''
);

-- Share quantities are sourced from the capital/share note. The resolver
-- rejects monetary Share capital values and accepts only explicit quantities.
-- NOTE_TABLE_ALLOWED permits this one governed exception to the usual
-- primary-statement-table rule.
UPDATE financial_risk_intelligence.financial_concepts
SET statement_type = 'BALANCE_SHEET',
    scope_preference = 'GROUP_THEN_REPORTED_THEN_COMPANY',
    validation_definition = COALESCE(validation_definition, '{}'::jsonb)
        || jsonb_build_object(
            'resolver_statement_type', 'BALANCE_SHEET',
            'selection_rule', 'NOTE_TABLE_ALLOWED',
            'resolver_priority', 1
        ),
    active = true,
    updated_at = now()
WHERE concept_key = 'shares_outstanding';

UPDATE financial_risk_intelligence.financial_concept_aliases
SET active = false, updated_at = now()
WHERE concept_key = 'shares_outstanding';

WITH alias_seed(alias_text, priority) AS (VALUES
    ('Number of ordinary shares', 1), ('Number of issued shares', 2),
    ('Number of issued ordinary shares', 3), ('Number of shares in issue', 4),
    ('Number of ordinary shares in issue', 5), ('Issued ordinary shares at end', 6),
    ('Issued shares at end', 7), ('Ordinary shares at end of the financial year', 8),
    ('Ordinary shares at end of the financial period', 9)
)
UPDATE financial_risk_intelligence.financial_concept_aliases AS target
SET alias_text = seed.alias_text, priority = seed.priority, active = true,
    approval_status = 'APPROVED', approved_by = 'EVIDENCE_DRIVEN_DEBT_AND_SHARES',
    approved_at = now(), updated_at = now()
FROM alias_seed AS seed
WHERE target.concept_key = 'shares_outstanding'
  AND target.normalized_alias_text = financial_risk_intelligence.normalize_financial_alias_text(seed.alias_text)
  AND COALESCE(target.sector_key, '') = 'COMMERCIAL'
  AND COALESCE(target.country_code, '') = '';

INSERT INTO financial_risk_intelligence.financial_concept_aliases
    (concept_key, alias_text, normalized_alias_text, sector_key, country_code,
     priority, active, approval_status, approved_by, approved_at)
SELECT 'shares_outstanding', seed.alias_text,
       financial_risk_intelligence.normalize_financial_alias_text(seed.alias_text),
       'COMMERCIAL', NULL, seed.priority, true, 'APPROVED',
       'EVIDENCE_DRIVEN_DEBT_AND_SHARES', now()
FROM (VALUES
    ('Number of ordinary shares', 1), ('Number of issued shares', 2),
    ('Number of issued ordinary shares', 3), ('Number of shares in issue', 4),
    ('Number of ordinary shares in issue', 5), ('Issued ordinary shares at end', 6),
    ('Issued shares at end', 7), ('Ordinary shares at end of the financial year', 8),
    ('Ordinary shares at end of the financial period', 9)
) AS seed(alias_text, priority)
WHERE NOT EXISTS (
    SELECT 1
    FROM financial_risk_intelligence.financial_concept_aliases AS existing
    WHERE existing.concept_key = 'shares_outstanding'
      AND existing.normalized_alias_text = financial_risk_intelligence.normalize_financial_alias_text(seed.alias_text)
      AND COALESCE(existing.sector_key, '') = 'COMMERCIAL'
      AND COALESCE(existing.country_code, '') = ''
);

COMMIT;

-- Both rows must be active. Confirm JSON resolver controls and aliases that
-- feed the aggregated Dataiku configuration view.
SELECT c.concept_key, c.scope_preference,
       c.validation_definition ->> 'resolver_statement_type' AS resolver_statement_type,
       c.validation_definition ->> 'selection_rule' AS selection_rule,
       c.active, a.alias_text, a.priority
FROM financial_risk_intelligence.financial_concepts AS c
LEFT JOIN financial_risk_intelligence.financial_concept_aliases AS a
  ON a.concept_key = c.concept_key
 AND a.active = true
 AND a.approval_status = 'APPROVED'
WHERE c.concept_key IN ('long_term_debt', 'shares_outstanding')
ORDER BY c.concept_key, a.priority, a.alias_text;
