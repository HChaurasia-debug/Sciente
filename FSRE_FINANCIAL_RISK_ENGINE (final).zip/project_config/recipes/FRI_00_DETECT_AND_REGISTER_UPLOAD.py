"""Register uploads using the canonical financial_risk_intelligence schema.

Database mapping:
- analysed entity -> customers
- filing -> reports
- processing execution -> runs
- uploaded file -> source_documents

The Dataiku output retains entity_id, assessment_run_id and source_document_id
as compatibility aliases for customer_id, run_id and document_id.
"""
from __future__ import annotations

import hashlib
import json
import mimetypes
import os
import posixpath
import re
import traceback
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

import dataiku
import pandas as pd
import psycopg2

from financial_risk_intelligence.database import DatabaseSettings

INPUT_FOLDER_ID = "avBJ7Lwp"
REGISTERED_FOLDER_ID = "t4d04GkB"
OUTPUT_DATASET_NAME = "FRI_UPLOAD_REGISTRATION_RESULTS"
FAIL_RECIPE_WHEN_ANY_DOCUMENT_FAILS = False
SUPPORTED_EXTENSIONS = {".pdf", ".xlsx", ".xls", ".csv", ".xml", ".xbrl", ".html", ".htm"}
OUTPUT_COLUMNS = [
    "source_path", "registered_path", "file_name", "file_extension",
    "file_size_bytes", "document_checksum", "tenant_key", "tenant_id",
    "entity_key", "entity_id", "assessment_run_id", "source_document_id",
    "processing_status", "registration_status", "duplicate_document",
    "message", "registered_at",
]


def now():
    return datetime.now(timezone.utc)


def connect_database():
    value = DatabaseSettings.from_runtime()
    return psycopg2.connect(
        host=value.host, port=value.port, dbname=value.database,
        user=value.user, password=value.password,
        application_name=value.application_name, connect_timeout=30,
    )


def row_value(row, key, index):
    return row[key] if isinstance(row, dict) else row[index]


def derive_identity(path: str) -> Tuple[str, Optional[int]]:
    file_name = posixpath.basename(path)
    stem = os.path.splitext(file_name)[0]
    years = re.findall(r"\b(?:19|20)\d{2}\b", stem)
    year = int(years[-1]) if years else None
    value = re.sub(
        r"\b(annual\s+report|integrated\s+report|financial\s+statements?|"
        r"financial\s+report|yearly\s+report)\b", " ", stem,
        flags=re.IGNORECASE,
    )
    value = re.sub(r"\b(?:19|20)\d{2}\b", " ", value)
    key = re.sub(r"[^A-Za-z0-9]+", "_", value).strip("_").upper()
    if not key:
        raise ValueError(f"Could not derive analysed entity from '{file_name}'")
    return key, year


def sha256(folder, path):
    digest, size = hashlib.sha256(), 0
    with folder.get_download_stream(path) as stream:
        while True:
            block = stream.read(1024 * 1024)
            if not block:
                break
            digest.update(block)
            size += len(block)
    return digest.hexdigest(), size


def copy_file(source_folder, source_path, target_folder, target_path):
    with source_folder.get_download_stream(source_path) as source:
        with target_folder.get_writer(target_path) as target:
            while True:
                block = source.read(1024 * 1024)
                if not block:
                    break
                target.write(block)


def sole_tenant(cursor):
    cursor.execute(
        """SELECT tenant_id,tenant_key FROM financial_risk_intelligence.tenants
           WHERE LOWER(lifecycle_state)='active' ORDER BY created_at"""
    )
    rows = cursor.fetchall()
    if len(rows) != 1:
        raise LookupError(
            f"Single-tenant upload mode requires exactly one active tenant; found {len(rows)}"
        )
    return str(row_value(rows[0], "tenant_id", 0)), str(row_value(rows[0], "tenant_key", 1))


def active_configuration(cursor, tenant_id):
    cursor.execute(
        """SELECT configuration_set_id,definition
           FROM financial_risk_intelligence.configuration_sets
           WHERE tenant_id=%s AND LOWER(lifecycle_state)='active'
             AND (effective_from IS NULL OR effective_from<=CURRENT_TIMESTAMP)
             AND (effective_to IS NULL OR effective_to>CURRENT_TIMESTAMP)
           ORDER BY effective_from DESC NULLS LAST,created_at DESC""",
        (tenant_id,),
    )
    rows = cursor.fetchall()
    if len(rows) != 1:
        raise LookupError(
            f"Exactly one effective active configuration is required; found {len(rows)}"
        )
    definition = row_value(rows[0], "definition", 1) or {}
    required = [
        "engine_release", "run_initial_state", "default_report_type",
        "default_reporting_context",
    ]
    missing = [key for key in required if not str(definition.get(key, "")).strip()]
    if missing:
        raise ValueError("Active configuration is missing: " + ", ".join(missing))
    return str(row_value(rows[0], "configuration_set_id", 0)), definition


def resolve_customer(cursor, tenant_id, entity_key):
    cursor.execute(
        """SELECT customer_id FROM financial_risk_intelligence.customers
           WHERE tenant_id=%s AND customer_key=%s""",
        (tenant_id, entity_key),
    )
    row = cursor.fetchone()
    if row:
        return str(row_value(row, "customer_id", 0))
    customer_id = str(uuid.uuid4())
    cursor.execute(
        """INSERT INTO financial_risk_intelligence.customers
           (tenant_id,customer_id,customer_key,legal_name,lifecycle_state,attributes)
           VALUES (%s,%s,%s,%s,'active',%s::jsonb)""",
        (tenant_id, customer_id, entity_key, entity_key.replace("_", " ").title(),
         json.dumps({"identity_status": "provisional", "identity_source": "filename"})),
    )
    return customer_id


def register(cursor, tenant_id, tenant_key, entity_key, year, source_path,
             file_name, extension, checksum, size):
    cursor.execute(
        """SELECT d.document_id,d.report_id,r.customer_id,
                  (SELECT x.run_id FROM financial_risk_intelligence.runs x
                   WHERE x.tenant_id=d.tenant_id AND x.report_id=d.report_id
                   ORDER BY x.created_at DESC LIMIT 1) AS run_id,d.storage_uri
           FROM financial_risk_intelligence.source_documents d
           JOIN financial_risk_intelligence.reports r
             ON r.tenant_id=d.tenant_id AND r.report_id=d.report_id
           WHERE d.tenant_id=%s AND d.content_hash=%s LIMIT 1""",
        (tenant_id, checksum),
    )
    old = cursor.fetchone()
    if old:
        return {
            "customer_id": str(row_value(old, "customer_id", 2)),
            "run_id": str(row_value(old, "run_id", 3)),
            "document_id": str(row_value(old, "document_id", 0)),
            "registered_path": str(row_value(old, "storage_uri", 4)).split("/", 3)[-1]
            if str(row_value(old, "storage_uri", 4)).startswith("dataiku-managed-folder://")
            else str(row_value(old, "storage_uri", 4)),
            "duplicate": True,
        }

    configuration_id, config = active_configuration(cursor, tenant_id)
    customer_id = resolve_customer(cursor, tenant_id, entity_key)
    report_id, run_id, document_id = str(uuid.uuid4()), str(uuid.uuid4()), str(uuid.uuid4())
    report_key = f"{entity_key}:{year or 'UNSPECIFIED'}:{checksum[:16]}"
    period_end = f"{year}-12-31" if year else None
    cursor.execute(
        """INSERT INTO financial_risk_intelligence.reports
           (tenant_id,report_id,customer_id,report_key,report_type,reporting_context,
            period_end,lifecycle_state,attributes)
           VALUES (%s,%s,%s,%s,%s,%s,%s,'active',%s::jsonb)""",
        (tenant_id, report_id, customer_id, report_key,
         config["default_report_type"], config["default_reporting_context"], period_end,
         json.dumps({"identity_source": "filename"})),
    )
    cursor.execute(
        """INSERT INTO financial_risk_intelligence.runs
           (tenant_id,run_id,customer_id,report_id,configuration_set_id,idempotency_key,
            lifecycle_state,current_stage,engine_release,request_payload)
           VALUES (%s,%s,%s,%s,%s,%s,%s,'document_registration',%s,%s::jsonb)""",
        (tenant_id, run_id, customer_id, report_id, configuration_id,
         f"upload:{checksum}", config["run_initial_state"], config["engine_release"],
         json.dumps({"source_path": source_path, "file_name": file_name})),
    )
    registered_path = f"/{tenant_key}/{entity_key}/{run_id}/{file_name}"
    storage_uri = f"dataiku-managed-folder://{REGISTERED_FOLDER_ID}{registered_path}"
    cursor.execute(
        """INSERT INTO financial_risk_intelligence.source_documents
           (tenant_id,document_id,report_id,document_type,file_name,media_type,
            storage_uri,content_hash,byte_size,ingestion_metadata)
           VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s::jsonb)""",
        (tenant_id, document_id, report_id, config["default_report_type"], file_name,
         mimetypes.guess_type(file_name)[0] or "application/octet-stream",
         storage_uri, checksum, size, json.dumps({"source_path": source_path})),
    )
    return {"customer_id": customer_id, "run_id": run_id,
            "document_id": document_id, "registered_path": registered_path,
            "duplicate": False}


def process(input_folder, output_folder, path):
    timestamp, stage = now(), "IDENTIFY_DOCUMENT"
    entity_key = tenant_key = tenant_id = None
    file_name, extension = posixpath.basename(path), os.path.splitext(path)[1].lower()
    checksum = size = None
    try:
        if extension not in SUPPORTED_EXTENSIONS:
            raise ValueError(f"Unsupported extension '{extension}'")
        entity_key, year = derive_identity(path)
        stage = "CALCULATE_CHECKSUM"
        checksum, size = sha256(input_folder, path)
        stage = "DATABASE_REGISTRATION"
        connection = connect_database()
        try:
            connection.autocommit = False
            with connection.cursor() as cursor:
                tenant_id, tenant_key = sole_tenant(cursor)
                cursor.execute("SELECT set_config('fsre.tenant_id',%s,true)", (tenant_id,))
                result = register(cursor, tenant_id, tenant_key, entity_key, year, path,
                                  file_name, extension, checksum, size)
                if not result["duplicate"]:
                    stage = "COPY_REGISTERED_FILE"
                    copy_file(input_folder, path, output_folder, result["registered_path"])
                connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()
        return {
            "source_path": path, "registered_path": result["registered_path"],
            "file_name": file_name, "file_extension": extension,
            "file_size_bytes": size, "document_checksum": checksum,
            "tenant_key": tenant_key, "tenant_id": tenant_id,
            "entity_key": entity_key, "entity_id": result["customer_id"],
            "assessment_run_id": result["run_id"],
            "source_document_id": result["document_id"],
            "processing_status": "ALREADY_REGISTERED" if result["duplicate"] else "QUEUED",
            "registration_status": "SUCCESS", "duplicate_document": result["duplicate"],
            "message": "Document already registered" if result["duplicate"] else "Registered",
            "registered_at": timestamp,
        }
    except Exception as exc:
        print(traceback.format_exc())
        return {
            "source_path": path, "registered_path": None, "file_name": file_name,
            "file_extension": extension, "file_size_bytes": size,
            "document_checksum": checksum, "tenant_key": tenant_key,
            "tenant_id": tenant_id, "entity_key": entity_key, "entity_id": None,
            "assessment_run_id": None, "source_document_id": None,
            "processing_status": "FAILED", "registration_status": "FAILED",
            "duplicate_document": False,
            "message": f"Stage={stage}; {type(exc).__name__}: {exc}",
            "registered_at": timestamp,
        }


def main():
    input_folder, output_folder = dataiku.Folder(INPUT_FOLDER_ID), dataiku.Folder(REGISTERED_FOLDER_ID)
    paths = [p for p in sorted(input_folder.list_paths_in_partition())
             if not p.endswith("/") and os.path.splitext(p)[1].lower() in SUPPORTED_EXTENSIONS]
    frame = pd.DataFrame([process(input_folder, output_folder, p) for p in paths], columns=OUTPUT_COLUMNS)
    dataiku.Dataset(OUTPUT_DATASET_NAME).write_with_schema(frame)
    failures = frame[frame["registration_status"] == "FAILED"] if not frame.empty else frame
    print(json.dumps({"files": len(frame), "failures": len(failures)}, indent=2))
    if not failures.empty and FAIL_RECIPE_WHEN_ANY_DOCUMENT_FAILS:
        raise RuntimeError(f"{len(failures)} registrations failed")


main()
