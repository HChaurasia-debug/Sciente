﻿"""FRI_04A_STANDARDIZE_FINANCIAL_STATEMENTS

Inputs
------
FRI_VALIDATED_TABLE_ARTIFACTS
FRI_VALIDATED_TABLE_CELLS

Outputs
-------
FRI_STANDARDIZED_STATEMENT_VALUES
FRI_STATEMENT_NORMALIZATION_EXCEPTIONS

The recipe preserves every extracted numeric table cell as one auditable value.
Python owns layout reconstruction, period/scope alignment and numeric integrity.
Ambiguous classifications are recorded as review exceptions for a separate
comparison/derivation workflow. This recipe never calls a language model and
never creates or changes a financial amount.
"""

from __future__ import annotations

import collections
import datetime as dt
import hashlib
import json
import math
import os
import re
from typing import Any, Dict, Iterable, List, Optional, Tuple

import dataiku
import pandas as pd


INPUT_TABLES = "FRI_VALIDATED_TABLE_ARTIFACTS"
INPUT_CELLS = "FRI_VALIDATED_TABLE_CELLS"
OUTPUT_VALUES = "FRI_STANDARDIZED_STATEMENT_VALUES"
OUTPUT_EXCEPTIONS = "FRI_STATEMENT_NORMALIZATION_EXCEPTIONS"
STATEMENT_ALIAS_DATASET = os.getenv(
    "FRI_STATEMENT_ALIAS_DATASET",
    "FRI_APPROVED_FINANCIAL_STATEMENT_ALIASES",
)

VERSION = "fri-statement-standardizer-share-notes-1.6.0"
MINIMUM_PYTHON_CONFIDENCE = 0.78
PRIMARY_STATEMENTS = {
    "BALANCE_SHEET",
    "INCOME_STATEMENT",
    "CASH_FLOW_STATEMENT",
}
TARGET_STATEMENTS = PRIMARY_STATEMENTS
ACCEPTED_STATUSES = {
    "VALIDATED",
    "VALIDATED_WITH_WARNINGS",
    "MANUAL_REVIEW",
    "RETRY_REQUIRED",
}

VALUE_COLUMNS = [
    "statement_value_id", "tenant_id", "entity_id", "assessment_run_id",
    "source_document_id", "table_artifact_id", "source_table_id",
    "statement_type", "statement_title", "statement_section", "row_index",
    "row_order", "row_label", "note_reference", "entity_scope",
    "period_label", "period_end", "column_index", "raw_value",
    "numeric_value", "currency", "unit", "is_total", "page_number",
    "extraction_confidence", "structure_score", "classification_method",
    "model_name", "normalization_status", "normalizer_version",
    "normalized_at",
]
EXCEPTION_COLUMNS = [
    "tenant_id", "entity_id", "assessment_run_id", "source_document_id",
    "table_artifact_id", "page_number", "exception_code", "severity",
    "message", "recommended_action", "normalizer_version", "created_at",
]


def missing(value: Any) -> bool:
    if value is None:
        return True
    try:
        result = pd.isna(value)
        if isinstance(result, bool) and result:
            return True
    except (TypeError, ValueError):
        pass
    return str(value).strip().lower() in {"", "nan", "none", "null", "nat"}


def text(value: Any) -> str:
    return "" if missing(value) else str(value).strip()


def number(value: Any) -> Optional[float]:
    if missing(value):
        return None
    try:
        result = float(value)
        return None if math.isnan(result) else result
    except (TypeError, ValueError):
        return None


def integer(value: Any, default: int = -1) -> int:
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return default


def read_dataset(name: str) -> pd.DataFrame:
    try:
        return dataiku.Dataset(name).get_dataframe(infer_with_pandas=False)
    except TypeError:
        return dataiku.Dataset(name).get_dataframe()


_STATEMENT_ALIASES: Optional[List[Tuple[str, str, int]]] = None


def normalized_phrase(value: Any) -> str:
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9]+", " ", text(value).lower())).strip()


def configured_statement_aliases() -> List[Tuple[str, str, int]]:
    global _STATEMENT_ALIASES
    if _STATEMENT_ALIASES is not None:
        return _STATEMENT_ALIASES
    aliases: List[Tuple[str, str, int]] = []
    try:
        frame = read_dataset(STATEMENT_ALIAS_DATASET)
        for row in frame.to_dict(orient="records"):
            statement_type = text(row.get("statement_type")).upper()
            alias = normalized_phrase(row.get("alias_text") or row.get("normalized_alias_text"))
            if statement_type in PRIMARY_STATEMENTS and alias:
                aliases.append((statement_type, alias, integer(row.get("priority"), 100)))
        print(
            f"Loaded {len(aliases)} approved statement-title aliases from "
            f"{STATEMENT_ALIAS_DATASET}",
            flush=True,
        )
    except Exception as error:
        print(
            f"Statement-title alias dataset unavailable; using built-ins: {error}",
            flush=True,
        )
    _STATEMENT_ALIASES = sorted(aliases, key=lambda item: (-len(item[1]), item[2]))
    return _STATEMENT_ALIASES


def statement_type_from_title(value: Any) -> str:
    candidate = normalized_phrase(value)
    matches = [
        item for item in configured_statement_aliases()
        if item[1] == candidate or item[1] in candidate
    ]
    return matches[0][0] if matches else ""


def table_id(row: Dict[str, Any]) -> str:
    return text(row.get("table_artifact_id") or row.get("source_table_id"))


def canonical_statement(value: Any) -> str:
    configured = statement_type_from_title(value)
    if configured:
        return configured
    normalized = re.sub(r"[^a-z0-9]+", "_", text(value).lower()).strip("_")
    aliases = {
        "balance_sheet": "BALANCE_SHEET",
        "balance_sheets": "BALANCE_SHEET",
        "statement_of_financial_position": "BALANCE_SHEET",
        "statements_of_financial_position": "BALANCE_SHEET",
        "statement_of_financial_condition": "BALANCE_SHEET",
        "statements_of_financial_condition": "BALANCE_SHEET",
        "income_statement": "INCOME_STATEMENT",
        "income_statements": "INCOME_STATEMENT",
        "profit_and_loss": "INCOME_STATEMENT",
        "statement_of_income": "INCOME_STATEMENT",
        "statement_of_comprehensive_income": "INCOME_STATEMENT",
        "statements_of_comprehensive_income": "INCOME_STATEMENT",
        "statement_of_profit_or_loss": "INCOME_STATEMENT",
        "statements_of_profit_or_loss": "INCOME_STATEMENT",
        "statement_of_operations": "INCOME_STATEMENT",
        "statements_of_operations": "INCOME_STATEMENT",
        "cash_flow": "CASH_FLOW_STATEMENT",
        "cash_flow_statement": "CASH_FLOW_STATEMENT",
        "cash_flow_statements": "CASH_FLOW_STATEMENT",
        "statement_of_cash_flows": "CASH_FLOW_STATEMENT",
        "statements_of_cash_flows": "CASH_FLOW_STATEMENT",
    }
    return aliases.get(normalized, normalized.upper() or "UNCLASSIFIED")


def python_statement_classification(title: str, cells: Iterable[Dict[str, Any]]) -> Tuple[str, float]:
    configured = statement_type_from_title(title)
    if configured:
        return configured, 0.99
    sample = " ".join(
        [title] + [text(row.get("row_label")) for row in list(cells)[:80]]
    ).lower()
    scores = {
        "BALANCE_SHEET": sum(bool(re.search(pattern, sample)) for pattern in [
            r"balance\s+sheets?", r"financial\s+(?:position|condition)", r"total\s+assets",
            r"total\s+liabilities", r"shareholders?.?\s+funds",
        ]),
        "INCOME_STATEMENT": sum(bool(re.search(pattern, sample)) for pattern in [
            r"income\s+statements?", r"profit\s+(?:and\s+loss|or\s+loss)", r"profit\s+before\s+tax",
            r"net\s+interest\s+income", r"earnings\s+per\s+share",
        ]),
        "CASH_FLOW_STATEMENT": sum(bool(re.search(pattern, sample)) for pattern in [
            r"cash\s+flow", r"operating\s+activities", r"investing\s+activities",
            r"financing\s+activities", r"cash\s+and\s+cash\s+equivalents\s+at",
        ]),
    }
    ranked = sorted(scores.items(), key=lambda item: item[1], reverse=True)
    if not ranked or ranked[0][1] == 0:
        return "UNCLASSIFIED", 0.0
    confidence = min(0.98, 0.50 + ranked[0][1] * 0.12)
    if len(ranked) > 1 and ranked[0][1] == ranked[1][1]:
        confidence = min(confidence, 0.55)
    return ranked[0][0], confidence


def infer_period(cell: Dict[str, Any], header: str) -> str:
    configured = text(cell.get("period_label"))
    if configured:
        years = re.findall(r"\b(?:19|20)\d{2}\b", configured)
        return years[-1] if years else configured
    years = re.findall(r"\b(?:19|20)\d{2}\b", header)
    return years[-1] if years else ""


def table_period_map(cells: List[Dict[str, Any]]) -> Dict[int, str]:
    """Infer omitted comparative headers without assuming a company layout.

    PDF extractors frequently attach 2026/2025 only to the first Group
    columns, leaving later Company columns blank. A repeated two-period
    header pattern is inferred only when two adjacent period columns are
    explicitly present; otherwise no period is invented.
    """
    explicit: Dict[int, str] = {}
    for cell in cells:
        column = integer(cell.get("column_index"), -1)
        if column < 0:
            continue
        # Some PDF extractors place the period header in raw_text instead of
        # header_path. Only nonnumeric cells are eligible as headers so a
        # reported value such as 2026 cannot be mistaken for a year label.
        header_text = text(cell.get("header_path"))
        raw_text = text(cell.get("raw_text"))
        if not number(raw_text):
            header_text = f"{header_text} {raw_text}".strip()
        value = infer_period(cell, header_text)
        if value:
            explicit.setdefault(column, value)
    if len(explicit) < 2:
        return explicit
    ordered = sorted(explicit)
    pair = None
    for left, right in zip(ordered, ordered[1:]):
        if right == left + 1 and explicit[left] != explicit[right]:
            pair = (left, right)
            break
    if pair is None:
        return explicit
    result = dict(explicit)
    left, right = pair
    for column in range(left + 1, max(integer(c.get("column_index"), -1) for c in cells) + 1):
        result.setdefault(column, explicit[left if (column - left) % 2 == 0 else right])
    return result


def infer_scope(cell: Dict[str, Any], header: str) -> str:
    configured = text(cell.get("entity_scope") or cell.get("column_scope")).upper()
    if configured not in {"", "UNKNOWN", "UNSPECIFIED", "NONE"}:
        return configured
    lowered = header.lower()
    if "company" in lowered or "standalone" in lowered or "parent" in lowered:
        return "COMPANY"
    if "group" in lowered or "consolidated" in lowered:
        return "GROUP"
    return "REPORTED"


def has_primary_layout_signature(statement_type: str, title: str, cells: List[Dict[str, Any]]) -> bool:
    """Require audited statement anchors before repairing a missing header.

    This deliberately rejects generic note tables with four numeric columns;
    header recovery is a last-resort repair for a recognisable primary
    statement, never a replacement for valid extractor metadata.
    """
    sample = " ".join([title] + [
        text(cell.get("row_label") or cell.get("raw_text")) for cell in cells
    ]).lower()
    if statement_type == "BALANCE_SHEET":
        anchors = sum(phrase in sample for phrase in (
            "total assets", "total liabilities", "total equity", "net assets",
        ))
        return anchors >= 3
    if statement_type == "INCOME_STATEMENT":
        anchors = sum(phrase in sample for phrase in (
            "revenue", "cost of sales", "cost of goods sold", "profit before tax",
            "loss before tax", "profit for the year", "loss for the year",
        ))
        return anchors >= 2
    if statement_type == "CASH_FLOW_STATEMENT":
        anchors = sum(phrase in sample for phrase in (
            "cash flows from operating", "cash flows from investing",
            "cash flows from financing", "net cash", "cash and cash equivalents",
        ))
        return anchors >= 2
    return False


def recover_headerless_group_layout(statement_type: str, period_map: Dict[int, str], value_columns: set[int], title: str, cells: List[Dict[str, Any]]) -> Tuple[Dict[int, str], set[int], str]:
    """Recover Group current/prior columns only for a verified primary statement."""
    if (
        statement_type not in PRIMARY_STATEMENTS
        or period_map
        or len(value_columns) < 4
        or not has_primary_layout_signature(statement_type, title, cells)
    ):
        return period_map, set(), ""
    columns = sorted(value_columns)
    # Standard layout: Note | Group current | Group prior | Company current | Company prior.
    group_pair = columns[1:3] if len(columns) >= 5 else columns[:2]
    if len(group_pair) != 2:
        return period_map, set(), ""
    recovered = dict(period_map)
    recovered[group_pair[0]], recovered[group_pair[1]] = "CURRENT", "PRIOR"
    return recovered, set(group_pair), "HEADERLESS_GROUP_COMPANY_PAIR"


def is_total_label(label: str) -> bool:
    normalized = re.sub(r"\s+", " ", label.lower()).strip()
    return bool(re.search(
        r"(^total\b|\btotal$|^net (?:assets|profit|cash)|shareholders?.? funds|"
        r"profit (?:before|after) tax|cash and cash equivalents at (?:beginning|end))",
        normalized,
    ))


def is_primary_balance_sheet(title: str, cells: List[Dict[str, Any]]) -> bool:
    labels = " | ".join(text(cell.get("row_label")) for cell in cells).lower()
    title_text = title.lower()
    title_signal = bool(re.search(
        r"\bbalance\s+sheets?\b|\bstatements?\s+of\s+financial\s+(?:position|condition)\b",
        title_text,
    ))
    anchors = sum(bool(re.search(pattern, labels)) for pattern in [
        r"\btotal\s+assets\b",
        r"\btotal\s+liabilities\b",
        r"\btotal\s+equity\b|\bshareholders['â€™]?\s+funds\b|\bnet\s+assets\b",
    ])
    return anchors == 3 or (title_signal and anchors >= 2)


def is_supporting_balance_sheet_note(title: str, cells: List[Dict[str, Any]]) -> bool:
    """Admit structurally confirmed share-capital notes, not generic notes."""
    labels = " ".join(text(cell.get("row_label") or cell.get("raw_text")) for cell in cells)
    sample = re.sub(r"\s+", " ", f"{title} {labels}".lower())
    share_heading = bool(re.search(r"\bshare capital\b|\btreasury shares?\b|\bshare capital and treasury shares\b", sample))
    movement = bool(re.search(r"\bat (?:beginning|end)\b|\bissuance of (?:new )?shares?\b", sample))
    years = set(re.findall(r"\b(?:19|20)\d{2}\b", sample))
    return share_heading and movement and len(years) >= 2


def is_share_count_note(title: str, cells: List[Dict[str, Any]]) -> bool:
    """Recognize share-count notes even when PDF row labels are fragmented."""
    sample = " ".join(text(cell.get("row_label") or cell.get("raw_text")) for cell in cells).lower()
    title_sample = title.lower()
    return bool(
        re.search(r"share capital and treasury shares|share capital|treasury shares?", title_sample)
        and re.search(r"ordinary shares|issued shares|treasury shares|number of shares", sample)
        and len(set(re.findall(r"\b(?:19|20)\d{2}\b", title_sample + " " + sample))) >= 2
    )

def statement_section(label: str, current: str) -> str:
    normalized = re.sub(r"[^a-z ]+", " ", label.lower()).strip()
    section_names = {
        "assets": "ASSETS", "liabilities": "LIABILITIES", "equity": "EQUITY",
        "non current assets": "NON_CURRENT_ASSETS",
        "non current asset": "NON_CURRENT_ASSETS",
        "current assets": "CURRENT_ASSETS",
        "non current liabilities": "NON_CURRENT_LIABILITIES",
        "non current liability": "NON_CURRENT_LIABILITIES",
        "current liabilities": "CURRENT_LIABILITIES",
        "current liability": "CURRENT_LIABILITIES",
        "operating activities": "OPERATING_ACTIVITIES",
        "investing activities": "INVESTING_ACTIVITIES",
        "financing activities": "FINANCING_ACTIVITIES",
        "other comprehensive income": "OTHER_COMPREHENSIVE_INCOME",
    }
    return section_names.get(normalized, current)


def structural_balance_subtotal_labels(cells: List[Dict[str, Any]]) -> Dict[int, Dict[str, str]]:
    """Name unlabeled section-ending totals on a primary balance sheet."""
    rows: Dict[int, List[Dict[str, Any]]] = collections.defaultdict(list)
    for cell in cells:
        rows[integer(cell.get("row_index"), -1)].append(cell)
    section_labels = {
        "current assets": "Total current assets",
        "non current assets": "Total non-current assets",
        "current liabilities": "Total current liabilities",
        "non current liabilities": "Total non-current liabilities",
    }
    active = ""
    data_rows = 0
    recovered: Dict[int, Dict[str, str]] = {}
    split_rows: List[int] = []
    for row_index in sorted(rows):
        siblings = sorted(rows[row_index], key=lambda cell: integer(cell.get("column_index"), 999))
        label = next((
            text(cell.get("row_label")) for cell in siblings
            if text(cell.get("row_label")) and number(cell.get("row_label")) is None
        ), "")
        if not label:
            label = next((
                text(cell.get("raw_text")) for cell in siblings
                if number(cell.get("numeric_value")) is None and text(cell.get("raw_text"))
            ), "")
        normalized = re.sub(r"[^a-z ]+", " ", label.lower())
        normalized = re.sub(r"\s+", " ", normalized).strip()
        numeric_count = sum(number(cell.get("numeric_value")) is not None for cell in siblings)
        if normalized in section_labels and numeric_count == 0:
            active, data_rows, split_rows = normalized, 0, []
            continue
        if active and label and numeric_count:
            data_rows += 1
            split_rows = []
            continue
        if active and not label and numeric_count >= 2 and data_rows:
            recovered[row_index] = {"label": section_labels[active], "period_role": ""}
            active, data_rows, split_rows = "", 0, []
            continue
        if active and not label and numeric_count == 1 and data_rows:
            split_rows.append(row_index)
            if len(split_rows) == 2:
                recovered[split_rows[0]] = {"label": section_labels[active], "period_role": "CURRENT"}
                recovered[split_rows[1]] = {"label": section_labels[active], "period_role": "PRIOR"}
                active, data_rows, split_rows = "", 0, []
    return recovered


tables_df = read_dataset(INPUT_TABLES)
cells_df = read_dataset(INPUT_CELLS)
if cells_df.empty:
    raise RuntimeError(
        "FRI_VALIDATED_TABLE_CELLS is empty. Run FRI_03B_EXTRACT_TABLE_LAYOUTS "
        "and FRI_03C_VALIDATE_TABLE_STRUCTURE first."
    )

artifacts = {table_id(row): row for row in tables_df.to_dict(orient="records") if table_id(row)}
cells_by_table: Dict[str, List[Dict[str, Any]]] = collections.defaultdict(list)
for cell in cells_df.to_dict(orient="records"):
    if text(cell.get("validation_status")).upper() not in ACCEPTED_STATUSES:
        continue
    key = table_id(cell)
    if key:
        cells_by_table[key].append(cell)

now = dt.datetime.now(dt.timezone.utc).isoformat()
value_rows: List[Dict[str, Any]] = []
exception_rows: List[Dict[str, Any]] = []

for key, table_cells in cells_by_table.items():
    artifact = artifacts.get(key, {})
    title = text(artifact.get("table_title"))
    supplied = canonical_statement(artifact.get("statement_type"))
    python_type, python_confidence = python_statement_classification(title, table_cells)
    labels_text = " ".join(
        text(cell.get("row_label")) for cell in table_cells
    ).lower()
    cashflow_statement_signal = bool(re.search(
        r"\bcash flows? from (?:operating|investing|financing) activities\b|"
        r"\bnet cash (?:generated|provided|used|flows?)\b|"
        r"\bcash and cash equivalents at (?:the )?(?:beginning|end)\b",
        (title + " " + labels_text).lower(),
    ))
    income_override_signal = bool(
        re.search(
            r"income\s+statement|statement\s+of\s+comprehensive\s+income|"
            r"net\s+interest\s+income|profit\s+before\s+tax|"
            r"earnings\s+per\s+share",
            (title + " " + labels_text).lower(),
        )
    )
    statement_type = supplied if supplied in PRIMARY_STATEMENTS else python_type
    classification_method = "SOURCE_METADATA" if supplied in PRIMARY_STATEMENTS else "PYTHON"
    supporting_balance_note = is_supporting_balance_sheet_note(title, table_cells)
    share_count_note = is_share_count_note(title, table_cells)
    primary_balance_structure = is_primary_balance_sheet(title, table_cells)
    if share_count_note:
        supporting_balance_note = True
    # A complete Total assets / Total liabilities / Total equity structure is
    # authoritative balance-sheet evidence. Page-level metadata can inherit
    # INCOME_STATEMENT from the preceding page; do not let that stale label
    # suppress the balance-sheet section and subtotal recovery below.
    if primary_balance_structure and statement_type != "BALANCE_SHEET":
        statement_type = "BALANCE_SHEET"
        python_type = "BALANCE_SHEET"
        python_confidence = max(python_confidence, 0.98)
        classification_method = "PYTHON_PRIMARY_BALANCE_STRUCTURE_OVERRIDE"
    if statement_type not in PRIMARY_STATEMENTS and supporting_balance_note:
        statement_type = "BALANCE_SHEET"
        classification_method = "PYTHON_SUPPORTING_BALANCE_SHEET_NOTE"
    # A cash-flow statement is often split across pages/regions. Promote a
    # validated operating-activities fragment even when its title is absent or
    # page metadata says UNCLASSIFIED/BALANCE_SHEET. This is table-structural,
    # not company-specific, and is required to preserve D&A add-backs.
    if cashflow_statement_signal and (
        statement_type not in PRIMARY_STATEMENTS
        or supplied in {"", "UNCLASSIFIED", "NOTES_TABLE", "BALANCE_SHEET"}
    ):
        statement_type = "CASH_FLOW_STATEMENT"
        classification_method = "PYTHON_CASH_FLOW_FRAGMENT"
    # Source metadata can be stale or can label every page of an annual report
    # as BALANCE_SHEET. Override it only when the table itself has strong,
    # unambiguous income-statement evidence.
    if (
        supplied == "BALANCE_SHEET"
        and python_type == "INCOME_STATEMENT"
        and python_confidence >= 0.74
        and income_override_signal
    ):
        statement_type = "INCOME_STATEMENT"
        classification_method = "PYTHON_OVERRIDE_SOURCE_METADATA"
    model_name = ""

    first = table_cells[0]
    context = {
        "tenant_id": text(first.get("tenant_id") or artifact.get("tenant_id")),
        "entity_id": text(first.get("entity_id") or artifact.get("entity_id")),
        "assessment_run_id": text(first.get("assessment_run_id") or first.get("run_id") or artifact.get("assessment_run_id")),
        "source_document_id": text(first.get("source_document_id") or artifact.get("source_document_id")),
        "table_artifact_id": text(first.get("table_artifact_id") or artifact.get("table_artifact_id") or key),
        "source_table_id": text(first.get("source_table_id") or artifact.get("source_table_id") or key),
        "page_number": integer(first.get("page_number") or artifact.get("page_number"), 0),
    }

    if python_confidence < MINIMUM_PYTHON_CONFIDENCE:
        exception_rows.append({
            **context,
            "exception_code": "PYTHON_LOW_CONFIDENCE_CLASSIFICATION",
            "severity": "WARNING",
            "message": (
                f"Python classified the table as {statement_type} with confidence "
                f"{python_confidence:.2f}; model comparison was intentionally deferred."
            ),
            "recommended_action": (
                "Review this table in the comparison/derivation screen against the source PDF "
                "before approving derived financial values."
            ),
            "normalizer_version": VERSION,
            "created_at": now,
        })

    if statement_type not in TARGET_STATEMENTS:
        exception_rows.append({
            **context,
            "exception_code": "NON_BALANCE_SHEET_TABLE_SKIPPED",
            "severity": "INFO",
            "message": "Table is not the target balance sheet and was intentionally excluded from the standardized value output.",
            "recommended_action": "No action is required unless this table is expected to be the balance sheet.",
            "normalizer_version": VERSION,
            "created_at": now,
        })
        continue

    if statement_type == "BALANCE_SHEET" and not (
        is_primary_balance_sheet(title, table_cells) or supporting_balance_note
    ):
        exception_rows.append({
            **context,
            "exception_code": "BALANCE_SHEET_STRUCTURE_NOT_CONFIRMED",
            "severity": "WARNING",
            "message": "The table was classified as a balance sheet but does not contain sufficient primary-statement totals.",
            "recommended_action": "Review table title and Total assets, Total liabilities and Total equity rows.",
            "normalizer_version": VERSION,
            "created_at": now,
        })
        continue
    table_cells.sort(key=lambda row: (
        integer(row.get("row_index"), 10**9),
        integer(row.get("column_index"), 10**9),
    ))
    structural_subtotals = (
        structural_balance_subtotal_labels(table_cells)
        if statement_type == "BALANCE_SHEET" else {}
    )
    current_section = ""
    period_map = table_period_map(table_cells)
    share_note_section = (
        "TREASURY" if supporting_balance_note and "treasury share" in title.lower()
        and "share capital" not in title.lower() else
        "ISSUED" if supporting_balance_note else ""
    )
    row_labels: Dict[int, str] = {}
    # Consolidated statements often expose COMPANY in the first columns and
    # leave the GROUP header implicit on the remaining period columns. Infer
    # those group columns from the explicit company columns and period map.
    company_columns = {
        integer(cell.get("column_index")) for cell in table_cells
        if "company" in text(cell.get("entity_scope") or cell.get("header_path")).lower()
    }
    period_columns = set(period_map)
    # Exclude note/reference columns that carry a year header but mostly
    # contain note numbers (for example column 2 with values 20, 21, 22).
    numeric_density = {}
    for cell in table_cells:
        column = integer(cell.get("column_index"))
        if column < 0:
            continue
        stats = numeric_density.setdefault(column, {"numeric": 0, "total": 0, "large": 0})
        stats["total"] += 1
        parsed_numeric = number(cell.get("numeric_value"))
        if parsed_numeric is not None:
            stats["numeric"] += 1
            if abs(parsed_numeric) >= 1000:
                stats["large"] += 1
    value_columns = {
        column for column, stats in numeric_density.items()
        if stats["numeric"] >= 2 and stats["numeric"] / max(stats["total"], 1) >= 0.20
    }
    # Use the final structural classification, not the source metadata.  PDF
    # extractors commonly leave that metadata blank or incorrectly reuse the
    # prior page's statement type; the layout recovery must still run when the
    # table itself was confidently classified as a primary statement.
    period_map, recovered_group_columns, layout_recovery = recover_headerless_group_layout(
        statement_type, period_map, value_columns, title, table_cells
    )
    # In a share-capital note, the first paired numeric columns are share
    # quantities; later paired columns are monetary amounts. Keep that
    # distinction so a US$14 share-capital amount can never become 14 shares.
    share_count_columns = set(sorted(value_columns)[:2]) if share_count_note else set()
    candidate_value_columns = (period_columns & value_columns) - company_columns
    # A consolidated table normally has exactly two Group period columns.
    # Pick the densest numeric columns so note/reference columns (20, 21,
    # note numbers) cannot become financial values.
    ranked_value_columns = sorted(
        candidate_value_columns,
        key=lambda column: (
            numeric_density.get(column, {}).get("large", 0),
            numeric_density.get(column, {}).get("numeric", 0),
        ),
        reverse=True,
    )
    # In the standard Group/Company primary-statement layout the first
    # physical pair after the note column belongs to Group.  Density ranking
    # alone can select one Group and one Company column when all four columns
    # are fully populated, which leaves the Group comparative year missing.
    # Keep the existing ranking for two-column layouts; use the left-hand
    # pair only for an unlabelled four-or-more-column primary statement.
    physical_value_columns = sorted(candidate_value_columns)
    if (
        statement_type in PRIMARY_STATEMENTS
        and not company_columns
        and len(physical_value_columns) >= 4
    ):
        implicit_group_columns = set(physical_value_columns[:2])
    else:
        implicit_group_columns = set(ranked_value_columns[:2]) if len(ranked_value_columns) >= 2 else set(ranked_value_columns)
    if recovered_group_columns:
        implicit_group_columns = recovered_group_columns
        print(f"Recovered {layout_recovery} for {key}: Group columns {sorted(recovered_group_columns)}", flush=True)
    if statement_type in PRIMARY_STATEMENTS and len(implicit_group_columns) >= 2:
        implicit_group_columns = {
            column for column in implicit_group_columns
            if column >= min(implicit_group_columns)
        }

    # Note tables may expose the note identifier as an ordinary numeric cell
    # (for example: label | 11 | 4,074,316 | 4,935,121). Mark that first cell
    # structurally so it cannot become the current-period canonical fact.
    structural_note_cells = set()
    cells_by_row = collections.defaultdict(list)
    for candidate_cell in table_cells:
        cells_by_row[integer(candidate_cell.get("row_index"), -1)].append(candidate_cell)
    for sibling_cells in cells_by_row.values():
        numeric_cells = [
            candidate_cell for candidate_cell in sibling_cells
            if number(candidate_cell.get("numeric_value")) is not None
        ]
        numeric_cells.sort(key=lambda candidate_cell: integer(candidate_cell.get("column_index"), 999))
        if len(numeric_cells) < 3:
            continue
        first = numeric_cells[0]
        first_value = number(first.get("numeric_value"))
        later_year_cells = [
            candidate_cell for candidate_cell in numeric_cells[1:]
            if re.search(r"\b(?:19|20)\d{2}\b", text(candidate_cell.get("header_path")))
        ]
        if (
            first_value is not None
            and abs(first_value) <= 999
            and abs(first_value - round(first_value)) < 0.000001
            and not re.search(r"\b(?:19|20)\d{2}\b", text(first.get("header_path")))
            and len(later_year_cells) >= 2
        ):
            structural_note_cells.add(id(first))
    for cell in table_cells:
        row_index = integer(cell.get("row_index"))
        label = text(cell.get("row_label"))
        raw_label = text(cell.get("raw_text"))
        # Standardize all nonnumeric text cells as labels. Earlier logic only
        # promoted share-note text, which left labels such as Revenue,
        # Administrative and Total Assets invisible to the resolver.
        if not label and raw_label and not number(raw_label):
            label = raw_label
        subtotal_repair = structural_subtotals.get(row_index, {})
        label = label or subtotal_repair.get("label", "")
        if label:
            normalized_row_label = re.sub(r"\s+", " ", label.lower()).strip()
            if supporting_balance_note:
                if re.fullmatch(r"(?:share capital|issued shares?)", normalized_row_label):
                    share_note_section = "ISSUED"
                elif re.fullmatch(r"treasury shares?", normalized_row_label):
                    share_note_section = "TREASURY"
                elif re.search(r"\b(?:at )?end of (?:the )?(?:financial )?(?:year|period)\b", normalized_row_label):
                    label = (
                        "Treasury shares count at end" if share_note_section == "TREASURY"
                        else "Issued shares at end"
                    )
                elif re.search(r"\b(?:shares? )?(?:outstanding|in issue) at (?:the )?(?:financial )?(?:year|period) end\b", normalized_row_label):
                    label = (
                        "Treasury shares count at end" if share_note_section == "TREASURY"
                        else "Issued shares at end"
                    )
                elif (
                    share_note_section == "TREASURY"
                    and re.search(r"\bat beginning and end\b", normalized_row_label)
                ):
                    label = "Treasury shares count at end"
                elif share_count_note and re.search(r"\b(?:at )?end of (?:the )?(?:financial )?(?:year|period)\b", normalized_row_label):
                    label = "Treasury shares count at end" if "treasury" in normalized_row_label else "Issued shares at end"
            current_section = statement_section(label, current_section)
            # Qualify ambiguous debt labels using their audited statement
            # section. This prevents current borrowings/leases from being
            # selected as long-term debt and works independently of wording.
            normalized_row_label = re.sub(r"\s+", " ", label.lower()).strip()
            if current_section == "NON_CURRENT_LIABILITIES" and normalized_row_label in {
                "borrowings", "loans and borrowings", "lease liabilities"
            }:
                label = "Non-current " + label
            elif current_section == "CURRENT_LIABILITIES" and normalized_row_label in {
                "borrowings", "loans and borrowings", "lease liabilities"
            }:
                label = "Current " + label
            row_labels[row_index] = label

        numeric_value = number(cell.get("numeric_value"))
        # In a confirmed non-current debt row, an accounting dash is an
        # explicitly disclosed nil balance, not missing evidence. Preserve
        # that semantic zero so component sums can reconcile debt across both
        # periods. Dashes in every other row remain NOT_REPORTED.
        normalized_debt_label = re.sub(r"[^a-z0-9]+", " ", text(label or row_labels.get(row_index, "")).lower()).strip()
        explicit_nil_debt = (
            normalized_debt_label.startswith("non current ")
            and any(term in normalized_debt_label for term in ("borrowings", "loans", "lease liabilities"))
        )
        explicit_nil_ppe_component = (
            statement_type == "BALANCE_SHEET"
            and normalized_debt_label in {"right of use asset", "right of use assets"}
        )
        if (
            numeric_value is None
            and text(cell.get("raw_text") or cell.get("raw_value")) in {"-", "–", "—", "−"}
            and (explicit_nil_debt or explicit_nil_ppe_component)
        ):
            numeric_value = 0.0
        # A standalone accounting dash is not a number.  Preserve it as
        # NOT_REPORTED rather than converting it to zero or a negative value.
        # A zero is accepted only when the filing actually reports a numeric 0.
        if numeric_value is None or row_index < 0:
            continue
        if id(cell) in structural_note_cells:
            continue
        if label and number(label) is not None:
            label = ""
        label = label or row_labels.get(row_index, "")
        if not label:
            continue

        column_index = integer(cell.get("column_index"))
        if (
            share_count_note
            and label in {"Issued shares at end", "Treasury shares count at end"}
            and column_index not in share_count_columns
        ):
            label = "Share capital monetary amount"
        header = text(cell.get("header_path"))
        period = infer_period(cell, header) or period_map.get(column_index, "")
        if subtotal_repair.get("period_role"):
            period = subtotal_repair["period_role"]
        if share_count_note and column_index in share_count_columns:
            period = "CURRENT" if column_index == min(share_count_columns) else "PRIOR"
            scope = "GROUP"
        else:
            scope = "GROUP" if column_index in implicit_group_columns else infer_scope(cell, header)
        identity = "|".join([
            context["source_document_id"], key, str(row_index), str(column_index),
            scope, period, label,
        ])
        value_rows.append({
            "statement_value_id": hashlib.sha256(identity.encode("utf-8")).hexdigest(),
            **{name: context[name] for name in [
                "tenant_id", "entity_id", "assessment_run_id", "source_document_id",
                "table_artifact_id", "source_table_id",
            ]},
            "statement_type": statement_type,
            "statement_title": title,
            "statement_section": current_section,
            "row_index": row_index,
            "row_order": row_index,
            "row_label": label,
            "note_reference": text(cell.get("note_reference")),
            "entity_scope": scope,
            "period_label": period,
            "period_end": period,
            "column_index": column_index,
            "raw_value": text(cell.get("raw_text")),
            "numeric_value": numeric_value,
            "currency": text(cell.get("currency") or artifact.get("presentation_currency")),
            "unit": text(cell.get("unit") or artifact.get("presentation_unit")),
            "is_total": is_total_label(label),
            "page_number": context["page_number"],
            "extraction_confidence": number(cell.get("extraction_confidence")),
            "structure_score": number(cell.get("structure_score") or artifact.get("structure_score")),
            "classification_method": classification_method,
            "model_name": model_name,
            "normalization_status": "STANDARDIZED",
            "normalizer_version": VERSION,
            "normalized_at": now,
        })

values_df = pd.DataFrame(value_rows, columns=VALUE_COLUMNS)
exceptions_df = pd.DataFrame(exception_rows, columns=EXCEPTION_COLUMNS)
dataiku.Dataset(OUTPUT_VALUES).write_with_schema(values_df)
dataiku.Dataset(OUTPUT_EXCEPTIONS).write_with_schema(exceptions_df)

print(json.dumps({
    "normalizer_version": VERSION,
    "input_table_count": len(cells_by_table),
    "standardized_value_count": len(values_df),
    "exception_count": len(exceptions_df),
    "classification_engine": "PYTHON_ONLY",
    "deferred_review_threshold": MINIMUM_PYTHON_CONFIDENCE,
    "statement_counts": values_df["statement_type"].value_counts().to_dict() if not values_df.empty else {},
}, indent=2, default=str))

