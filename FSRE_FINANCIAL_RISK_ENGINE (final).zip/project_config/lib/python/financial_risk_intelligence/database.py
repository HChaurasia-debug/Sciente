from __future__ import annotations

import os
from contextlib import contextmanager
from dataclasses import dataclass
from typing import Any, Iterator
from uuid import UUID


def _dataiku_variables() -> dict[str, Any]:
    try:
        import dataiku  # type: ignore
        return dataiku.get_custom_variables()
    except Exception:
        return {}


def _required_value(
    variables: dict[str, Any],
    dataiku_keys: tuple[str, ...],
    environment_keys: tuple[str, ...],
) -> str:
    for key in dataiku_keys:
        value = variables.get(key)
        if value not in (None, ""):
            return str(value)
    for key in environment_keys:
        value = os.getenv(key)
        if value not in (None, ""):
            return str(value)
    raise RuntimeError("Missing configuration: " + "/".join((*dataiku_keys, *environment_keys)))


@dataclass(frozen=True)
class DatabaseSettings:
    host: str
    port: int
    database: str
    user: str
    password: str
    application_name: str

    @classmethod
    def from_runtime(cls) -> "DatabaseSettings":
        variables = _dataiku_variables()
        return cls(
            host=_required_value(variables, ("fsre_pg_host", "fri_pg_host"), ("FSRE_PG_HOST", "FRI_PG_HOST")),
            port=int(_required_value(variables, ("fsre_pg_port", "fri_pg_port"), ("FSRE_PG_PORT", "FRI_PG_PORT"))),
            database=_required_value(variables, ("fsre_pg_database", "fri_pg_database"), ("FSRE_PG_DATABASE", "FRI_PG_DATABASE")),
            user=_required_value(variables, ("fsre_pg_user", "fri_pg_user"), ("FSRE_PG_USER", "FRI_PG_USER")),
            password=_required_value(variables, ("fsre_pg_password", "fri_pg_password"), ("FSRE_PG_PASSWORD", "FRI_PG_PASSWORD")),
            application_name=_required_value(
                variables,
                ("fsre_application_name", "fri_application_name"),
                ("FSRE_APPLICATION_NAME", "FRI_APPLICATION_NAME"),
            ),
        )


@contextmanager
def tenant_connection(tenant_id: str, settings: DatabaseSettings | None = None) -> Iterator[object]:
    """Open one transaction and apply transaction-local PostgreSQL RLS context."""
    try:
        import psycopg2
        import psycopg2.extras
    except ImportError as exc:
        raise RuntimeError("Install psycopg2-binary in the Dataiku code environment") from exc

    validated_tenant_id = str(UUID(str(tenant_id)))
    cfg = settings or DatabaseSettings.from_runtime()
    connection = psycopg2.connect(
        host=cfg.host,
        port=cfg.port,
        dbname=cfg.database,
        user=cfg.user,
        password=cfg.password,
        application_name=cfg.application_name,
        cursor_factory=psycopg2.extras.RealDictCursor,
    )
    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT set_config('fsre.tenant_id', %s, true)", (validated_tenant_id,))
            yield cursor
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()
