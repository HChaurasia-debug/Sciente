# coding: utf-8

import hashlib
import re
import shutil
import tempfile
import time
from pathlib import Path
from urllib.parse import unquote, urlparse

import dataiku
import pandas as pd
import requests


# ================================================================
# CONFIGURATION
# ================================================================

INPUT_DATASET = "FRI_SGX_ANNUAL_REPORT_URLS"
OUTPUT_FOLDER_ID = "avBJ7Lwp"

# True deletes existing managed-folder reports only after every
# enabled report has downloaded and validated successfully.
REPLACE_EXISTING_FILES = True

CONNECT_TIMEOUT_SECONDS = 30
DOWNLOAD_TIMEOUT_SECONDS = 300
MINIMUM_PDF_SIZE = 10_000


def log(message):
    print(
        f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] "
        f"{message}",
        flush=True,
    )


def clean_filename(value):
    value = unquote(str(value or ""))

    value = re.sub(
        r'[<>:"/\\|?*\x00-\x1f]',
        "_",
        value,
    )

    value = re.sub(
        r"\s+",
        " ",
        value,
    ).strip(" ._")

    return value[:180] or "annual_report"


def boolean_value(value):
    if pd.isna(value):
        return True

    return str(value).strip().lower() in {
        "true",
        "1",
        "yes",
        "y",
    }


def create_filename(row, sequence):
    company = clean_filename(
        row.get("company_name")
        or f"company_{sequence}"
    )

    year = row.get("report_year")

    if pd.notna(year):
        try:
            year = str(int(float(year)))
        except Exception:
            year = clean_filename(year)
    else:
        year = "unknown_year"

    return f"{company}_Annual_Report_{year}.pdf"


def validate_pdf(path):
    if not path.exists():
        raise RuntimeError(
            f"File was not created: {path}"
        )

    size = path.stat().st_size

    if size < MINIMUM_PDF_SIZE:
        raise RuntimeError(
            f"File is too small: {size:,} bytes"
        )

    with path.open("rb") as source:
        signature = source.read(5)

    if not signature.startswith(b"%PDF"):
        preview = path.read_bytes()[:300].decode(
            "utf-8",
            errors="replace",
        )

        raise RuntimeError(
            "Response is not PDF content. "
            f"Preview: {preview!r}"
        )

    digest = hashlib.sha256()

    with path.open("rb") as source:
        for block in iter(
            lambda: source.read(1024 * 1024),
            b"",
        ):
            digest.update(block)

    return {
        "size": size,
        "sha256": digest.hexdigest(),
    }


def download_pdf(session, url, destination):
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 "
            "(KHTML, like Gecko) "
            "Chrome/127.0.0.0 Safari/537.36"
        ),
        "Accept": (
            "application/pdf,"
            "application/octet-stream,"
            "*/*"
        ),
        "Accept-Language": "en-US,en;q=0.9",
        "Referer": "https://links.sgx.com/",
    }

    partial_path = destination.with_suffix(
        ".pdf.part"
    )

    if partial_path.exists():
        partial_path.unlink()

    log(f"Downloading: {url}")

    try:
        with session.get(
            url,
            headers=headers,
            stream=True,
            allow_redirects=True,
            timeout=(
                CONNECT_TIMEOUT_SECONDS,
                DOWNLOAD_TIMEOUT_SECONDS,
            ),
        ) as response:
            response.raise_for_status()

            content_type = response.headers.get(
                "Content-Type",
                "",
            )

            total_size = int(
                response.headers.get(
                    "Content-Length",
                    0,
                )
                or 0
            )

            log(
                f"HTTP {response.status_code}; "
                f"type={content_type}; "
                f"expected={total_size:,}"
            )

            received_size = 0
            last_mb = -1

            with partial_path.open("wb") as output:
                for chunk in response.iter_content(
                    chunk_size=1024 * 1024
                ):
                    if not chunk:
                        continue

                    output.write(chunk)
                    received_size += len(chunk)

                    current_mb = (
                        received_size // (1024 * 1024)
                    )

                    if current_mb != last_mb:
                        last_mb = current_mb

                        if total_size:
                            percentage = (
                                received_size
                                / total_size
                                * 100
                            )

                            log(
                                f"Progress: {received_size:,}/"
                                f"{total_size:,} "
                                f"({percentage:.1f}%)"
                            )
                        else:
                            log(
                                f"Progress: "
                                f"{received_size:,} bytes"
                            )

        partial_path.replace(destination)

        validation = validate_pdf(destination)

        log(
            f"Validated: {destination.name}; "
            f"{validation['size']:,} bytes"
        )

        return validation

    except Exception:
        if partial_path.exists():
            partial_path.unlink()

        if destination.exists():
            destination.unlink()

        raise


# ================================================================
# READ URL MANIFEST
# ================================================================

url_dataset = dataiku.Dataset(INPUT_DATASET)
url_df = url_dataset.get_dataframe()

required_columns = {
    "company_name",
    "report_year",
    "report_url",
}

missing_columns = (
    required_columns - set(url_df.columns)
)

if missing_columns:
    raise RuntimeError(
        "Input dataset is missing columns: "
        + ", ".join(sorted(missing_columns))
    )

if "enabled" in url_df.columns:
    url_df = url_df[
        url_df["enabled"].apply(boolean_value)
    ]

url_df["report_url"] = (
    url_df["report_url"]
    .fillna("")
    .astype(str)
    .str.strip()
)

url_df = url_df[
    url_df["report_url"] != ""
].copy()

url_df = url_df.drop_duplicates(
    subset=["report_url"],
    keep="last",
)

if url_df.empty:
    raise RuntimeError(
        "No enabled annual-report URLs were found."
    )

log(f"Reports to download: {len(url_df)}")


# ================================================================
# STAGE EVERY REPORT
# ================================================================

staging_directory = Path(
    tempfile.mkdtemp(
        prefix="fri_sgx_all_reports_"
    )
)

session = requests.Session()
staged_reports = []
failures = []
used_names = set()

try:
    for sequence, (_, row) in enumerate(
        url_df.iterrows(),
        start=1,
    ):
        report_url = row["report_url"]

        filename = create_filename(
            row,
            sequence,
        )

        base_filename = filename
        suffix_number = 2

        while filename.lower() in used_names:
            original = Path(base_filename)

            filename = (
                f"{original.stem}_{suffix_number}"
                f"{original.suffix}"
            )

            suffix_number += 1

        used_names.add(filename.lower())

        destination = (
            staging_directory / filename
        )

        log("=" * 72)
        log(
            f"Report {sequence}/{len(url_df)}: "
            f"{filename}"
        )

        try:
            validation = download_pdf(
                session,
                report_url,
                destination,
            )

            staged_reports.append(
                {
                    "filename": filename,
                    "local_path": destination,
                    "source_url": report_url,
                    "company_name": row["company_name"],
                    "report_year": row["report_year"],
                    "size": validation["size"],
                    "sha256": validation["sha256"],
                }
            )

        except Exception as error:
            log(f"FAILED: {error}")

            failures.append(
                {
                    "company_name": row["company_name"],
                    "report_year": row["report_year"],
                    "report_url": report_url,
                    "error": str(error),
                }
            )

finally:
    session.close()


# ================================================================
# FAIL CLOSED
# ================================================================

if failures:
    print(
        pd.DataFrame(failures).to_string(
            index=False
        ),
        flush=True,
    )

    raise RuntimeError(
        f"{len(failures)} report(s) failed. "
        "The managed folder was not changed."
    )

if len(staged_reports) != len(url_df):
    raise RuntimeError(
        "Not every report was staged. "
        "The managed folder was not changed."
    )


# ================================================================
# WRITE MANAGED FOLDER
# ================================================================

output_folder = dataiku.Folder(
    OUTPUT_FOLDER_ID
)

if REPLACE_EXISTING_FILES:
    existing_paths = (
        output_folder.list_paths_in_partition()
    )

    log(
        f"Deleting {len(existing_paths)} "
        f"existing managed-folder paths"
    )

    for index, existing_path in enumerate(
        existing_paths,
        start=1,
    ):
        log(
            f"Deleting {index}/"
            f"{len(existing_paths)}: "
            f"{existing_path}"
        )

        output_folder.delete_path(
            existing_path
        )


for index, report in enumerate(
    staged_reports,
    start=1,
):
    managed_path = "/" + report["filename"]

    log(
        f"Uploading {index}/"
        f"{len(staged_reports)}: "
        f"{managed_path}"
    )

    with report["local_path"].open("rb") as source:
        with output_folder.get_writer(
            managed_path
        ) as destination:
            shutil.copyfileobj(
                source,
                destination,
                length=1024 * 1024,
            )


# ================================================================
# VERIFY
# ================================================================

managed_paths = (
    output_folder.list_paths_in_partition()
)

log("=" * 72)
log("Recipe completed successfully")
log(f"Reports uploaded: {len(staged_reports)}")
log(
    f"Managed-folder paths: "
    f"{len(managed_paths)}"
)

for path in managed_paths:
    log(f"  {path}")