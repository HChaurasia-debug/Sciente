from __future__ import annotations

import json
from typing import Any

from .database import DatabaseSettings, tenant_connection


def store_variable(
    tenant_id: str,
    variable_scope: str,
    scope_key: str,
    variable_key: str,
    value: Any,
    value_type: str,
    lifecycle_state: str,
    version: int,
    created_by: str | None,
    description: str | None = None,
    effective_from=None,
    effective_to=None,
    settings: DatabaseSettings | None = None,
) -> str:
    """Insert one immutable variable version; reruns with the same key are idempotent."""
    with tenant_connection(tenant_id, settings) as cursor:
        cursor.execute(
            """INSERT INTO financial_risk_intelligence.database_variables
               (tenant_id,variable_scope,scope_key,variable_key,value_type,value_json,
                lifecycle_state,version,effective_from,effective_to,description,created_by)
               VALUES (%s,%s,%s,%s,%s,%s::jsonb,%s,%s,%s,%s,%s,%s)
               ON CONFLICT (tenant_id,variable_scope,scope_key,variable_key,version)
               DO UPDATE SET value_type=EXCLUDED.value_type,value_json=EXCLUDED.value_json,
                 lifecycle_state=EXCLUDED.lifecycle_state,effective_from=EXCLUDED.effective_from,
                 effective_to=EXCLUDED.effective_to,description=EXCLUDED.description,
                 updated_at=clock_timestamp()
               RETURNING variable_id""",
            (
                tenant_id, variable_scope, scope_key, variable_key, value_type,
                json.dumps(value), lifecycle_state, int(version), effective_from,
                effective_to, description, created_by,
            ),
        )
        return str(cursor.fetchone()["variable_id"])
