"""
FRI_03D_PRESERVE_FINANCIAL_TABLE_JSON

Inputs
------
FRI_VALIDATED_TABLE_ARTIFACTS
FRI_VALIDATED_TABLE_CELLS

Output
-------
FRI_FINANCIAL_TABLE_JSON

This recipe preserves each validated financial table as one canonical JSON
document without requiring an external Python project library.
"""

from __future__ import annotations

import hashlib
import json
import math
import os
from collections import Counter, defaultdict
from datetime import date, datetime
from decimal import Decimal
from typing import Any, Dict, Iterable, List, Tuple

import dataiku
import pandas as pd


# ---------------------------------------------------------------------------
# Dataset configuration
# ---------------------------------------------------------------------------

INPUT_ARTIFACTS = os.getenv(
    "FRI_VALIDATED_TABLE_ARTIFACTS",
    "FRI_VALIDATED_TABLE_ARTIFACTS",
)

INPUT_CELLS = os.getenv(
    "FRI_VALIDATED_TABLE_CELLS",
    "FRI_VALIDATED_TABLE_CELLS",
)

OUTPUT_DATASET = os.getenv(
    "FRI_FINANCIAL_TABLE_JSON",
    "FRI_FINANCIAL_TABLE_JSON",
)

SCHEMA_VERSION = "fsre.financial-table.v1"


OUTPUT_COLUMNS = [
    "table_artifact_id",
    "source_document_id",
    "statement_type",
    "page_number",
    "schema_version",
    "validation_status",
    "issue_count",
    "cell_count",
    "sha256",
    "table_json",
]


# ---------------------------------------------------------------------------
# General utility functions
# ---------------------------------------------------------------------------

def is_missing(value: Any) -> bool:
    if value is None:
        return True

    try:
        result = pd.isna(value)

        if isinstance(result, bool):
            return result
    except (TypeError, ValueError):
        pass

    return False


def json_value(value: Any) -> Any:
    """Convert pandas, Decimal and datetime values to JSON-compatible values."""

    if is_missing(value):
        return None

    if isinstance(value, Decimal):
        return str(value)

    if isinstance(value, (datetime, date)):
        return value.isoformat()

    if hasattr(value, "item"):
        try:
            return json_value(value.item())
        except (TypeError, ValueError):
            pass

    return value


def text(value: Any) -> str:
    value = json_value(value)

    if value is None:
        return ""

    return str(value).strip()


def integer(value: Any, default: int = -1) -> int:
    if is_missing(value):
        return default

    try:
        return int(float(value))
    except (TypeError, ValueError):
        return default


def parse_json(value: Any, default: Any) -> Any:
    """Parse an existing JSON value without failing the complete recipe."""

    if isinstance(value, (dict, list)):
        return value

    raw = text(value)

    if not raw:
        return default

    try:
        return json.loads(raw)
    except (json.JSONDecodeError, TypeError, ValueError):
        return default


def read_dataset(name: str) -> pd.DataFrame:
    try:
        return dataiku.Dataset(name).get_dataframe(
            infer_with_pandas=False
        )
    except TypeError:
        return dataiku.Dataset(name).get_dataframe()


def table_id(row: Dict[str, Any]) -> str:
    return text(
        row.get("table_artifact_id")
        or row.get("source_table_id")
        or row.get("table_id")
    )


# ---------------------------------------------------------------------------
# Canonical cell representation
# ---------------------------------------------------------------------------

def canonical_cell(cell: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "cell_id": text(cell.get("cell_id")),
        "row_index": integer(cell.get("row_index")),
        "column_index": integer(cell.get("column_index")),
        "row_span": max(1, integer(cell.get("row_span"), 1)),
        "column_span": max(1, integer(cell.get("column_span"), 1)),
        "role": (
            text(cell.get("cell_role")).upper()
            or "DATA"
        ),
        "raw_text": text(
            cell.get("raw_text")
            if not is_missing(cell.get("raw_text"))
            else cell.get("raw_value")
        ),
        "normalized_text": text(cell.get("normalized_text")),
        "numeric_value": json_value(cell.get("numeric_value")),
        "row_label": text(cell.get("row_label")),
        "header_path": text(cell.get("header_path")),
        "note_reference": text(cell.get("note_reference")),
        "period_label": text(
            cell.get("period_label")
            or cell.get("period_end")
        ),
        "entity_scope": text(
            cell.get("entity_scope")
            or cell.get("column_scope")
        ).upper(),
        "currency": text(cell.get("currency")),
        "unit": text(cell.get("unit")),
        "bbox": parse_json(
            cell.get("cell_bbox_json"),
            {},
        ),
        "confidence": json_value(
            cell.get("extraction_confidence")
        ),
    }


# ---------------------------------------------------------------------------
# Structural validation
# ---------------------------------------------------------------------------

def validate_cells(
    cells: List[Dict[str, Any]],
) -> List[Dict[str, str]]:
    issues: List[Dict[str, str]] = []

    coordinates = [
        (
            cell["row_index"],
            cell["column_index"],
        )
        for cell in cells
    ]

    # Every non-empty source cell must have a valid table coordinate.
    invalid_coordinates = [
        coordinate
        for coordinate in coordinates
        if coordinate[0] < 0 or coordinate[1] < 0
    ]

    if invalid_coordinates:
        issues.append({
            "code": "INVALID_CELL_COORDINATE",
            "severity": "ERROR",
            "message": (
                f"{len(invalid_coordinates)} cells have missing "
                "or negative row/column coordinates"
            ),
        })

    # Two different extracted cells must not occupy the same table position.
    coordinate_counts = Counter(coordinates)

    for coordinate, count in sorted(coordinate_counts.items()):
        if count > 1:
            issues.append({
                "code": "DUPLICATE_CELL_COORDINATE",
                "severity": "ERROR",
                "message": (
                    f"Coordinate {coordinate} occurs {count} times"
                ),
            })

    # A numeric source column must not represent multiple years or scopes.
    column_contexts = defaultdict(set)

    for cell in cells:
        if cell["numeric_value"] is None:
            continue

        period = cell["period_label"]
        scope = cell["entity_scope"]

        if period or scope:
            column_contexts[cell["column_index"]].add(
                (period, scope)
            )

    for column_index, contexts in sorted(column_contexts.items()):
        if len(contexts) > 1:
            issues.append({
                "code": "AMBIGUOUS_COLUMN_CONTEXT",
                "severity": "ERROR",
                "message": (
                    f"Column {column_index} has multiple period/scope "
                    f"contexts: {sorted(contexts)}"
                ),
            })

    if not cells:
        issues.append({
            "code": "EMPTY_TABLE",
            "severity": "ERROR",
            "message": "The table has no preserved cells",
        })

    return issues


# ---------------------------------------------------------------------------
# Canonical table-document creation
# ---------------------------------------------------------------------------

def build_table_document(
    artifact: Dict[str, Any],
    source_cells: Iterable[Dict[str, Any]],
) -> Tuple[Dict[str, Any], List[Dict[str, str]]]:

    cells = [
        canonical_cell(cell)
        for cell in source_cells
    ]

    cells.sort(
        key=lambda cell: (
            cell["row_index"],
            cell["column_index"],
        )
    )

    issues = validate_cells(cells)

    rows_by_index: Dict[int, List[Dict[str, Any]]] = defaultdict(list)

    for cell in cells:
        rows_by_index[cell["row_index"]].append(cell)

    table_rows = [
        {
            "row_index": row_index,
            "cells": rows_by_index[row_index],
        }
        for row_index in sorted(rows_by_index)
    ]

    document = {
        "schema_version": SCHEMA_VERSION,

        "identity": {
            "tenant_id": text(artifact.get("tenant_id")),
            "entity_id": text(artifact.get("entity_id")),
            "assessment_run_id": text(
                artifact.get("assessment_run_id")
            ),
            "source_document_id": text(
                artifact.get("source_document_id")
            ),
            "table_artifact_id": table_id(artifact),
            "source_table_id": text(
                artifact.get("source_table_id")
            ),
        },

        "source": {
            "page_number": json_value(
                artifact.get("page_number")
            ),
            "page_image_path": text(
                artifact.get("page_image_path")
            ),
            "table_bbox": parse_json(
                artifact.get("table_bbox_json"),
                {},
            ),
            "extraction_method": text(
                artifact.get("extraction_method")
            ),
            "model_name": text(
                artifact.get("model_name")
            ),
        },

        "table": {
            "title": text(
                artifact.get("table_title")
                or artifact.get("statement_title")
            ),
            "statement_type": text(
                artifact.get("statement_type")
            ).upper(),
            "currency": text(
                artifact.get("presentation_currency")
                or artifact.get("currency")
            ),
            "unit": text(
                artifact.get("presentation_unit")
                or artifact.get("unit")
            ),
            "row_count": integer(
                artifact.get("row_count"),
                len(table_rows),
            ),
            "column_count": integer(
                artifact.get("column_count"),
                0,
            ),
            "header_tree": parse_json(
                artifact.get("header_tree_json"),
                {},
            ),
            "merged_cells": parse_json(
                artifact.get("merged_cells_json"),
                [],
            ),
            "rows": table_rows,
            "cells": cells,
        },

        "validation": {
            "status": (
                "INVALID"
                if any(
                    issue["severity"] == "ERROR"
                    for issue in issues
                )
                else "VALID"
            ),
            "issues": issues,
        },
    }

    # Generate the fingerprint before adding the integrity section.
    fingerprint_input = json.dumps(
        document,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    )

    fingerprint = hashlib.sha256(
        fingerprint_input.encode("utf-8")
    ).hexdigest()

    document["integrity"] = {
        "algorithm": "sha256",
        "fingerprint": fingerprint,
        "cell_count": len(cells),
    }

    return document, issues


def serialize_document(document: Dict[str, Any]) -> str:
    return json.dumps(
        document,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    )


# ---------------------------------------------------------------------------
# Main recipe
# ---------------------------------------------------------------------------

def main() -> None:
    artifacts_df = read_dataset(INPUT_ARTIFACTS)
    cells_df = read_dataset(INPUT_CELLS)

    if artifacts_df.empty:
        raise RuntimeError(
            f"{INPUT_ARTIFACTS} is empty"
        )

    if cells_df.empty:
        raise RuntimeError(
            f"{INPUT_CELLS} is empty"
        )

    artifact_records = artifacts_df.to_dict(
        orient="records"
    )

    cell_records = cells_df.to_dict(
        orient="records"
    )

    cells_by_table: Dict[str, List[Dict[str, Any]]] = defaultdict(list)

    cells_without_table_id = 0

    for cell in cell_records:
        key = table_id(cell)

        if not key:
            cells_without_table_id += 1
            continue

        cells_by_table[key].append(cell)

    if cells_without_table_id:
        print(
            f"Warning: {cells_without_table_id} cells do not have "
            "a table_artifact_id/source_table_id"
        )

    output_rows = []
    artifact_ids = set()

    for artifact in artifact_records:
        key = table_id(artifact)

        if not key:
            raise RuntimeError(
                "A validated table artifact does not have "
                "table_artifact_id, source_table_id, or table_id"
            )

        if key in artifact_ids:
            raise RuntimeError(
                f"Duplicate table artifact ID: {key}"
            )

        artifact_ids.add(key)

        document, issues = build_table_document(
            artifact,
            cells_by_table.get(key, []),
        )

        output_rows.append({
            "table_artifact_id": key,
            "source_document_id": text(
                artifact.get("source_document_id")
            ),
            "statement_type": text(
                artifact.get("statement_type")
            ).upper(),
            "page_number": json_value(
                artifact.get("page_number")
            ),
            "schema_version": SCHEMA_VERSION,
            "validation_status": (
                document["validation"]["status"]
            ),
            "issue_count": len(issues),
            "cell_count": document["integrity"]["cell_count"],
            "sha256": document["integrity"]["fingerprint"],
            "table_json": serialize_document(document),
        })

    output_df = pd.DataFrame(
        output_rows,
        columns=OUTPUT_COLUMNS,
    )

    dataiku.Dataset(
        OUTPUT_DATASET
    ).write_with_schema(output_df)

    invalid_count = int(
        output_df["validation_status"]
        .eq("INVALID")
        .sum()
    )

    print(json.dumps({
        "status": (
            "SUCCESS_WITH_INVALID_TABLES"
            if invalid_count
            else "SUCCESS"
        ),
        "input_artifact_count": len(artifact_records),
        "input_cell_count": len(cell_records),
        "output_table_count": len(output_df),
        "valid_table_count": (
            len(output_df) - invalid_count
        ),
        "invalid_table_count": invalid_count,
        "cells_without_table_id": cells_without_table_id,
        "output_dataset": OUTPUT_DATASET,
        "schema_version": SCHEMA_VERSION,
    }, indent=2))


main()