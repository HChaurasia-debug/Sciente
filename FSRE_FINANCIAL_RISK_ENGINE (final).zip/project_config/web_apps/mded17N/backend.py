"""
Dataiku Dash Webapp: FSRE New Assessment Workbench.

Purpose:
- Upload annual reports / financial statement support files to the configured
  Dataiku managed folder.
- Start the existing FSRE E2E scenario that performs intake, extraction,
  validation, rule execution, and report refresh.

Recommended project variables:
- FSRE_ASSESSMENT_UPLOAD_FOLDER_ID = Dataiku managed folder id, for example NqgJNzVa
- FSRE_COMPANY_LOGO_FOLDER_ID = managed folder containing the company logo
- FSRE_COMPANY_LOGO_PATH = logo path in that folder, for example /branding/sciente-logo.jpg
- FSRE_E2E_SCENARIO_ID = FSRE_E2E_FINANCIAL_STATEMENT_RUN
- FSRE_REPORT_DASHBOARD_URL = optional URL of final report dashboard

The Webapp is orchestration/UI only. Runtime registration and rule execution
remain handled by the existing Dataiku recipes and PostgreSQL configuration.
"""

from __future__ import annotations

import base64
import io
import json
import os
import re
import time
import uuid
from datetime import datetime, timedelta, timezone
from threading import RLock, Thread
from typing import Any, Optional
from urllib.parse import quote

import dataiku
import pandas as pd
from dash import Input, Output, State, ctx, dcc, html, no_update

try:
    from flask import Response, jsonify, request
except Exception:
    Response = None
    jsonify = None
    request = None

try:
    app
except NameError:
    from dash import Dash

    app = Dash(__name__)


DEFAULT_FOLDER_ID = "NqgJNzVa"
DEFAULT_LOGO_FOLDER_ID = "r9BCXvH0"
DEFAULT_LOGO_PATH = "/company logo.jpg"
DEFAULT_SCENARIO_ID = "FSRE_E2E_FINANCIAL_STATEMENT_RUN"
ALLOWED_EXTENSIONS = {"pdf", "xlsx", "xls"}

REPORT_DATASET_NAMES = {
    "summary": "fsre_report_run_summary",
    "rules": "fsre_report_rule_results",
    "red_flags": "fsre_report_red_flags",
    "review": "fsre_report_review_items",
    "external": "fsre_report_external_blockers",
    "evidence": "fsre_report_evidence_trail",
}

REPORT_VIEW_NAMES = {
    "summary": "fsre_report.vw_run_summary",
    "rules": "fsre_report.vw_rule_results",
    "red_flags": "fsre_report.vw_red_flags",
    "review": "fsre_report.vw_review_items",
    "external": "fsre_report.vw_external_blockers",
    "evidence": "fsre_report.vw_evidence_trail",
}

JOB_RESULT_DATASET_CANDIDATES = [
    "04_execute_rules_log",
    "rule_execution_log",
    "03f_validate_rule_inputs_log",
    "rule_input_validation_log",
    "assessment_run_log",
]

RULE_CATALOG = [
    {
        "id": "FIN-REV-001",
        "name": "Receivables growing faster than revenue",
        "category": "Revenue Quality",
        "severity": "High",
        "friendly": "Detects revenue that may not be converting into cash.",
        "default": True,
    },
    {
        "id": "FIN-REV-002",
        "name": "Related-party revenue concentration",
        "category": "Revenue Quality",
        "severity": "Medium",
        "friendly": "Checks whether revenue from related parties needs approval or review.",
        "default": True,
    },
    {
        "id": "FIN-REV-003",
        "name": "Period-end revenue concentration",
        "category": "Revenue Quality",
        "severity": "Medium",
        "friendly": "Looks for unusual revenue concentration close to the reporting date.",
        "default": True,
    },
    {
        "id": "FIN-REV-004",
        "name": "Revenue policy wording change",
        "category": "Narrative Review",
        "severity": "Medium",
        "friendly": "Compares current and prior revenue recognition wording.",
        "default": True,
    },
    {
        "id": "FIN-REV-005",
        "name": "Circular fund-flow check",
        "category": "Related Parties",
        "severity": "Critical",
        "friendly": "Looks for connected parties appearing as both revenue source and fund recipient.",
        "default": True,
    },
    {
        "id": "FIN-CSH-001",
        "name": "Profit-to-cash divergence",
        "category": "Cash Flow",
        "severity": "High",
        "friendly": "Highlights profit that is not supported by operating cash flow.",
        "default": True,
    },
    {
        "id": "FIN-CSH-002",
        "name": "Cash movement quality",
        "category": "Cash Flow",
        "severity": "Medium",
        "friendly": "Reviews whether cash movement depends on financing or unusual timing.",
        "default": True,
    },
    {
        "id": "FIN-AST-001",
        "name": "Inventory turnover decline",
        "category": "Assets",
        "severity": "Medium",
        "friendly": "Flags inventory build-up or slower inventory movement.",
        "default": True,
    },
    {
        "id": "FIN-AST-002",
        "name": "Intangible asset increase",
        "category": "Assets",
        "severity": "Medium",
        "friendly": "Checks whether intangible growth needs R&D or acquisition context.",
        "default": True,
    },
    {
        "id": "FIN-AST-003",
        "name": "Goodwill impairment pressure",
        "category": "Assets",
        "severity": "High",
        "friendly": "Combines goodwill intensity, market discount and impairment evidence.",
        "default": True,
    },
    {
        "id": "FIN-LIA-001",
        "name": "Related-party payable concentration",
        "category": "Liabilities",
        "severity": "High",
        "friendly": "Checks whether related-party payables are large versus liabilities.",
        "default": True,
    },
    {
        "id": "FIN-LIA-002",
        "name": "Provision and contingency movement",
        "category": "Liabilities",
        "severity": "High",
        "friendly": "Flags provision releases where contingency evidence exists.",
        "default": True,
    },
    {
        "id": "FIN-LIA-003",
        "name": "Off-balance-sheet guarantees",
        "category": "Liabilities",
        "severity": "Critical",
        "friendly": "Compares guarantee exposure from notes against total equity.",
        "default": True,
    },
    {
        "id": "FIN-OWN-001",
        "name": "Opaque ownership structure",
        "category": "Ownership",
        "severity": "High",
        "friendly": "Reviews ownership layers, opaque jurisdictions and missing commercial rationale.",
        "default": True,
    },
    {
        "id": "FIN-OWN-002",
        "name": "Control with weak oversight",
        "category": "Governance",
        "severity": "High",
        "friendly": "Checks control concentration against independent board oversight.",
        "default": True,
    },
    {
        "id": "FIN-CMP-001",
        "name": "Beneish proxy score",
        "category": "Composite",
        "severity": "High",
        "friendly": "Summarizes manipulation-risk indicators into a composite score.",
        "default": True,
    },
    {
        "id": "FIN-CMP-002",
        "name": "Altman Z-score distress",
        "category": "Composite",
        "severity": "Medium",
        "friendly": "Calculates financial distress context from working capital, earnings, leverage and sales.",
        "default": True,
    },
]

FRAUD_AREA_DEFINITIONS = [
    {
        "id": "revenue",
        "title": "Revenue Manipulation",
        "subtitle": "Revenue quality, timing, collection and related-party sales risk.",
        "rule_ids": {"FIN-REV-001", "FIN-REV-002", "FIN-REV-003", "FIN-REV-004", "FIN-REV-005"},
        "review_focus": "Validate revenue recognition, receivable ageing, collection evidence and related-party pricing.",
    },
    {
        "id": "cash",
        "title": "Cash Flow Quality",
        "subtitle": "Profit supported by weak cash conversion or temporary liquidity movements.",
        "rule_ids": {"FIN-CSH-001", "FIN-CSH-002"},
        "review_focus": "Compare net income, operating cash flow, debt drawdowns and period-end cash movements.",
    },
    {
        "id": "assets",
        "title": "Asset Overstatement",
        "subtitle": "Inventory, capitalisation, goodwill or intangible values that may be overstated.",
        "rule_ids": {"FIN-AST-001", "FIN-AST-002", "FIN-AST-003"},
        "review_focus": "Check turnover, capitalised costs, impairment testing, market indicators and valuation support.",
    },
    {
        "id": "liabilities",
        "title": "Liability Understatement",
        "subtitle": "Payables, provisions, contingencies or guarantees that may not be fully reflected.",
        "rule_ids": {"FIN-LIA-001", "FIN-LIA-002", "FIN-LIA-003"},
        "review_focus": "Review related-party balances, provision releases, contingencies and guarantee disclosures.",
    },
    {
        "id": "ownership",
        "title": "Ownership And Control Risk",
        "subtitle": "Opaque ownership layers, concentrated control or weak independent oversight.",
        "rule_ids": {"FIN-OWN-001", "FIN-OWN-002"},
        "review_focus": "Confirm beneficial ownership, board independence, control concentration and commercial rationale.",
    },
    {
        "id": "composite",
        "title": "Composite Manipulation Or Distress",
        "subtitle": "Combined earnings manipulation and financial distress indicators.",
        "rule_ids": {"FIN-CMP-001", "FIN-CMP-002"},
        "review_focus": "Use this as an escalation lens across accounting quality, leverage, profitability and solvency.",
    },
]

FRAUD_AREA_BY_RULE_ID = {
    rule_id: area
    for area in FRAUD_AREA_DEFINITIONS
    for rule_id in area["rule_ids"]
}

PIPELINE_STEPS = [
    ("Run created", "Assessment request registered"),
    ("Document uploaded", "Report stored in the managed Report folder"),
    ("Document ingestion", "Pages, chunks and document metadata prepared"),
    ("Field extraction", "Financial tables and narrative fields resolved"),
    ("Input validation", "Required rule inputs checked"),
    ("Rule execution", "Selected FSRE rules evaluated"),
    ("Report refresh", "Dashboard/report views updated"),
]

FLOW_DATASET_SEQUENCE = [
    "assessment_run_log",
    "document_ingestion_log",
    "03a_build_required_field_manifest_log",
    "03b_build_page_inventory_log",
    "03c_extract_financial_tables_log",
    "03d_resolve_financial_fields_log",
    "03e_extract_narrative_fields_ollama_log",
    "03f_validate_rule_inputs_log",
    "04_execute_rules_log",
]

DATASET_STEP_LABELS = {
    "assessment_run_log": ("Create Assessment Run", "Registers the assessment request and run context."),
    "document_ingestion_log": ("Ingest Report Document", "Loads uploaded report files and stores document metadata."),
    "03a_build_required_field_manifest_log": ("Prepare Rule Field Manifest", "Identifies the financial and narrative fields required by selected rules."),
    "03b_build_page_inventory_log": ("Build Page Inventory", "Classifies report pages so extraction can focus on relevant sections."),
    "03c_extract_financial_tables_log": ("Extract Financial Tables", "Reads statement tables and candidate numeric evidence from the report."),
    "03d_resolve_financial_fields_log": ("Resolve Financial Fields", "Maps extracted values to canonical FSRE financial fields."),
    "03e_extract_narrative_fields_ollama_log": ("Extract Narrative Evidence", "Extracts policy, notes and disclosure text needed by review rules."),
    "03f_validate_rule_inputs_log": ("Validate Rule Inputs", "Checks whether each selected rule has pass, warning, blocked or failed inputs."),
    "04_execute_rules_log": ("Execute Risk Rules", "Runs the FSRE rules and writes findings, scores and report-ready outputs."),
}

VISIBLE_PIPELINE_STAGES = [
    {
        "name": "Create Assessment Run",
        "detail": "Registers the assessment request and locks the run so it cannot be triggered twice.",
        "datasets": ["assessment_run_log"],
    },
    {
        "name": "Ingest Report",
        "detail": "Prepares uploaded report pages, metadata and extraction readiness checks.",
        "datasets": ["document_ingestion_log", "03a_build_required_field_manifest_log", "03b_build_page_inventory_log"],
    },
    {
        "name": "Extract Evidence",
        "detail": "Extracts financial tables, narrative disclosures and resolved FSRE fields.",
        "datasets": [
            "03c_extract_financial_tables_log",
            "03d_resolve_financial_fields_log",
            "03e_extract_narrative_fields_ollama_log",
        ],
    },
    {
        "name": "Validate Rule Inputs",
        "detail": "Checks that selected rules have the required evidence and input quality.",
        "datasets": ["03f_validate_rule_inputs_log"],
    },
    {
        "name": "Execute Risk Rules",
        "detail": "Runs selected FSRE rules and prepares findings for dashboard review.",
        "datasets": ["04_execute_rules_log"],
    },
]

RUN_LOCK = RLock()
ASSESSMENT_RUNS = {}
RUNNING_STATUSES = {"running", "started", "queued"}
REPORT_DATASET_LOAD_ERRORS: dict[str, str] = {}


def project_variables() -> dict[str, Any]:
    try:
        return dataiku.get_custom_variables()
    except Exception:
        return {}


def get_setting(name: str, default: str) -> str:
    value = project_variables().get(name)
    return str(value).strip() if value not in (None, "") else default


def company_logo_src() -> str:
    configured_url = get_setting("FSRE_COMPANY_LOGO_URL", "")
    if configured_url:
        return configured_url
    return "fsre-company-logo"


def company_brand_mark():
    logo_src = company_logo_src()
    if logo_src:
        return html.Img(src=logo_src, alt="Sciente", className="company-logo")
    return html.Div("F", className="mark")


def report_view_name(name: str) -> str:
    return REPORT_VIEW_NAMES.get(name, "")


def sql_identifier_path(identifier: str) -> str:
    parts = [part.strip() for part in str(identifier or "").split(".") if part.strip()]
    return ".".join('"' + part.replace('"', '""') + '"' for part in parts)


def load_report_view_with_sql_executor(name: str) -> pd.DataFrame:
    view_name = report_view_name(name)
    connection_name = get_setting("FSRE_POSTGRES_CONNECTION", get_setting("FSRE_POSTGRESQL_CONNECTION", "fsre_postgres"))
    if not view_name or not connection_name:
        return pd.DataFrame()
    try:
        executor = dataiku.SQLExecutor2(connection=connection_name)
        return executor.query_to_df(f"select * from {sql_identifier_path(view_name)}")
    except Exception as exc:
        REPORT_DATASET_LOAD_ERRORS[f"{name}_sql_executor"] = str(exc)
        return pd.DataFrame()


def postgres_setting(variables: dict[str, Any], dataiku_key: str, env_key: str, default: Optional[str] = None) -> Optional[str]:
    value = variables.get(dataiku_key)
    if value not in (None, ""):
        return str(value)
    value = variables.get(dataiku_key.upper())
    if value not in (None, ""):
        return str(value)
    return os.getenv(env_key, default)


def load_report_view_with_psycopg(name: str) -> pd.DataFrame:
    view_name = report_view_name(name)
    if not view_name:
        return pd.DataFrame()
    try:
        import psycopg2
    except Exception as exc:
        REPORT_DATASET_LOAD_ERRORS[f"{name}_psycopg_import"] = str(exc)
        return pd.DataFrame()

    variables = project_variables()
    conn = None
    try:
        conn = psycopg2.connect(
            host=postgres_setting(variables, "fsre_pg_host", "PGHOST", "fsre-postgres"),
            port=int(postgres_setting(variables, "fsre_pg_port", "PGPORT", "5432") or "5432"),
            dbname=postgres_setting(variables, "fsre_pg_database", "PGDATABASE", "fsre"),
            user=postgres_setting(variables, "fsre_pg_user", "PGUSER", "fsre_admin"),
            password=postgres_setting(variables, "fsre_pg_password", "PGPASSWORD", None),
        )
        return pd.read_sql_query(f"select * from {sql_identifier_path(view_name)}", conn)
    except Exception as exc:
        REPORT_DATASET_LOAD_ERRORS[f"{name}_psycopg"] = str(exc)
        return pd.DataFrame()
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass


def load_live_report_view(name: str) -> pd.DataFrame:
    df = load_report_view_with_sql_executor(name)
    if not df.empty:
        return df
    return load_report_view_with_psycopg(name)


def load_report_dataset(name: str, dataset_name: str) -> pd.DataFrame:
    live_df = load_live_report_view(name)
    if not live_df.empty:
        REPORT_DATASET_LOAD_ERRORS.pop(dataset_name, None)
        return live_df
    try:
        df = dataiku.Dataset(dataset_name).get_dataframe()
        if not df.empty:
            return df
        REPORT_DATASET_LOAD_ERRORS[dataset_name] = "Live PostgreSQL view and Dataiku dataset returned no rows."
    except Exception as exc:
        REPORT_DATASET_LOAD_ERRORS[dataset_name] = str(exc)
    return pd.DataFrame()


def load_report_data() -> dict[str, pd.DataFrame]:
    REPORT_DATASET_LOAD_ERRORS.clear()
    return {key: load_report_dataset(key, dataset_name) for key, dataset_name in REPORT_DATASET_NAMES.items()}


def load_first_available_dataset(dataset_names: list[str]) -> pd.DataFrame:
    for dataset_name in dataset_names:
        try:
            df = dataiku.Dataset(dataset_name).get_dataframe()
            if not df.empty:
                return df
        except Exception:
            continue
    return pd.DataFrame()


def safe_value(row, key: str, default: Any = "-"):
    if row is None:
        return default
    try:
        value = row.get(key, default)
    except Exception:
        return default
    if isinstance(value, pd.Series):
        values = [item for item in value.dropna().tolist() if item not in ("", None)]
        if not values:
            return default
        unique_values = []
        for item in values:
            text = str(item)
            if text not in unique_values:
                unique_values.append(text)
        return unique_values[0] if len(unique_values) == 1 else ", ".join(unique_values)
    if isinstance(value, pd.DataFrame):
        return default
    try:
        if pd.isna(value):
            return default
    except Exception:
        pass
    return value


def as_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {"true", "1", "yes", "y"}


def format_number(value: Any) -> str:
    try:
        if value in (None, "") or pd.isna(value):
            return "-"
        number = float(value)
        if number.is_integer():
            return str(int(number))
        return f"{number:.4f}".rstrip("0").rstrip(".")
    except Exception:
        return str(value) if value not in (None, "") else "-"


def format_confidence(value: Any) -> str:
    try:
        if value in (None, "") or pd.isna(value):
            return "-"
        number = float(value)
        if 0 <= number <= 1:
            number *= 100
        return f"{number:.0f}%"
    except Exception:
        return str(value) if value not in (None, "") else "-"


def has_value(value: Any) -> bool:
    if value is None:
        return False
    if isinstance(value, str):
        return value.strip() not in {"", "-", "None", "nan", "NaN", "null"}
    try:
        return not pd.isna(value)
    except Exception:
        return True


def parse_json_value(value: Any) -> Any:
    if not has_value(value):
        return None
    if isinstance(value, (dict, list)):
        return value
    text = str(value).strip()
    if not (text.startswith("{") or text.startswith("[")):
        return None
    try:
        return json.loads(text)
    except Exception:
        return None


def humanize_key(key: str) -> str:
    return str(key).replace("_", " ").replace(".", " ").title()


CONFIG_VALUE_LABELS = {
    "m_score_gt_threshold": "M-score is above threshold",
    "activated_by_user_request_requires_missing_input_handling": "Activated by user request; missing inputs require review handling",
    "extended_requested": "Extended rule set requested",
    "beneish_proxy_required_fields_v2": "Beneish proxy required fields v2",
}


def humanize_identifier(value: Any) -> str:
    if not has_value(value):
        return ""
    text = str(value).strip()
    if text in CONFIG_VALUE_LABELS:
        return CONFIG_VALUE_LABELS[text]
    words = text.replace(".", " ").replace("_", " ").split()
    abbreviations = {"m": "M", "sgx": "SGX", "rd": "R&D", "r&d": "R&D", "v2": "v2"}
    return " ".join(abbreviations.get(word.lower(), word.capitalize()) for word in words)


FIELD_LABEL_OVERRIDES = {
    "cogs": "Cost of goods sold",
    "cost_of_goods_sold": "Cost of goods sold",
    "rd_projects": "R&D projects",
    "ebit": "EBIT",
    "market_capitalisation": "Market capitalisation",
    "market_value_of_equity": "Market value of equity",
    "intangible_assets_and_goodwill": "Intangible assets and goodwill",
}


def friendly_config_value(key: str, value: Any) -> str:
    if not has_value(value):
        return ""
    key_text = str(key).strip().lower()
    if key_text in {"trigger_when", "activation_policy", "activation_group", "input_contract_version", "readiness_group"}:
        return humanize_identifier(value)
    if isinstance(value, bool):
        return "Yes" if value else "No"
    return short_value(value, 120)


def humanize_field_path(value: Any) -> str:
    if not has_value(value):
        return "-"
    text = str(value).strip()
    parts = text.split(".")
    period = ""
    if parts[-1].lower() in {"current", "prior", "next_period", "historical"} and len(parts) > 1:
        period = parts[-1].lower()
        leaf = parts[-2]
    else:
        leaf = parts[-1]
    label = FIELD_LABEL_OVERRIDES.get(leaf.lower(), humanize_identifier(leaf))
    if period:
        label += f" ({humanize_identifier(period)})"
    return label


def friendly_non_pass_inputs(value: Any) -> str:
    items = friendly_non_pass_input_items(value)
    return "; ".join(f"{field}: {status}" for field, status in items)


def friendly_input_status(value: Any) -> str:
    text = str(value or "").strip()
    mapping = {
        "warn": "Warning",
        "warning": "Warning",
        "blocked": "Blocked",
        "fail": "Failed",
        "failed": "Failed",
        "missing": "Missing",
        "pending": "Pending",
        "pass": "Passed",
    }
    return mapping.get(text.lower(), humanize_identifier(text))


def friendly_non_pass_input_items(value: Any) -> list[tuple[str, str]]:
    if not has_value(value) or str(value).strip().upper() == "NONE":
        return []
    parts = []
    for item in str(value).split(";"):
        item = item.strip()
        if not item:
            continue
        if "=" in item:
            field_path, status = [part.strip() for part in item.split("=", 1)]
            parts.append((humanize_field_path(field_path), friendly_input_status(status)))
        else:
            parts.append((humanize_field_path(item), "Needs review"))
    return parts


def evidence_field_label(row: dict[str, Any]) -> str:
    for key in ("field_alias", "field_name", "display_name"):
        value = safe_value(row, key, "")
        if has_value(value):
            return humanize_identifier(value)
    return humanize_field_path(safe_value(row, "field_path", ""))


def short_value(value: Any, limit: int = 120) -> str:
    if not has_value(value):
        return ""
    text = str(value).strip()
    if len(text) <= limit:
        return text
    return text[: limit - 3].rstrip() + "..."


def filter_report_run(df: pd.DataFrame, run_id: Optional[str]) -> pd.DataFrame:
    if df.empty or not run_id or "run_id" not in df.columns:
        return df.iloc[0:0].copy()
    return df[df["run_id"].astype(str) == str(run_id)].copy()


def report_summary_row(report_ctx: Optional[dict[str, Any]]) -> Any:
    if not report_ctx:
        return {}
    summary = report_ctx.get("summary")
    return summary if summary is not None else {}


def summary_int(summary: Any, key: str, default: int = 0) -> int:
    return as_int_value(safe_value(summary, key, default), default)


def report_detail_warning(report_ctx: Optional[dict[str, Any]], detail_name: str = "rule result") -> html.Div:
    run_id = (report_ctx or {}).get("run_id") or "-"
    errors = (report_ctx or {}).get("load_errors") or {}
    short_run = str(run_id)[:8] if run_id != "-" else "-"
    if errors:
        message = f"{detail_name.title()} details unavailable for run {short_run}. Refresh report datasets."
    else:
        message = f"{detail_name.title()} details not loaded for run {short_run}."
    return html.Div(message, className="empty-state compact")


def get_upload_folder_id() -> str:
    variables = project_variables()
    for name in (
        "FSRE_REPORT_UPLOAD_FOLDER_ID",
        "FSRE_REPORT_FOLDER_ID",
        "FSRE_ASSESSMENT_UPLOAD_FOLDER_ID",
    ):
        value = variables.get(name)
        if value not in (None, ""):
            return str(value).strip()
    return DEFAULT_FOLDER_ID


def get_upload_folder_label() -> str:
    return get_setting("FSRE_REPORT_UPLOAD_FOLDER_LABEL", "Report folder")


def get_company_logo_folder_id() -> str:
    return get_setting("FSRE_COMPANY_LOGO_FOLDER_ID", DEFAULT_LOGO_FOLDER_ID)


def get_company_logo_path() -> str:
    path = get_setting("FSRE_COMPANY_LOGO_PATH", DEFAULT_LOGO_PATH)
    return "/" + path.strip().lstrip("/")


def get_upload_path_prefix() -> str:
    prefix = get_setting("FSRE_REPORT_UPLOAD_PATH_PREFIX", "")
    return prefix.strip().strip("/")


def managed_folder_path(filename: str) -> str:
    safe_name = clean_filename(filename)
    prefix = get_upload_path_prefix()
    if prefix:
        return f"/{prefix}/{safe_name}"
    return f"/{safe_name}"


def get_scenario_id() -> str:
    return get_setting("FSRE_E2E_SCENARIO_ID", DEFAULT_SCENARIO_ID)


def get_report_dashboard_url() -> str:
    return get_setting("FSRE_REPORT_DASHBOARD_URL", "")


def clean_filename(filename: str) -> str:
    name = (filename or "uploaded_file").replace("\\", "/").rsplit("/", 1)[-1]
    name = re.sub(r"[^A-Za-z0-9._ -]+", "_", name).strip(" .")
    return name or "uploaded_file"


def extension(filename: str) -> str:
    return filename.rsplit(".", 1)[-1].lower() if "." in filename else ""


def decode_upload(contents: str) -> bytes:
    if not contents or "," not in contents:
        raise ValueError("Invalid upload payload.")
    _, encoded = contents.split(",", 1)
    return base64.b64decode(encoded)


def folder_file_rows(folder_id: str) -> list[dict[str, Any]]:
    try:
        folder = dataiku.Folder(folder_id)
        paths = folder.list_paths_in_partition()
    except Exception as exc:
        return [
            {
                "file_name": "Folder not accessible",
                "file_type": "-",
                "size": "-",
                "path": str(exc),
                "status": "error",
            }
        ]

    rows = []
    for path in sorted(paths):
        file_name = path.lstrip("/").rsplit("/", 1)[-1]
        ext = extension(file_name)
        rows.append(
            {
                "file_name": file_name,
                "file_type": ext.upper() if ext else "-",
                "size": "-",
                "path": path,
                "status": "ready" if ext in ALLOWED_EXTENSIONS else "ignored",
            }
        )
    return rows


def delete_existing_folder_path(folder: Any, normalized_path: str) -> None:
    candidates = [normalized_path, normalized_path.lstrip("/")]
    for candidate in candidates:
        if hasattr(folder, "delete_path"):
            try:
                folder.delete_path(candidate)
                return
            except Exception:
                pass
        if hasattr(folder, "delete_paths"):
            try:
                folder.delete_paths([candidate])
                return
            except Exception:
                pass


def upload_bytes_to_folder(folder_id: str, folder_path: str, file_bytes: bytes) -> str:
    folder = dataiku.Folder(folder_id)
    normalized_path = "/" + str(folder_path).lstrip("/")
    delete_existing_folder_path(folder, normalized_path)

    upload_errors = []
    if hasattr(folder, "upload_stream"):
        for candidate in (normalized_path.lstrip("/"), normalized_path):
            try:
                folder.upload_stream(candidate, io.BytesIO(file_bytes))
                return normalized_path
            except Exception as exc:
                upload_errors.append(exc)

    if hasattr(folder, "get_writer"):
        try:
            with folder.get_writer(normalized_path) as writer:
                writer.write(file_bytes)
            return normalized_path
        except Exception as exc:
            upload_errors.append(exc)

    if upload_errors:
        raise upload_errors[-1]
    raise RuntimeError("Managed folder does not expose a supported upload writer.")


def upload_file_stream_to_folder(folder_id: str, filename: str, file_stream: Any) -> str:
    folder = dataiku.Folder(folder_id)
    normalized_path = managed_folder_path(filename)
    delete_existing_folder_path(folder, normalized_path)

    upload_errors = []
    if hasattr(folder, "upload_stream"):
        for candidate in (normalized_path.lstrip("/"), normalized_path):
            try:
                if hasattr(file_stream, "seek"):
                    file_stream.seek(0)
                folder.upload_stream(candidate, file_stream)
                return normalized_path
            except Exception as exc:
                upload_errors.append(exc)

    if hasattr(file_stream, "seek"):
        file_stream.seek(0)
    return upload_bytes_to_folder(folder_id, normalized_path, file_stream.read())


def register_fast_upload_route() -> None:
    server = getattr(app, "server", None)
    if server is None or request is None or jsonify is None:
        return
    if getattr(server, "_fsre_fast_upload_registered", False):
        return

    @server.route("/fsre-fast-upload", methods=["POST"])
    def fsre_fast_upload():
        uploaded_files = request.files.getlist("files") or request.files.getlist("file")
        if not uploaded_files:
            return jsonify({"ok": False, "error": "No files were received."}), 400

        folder_id = get_upload_folder_id()
        results = []
        for upload in uploaded_files:
            safe_name = clean_filename(upload.filename or "uploaded_file")
            ext = extension(safe_name)
            if ext not in ALLOWED_EXTENSIONS:
                results.append({"file": safe_name, "ok": False, "error": "Unsupported file type."})
                continue
            try:
                written_path = upload_file_stream_to_folder(folder_id, safe_name, upload.stream)
                results.append({"file": safe_name, "ok": True, "path": written_path})
            except Exception as exc:
                results.append({"file": safe_name, "ok": False, "error": str(exc)})

        ok_count = sum(1 for item in results if item.get("ok"))
        status_code = 200 if ok_count else 500
        return jsonify(
            {
                "ok": ok_count > 0,
                "uploaded_count": ok_count,
                "folder_id": folder_id,
                "folder_label": get_upload_folder_label(),
                "results": results,
            }
        ), status_code

    server._fsre_fast_upload_registered = True


def register_company_logo_route() -> None:
    server = getattr(app, "server", None)
    if server is None or Response is None:
        return
    if getattr(server, "_fsre_company_logo_registered", False):
        return

    @server.route("/fsre-company-logo", methods=["GET"])
    def fsre_company_logo():
        folder = dataiku.Folder(get_company_logo_folder_id())
        logo_path = get_company_logo_path()
        errors = []
        for candidate in (logo_path, logo_path.lstrip("/")):
            try:
                with folder.get_download_stream(candidate) as stream:
                    payload = stream.read()
                response = Response(payload, mimetype="image/jpeg")
                response.headers["Cache-Control"] = "public, max-age=3600"
                return response
            except Exception as exc:
                errors.append(exc)
        return Response(
            "Company logo not found in the configured Dataiku managed folder.",
            status=404,
            mimetype="text/plain",
        )

    server._fsre_company_logo_registered = True


def register_report_pdf_route() -> None:
    server = getattr(app, "server", None)
    if server is None or request is None or Response is None:
        return
    if getattr(server, "_fsre_report_pdf_registered", False):
        return

    @server.route("/fsre-report-file", methods=["GET"])
    def fsre_report_file():
        requested_path = str(request.args.get("path") or "").strip().replace("\\", "/")
        if not requested_path or ".." in requested_path.split("/") or extension(requested_path) != "pdf":
            return Response("A valid PDF report path is required.", status=400, mimetype="text/plain")
        normalized_path = "/" + requested_path.lstrip("/")
        folder = dataiku.Folder(get_upload_folder_id())
        errors = []
        for candidate in (normalized_path, normalized_path.lstrip("/")):
            try:
                with folder.get_download_stream(candidate) as stream:
                    payload = stream.read()
                response = Response(payload, mimetype="application/pdf")
                response.headers["Content-Disposition"] = f'inline; filename="{clean_filename(normalized_path.rsplit("/", 1)[-1])}"'
                response.headers["Cache-Control"] = "private, max-age=300"
                return response
            except Exception as exc:
                errors.append(exc)
        return Response("Annual report PDF was not found in the managed upload folder.", status=404, mimetype="text/plain")

    server._fsre_report_pdf_registered = True


register_fast_upload_route()
register_company_logo_route()
register_report_pdf_route()


def start_scenario(scenario_id: str) -> dict[str, Any]:
    client = dataiku.api_client()
    try:
        project = client.get_default_project()
    except Exception:
        project = client.get_project(dataiku.default_project_key())

    scenario = project.get_scenario(scenario_id)
    run = scenario.run()
    run_info = {}
    try:
        run_info = run.get_info()
    except Exception:
        run_info = {}

    scenario_run_id = (
        getattr(run, "id", None)
        or getattr(run, "run_id", None)
        or run_info.get("id")
        or run_info.get("runId")
        or "started"
    )
    return {
        "scenario_id": scenario_id,
        "scenario_run_id": scenario_run_id,
        "started_at": datetime.utcnow().isoformat(timespec="seconds") + "Z",
        "status": "started",
        "trigger_mode": "scenario",
    }


def wait_for_job(job: Any) -> None:
    if job is None:
        return
    if hasattr(job, "wait_for_result"):
        job.wait_for_result()
        return
    if hasattr(job, "wait"):
        job.wait()


def build_dataset_direct(project: Any, dataset_name: str) -> None:
    dataset = project.get_dataset(dataset_name)
    errors = []

    for kwargs in (
        {"job_type": "NON_RECURSIVE_FORCED_BUILD"},
        {"build_mode": "NON_RECURSIVE_FORCED_BUILD"},
        {},
    ):
        if not hasattr(dataset, "build"):
            break
        try:
            wait_for_job(dataset.build(**kwargs))
            return
        except TypeError as exc:
            errors.append(str(exc))
        except Exception as exc:
            errors.append(str(exc))
            continue

    project_key = getattr(project, "project_key", "") or dataiku.default_project_key()
    output_targets = [
        [{"type": "DATASET", "id": dataset_name}],
        [{"type": "DATASET", "projectKey": project_key, "id": dataset_name}],
    ]
    job_definitions = []
    for outputs in output_targets:
        job_definitions.extend(
            [
                {"type": "NON_RECURSIVE_FORCED_BUILD", "outputs": outputs},
                {"jobType": "NON_RECURSIVE_FORCED_BUILD", "outputs": outputs},
                {"type": "NON_RECURSIVE_FORCED_BUILD", "output": outputs[0]},
            ]
        )

    for job_definition in job_definitions:
        try:
            wait_for_job(project.start_job(job_definition))
            return
        except TypeError as exc:
            errors.append(str(exc))
        except Exception as exc:
            errors.append(str(exc))

    unique_errors = []
    for error in errors:
        if error not in unique_errors:
            unique_errors.append(error)
    raise RuntimeError(f"Could not build dataset {dataset_name}: {' | '.join(unique_errors[-5:])}")


def start_direct_flow_build() -> dict[str, Any]:
    client = dataiku.api_client()
    try:
        project = client.get_default_project()
    except Exception:
        project = client.get_project(dataiku.default_project_key())

    completed = []
    for dataset_name in FLOW_DATASET_SEQUENCE:
        build_dataset_direct(project, dataset_name)
        completed.append(dataset_name)

    return {
        "scenario_id": "direct-flow-build",
        "scenario_run_id": "direct-" + datetime.utcnow().strftime("%Y%m%d%H%M%S"),
        "started_at": datetime.utcnow().isoformat(timespec="seconds") + "Z",
        "status": "completed",
        "trigger_mode": "direct_flow_build",
        "completed_datasets": completed,
    }


def get_tracked_run(run_id: str) -> dict[str, Any]:
    with RUN_LOCK:
        state = ASSESSMENT_RUNS.get(run_id) or {}
        return dict(state)


def active_run_state() -> Optional[dict[str, Any]]:
    with RUN_LOCK:
        for state in ASSESSMENT_RUNS.values():
            if state.get("status") == "running":
                return dict(state)
    return None


def update_tracked_run(tracked_run_id: str, **updates) -> None:
    with RUN_LOCK:
        state = ASSESSMENT_RUNS.setdefault(tracked_run_id, {})
        state.update(updates)


def get_default_project():
    client = dataiku.api_client()
    try:
        return client.get_default_project()
    except Exception:
        return client.get_project(dataiku.default_project_key())


def project_standard_variables() -> dict[str, Any]:
    try:
        project = get_default_project()
        variables = project.get_variables()
        return variables.get("standard", {}) or {}
    except Exception:
        return {}


def as_int_value(value: Any, default: int = 0) -> int:
    try:
        if value in (None, ""):
            return default
        return int(value)
    except Exception:
        return default


def project_run_state() -> Optional[dict[str, Any]]:
    variables = project_standard_variables()
    ui_status = str(variables.get("FSRE_ASSESSMENT_RUN_STATUS", "")).lower()
    scenario_status = str(variables.get("fsre_e2e_status", "")).lower()
    status = ui_status or scenario_status
    if not status:
        return None
    updated_at = variables.get("FSRE_ASSESSMENT_RUN_UPDATED_AT")
    if status in {"completed", "failed"} and updated_at:
        try:
            updated = datetime.fromisoformat(str(updated_at).replace("Z", "+00:00"))
            if updated.tzinfo is None:
                updated = updated.replace(tzinfo=timezone.utc)
            if datetime.now(timezone.utc) - updated > timedelta(hours=12):
                return None
        except Exception:
            pass

    completed_raw = str(variables.get("FSRE_ASSESSMENT_COMPLETED_DATASETS", "") or "")
    completed = [item for item in completed_raw.split(",") if item]
    run_id = variables.get("FSRE_ASSESSMENT_RUN_ID", "-")
    return {
        "status": "running" if status in RUNNING_STATUSES else status,
        "run_id": run_id,
        "scenario_run_id": run_id,
        "started_at": variables.get("FSRE_ASSESSMENT_RUN_STARTED_AT", "-"),
        "completed_at": variables.get("FSRE_ASSESSMENT_RUN_COMPLETED_AT", ""),
        "current_dataset": variables.get("FSRE_ASSESSMENT_CURRENT_DATASET", ""),
        "current_report": variables.get("FSRE_ASSESSMENT_CURRENT_REPORT", ""),
        "report_index": as_int_value(variables.get("FSRE_ASSESSMENT_REPORT_INDEX"), 0),
        "report_count": as_int_value(variables.get("FSRE_ASSESSMENT_REPORT_COUNT"), 0),
        "completed_datasets": completed,
        "completed_count": as_int_value(variables.get("FSRE_ASSESSMENT_COMPLETED_COUNT"), len(completed)),
        "total_count": as_int_value(variables.get("FSRE_ASSESSMENT_TOTAL_COUNT"), len(FLOW_DATASET_SEQUENCE)),
        "trigger_mode": variables.get("FSRE_ASSESSMENT_TRIGGER_MODE", ""),
        "database_run_id": variables.get("FSRE_ASSESSMENT_DB_RUN_ID", ""),
        "result_warning": variables.get("FSRE_ASSESSMENT_RESULT_WARNING", ""),
        "result_warning_run_id": variables.get("FSRE_ASSESSMENT_RESULT_WARNING_RUN_ID", ""),
        "error": variables.get("FSRE_ASSESSMENT_ERROR", ""),
        "message": "Backend assessment run state restored from Dataiku project variables.",
    }


def active_project_run_state() -> Optional[dict[str, Any]]:
    state = project_run_state()
    if state and state.get("status") in RUNNING_STATUSES:
        return state
    return None


def set_project_run_lock(run_id: str, status: str, **extra) -> Optional[str]:
    try:
        project = get_default_project()
        variables = project.get_variables()
        standard = variables.setdefault("standard", {})
        previous_run_id = str(standard.get("FSRE_ASSESSMENT_RUN_ID") or "")
        is_new_run = bool(run_id) and previous_run_id != str(run_id)
        now = datetime.utcnow().isoformat(timespec="seconds") + "Z"
        if status == "running" and is_new_run:
            standard["FSRE_ASSESSMENT_RUN_STARTED_AT"] = now
            standard["FSRE_ASSESSMENT_RUN_COMPLETED_AT"] = ""
            standard["FSRE_ASSESSMENT_ERROR"] = ""
            standard["FSRE_ASSESSMENT_RESULT_WARNING"] = ""
            standard["FSRE_ASSESSMENT_RESULT_WARNING_RUN_ID"] = ""
            standard["FSRE_ASSESSMENT_CURRENT_DATASET"] = ""
            standard["FSRE_ASSESSMENT_COMPLETED_DATASETS"] = ""
            standard["FSRE_ASSESSMENT_COMPLETED_COUNT"] = "0"
            standard["FSRE_ASSESSMENT_DB_RUN_ID"] = ""
        standard["FSRE_ASSESSMENT_RUN_ID"] = run_id
        standard["FSRE_ASSESSMENT_RUN_STATUS"] = status
        standard["FSRE_ASSESSMENT_RUN_UPDATED_AT"] = now
        if status == "running" and not standard.get("FSRE_ASSESSMENT_RUN_STARTED_AT"):
            standard["FSRE_ASSESSMENT_RUN_STARTED_AT"] = now
        if status in {"completed", "failed"}:
            standard["FSRE_ASSESSMENT_RUN_COMPLETED_AT"] = now
            standard["FSRE_ASSESSMENT_CURRENT_DATASET"] = ""
        for key, value in extra.items():
            standard[key] = "" if value is None else str(value)
        project.set_variables(variables)
        return None
    except Exception as exc:
        return str(exc)


def build_flow_sequence_tracked(
    run_id: str,
    report_path: str = "",
    report_index: int = 1,
    report_count: int = 1,
    completed_offset: int = 0,
) -> None:
    client = dataiku.api_client()
    try:
        project = client.get_default_project()
    except Exception:
        project = client.get_project(dataiku.default_project_key())

    completed = []
    total_steps = len(FLOW_DATASET_SEQUENCE) * report_count
    report_name = report_display_name(report_path) or f"Report {report_index}"
    for dataset_name in FLOW_DATASET_SEQUENCE:
        overall_completed = completed_offset + len(completed)
        set_project_run_lock(
            run_id,
            "running",
            FSRE_ASSESSMENT_CURRENT_DATASET=dataset_name,
            FSRE_ASSESSMENT_COMPLETED_DATASETS=",".join(completed),
            FSRE_ASSESSMENT_COMPLETED_COUNT=overall_completed,
            FSRE_ASSESSMENT_TOTAL_COUNT=total_steps,
            FSRE_ASSESSMENT_CURRENT_REPORT=report_name,
            FSRE_ASSESSMENT_REPORT_INDEX=report_index,
            FSRE_ASSESSMENT_REPORT_COUNT=report_count,
        )
        update_tracked_run(
            run_id,
            status="running",
            current_dataset=dataset_name,
            completed_datasets=completed[:],
            completed_count=overall_completed,
            total_count=total_steps,
            current_report=report_name,
            report_index=report_index,
            report_count=report_count,
            message=f"Processing report {report_index} of {report_count}: {report_name}",
        )
        build_dataset_direct(project, dataset_name)
        completed.append(dataset_name)
        overall_completed = completed_offset + len(completed)
        set_project_run_lock(
            run_id,
            "running",
            FSRE_ASSESSMENT_CURRENT_DATASET="",
            FSRE_ASSESSMENT_COMPLETED_DATASETS=",".join(completed),
            FSRE_ASSESSMENT_COMPLETED_COUNT=overall_completed,
            FSRE_ASSESSMENT_TOTAL_COUNT=total_steps,
        )
        update_tracked_run(
            run_id,
            completed_datasets=completed[:],
            completed_count=overall_completed,
            current_dataset=None,
        )


def verify_database_assessment(
    previous_database_run_id: str,
    expected_report_count: int,
) -> tuple[str, int, str]:
    last_reason = "No database assessment output was found."
    for _ in range(15):
        variables = project_standard_variables()
        database_run_id = str(
            variables.get("FSRE_ASSESSMENT_DB_RUN_ID")
            or variables.get("FSRE_LAST_DATABASE_RUN_ID")
            or ""
        ).strip()
        if not database_run_id or database_run_id == previous_database_run_id:
            last_reason = "Recipe 01 did not create a new database run."
            time.sleep(2)
            continue

        report_data = load_report_data()
        rules_df = filter_report_run(report_data.get("rules", pd.DataFrame()), database_run_id)
        summary_df = filter_report_run(report_data.get("summary", pd.DataFrame()), database_run_id)
        if rules_df.empty:
            last_reason = f"Database run {database_run_id} has no rule-result rows."
            time.sleep(2)
            continue

        document_count = 0
        if not summary_df.empty:
            document_count = as_int_value(summary_df.iloc[0].get("document_count"), 0)
        if not document_count and "source_documents" in rules_df.columns:
            source_names = set()
            for _, row in rules_df.iterrows():
                source_names.update(row_source_file_names(row))
            document_count = len(source_names)
        if expected_report_count > 1 and document_count != expected_report_count:
            raise RuntimeError(
                f"Database run {database_run_id} contains {document_count} document(s); "
                f"{expected_report_count} were selected. Deploy the grouped multi-document "
                "recipe before running again."
            )
        return database_run_id, document_count, ""
    if database_run_id and database_run_id != previous_database_run_id:
        return database_run_id, 0, last_reason
    raise RuntimeError(last_reason)


def assessment_worker(
    run_id: str,
    scenario_id: str,
    company: str,
    report_paths: list[str],
    rule_ids: list[str],
) -> None:
    try:
        previous_database_run_id = str(
            project_standard_variables().get("FSRE_ASSESSMENT_DB_RUN_ID")
            or project_standard_variables().get("FSRE_LAST_DATABASE_RUN_ID")
            or ""
        ).strip()
        set_project_run_lock(run_id, "running", FSRE_ASSESSMENT_CURRENT_DATASET="starting")
        context_warning = persist_assessment_context(company, report_paths, rule_ids)
        if context_warning:
            raise RuntimeError(f"Could not set multi-report assessment context: {context_warning}")
        if len(report_paths) == 1:
            try:
                result = start_scenario(scenario_id)
                set_project_run_lock(
                    run_id,
                    "running",
                    FSRE_ASSESSMENT_TRIGGER_MODE="scenario",
                    FSRE_ASSESSMENT_CURRENT_DATASET="scenario_started",
                )
                update_tracked_run(
                    run_id,
                    **result,
                    status="running",
                    message="Scenario trigger accepted by Dataiku.",
                )
                return
            except Exception as exc:
                message = str(exc)
                if "LicenseRestrictionException" not in message and "Automated triggering of scenarios" not in message:
                    raise
                update_tracked_run(
                    run_id,
                    scenario_warning=message,
                    trigger_mode="direct_flow_build",
                    message="Scenario trigger blocked by license; running the direct assessment pipeline.",
                )

        report_count = len(report_paths)
        report_label = ", ".join(report_display_name(path) for path in report_paths)
        build_flow_sequence_tracked(
            run_id,
            report_path=report_label,
            report_index=1,
            report_count=1,
            completed_offset=0,
        )
        database_run_id, document_count, result_warning = verify_database_assessment(
            previous_database_run_id,
            report_count,
        )
        update_tracked_run(
            run_id,
            status="completed",
            scenario_id="direct-flow-build",
            scenario_run_id=run_id,
            trigger_mode="direct_flow_build",
            completed_at=datetime.utcnow().isoformat(timespec="seconds") + "Z",
            report_count=report_count,
            database_run_id=database_run_id,
            document_count=document_count,
            result_warning=result_warning,
            result_warning_run_id=database_run_id if result_warning else "",
            message=(
                f"One assessment run completed with {report_count} report(s). "
                "Rule result rows are still pending."
                if result_warning
                else f"One assessment run completed with {report_count} report(s)."
            ),
        )
        total_steps = len(FLOW_DATASET_SEQUENCE)
        set_project_run_lock(
            run_id,
            "completed",
            FSRE_ASSESSMENT_TRIGGER_MODE="direct_flow_build",
            FSRE_ASSESSMENT_COMPLETED_COUNT=total_steps,
            FSRE_ASSESSMENT_TOTAL_COUNT=total_steps,
            FSRE_ASSESSMENT_REPORT_COUNT=report_count,
            FSRE_ASSESSMENT_DB_RUN_ID=database_run_id,
            FSRE_ASSESSMENT_RESULT_WARNING=result_warning,
            FSRE_ASSESSMENT_RESULT_WARNING_RUN_ID=database_run_id if result_warning else "",
        )
    except Exception as exc:
        update_tracked_run(
            run_id,
            status="failed",
            error=str(exc),
            completed_at=datetime.utcnow().isoformat(timespec="seconds") + "Z",
        )
        set_project_run_lock(
            run_id,
            "failed",
            FSRE_ASSESSMENT_ERROR=str(exc),
        )


def start_assessment_pipeline(scenario_id: str) -> tuple[dict[str, Any], Optional[str]]:
    try:
        return start_scenario(scenario_id), None
    except Exception as exc:
        message = str(exc)
        if "LicenseRestrictionException" not in message and "Automated triggering of scenarios" not in message:
            raise
        result = start_direct_flow_build()
        return result, message


def selected_report_paths(report_path: Any) -> list[str]:
    if report_path in (None, ""):
        return []
    if isinstance(report_path, (list, tuple)):
        return [str(item) for item in report_path if item not in (None, "")]
    return [str(report_path)]


def primary_report_path(report_path: Any) -> str:
    paths = selected_report_paths(report_path)
    return paths[0] if paths else ""


def selected_report_count_text(report_path: Any) -> str:
    count = len(selected_report_paths(report_path))
    return f"{count} report{'s' if count != 1 else ''}"


def persist_assessment_context(company: str, report_path: Any, rule_ids: list[str]) -> Optional[str]:
    try:
        client = dataiku.api_client()
        try:
            project = client.get_default_project()
        except Exception:
            project = client.get_project(dataiku.default_project_key())
        variables = project.get_variables()
        standard = variables.setdefault("standard", {})
        report_paths = selected_report_paths(report_path)[:3]
        standard["FSRE_SELECTED_COMPANY"] = company or ""
        standard["FSRE_SELECTED_REPORT_PATH"] = report_paths[0] if report_paths else ""
        standard["FSRE_SELECTED_REPORT_PATHS"] = json.dumps(report_paths)
        standard["FSRE_SELECTED_REPORT_COUNT"] = str(len(report_paths))
        standard["FSRE_SELECTED_RULE_IDS"] = ",".join(rule_ids or [])
        standard["FSRE_ASSESSMENT_REQUESTED_AT"] = datetime.utcnow().isoformat(timespec="seconds") + "Z"
        project.set_variables(variables)
        return None
    except Exception as exc:
        return str(exc)


def status_tag(text: str, tone: str = "neutral"):
    return html.Span(text, className=f"tag {tone}")


def pipeline_stage_for_dataset(dataset_name: str) -> tuple[str, str]:
    if dataset_name == "starting":
        return "Starting Assessment", "Preparing the assessment pipeline."
    if dataset_name == "scenario_started":
        return "Pipeline Triggered", "Dataiku accepted the scenario trigger."
    for stage in VISIBLE_PIPELINE_STAGES:
        if dataset_name in stage["datasets"]:
            return stage["name"], stage["detail"]
    display_name, display_detail = DATASET_STEP_LABELS.get(dataset_name, ("Pipeline Step", "Assessment pipeline is processing."))
    return display_name, display_detail


def visible_stage_progress(run_state: dict[str, Any]) -> tuple[int, int, str]:
    completed = set((run_state or {}).get("completed_datasets") or [])
    current_dataset = (run_state or {}).get("current_dataset") or ""
    completed_stages = 0
    current_stage_name = ""
    next_stage_name = ""
    for stage in VISIBLE_PIPELINE_STAGES:
        stage_datasets = set(stage["datasets"])
        if stage_datasets and stage_datasets.issubset(completed):
            completed_stages += 1
        elif current_dataset in stage_datasets:
            current_stage_name = stage["name"]
        elif not next_stage_name:
            next_stage_name = stage["name"]
    if not current_stage_name and current_dataset:
        current_stage_name, _ = pipeline_stage_for_dataset(current_dataset)
    if not current_stage_name and next_stage_name:
        current_stage_name = f"Preparing {next_stage_name}"
    if not current_stage_name and completed_stages >= len(VISIBLE_PIPELINE_STAGES):
        current_stage_name = "Finalizing report results"
    return completed_stages, len(VISIBLE_PIPELINE_STAGES), current_stage_name


def user_friendly_pipeline_error(error: str) -> str:
    message = str(error or "Unknown error")
    for dataset_name, (display_name, _) in DATASET_STEP_LABELS.items():
        message = message.replace(f"dataset {dataset_name}", f"step {display_name}")
        message = message.replace(dataset_name, display_name)
    return message


def file_queue_table(rows: list[dict[str, Any]]):
    if not rows:
        return html.Div("No files uploaded yet.", className="empty-state")
    return html.Table(
        className="file-table",
        children=[
            html.Thead(
                html.Tr(
                    [
                        html.Th("File"),
                        html.Th("Company"),
                        html.Th("Type"),
                        html.Th("Status"),
                    ]
                )
            ),
            html.Tbody(
                [
                    html.Tr(
                        [
                            html.Td([html.Strong(row["file_name"]), html.Small(row["path"])]),
                            html.Td(infer_company_from_report_path(row.get("path") or row.get("file_name")) or "-"),
                            html.Td(row["file_type"]),
                            html.Td(status_tag(row["status"], "low" if row["status"] == "ready" else "medium")),
                        ]
                    )
                    for row in rows
                ]
            ),
        ],
    )


def uploaded_reports_panel(rows: list[dict[str, Any]]):
    ready_count = sum(1 for row in rows if row.get("status") == "ready")
    total_count = len(rows)
    summary_text = f"{ready_count} ready report(s)" if total_count else "No uploaded reports"
    return html.Details(
        open=True,
        className="report-switcher",
        children=[
            html.Summary(
                children=[
                    html.Span("Uploaded Reports"),
                    html.Strong(summary_text),
                ],
                title="Expand to view uploaded report files.",
            ),
            html.Div(
                className="report-switcher-body",
                children=[
                    html.Div(
                        className="report-switcher-summary",
                        children=[
                            html.Div([html.Span("Ready"), html.Strong(str(ready_count))]),
                            html.Div([html.Span("Total"), html.Strong(str(total_count))]),
                        ],
                    ),
                    file_queue_table(rows),
                ],
            ),
        ],
    )


def upload_progress_card(file_name: str, folder_label: str, folder_id: str, written_path: str, replaced: bool):
    status_text = "Replaced existing report" if replaced else "Uploaded new report"
    return html.Div(
        className="upload-progress-card",
        children=[
            html.Div(
                className="upload-progress-head",
                children=[
                    html.Strong(file_name),
                    status_tag(status_text, "low"),
                ],
            ),
            html.Div(
                className="progress-bar complete",
                children=html.Div(className="progress-fill", style={"width": "100%"}),
            ),
            html.Div(
                f"100% complete - stored in managed folder {folder_label} ({folder_id}) at {written_path}.",
                className="upload-progress-meta",
            ),
        ],
    )


def ready_report_options(rows: list[dict[str, Any]]) -> list[dict[str, str]]:
    options = []
    for row in rows:
        if row.get("status") != "ready":
            continue
        company = infer_company_from_report_path(row.get("path") or row.get("file_name"))
        label = f"{company} / {row['file_name']}" if company else row["file_name"]
        options.append({"label": label, "value": row["path"]})
    return options


def default_rule_ids() -> list[str]:
    return [rule["id"] for rule in RULE_CATALOG if rule["default"]]


def rule_categories() -> list[dict[str, str]]:
    categories = sorted({rule["category"] for rule in RULE_CATALOG})
    return [{"label": "All categories", "value": "all"}] + [{"label": item, "value": item} for item in categories]


def rule_severities() -> list[dict[str, str]]:
    severities = ["Critical", "High", "Medium"]
    return [{"label": "All severities", "value": "all"}] + [{"label": item, "value": item} for item in severities]


def rule_options(category: str = "all", severity: str = "all") -> list[dict[str, Any]]:
    category = category or "all"
    severity = severity or "all"
    visible_rules = [
        rule
        for rule in RULE_CATALOG
        if (category == "all" or rule["category"] == category)
        and (severity == "all" or rule["severity"] == severity)
    ]
    return [
        {
            "label": html.Div(
                className="rule-option",
                children=[
                    html.Div(
                        [
                            html.Strong(f"{rule['id']} - {rule['name']}"),
                            html.Span(rule["friendly"]),
                        ]
                    ),
                    status_tag(rule["severity"], "high" if rule["severity"] in {"Critical", "High"} else "medium"),
                ],
            ),
            "value": rule["id"],
        }
        for rule in visible_rules
    ]


def selected_rule_details(rule_ids: list[str]) -> list[dict[str, Any]]:
    selected = set(rule_ids or [])
    return [rule for rule in RULE_CATALOG if rule["id"] in selected]


def report_display_name(report_path: Any) -> str:
    report_path = primary_report_path(report_path)
    if not report_path:
        return "selected report"
    return str(report_path).lstrip("/").rsplit("/", 1)[-1] or "selected report"


GENERIC_FILE_NAME_TOKENS = {
    "annual",
    "ar",
    "financial",
    "final",
    "full",
    "fy",
    "integrated",
    "interim",
    "limited",
    "ltd",
    "plc",
    "report",
    "reports",
    "statement",
    "statements",
    "sustainability",
}


def display_entity_name(value: str) -> str:
    words = []
    for word in re.split(r"\s+", value.strip()):
        if word:
            words.append(word.upper() if len(word) <= 4 else word.capitalize())
    return " ".join(words)


def infer_company_from_report_path(report_path: Any) -> str:
    report_path = primary_report_path(report_path)
    if not report_path:
        return ""
    file_name = report_display_name(report_path)
    stem = file_name.rsplit(".", 1)[0]
    stem = re.sub(r"[_\-+.]+", " ", stem)
    tokens = []
    for token in re.split(r"\s+", stem):
        cleaned = re.sub(r"[^A-Za-z0-9&]+", "", token).strip()
        if not cleaned:
            continue
        lower = cleaned.lower()
        if re.fullmatch(r"20\d{2}", cleaned) or re.fullmatch(r"\d{2}", cleaned):
            continue
        if re.fullmatch(r"ar\d{2,4}", lower) or re.fullmatch(r"fy\d{2,4}", lower) or re.fullmatch(r"h[12]fy\d{2,4}", lower):
            continue
        if lower in GENERIC_FILE_NAME_TOKENS:
            continue
        tokens.append(cleaned)
    return display_entity_name(" ".join(tokens))


def infer_company_from_report_paths(report_path: Any) -> str:
    inferred = [
        infer_company_from_report_path(path)
        for path in selected_report_paths(report_path)
    ]
    inferred = [company for company in inferred if company]
    if not inferred:
        return ""
    counts = {}
    for company in inferred:
        counts[company] = counts.get(company, 0) + 1
    return sorted(counts.items(), key=lambda item: (-item[1], item[0]))[0][0]


def infer_company_from_report_text(value: Any) -> str:
    text = str(value or "")
    if not text.strip():
        return ""
    candidates = re.findall(r'[^,;|\[\]"]+?\.pdf', text, flags=re.IGNORECASE)
    if not candidates and ".pdf" in text.lower():
        candidates = [text]
    return infer_company_from_report_paths(candidates)


def resolve_company_selection(company: str, report_path: Any) -> str:
    inferred = infer_company_from_report_paths(report_path)
    if str(company or "").strip().lower() in {"", "auto", "auto from selected report"}:
        return inferred or "Configured default"
    return company or inferred or "Configured default"


def sort_report_runs(summary_df: pd.DataFrame) -> pd.DataFrame:
    if summary_df.empty:
        return summary_df
    for column in ("latest_rule_result_at", "completed_at", "started_at", "created_at"):
        if column in summary_df.columns:
            return summary_df.sort_values(column, ascending=False, na_position="last")
    return summary_df


def run_has_rule_results(report_data: dict[str, pd.DataFrame], run_id: Optional[str]) -> bool:
    if not run_id:
        return False
    rules_df = report_data.get("rules", pd.DataFrame())
    if not rules_df.empty and "run_id" in rules_df.columns:
        if not filter_report_run(rules_df, run_id).empty:
            return True
    summary_df = report_data.get("summary", pd.DataFrame())
    if not summary_df.empty and "run_id" in summary_df.columns:
        row_df = filter_report_run(summary_df, run_id)
        if not row_df.empty:
            row = row_df.iloc[0]
            for column in ("rule_result_count", "total_rule_count", "calculated_or_reviewable_rules", "included_rule_count"):
                if column in row_df.columns and as_int_value(row.get(column), 0) > 0:
                    return True
    return False


def latest_job_run_id_from_outputs() -> Optional[str]:
    df = load_first_available_dataset(JOB_RESULT_DATASET_CANDIDATES)
    if df.empty or "run_id" not in df.columns:
        return None
    sorted_df = df
    for column in ("created_at", "completed_at", "started_at"):
        if column in df.columns:
            sorted_df = df.sort_values(column, ascending=False, na_position="last")
            break
    for value in sorted_df["run_id"].dropna().astype(str):
        if value and not value.startswith("direct-"):
            return value
    return None


def row_source_file_names(row) -> set[str]:
    documents = parse_json_value(safe_value(row, "source_documents", []))
    if isinstance(documents, dict):
        documents = [documents]
    names = set()
    for document in documents if isinstance(documents, list) else []:
        if isinstance(document, dict):
            name = str(document.get("file_name") or document.get("filename") or "").strip()
            if name:
                names.add(name.lower())
    return names


def report_run_ids_for_files(report_data: dict[str, pd.DataFrame], report_path: Any) -> list[str]:
    selected_names = {
        report_display_name(path).strip().lower()
        for path in selected_report_paths(report_path)
        if report_display_name(path).strip()
    }
    rules_df = report_data.get("rules", pd.DataFrame())
    if not selected_names or rules_df.empty or "run_id" not in rules_df.columns or "source_documents" not in rules_df.columns:
        return []
    matched = rules_df[rules_df.apply(lambda row: bool(row_source_file_names(row) & selected_names), axis=1)]
    if matched.empty:
        return []
    for timestamp_column in ("created_at", "completed_at", "started_at"):
        if timestamp_column in matched.columns:
            matched = matched.assign(
                _dashboard_timestamp=pd.to_datetime(matched[timestamp_column], errors="coerce", utc=True)
            ).sort_values("_dashboard_timestamp", ascending=False, na_position="last")
            break
    return list(dict.fromkeys(matched["run_id"].dropna().astype(str).tolist()))


def run_matches_selected_files(report_data: dict[str, pd.DataFrame], run_id: str, report_path: Any) -> bool:
    selected_names = {
        report_display_name(path).strip().lower()
        for path in selected_report_paths(report_path)
        if report_display_name(path).strip()
    }
    if not selected_names:
        return True
    rules_df = filter_report_run(report_data.get("rules", pd.DataFrame()), run_id)
    if rules_df.empty or "source_documents" not in rules_df.columns:
        return True
    run_names = set()
    for _, row in rules_df.iterrows():
        run_names.update(row_source_file_names(row))
    return not run_names or bool(run_names & selected_names)


def resolve_dashboard_run_id(
    report_data: dict[str, pd.DataFrame],
    run_state: dict[str, Any],
    report_path: str = "",
) -> Optional[str]:
    summary_df = report_data.get("summary", pd.DataFrame())
    variables = project_standard_variables()
    selected_database_run_id = (run_state or {}).get("selected_database_run_id")
    explicit_database_ids = [
        (run_state or {}).get("database_run_id"),
        (run_state or {}).get("db_run_id"),
        variables.get("FSRE_DATABASE_RUN_ID"),
        variables.get("FSRE_LAST_DATABASE_RUN_ID"),
        variables.get("FSRE_ASSESSMENT_DB_RUN_ID"),
    ]
    available = set()
    if not summary_df.empty and "run_id" in summary_df.columns:
        available.update(str(value) for value in summary_df["run_id"].dropna().astype(str))
    for key in ("rules", "red_flags", "review", "external", "evidence"):
        df = report_data.get(key, pd.DataFrame())
        if not df.empty and "run_id" in df.columns:
            available.update(str(value) for value in df["run_id"].dropna().astype(str))
    if not available:
        for candidate in [selected_database_run_id, *explicit_database_ids]:
            if candidate is not None and str(candidate).strip():
                return str(candidate)
        return None

    if selected_database_run_id is not None and str(selected_database_run_id) in available:
        return str(selected_database_run_id)
    for candidate in explicit_database_ids:
        if (
            candidate is not None
            and str(candidate) in available
            and run_has_rule_results(report_data, str(candidate))
            and run_matches_selected_files(report_data, str(candidate), report_path)
        ):
            return str(candidate)

    # When vw_run_summary is unavailable, source_documents is the reliable link
    # between a selected upload and its database rule run.
    for candidate in report_run_ids_for_files(report_data, report_path):
        if candidate in available and run_has_rule_results(report_data, candidate):
            return candidate

    generic_candidate_ids = [
        latest_job_run_id_from_outputs(),
        variables.get("FSRE_ASSESSMENT_RUN_ID"),
        (run_state or {}).get("run_id"),
        (run_state or {}).get("scenario_run_id"),
    ]
    for candidate in generic_candidate_ids:
        if (
            candidate is not None
            and str(candidate) in available
            and run_has_rule_results(report_data, str(candidate))
            and run_matches_selected_files(report_data, str(candidate), report_path)
        ):
            return str(candidate)

    report_name = report_display_name(report_path)
    if report_name and not summary_df.empty and "file_names" in summary_df.columns:
        matched = summary_df[
            summary_df["file_names"].fillna("").astype(str).str.contains(re.escape(report_name), case=False, regex=True)
        ]
        matched = sort_report_runs(matched)
        for _, row in matched.iterrows():
            candidate = str(row["run_id"])
            if run_has_rule_results(report_data, candidate):
                return candidate

    if not summary_df.empty:
        sorted_df = sort_report_runs(summary_df)
    else:
        sorted_df = pd.DataFrame()
    if not sorted_df.empty and str((run_state or {}).get("status", "")).lower() == "completed":
        for _, row in sorted_df.iterrows():
            candidate = str(row["run_id"])
            if run_has_rule_results(report_data, candidate):
                return candidate
    for key in ("rules", "red_flags", "review", "external", "evidence"):
        df = report_data.get(key, pd.DataFrame())
        if df.empty or "run_id" not in df.columns:
            continue
        sorted_df = df
        for column in ("created_at", "completed_at", "started_at"):
            if column in df.columns:
                sorted_df = df.sort_values(column, ascending=False, na_position="last")
                break
        for value in sorted_df["run_id"].dropna().astype(str):
            if run_has_rule_results(report_data, value):
                return value
    return None


def rule_row_is_triggered(row) -> bool:
    if as_bool(safe_value(row, "triggered", False)):
        return True
    return str(safe_value(row, "outcome_bucket", "")).strip().lower() == "red_flag"


def triggered_rule_mask(df: pd.DataFrame) -> pd.Series:
    if df.empty:
        return pd.Series(dtype=bool)
    return df.apply(rule_row_is_triggered, axis=1)


def review_rule_mask(df: pd.DataFrame) -> pd.Series:
    if df.empty:
        return pd.Series(dtype=bool)
    if "outcome_bucket" in df.columns:
        return df["outcome_bucket"].fillna("").astype(str).str.strip().str.lower().eq("review_required")
    if "needs_review" in df.columns:
        return df["needs_review"].map(as_bool)
    return pd.Series(False, index=df.index, dtype=bool)


def triggered_count_from_db(report_ctx: Optional[dict[str, Any]]) -> int:
    summary = report_summary_row(report_ctx)
    summary_count = summary_int(summary, "triggered_rules")
    red_df = (report_ctx or {}).get("red_flags", pd.DataFrame())
    if summary_count:
        return summary_count
    if red_df is not None and not red_df.empty:
        return len(red_df)
    rules_df = (report_ctx or {}).get("rules", pd.DataFrame())
    if rules_df is not None and not rules_df.empty:
        return int(triggered_rule_mask(rules_df).sum())
    return 0


def report_status_from_db(report_ctx: Optional[dict[str, Any]]) -> str:
    summary = report_summary_row(report_ctx)
    rules_df = (report_ctx or {}).get("rules", pd.DataFrame())
    red_df = (report_ctx or {}).get("red_flags", pd.DataFrame())
    review_df = (report_ctx or {}).get("review", pd.DataFrame())
    if red_df is not None and not red_df.empty:
        return "RED_FLAG"
    if rules_df is not None and not rules_df.empty and int(triggered_rule_mask(rules_df).sum()) > 0:
        return "RED_FLAG"
    if review_df is not None and not review_df.empty:
        return "REVIEW_REQUIRED"
    if rules_df is not None and not rules_df.empty and len(rules_df[review_rule_mask(rules_df)]) > 0:
        return "REVIEW_REQUIRED"
    status = safe_value(summary, "report_status", "")
    if has_value(status):
        return str(status)
    if triggered_count_from_db(report_ctx) > 0:
        return "RED_FLAG"
    if rules_df is not None and not rules_df.empty:
        return "PASS"
    return "NO DATA"


def database_trigger_diagnostic(report_ctx: Optional[dict[str, Any]]) -> html.Div:
    if not (report_ctx or {}).get("run_id"):
        return html.Div()
    summary = report_summary_row(report_ctx)
    summary_count = summary_int(summary, "triggered_rules")
    red_df = (report_ctx or {}).get("red_flags", pd.DataFrame())
    rules_df = (report_ctx or {}).get("rules", pd.DataFrame())
    red_count = 0 if red_df is None or red_df.empty else len(red_df)
    rule_count = 0
    if rules_df is not None and not rules_df.empty:
        rule_count = int(triggered_rule_mask(rules_df).sum())
    counts = {summary_count, red_count, rule_count}
    if len(counts) <= 1:
        return html.Div()
    return html.Div(
        f"Database trigger count check: summary={summary_count}, red_flags={red_count}, rule_results={rule_count}.",
        className="message warn compact-message",
    )


def database_run_status(report_ctx: Optional[dict[str, Any]]) -> html.Div:
    run_id = str((report_ctx or {}).get("run_id") or "not resolved")
    rules_df = (report_ctx or {}).get("rules", pd.DataFrame())
    red_df = (report_ctx or {}).get("red_flags", pd.DataFrame())
    result_warning = str((report_ctx or {}).get("result_warning") or "").strip()
    trigger_count = 0 if rules_df is None or rules_df.empty else int(triggered_rule_mask(rules_df).sum())
    red_count = 0 if red_df is None or red_df.empty else len(red_df)
    children = [
        html.Div(
            f"Database run: {run_id} | rule results: {0 if rules_df is None else len(rules_df)} | "
            f"triggered: {max(trigger_count, red_count)}",
            className="message summary compact-message",
        )
    ]
    if result_warning:
        children.append(
            html.Div(
                f"Results pending: {user_friendly_pipeline_error(result_warning)}",
                className="message warn compact-message",
            )
        )
    return html.Div(children)


def database_load_diagnostic(report_ctx: Optional[dict[str, Any]]) -> html.Div:
    errors = (report_ctx or {}).get("load_errors") or {}
    if not errors:
        return html.Div(
            "No matching database run was found for the selected report.",
            className="message warn compact-message",
        )
    concise = []
    for source, error in list(errors.items())[:4]:
        text = re.sub(r"\s+", " ", str(error)).strip()
        concise.append(f"{source}: {text[:180]}")
    return html.Div(
        [
            html.Strong("Database loading failed. "),
            html.Span(" | ".join(concise)),
        ],
        className="message error compact-message",
    )


def blank_dashboard_panel() -> html.Div:
    return html.Div("", className="empty-state compact blank-state")


def dashboard_context(
    rule_ids: list[str],
    run_state: dict[str, Any],
    report_path: str = "",
) -> dict[str, Any]:
    report_data = load_report_data()
    dashboard_run_id = resolve_dashboard_run_id(report_data, run_state, report_path)
    filtered = {
        key: filter_report_run(df, dashboard_run_id)
        for key, df in report_data.items()
    }
    summary = filtered["summary"].iloc[0] if not filtered["summary"].empty else {}
    result_warning = str((run_state or {}).get("result_warning") or "").strip()
    if dashboard_run_id and not filtered.get("rules", pd.DataFrame()).empty:
        result_warning = ""
    return {
        "run_id": dashboard_run_id,
        "summary": summary,
        "load_errors": dict(REPORT_DATASET_LOAD_ERRORS),
        "result_warning": result_warning,
        **filtered,
    }


def recent_run_options(limit: int = 15, run_state: Optional[dict[str, Any]] = None) -> list[dict[str, str]]:
    def clean_entity(value: Any) -> str:
        text = str(value or "").strip()
        if text.upper().startswith("ENT-"):
            text = text[4:]
        return text.replace("-", " ").replace("_", " ").title() or "Company"

    def row_company(row: Any, fallback_entity: Any = "") -> str:
        for column in ("file_names", "source_documents", "document_names", "document_name", "file_name"):
            if hasattr(row, "get"):
                inferred = infer_company_from_report_text(row.get(column))
            else:
                inferred = ""
            if inferred:
                return inferred
        return clean_entity(fallback_entity)

    def clean_status(value: Any) -> str:
        aliases = {
            "RED_FLAG": "Red flag",
            "REVIEW_REQUIRED": "Review required",
            "FIX_REQUIRED": "Fix required",
            "PASS": "Pass",
            "NO_DATA": "No data",
        }
        text = str(value or "").strip().upper()
        return aliases.get(text, text.replace("_", " ").title() or "Completed")

    def clean_periods(value: Any) -> str:
        periods = re.findall(r"FY\s*\d{2,4}|20\d{2}", str(value or ""), flags=re.IGNORECASE)
        normalized = []
        for period in periods:
            digits = re.sub(r"\D", "", period)
            label = f"FY{digits}" if digits else ""
            if label and label not in normalized:
                normalized.append(label)
        if len(normalized) > 2:
            return f"{normalized[0]}-{normalized[-1]}"
        return "-".join(normalized)

    latest_state = latest_visible_run_state(run_state or {})
    latest_database_run_id = str(
        latest_state.get("database_run_id")
        or latest_state.get("db_run_id")
        or project_standard_variables().get("FSRE_ASSESSMENT_DB_RUN_ID")
        or ""
    ).strip()
    report_data = load_report_data()

    def prepend_latest_option(options: list[dict[str, str]]) -> list[dict[str, str]]:
        if not latest_database_run_id:
            return options[:limit]
        if any(str(option.get("value")) == latest_database_run_id for option in options):
            return options[:limit]
        has_results = run_has_rule_results(report_data, latest_database_run_id)
        status = "results ready" if has_results else "results pending"
        label = f"Latest completed run | {status} | {latest_database_run_id[:8]}"
        return [{"label": label, "value": latest_database_run_id}, *options][:limit]

    summary_df = report_data.get("summary", pd.DataFrame())
    if not summary_df.empty and "run_id" in summary_df.columns:
        rows = sort_report_runs(summary_df).head(limit)
        options = []
        for _, row in rows.iterrows():
            run_id = str(row["run_id"])
            entity = row_company(row, safe_value(row, "entity_id", ""))
            periods = clean_periods(safe_value(row, "reporting_periods", ""))
            status = clean_status(safe_value(row, "report_status", ""))
            document_count = summary_int(row, "document_count")
            label_parts = [
                entity,
                periods,
                status,
                f"{document_count} report{'s' if document_count != 1 else ''}" if document_count else "",
            ]
            options.append({"label": " | ".join(part for part in label_parts if part), "value": run_id})
        return prepend_latest_option(options)

    rules_df = report_data.get("rules", pd.DataFrame())
    if rules_df.empty or "run_id" not in rules_df.columns:
        return prepend_latest_option([])
    sorted_rules = rules_df
    if "created_at" in rules_df.columns:
        sorted_rules = rules_df.assign(
            _recent_timestamp=pd.to_datetime(rules_df["created_at"], errors="coerce", utc=True)
        ).sort_values("_recent_timestamp", ascending=False, na_position="last")
    options = []
    for run_id in dict.fromkeys(sorted_rules["run_id"].dropna().astype(str).tolist()):
        run_rows = filter_report_run(sorted_rules, run_id)
        files = set()
        for _, row in run_rows.iterrows():
            files.update(row_source_file_names(row))
        first_row = run_rows.iloc[0] if not run_rows.empty else {}
        entity = row_company(first_row, safe_value(first_row, "entity_id", ""))
        if entity == "Company" and files:
            entity = infer_company_from_report_paths(sorted(files)) or entity
        periods = clean_periods(
            ", ".join(run_rows["period_label"].dropna().astype(str).tolist())
            if "period_label" in run_rows.columns
            else ""
        )
        status = "Red flag" if int(triggered_rule_mask(run_rows).sum()) else (
            "Review required" if int(review_rule_mask(run_rows).sum()) else "Pass"
        )
        options.append(
            {
                "label": " | ".join(
                    part
                    for part in (
                        entity,
                        periods,
                        status,
                        f"{len(files)} report{'s' if len(files) != 1 else ''}" if files else "",
                    )
                    if part
                ),
                "value": run_id,
            }
        )
        if len(options) >= limit:
            break
    return prepend_latest_option(options)


def rule_catalog_lookup(rule_id: str) -> dict[str, Any]:
    for rule in RULE_CATALOG:
        if rule["id"] == rule_id:
            return rule
    return {"id": rule_id, "name": rule_id, "category": "Rule", "severity": "Medium", "friendly": ""}


def display_rule_severity(row) -> str:
    severity = str(safe_value(row, "severity", "") or "").strip()
    if severity and severity.upper() not in {"NONE", "NAN", "NULL", "-"}:
        return humanize_identifier(severity)
    rule = rule_catalog_lookup(str(safe_value(row, "rule_id", "")))
    fallback = str(rule.get("severity") or "").strip()
    return fallback or "Review"


def display_rule_tone(row) -> str:
    severity = display_rule_severity(row).lower()
    if severity in {"critical", "high"}:
        return "high"
    if severity in {"medium", "review"}:
        return "medium"
    return row_tone(row)


def rule_domain(rule_id: str) -> str:
    parts = str(rule_id or "").split("-")
    return parts[1] if len(parts) > 1 else ""


def rule_concern_label(row) -> str:
    rule_id = str(safe_value(row, "rule_id", ""))
    rule_name = str(safe_value(row, "rule_name", rule_id))
    domain = rule_domain(rule_id)
    labels = {
        "REV": "Revenue recognition and collection risk",
        "CSH": "Cash-flow quality and liquidity risk",
        "AST": "Asset quality and valuation risk",
        "LIA": "Liability completeness and obligation risk",
        "OWN": "Ownership, control and governance risk",
        "CMP": "Composite fraud or distress indicator",
    }
    return labels.get(domain) or str(safe_value(row, "category", rule_name))


def rule_id_from_row(row) -> str:
    return str(safe_value(row, "rule_id", "") or "").strip()


def fraud_signal_rows(report_ctx: Optional[dict[str, Any]]) -> pd.DataFrame:
    rules_df = (report_ctx or {}).get("rules", pd.DataFrame())
    red_df = (report_ctx or {}).get("red_flags", pd.DataFrame())
    review_df = (report_ctx or {}).get("review", pd.DataFrame())
    frames = []

    if red_df is not None and not red_df.empty:
        triggered_df = red_df.copy()
        triggered_df["fraud_signal_status"] = "Triggered"
        frames.append(triggered_df)
    elif rules_df is not None and not rules_df.empty:
        triggered_df = rules_df[triggered_rule_mask(rules_df)].copy()
        if not triggered_df.empty:
            triggered_df["fraud_signal_status"] = "Triggered"
            frames.append(triggered_df)

    if review_df is not None and not review_df.empty:
        watch_df = review_df.copy()
        watch_df["fraud_signal_status"] = "Review"
        frames.append(watch_df)
    elif rules_df is not None and not rules_df.empty:
        watch_df = rules_df[review_rule_mask(rules_df)].copy()
        if not watch_df.empty:
            watch_df["fraud_signal_status"] = "Review"
            frames.append(watch_df)

    if not frames:
        return pd.DataFrame()

    signals_df = pd.concat(frames, ignore_index=True, sort=False)
    if "rule_id" not in signals_df.columns:
        return pd.DataFrame()
    signals_df["rule_id"] = signals_df["rule_id"].fillna("").astype(str).str.strip()
    signals_df = signals_df[signals_df["rule_id"].ne("")]
    if signals_df.empty:
        return signals_df
    signals_df["fraud_area_id"] = signals_df["rule_id"].map(lambda value: FRAUD_AREA_BY_RULE_ID.get(value, {}).get("id", "other"))
    signals_df["fraud_signal_rank"] = signals_df["fraud_signal_status"].map({"Triggered": 0, "Review": 1}).fillna(2)
    signals_df = signals_df.sort_values(["fraud_area_id", "fraud_signal_rank", "rule_id"], na_position="last")
    return signals_df.drop_duplicates(subset=["fraud_area_id", "rule_id"], keep="first")


def fraud_area_card(area: dict[str, Any], area_df: pd.DataFrame) -> html.Article:
    triggered_count = int(area_df["fraud_signal_status"].eq("Triggered").sum()) if "fraud_signal_status" in area_df.columns else 0
    tone = "high" if triggered_count else "medium"
    rule_chips = []
    for _, row in area_df.head(5).iterrows():
        rule_id = rule_id_from_row(row)
        rule_name = str(safe_value(row, "rule_name", "") or rule_catalog_lookup(rule_id).get("name", rule_id))
        signal_status = str(safe_value(row, "fraud_signal_status", "Review"))
        rule_chips.append(
            html.Div(
                className=f"fraud-rule-chip {'triggered' if signal_status == 'Triggered' else 'review'}",
                children=[
                    html.Strong(rule_id),
                    html.Span(short_value(rule_name, 58)),
                    status_tag(signal_status, "high" if signal_status == "Triggered" else "medium"),
                ],
            )
        )
    return html.Article(
        className=f"fraud-area-card {tone}",
        children=[
            html.Div(
                className="fraud-area-head",
                children=[
                    html.Div([html.H4(area["title"]), html.P(area["subtitle"])]),
                ],
            ),
            html.Div(className="fraud-rule-list", children=rule_chips),
            html.Div(
                className="fraud-review-focus",
                children=[html.Span("Review focus"), html.Strong(area["review_focus"])],
            ),
        ],
    )


def potential_fraud_area_panel(report_ctx: Optional[dict[str, Any]]) -> html.Div:
    if not (report_ctx or {}).get("run_id"):
        return html.Div()
    signals_df = fraud_signal_rows(report_ctx)
    if signals_df.empty:
        body = [html.Div("No potential fraud area was triggered for this database run.", className="empty-state compact")]
    else:
        cards = []
        for area in FRAUD_AREA_DEFINITIONS:
            area_df = signals_df[signals_df["fraud_area_id"].eq(area["id"])]
            if not area_df.empty:
                cards.append(fraud_area_card(area, area_df))
        body = [html.Div(className="fraud-area-grid", children=cards)] if cards else [html.Div("No mapped fraud-area signals were found for this run.", className="empty-state compact")]
    return html.Div(
        className="compact-section fraud-area-section",
        children=[
            html.Div(
                className="compact-section-title",
                children=[
                    html.H4("Potential Fraud Areas"),
                    html.Span("Based on red flags and review-required rules"),
                ],
            ),
            *body,
        ],
    )


def concern_message(row) -> str:
    finding_type = str(safe_value(row, "finding_type", "")).strip().lower()
    rule_id = str(safe_value(row, "rule_id", ""))
    rule_name = str(safe_value(row, "rule_name", rule_id))
    concern = str(safe_value(row, "concern_label", rule_concern_label(row)))
    associated_rule = str(safe_value(row, "associated_rule", ""))
    if finding_type == "threshold_breach":
        return f"Raise concern: {rule_name} breached its configured threshold and should be treated as a red-flag finding under {concern}."
    if associated_rule:
        return f"Associated review: this rule supports {associated_rule}. Confirm the missing or warning inputs before clearing or escalating the {concern} concern."
    return f"Associated review: this rule may support a red-flag concern under {concern}. Confirm the warning inputs before clearing or escalating."


def row_tone(row) -> str:
    if rule_row_is_triggered(row):
        return "high"
    if as_bool(safe_value(row, "needs_review", False)) or str(safe_value(row, "outcome_bucket", "")).strip().lower() == "review_required":
        return "medium"
    return "low"


def row_status(row) -> str:
    if rule_row_is_triggered(row):
        return "Triggered"
    if as_bool(safe_value(row, "needs_review", False)) or str(safe_value(row, "outcome_bucket", "")).strip().lower() == "review_required":
        return "Review required"
    return "No trigger"


def evidence_rows_for_rule(evidence_df: pd.DataFrame, rule_id: str, limit: int = 6) -> list[dict[str, Any]]:
    if evidence_df.empty or "rule_id" not in evidence_df.columns:
        return []
    rows = evidence_df[evidence_df["rule_id"].astype(str) == str(rule_id)].copy()
    sort_columns = [
        column
        for column in ("field_path", "required_field_path", "value_period_label", "period_role", "reporting_period_label", "period_label", "page_number")
        if column in rows.columns
    ]
    if sort_columns:
        rows = rows.sort_values(sort_columns, na_position="last")
    rows = rows.head(limit)
    return [dict(row) for _, row in rows.iterrows()]


def period_role_from_required_path(required_path: Any) -> str:
    text = str(required_path or "").strip().lower()
    for suffix in ("current", "prior", "next_period", "historical"):
        if text.endswith(f".{suffix}"):
            return suffix
    return ""


def friendly_period_role(role: Any) -> str:
    labels = {
        "current": "Current period",
        "prior": "Prior period",
        "next_period": "Next period",
        "historical": "Historical period",
        "any": "Any period",
        "unspecified": "",
    }
    return labels.get(str(role or "").strip().lower(), humanize_identifier(role))


def evidence_period_label(row: dict[str, Any]) -> str:
    source_ref = parse_json_value(safe_value(row, "source_ref_json", ""))
    source_ref = source_ref if isinstance(source_ref, dict) else {}
    role = (
        safe_value(row, "period_role", "")
        or source_ref.get("period_role")
        or period_role_from_required_path(safe_value(row, "required_field_path", "") or source_ref.get("required_field_path"))
    )
    role_label = friendly_period_role(role)
    for key in ("value_period_label", "expected_period_label", "period_label"):
        value = safe_value(row, key, "")
        if has_value(value):
            return f"{value} - {role_label}" if role_label else str(value)
    for key in ("period_label", "year", "expected_period_label"):
        value = source_ref.get(key)
        if has_value(value):
            return f"{value} - {role_label}" if role_label else str(value)
    report_period = safe_value(row, "reporting_period_label", "")
    if has_value(report_period) and role_label:
        return f"{role_label} ({report_period} report)"
    if role_label:
        return role_label
    if has_value(report_period):
        return str(report_period)
    return "-"


def evidence_report_label(row: dict[str, Any]) -> str:
    for key in ("file_name", "document_name"):
        value = safe_value(row, key, "")
        if has_value(value):
            return str(value)
    return "-"


def evidence_report_path(row: dict[str, Any], report_path: Any = "") -> str:
    evidence_name = evidence_report_label(row)
    selected_paths = selected_report_paths(report_path)
    if evidence_name != "-":
        normalized_name = evidence_name.lstrip("/").rsplit("/", 1)[-1].casefold()
        for selected_path in selected_paths:
            if str(selected_path).lstrip("/").rsplit("/", 1)[-1].casefold() == normalized_name:
                return str(selected_path)
        return evidence_name
    return selected_paths[0] if selected_paths else ""


def evidence_pdf_url(row: dict[str, Any], report_path: Any = "") -> str:
    pdf_path = evidence_report_path(row, report_path)
    if not pdf_path or extension(pdf_path) != "pdf":
        return ""
    page = as_int_value(safe_value(row, "page_number", 0), 0)
    page_fragment = f"#page={page}" if page > 0 else ""
    return f"fsre-report-file?path={quote(str(pdf_path), safe='')}{page_fragment}"


def evidence_value_table_from_rows(evidence_rows: list[dict[str, Any]], report_path: Any = ""):
    if not evidence_rows:
        return html.Div("No evidence rows available for this rule/run.", className="empty-state compact")

    def evidence_reference(row):
        values = []
        page = safe_value(row, "page_number")
        if page != "-":
            values.append(f"Page {page}")
        note = safe_value(row, "note_reference", "")
        if has_value(note):
            values.append(str(note))
        return " | ".join(values) or "-"

    def evidence_record(row):
        field = evidence_field_label(row)
        pdf_url = evidence_pdf_url(row, report_path)
        normalized = str(safe_value(row, "normalized_value"))
        raw_value = str(safe_value(row, "raw_value"))
        values_are_duplicate = (
            re.sub(r"\s+", " ", normalized).strip().casefold()
            == re.sub(r"\s+", " ", raw_value).strip().casefold()
        )

        def expandable_value(value, limit=160):
            if len(value) <= limit:
                return html.Strong(value)
            return html.Strong(
                [
                    html.Span(short_value(value, limit), className="evidence-inline-text"),
                    html.Span(value, className="evidence-full-text"),
                ],
                title="Open the full evidence viewer to read this value",
            )

        return html.Article(
            className="evidence-record",
            children=[
                html.Div(
                    className="evidence-record-header",
                    children=[
                        html.Div(
                            [
                                html.Span("Field"),
                                html.Strong(field, title=str(safe_value(row, "field_path", ""))),
                            ]
                        ),
                        html.Div(
                            className="evidence-primary-value",
                            children=[html.Span("Normalized value"), expandable_value(normalized)],
                        ),
                        html.Button(
                            "Expand",
                            type="button",
                            className="evidence-expand-button",
                            title="Open full evidence",
                        ),
                    ],
                ),
                html.Div(
                    className="evidence-record-meta",
                    children=[
                        html.Div([html.Span("Period"), html.Strong(evidence_period_label(row))]),
                        html.Div(
                            [
                                html.Span("Source"),
                                html.A(
                                    evidence_reference(row),
                                    href=pdf_url,
                                    target="_blank",
                                    className="evidence-page-link",
                                    title="Open this annual-report PDF at the cited page",
                                )
                                if pdf_url
                                else html.Strong(evidence_reference(row)),
                            ]
                        ),
                        html.Div(
                            className="evidence-report-name",
                            children=[
                                html.Span("Report"),
                                html.A(
                                    evidence_report_label(row),
                                    href=pdf_url,
                                    target="_blank",
                                    className="evidence-report-link",
                                    title="Open the source annual report",
                                )
                                if pdf_url
                                else html.Strong(evidence_report_label(row)),
                            ],
                        ),
                    ],
                ),
                html.Div(
                    className="evidence-raw-value",
                    children=[
                        html.Span("Source value"),
                        expandable_value(raw_value, 220),
                    ],
                )
                if not values_are_duplicate
                else html.Div(),
            ],
        )

    return html.Div(
        className="evidence-record-list",
        children=[evidence_record(row) for row in evidence_rows],
    )


def page_summary_for_rule(evidence_rows: list[dict[str, Any]], fallback: str = "-") -> str:
    labels = []
    for row in evidence_rows:
        page = safe_value(row, "page_number", "")
        note = safe_value(row, "note_reference", "")
        parts = []
        if page not in ("", "-"):
            parts.append(f"Page {page}")
        if note not in ("", "-"):
            parts.append(str(note))
        label = ", ".join(parts)
        if label and label not in labels:
            labels.append(label)
    return "; ".join(labels) if labels else fallback


def report_page_label(report_path: Any) -> str:
    return f"{report_display_name(report_path)} page number(s)"


def threshold_summary_items(threshold_value: Any) -> list[tuple[str, str]]:
    parsed = parse_json_value(threshold_value)
    if not isinstance(parsed, dict):
        return [("Threshold", short_value(threshold_value, 90))] if has_value(threshold_value) else []
    keys = [
        "metric",
        "threshold",
        "trigger_when",
        "activation_policy",
        "activation_group",
        "input_contract_version",
        "formula",
        "formula_reference",
        "readiness_group",
    ]
    items = [(humanize_key(key), friendly_config_value(key, parsed.get(key))) for key in keys if has_value(parsed.get(key))]
    bands = parsed.get("bands")
    if isinstance(bands, list) and bands:
        band_labels = []
        for band in bands[:3]:
            if not isinstance(band, dict):
                continue
            severity = band.get("severity")
            tests = [f"{humanize_key(key)}: {friendly_config_value(key, value)}" for key, value in band.items() if key != "severity"]
            label = " ".join(tests)
            if severity:
                label = f"{severity}: {label}" if label else str(severity)
            if label:
                band_labels.append(label)
        if band_labels:
            items.append(("Trigger bands", "; ".join(band_labels)))
    return [(label, value) for label, value in items if has_value(value)]


def hidden_threshold_items(threshold_value: Any) -> list[tuple[str, str]]:
    parsed = parse_json_value(threshold_value)
    if not isinstance(parsed, dict):
        return []
    primary = {
        "metric",
        "threshold",
        "trigger_when",
        "formula",
        "formula_reference",
        "readiness_group",
        "activation_policy",
        "activation_group",
        "input_contract_version",
        "bands",
    }
    return [
        (humanize_key(key), friendly_config_value(key, value))
        for key, value in parsed.items()
        if key not in primary and has_value(value)
    ]


def field_chip(label: str, value: Any, tone: str = ""):
    if not has_value(value):
        return None
    return html.Div(
        className=f"field-chip {tone}".strip(),
        children=[html.Span(label), html.Strong(str(value))],
    )


def detail_rows(items: list[tuple[str, Any]]):
    rows = []
    for label, value in items:
        if has_value(value):
            rows.append(html.Div([html.Span(label), html.Strong(str(value))], className="detail-row"))
    return rows


def review_checklist(row):
    non_pass_items = friendly_non_pass_input_items(safe_value(row, "non_pass_inputs", ""))
    readiness_reason = safe_value(row, "readiness_reason", "")
    review_reason = safe_value(row, "review_reason", "")
    reason = readiness_reason if has_value(readiness_reason) else review_reason
    if not non_pass_items and not has_value(reason):
        return html.Div()
    children = []
    if has_value(reason):
        children.append(html.P(str(reason), className="review-reason"))
    if non_pass_items:
        children.append(
            html.Div(
                className="review-input-list",
                children=[
                    html.Div(
                        className="review-input-row",
                        children=[html.Span(field), status_tag(status, "medium")],
                    )
                    for field, status in non_pass_items
                ],
            )
        )
    return html.Div(
        className="review-checklist",
        children=[html.H5("Review checklist"), *children],
    )


def concern_panel(row):
    message = concern_message(row)
    if not has_value(message):
        return html.Div()
    return html.Div(
        className=f"concern-panel {row_tone(row)}",
        children=[
            html.H5("Concern"),
            html.P(message),
        ],
    )


def compact_rule_card(row, evidence_df: pd.DataFrame, report_path: str = ""):
    rule_id = str(safe_value(row, "rule_id"))
    evidence_rows = evidence_rows_for_rule(evidence_df, rule_id)
    evidence_count = as_int_value(safe_value(row, "evidence_count", 0), 0)
    pages = page_summary_for_rule(evidence_rows, "")
    threshold_items = threshold_summary_items(safe_value(row, "threshold_value", ""))
    extra_threshold_items = hidden_threshold_items(safe_value(row, "threshold_value", ""))
    severity = display_rule_severity(row)
    severity_tone = display_rule_tone(row)
    calculation_items = [
        ("Computed Value", format_number(safe_value(row, "computed_value"))),
    ] + [item for item in threshold_items[:6] if item[0] != "Trigger bands"]
    chips = [
        field_chip("Value", format_number(safe_value(row, "computed_value")), "value"),
        field_chip("Severity", severity, severity_tone),
        field_chip("Pages", pages),
    ]
    finding_type = safe_value(row, "finding_type", "")
    if has_value(finding_type):
        chips.append(field_chip("Finding", humanize_identifier(finding_type), "info"))
    chips.extend(field_chip(label, value) for label, value in threshold_items[:3])
    chips = [chip for chip in chips if chip is not None]
    detail_items = [
        ("Execution", safe_value(row, "execution_status", "")),
        ("Outcome", safe_value(row, "outcome_bucket", "")),
        ("Finding Type", humanize_identifier(finding_type)),
        ("Review", safe_value(row, "review_status", "")),
        ("Evidence Refs", safe_value(row, "evidence_count", "")),
    ]
    if evidence_rows:
        evidence_section = html.Div(
            className="evidence-mini evidence-visible",
            children=[html.H5("Evidence details"), evidence_value_table_from_rows(evidence_rows, report_path)],
        )
    elif evidence_count > 0:
        evidence_section = html.Div(
            className="evidence-mini evidence-visible",
            children=[
                html.H5("Evidence details"),
                html.Div(
                    "Evidence references were counted for this rule, but the evidence trail rows are not loaded for the selected run.",
                    className="empty-state compact",
                ),
            ],
        )
    else:
        evidence_section = html.Div()
    return html.Article(
        className=f"compact-finding {row_tone(row)}",
        children=[
            html.Div(
                className="compact-finding-head",
                children=[
                    html.Strong(rule_id),
                    status_tag(row_status(row), row_tone(row)),
                ],
            ),
            html.H4(str(safe_value(row, "rule_name", rule_id))),
            html.P(str(safe_value(row, "explanation", "No explanation stored for this result."))),
            html.Div(className="compact-finding-meta", children=chips),
            concern_panel(row),
            html.Div(
                className="calculation-snapshot",
                children=[
                    html.H5("Calculation snapshot"),
                    html.Div(className="detail-grid", children=detail_rows(calculation_items)),
                ],
            ),
            review_checklist(row),
            evidence_section,
            html.Details(
                className="finding-details",
                children=[
                    html.Summary("More details"),
                    html.Div(className="detail-grid", children=detail_rows(detail_items + threshold_items[6:] + extra_threshold_items)),
                ],
            ),
        ],
    )


def triggered_rule_results_table(df: pd.DataFrame):
    """Render a scan-friendly result index; investigation detail belongs below."""
    rows = []
    for _, row in df.head(12).iterrows():
        rule_id = str(safe_value(row, "rule_id"))
        rows.append(
            html.Tr(
                [
                    html.Td(html.Strong(rule_id)),
                    html.Td(
                        [
                            html.Strong(str(safe_value(row, "rule_name", rule_id))),
                            html.Small(str(safe_value(row, "category", "Rule"))),
                        ]
                    ),
                    html.Td(status_tag(row_status(row), row_tone(row))),
                    html.Td(format_number(safe_value(row, "computed_value"))),
                    html.Td(status_tag(display_rule_severity(row), display_rule_tone(row))),
                    html.Td(str(as_int_value(safe_value(row, "evidence_count", 0), 0))),
                ]
            )
        )
    return html.Div(
        className="triggered-results-index",
        children=[
            html.Div(
                className="section-purpose",
                children=[
                    html.Strong("What triggered?"),
                    html.Span("A concise rule-level index. Open Red Flag Investigation below for rationale, calculations, evidence, and review actions."),
                ],
            ),
            html.Div(
                className="table-scroll",
                children=[
                    html.Table(
                        className="result-table triggered-result-table",
                        children=[
                            html.Thead(html.Tr([html.Th("Rule ID"), html.Th("Rule"), html.Th("Outcome"), html.Th("Value"), html.Th("Severity"), html.Th("Evidence")])),
                            html.Tbody(rows),
                        ],
                    )
                ],
            ),
            html.Div(f"Showing {min(len(df), 12)} of {len(df)} triggered rule(s).", className="table-footnote") if len(df) > 12 else html.Div(),
        ],
    )


def selected_rule_summary(rule_ids: list[str]):
    details = selected_rule_details(rule_ids or [])
    critical = sum(1 for rule in details if rule["severity"] == "Critical")
    high = sum(1 for rule in details if rule["severity"] == "High")
    medium = sum(1 for rule in details if rule["severity"] == "Medium")
    categories = sorted({rule["category"] for rule in details})
    return html.Div(
        className="selected-rule-summary",
        children=[
            html.Div([html.Span("Selected"), html.Strong(str(len(details)))], className="summary-chip"),
            html.Div([html.Span("Critical"), html.Strong(str(critical))], className="summary-chip risk"),
            html.Div([html.Span("High"), html.Strong(str(high))], className="summary-chip risk"),
            html.Div([html.Span("Medium"), html.Strong(str(medium))], className="summary-chip warn"),
            html.Div([html.Span("Categories"), html.Strong(str(len(categories)))], className="summary-chip info"),
        ],
    )


def selected_report_card(report_path: Any):
    report_paths = selected_report_paths(report_path)
    if not report_paths:
        return html.Div("No reports selected yet.", className="empty-state compact")
    file_names = [str(path).lstrip("/").rsplit("/", 1)[-1] for path in report_paths]
    ext_values = sorted({extension(file_name).upper() or "-" for file_name in file_names})
    ext = ", ".join(ext_values)
    inferred_company = infer_company_from_report_paths(report_paths)
    return html.Div(
        className="selected-report-card",
        children=[
            html.Div(
                children=[
                    html.Span(f"Selected {selected_report_count_text(report_paths)}"),
                    html.Strong(", ".join(file_names)),
                    html.Small(
                        f"Inferred company: {inferred_company or 'configured default'}"
                    ),
                ]
            ),
            status_tag(ext, "info"),
        ],
    )


def monitor_steps(run_state: dict[str, Any]):
    status = str((run_state or {}).get("status", "not_started"))
    if status in {"running", "completed", "failed"}:
        completed = set((run_state or {}).get("completed_datasets") or [])
        current_dataset = (run_state or {}).get("current_dataset")
        items = []
        next_pending_marked = False
        for stage in VISIBLE_PIPELINE_STAGES:
            stage_datasets = set(stage["datasets"])
            if stage_datasets and stage_datasets.issubset(completed):
                step_class = "step done"
                detail = f"Completed - {stage['detail']}"
            elif current_dataset in stage_datasets:
                step_class = "step active"
                detail = f"Running now - {stage['detail']}"
                next_pending_marked = True
            elif status == "running" and not current_dataset and not next_pending_marked:
                step_class = "step active"
                detail = f"Preparing - {stage['detail']}"
                next_pending_marked = True
            else:
                step_class = "step"
                detail = f"Waiting - {stage['detail']}"
            items.append(
                html.Div(
                    className=step_class,
                    children=[
                        html.Span(className="dot"),
                        html.Strong(stage["name"]),
                        html.Span(detail),
                    ],
                )
            )
        if status == "failed":
            items.append(
                html.Div(
                    className="message error",
                    children=f"Pipeline failed: {user_friendly_pipeline_error((run_state or {}).get('error', 'Unknown error'))}",
                )
            )
        return html.Div(items, className="progress")

    if status == "started":
        active_index = 2
    elif status == "running":
        active_index = 3
    elif status == "completed":
        active_index = len(PIPELINE_STEPS)
    elif status == "failed":
        active_index = 1
    else:
        active_index = 0

    items = []
    for index, (title, detail) in enumerate(PIPELINE_STEPS, start=1):
        if index <= active_index:
            step_class = "step done"
        elif index == active_index + 1 and status == "started":
            step_class = "step active"
        else:
            step_class = "step"
        items.append(
            html.Div(
                className=step_class,
                children=[
                    html.Span(className="dot"),
                    html.Strong(title),
                    html.Span(detail),
                ],
            )
        )
    return html.Div(items, className="progress")


def friendly_report_status(status: Any) -> tuple[str, str, str]:
    normalized = str(status or "").strip().upper()
    if normalized == "RED_FLAG":
        return "Red flag review needed", "Rules exceeded configured thresholds and need analyst review.", "risk"
    if normalized == "REVIEW_REQUIRED":
        return "Review needed", "Warnings or incomplete rule inputs need analyst confirmation.", "warn"
    if normalized in {"PASS", "CLEAR"}:
        return "No priority findings", "Rules completed without high-risk findings.", "ok"
    if normalized in {"FIX_REQUIRED", "FAIL"}:
        return "Data quality issue", "Some rules could not be completed cleanly.", "risk"
    return "Pending", "Waiting for completed report output", "neutral"


def rule_name_list(df: pd.DataFrame, limit: int = 3) -> str:
    if df.empty:
        return ""
    names = []
    for _, row in df.head(limit).iterrows():
        rule_id = str(safe_value(row, "rule_id", "")).strip()
        rule_name = str(safe_value(row, "rule_name", "")).strip()
        label = " - ".join(item for item in (rule_id, rule_name) if item and item != "-")
        if label:
            names.append(label)
    remaining = max(0, len(df) - len(names))
    suffix = f" +{remaining} more" if remaining else ""
    return "; ".join(names) + suffix


def review_detail_text(review_df: pd.DataFrame, limit: int = 3) -> str:
    if review_df.empty:
        return ""
    details = []
    for _, row in review_df.head(limit).iterrows():
        rule_id = str(safe_value(row, "rule_id", "")).strip()
        reason = safe_value(row, "non_pass_inputs", "")
        if not has_value(reason) or str(reason) == "NONE":
            reason = safe_value(row, "explanation", "")
        else:
            reason = friendly_non_pass_inputs(reason)
        if not has_value(reason):
            reason = safe_value(row, "rule_name", "")
        detail = f"{rule_id}: {short_value(reason, 90)}" if rule_id else short_value(reason, 90)
        if detail:
            details.append(detail)
    remaining = max(0, len(review_df) - len(details))
    suffix = f" +{remaining} more" if remaining else ""
    return "; ".join(details) + suffix


def evidence_detail_text(rules_df: pd.DataFrame, limit: int = 3) -> str:
    if rules_df.empty or "evidence_count" not in rules_df.columns:
        return ""
    df = rules_df.copy()
    try:
        df["_evidence_count_sort"] = pd.to_numeric(df["evidence_count"], errors="coerce").fillna(0)
        df = df.sort_values("_evidence_count_sort", ascending=False)
    except Exception:
        pass
    details = []
    for _, row in df.head(limit).iterrows():
        count = safe_value(row, "evidence_count", "")
        if not has_value(count):
            continue
        rule_id = str(safe_value(row, "rule_id", "")).strip()
        details.append(f"{rule_id}: {count} refs" if rule_id else f"{count} refs")
    return "; ".join(details)


def risk_kpi_card(title: str, value: Any, detail: str = "", tone: str = "neutral", href: str = ""):
    content = html.Div(
        className=f"kpi action {tone}",
        children=[
            html.Span(title),
            html.Strong(str(value)),
            html.Small(detail) if has_value(detail) else html.Small(),
        ],
    )
    if href:
        return html.A(content, href=href, className="kpi-link")
    return content


def risk_overflow_details(hidden_chips: list[Any], tone: str = ""):
    if not hidden_chips:
        return None
    return html.Details(
        className="risk-more-details",
        children=[
            html.Summary(f"+{len(hidden_chips)}", className=f"risk-chip more {tone}".strip(), title=f"Show {len(hidden_chips)} more"),
            html.Div(className="risk-overflow-list", children=hidden_chips),
        ],
    )


def risk_mini_rule_rows(df: pd.DataFrame, evidence_df: pd.DataFrame, limit: int = 4) -> list[Any]:
    chips = []
    for _, row in df.iterrows():
        rule_id = str(safe_value(row, "rule_id", "")).strip()
        rule_name = str(safe_value(row, "rule_name", "")).strip()
        pages = page_summary_for_rule(evidence_rows_for_rule(evidence_df, rule_id), "")
        meta = [rule_name]
        value = format_number(safe_value(row, "computed_value", ""))
        severity = safe_value(row, "severity", "")
        if has_value(value):
            meta.append(f"Value {value}")
        if has_value(severity):
            meta.append(str(severity).title())
        if has_value(pages):
            meta.append(pages)
        chips.append(
            html.A(
                className="risk-chip risk",
                href="#triggered-rule-summary",
                title="Triggered rule: " + " | ".join(item for item in meta if has_value(item)),
                children=rule_id,
            )
        )
    rows = chips[:limit]
    more = risk_overflow_details(chips[limit:], "risk")
    if more:
        rows.append(more)
    return rows


def risk_mini_review_rows(df: pd.DataFrame, limit: int = 4) -> list[Any]:
    chips = []
    for _, row in df.iterrows():
        rule_id = str(safe_value(row, "rule_id", "")).strip()
        rule_name = str(safe_value(row, "rule_name", "")).strip()
        reason = safe_value(row, "non_pass_inputs", "")
        if not has_value(reason) or str(reason) == "NONE":
            reason = safe_value(row, "explanation", "")
        else:
            reason = friendly_non_pass_inputs(reason)
        chips.append(
            html.A(
                className="risk-chip warn",
                href="#red-flag-details",
                title="Needs review: " + " | ".join(item for item in (rule_name, short_value(reason, 120)) if has_value(item)),
                children=rule_id,
            )
        )
    rows = chips[:limit]
    more = risk_overflow_details(chips[limit:], "warn")
    if more:
        rows.append(more)
    return rows


def risk_mini_evidence_rows(df: pd.DataFrame, limit: int = 4) -> list[Any]:
    if df.empty or "evidence_count" not in df.columns:
        return []
    sorted_df = df.copy()
    try:
        sorted_df["_evidence_count_sort"] = pd.to_numeric(sorted_df["evidence_count"], errors="coerce").fillna(0)
        sorted_df = sorted_df.sort_values("_evidence_count_sort", ascending=False)
    except Exception:
        pass
    chips = []
    for _, row in sorted_df.iterrows():
        rule_id = str(safe_value(row, "rule_id", "")).strip()
        rule_name = str(safe_value(row, "rule_name", "")).strip()
        count = safe_value(row, "evidence_count", "")
        if not has_value(count):
            continue
        chips.append(
            html.A(
                className="risk-chip info",
                href="#report-preview",
                title="Evidence references: " + " | ".join(item for item in (rule_name, f"{count} evidence refs") if has_value(item)),
                children=[html.Span(rule_id), html.Strong(str(count))],
            )
        )
    rows = chips[:limit]
    more = risk_overflow_details(chips[limit:], "info")
    if more:
        rows.append(more)
    return rows


def risk_insight_panel(title: str, value: Any, tone: str, rows: list[Any], empty_text: str, href: str):
    help_text = {
        "Triggered rules": "Rules whose configured threshold was breached for this run.",
        "Needs review": "Rules with warnings, missing context, or analyst confirmation required.",
        "Evidence refs": "Source references linked to extracted values and rule outputs.",
    }.get(title, "")
    return html.Div(
        className=f"risk-insight {tone}",
        children=[
            html.Div(
                className="risk-insight-head",
                children=[
                    html.Div(
                        [
                            html.Div(
                                className="risk-insight-label",
                                children=[
                                    html.Span(title),
                                    html.Span(
                                        className="info-popover",
                                        tabIndex=0,
                                        children=[
                                            html.Span("i", className="info-dot"),
                                            html.Span(help_text, className="info-popover-text"),
                                        ],
                                    ) if help_text else None,
                                ],
                            ),
                            html.Strong(str(value)),
                        ]
                    ),
                    html.A("View", href=href) if href and rows else html.Span(),
                ],
            ),
            html.Div(className="risk-mini-list", children=rows or [html.Div(empty_text, className="risk-empty")]),
        ],
    )


def risk_board(
    status_label: str,
    status_detail: str,
    status_tone: str,
    triggered_count: int,
    review_count: int,
    evidence_count: int,
    triggered_rows: list[Any],
    review_rows: list[Any],
    evidence_rows: list[Any],
):
    return html.Div(
        className=f"risk-board {status_tone}",
        children=[
            html.Div(
                className="risk-board-toolbar",
                children=[
                    html.Div(
                        [
                            html.Span("Executive risk overview", className="risk-board-eyebrow"),
                            html.Span("Live assessment summary", className="risk-board-caption"),
                        ]
                    ),
                    html.Button(
                        [html.Span("Expand", className="risk-expand-label"), html.Span("↗", **{"aria-hidden": "true"})],
                        type="button",
                        className="button secondary compact risk-fullscreen-trigger",
                        title="Open the risk board in a full-screen view",
                        **{"aria-label": "Open risk board full screen"},
                    ),
                ],
            ),
            html.Div(
                className="risk-hero",
                children=[
                    html.Div(
                        [
                            html.Div(
                                className="risk-status-label",
                                children=[
                                    html.Span("Report status"),
                                    html.Span(
                                        className="info-popover",
                                        tabIndex=0,
                                        children=[
                                            html.Span("i", className="info-dot"),
                                            html.Span(status_detail, className="info-popover-text"),
                                        ],
                                    ),
                                ],
                            ),
                            html.H3(status_label),
                        ]
                    ),
                    html.Div(
                        className="risk-score-strip",
                        children=[
                            html.Div([html.Strong(str(triggered_count)), html.Span("Triggered")]),
                            html.Div([html.Strong(str(review_count)), html.Span("Review")]),
                            html.Div([html.Strong(str(evidence_count)), html.Span("Evidence")]),
                        ],
                    ),
                ],
            ),
            html.Div(
                className="risk-insight-grid",
                children=[
                    risk_insight_panel("Triggered rules", triggered_count, "risk", triggered_rows, "No triggered rules.", "#triggered-rule-summary"),
                    risk_insight_panel("Needs review", review_count, "warn", review_rows, "No review items.", "#red-flag-details"),
                    risk_insight_panel("Evidence refs", evidence_count, "info", evidence_rows, "No evidence references loaded.", "#report-preview"),
                ],
            ),
        ],
    )


def risk_preview(rule_ids: list[str], run_state: dict[str, Any], report_ctx: Optional[dict[str, Any]] = None):
    details = selected_rule_details(rule_ids)
    high_count = sum(1 for rule in details if rule["severity"] == "High")
    status = str((run_state or {}).get("status", "not_started"))
    summary = report_summary_row(report_ctx)
    rules_df = (report_ctx or {}).get("rules", pd.DataFrame())
    evidence_df = (report_ctx or {}).get("evidence", pd.DataFrame())

    if (report_ctx or {}).get("run_id") and not rules_df.empty:
        report_status = report_status_from_db(report_ctx)
        status_label, status_detail, status_tone = friendly_report_status(report_status)
        red_df = (report_ctx or {}).get("red_flags", pd.DataFrame())
        triggered_df = red_df if red_df is not None and not red_df.empty else rules_df[triggered_rule_mask(rules_df)]
        review_df = rules_df[review_rule_mask(rules_df)]
        blocked_count = 0
        if "outcome_bucket" in rules_df.columns:
            blocked_count = int(
                rules_df["outcome_bucket"]
                .fillna("")
                .astype(str)
                .str.strip()
                .str.lower()
                .isin({"blocked_or_failed", "external_blocked"})
                .sum()
            )
        if blocked_count:
            status_detail = f"{status_detail} {blocked_count} rule(s) are blocked or failed and were not counted as triggered."
        red_flags = triggered_count_from_db(report_ctx)
        review_count = len(review_df)
        evidence_count = int(rules_df["evidence_count"].fillna(0).sum()) if "evidence_count" in rules_df.columns else 0
        return html.Div(
            [
                database_run_status(report_ctx),
                database_trigger_diagnostic(report_ctx),
                potential_fraud_area_panel(report_ctx),
                risk_board(
                    status_label,
                    status_detail,
                    status_tone,
                    red_flags,
                    review_count,
                    evidence_count,
                    risk_mini_rule_rows(triggered_df, evidence_df),
                    risk_mini_review_rows(review_df),
                    risk_mini_evidence_rows(rules_df),
                ),
            ]
        )

    if (report_ctx or {}).get("run_id") and summary is not None:
        report_status = report_status_from_db(report_ctx)
        status_label, status_detail, status_tone = friendly_report_status(report_status)
        red_flags = summary_int(summary, "triggered_rules")
        review_count = summary_int(summary, "review_required_rules")
        evidence_count = summary_int(summary, "evidence_count")
        included_count = summary_int(summary, "included_rule_count", len(details))
        return html.Div(
            [
                database_run_status(report_ctx),
                database_trigger_diagnostic(report_ctx),
                potential_fraud_area_panel(report_ctx),
                risk_board(
                    status_label,
                    status_detail,
                    status_tone,
                    red_flags,
                    review_count,
                    evidence_count or included_count,
                    [],
                    [],
                    [],
                ),
            ]
        )

    tier = "Pending"
    score = "Waiting for DB run" if status in {"running", "started", "completed"} else "-"
    review_count = 0

    return html.Div(
        children=[
            database_load_diagnostic(report_ctx),
            html.Div(
                className="kpi-grid",
                children=[
                    html.Div([html.Span("Risk Tier"), html.Strong(tier)], className="kpi risk" if tier == "Review" else "kpi"),
                    html.Div([html.Span("Composite Score"), html.Strong(score)], className="kpi"),
                    html.Div([html.Span("Selected Rules"), html.Strong(str(len(details)))], className="kpi ok"),
                    html.Div([html.Span("Expected Review"), html.Strong(str(review_count))], className="kpi warn"),
                ],
            ),
        ],
    )


def triggered_summary(rule_ids: list[str], run_state: dict[str, Any], report_path: str = "", report_ctx: Optional[dict[str, Any]] = None):
    details = selected_rule_details(rule_ids)
    rules_df = (report_ctx or {}).get("rules", pd.DataFrame())
    evidence_df = (report_ctx or {}).get("evidence", pd.DataFrame())
    if (report_ctx or {}).get("run_id") and not rules_df.empty:
        red_df = (report_ctx or {}).get("red_flags", pd.DataFrame())
        candidate_df = red_df if red_df is not None and not red_df.empty else rules_df[triggered_rule_mask(rules_df)]
        if candidate_df.empty:
            review_count = len(rules_df[review_rule_mask(rules_df)])
            message = "No rules crossed a red-flag trigger for this run."
            if review_count:
                message += f" {review_count} rule(s) need analyst review in Red Flag Details."
            return html.Div([database_trigger_diagnostic(report_ctx), html.Div(message, className="empty-state")])
        return html.Div([database_trigger_diagnostic(report_ctx), triggered_rule_results_table(candidate_df)])

    summary = report_summary_row(report_ctx)
    if (report_ctx or {}).get("run_id") and summary_int(summary, "triggered_rules") > 0:
        return report_detail_warning(report_ctx, "triggered rule")

    candidate_rules = [rule for rule in details if rule["severity"] == "High"][:5]
    if not candidate_rules:
        return html.Div("Select rules to see the triggered-rule summary preview.", className="empty-state")

    return html.Div("Waiting for database-backed rule results for this run.", className="empty-state")


def red_flag_detail_screen_from_db(row, evidence_df: pd.DataFrame, report_path: str = ""):
    rule_id = str(safe_value(row, "rule_id"))
    evidence_rows = evidence_rows_for_rule(evidence_df, rule_id)
    severity = display_rule_severity(row)
    severity_tone = display_rule_tone(row)
    return html.Div(
        className="redflag-detail-screen",
        children=[
            html.Div(
                className="redflag-detail-header",
                children=[
                    html.Div(
                        [
                            html.Span(str(safe_value(row, "category", "Rule")), className="redflag-category"),
                            html.Span(rule_id, className="redflag-rule-badge"),
                            html.H4(str(safe_value(row, "rule_name", rule_id))),
                            html.P(str(safe_value(row, "explanation", "No explanation stored for this result."))),
                        ]
                    ),
                    html.Div(
                        className="redflag-status-stack",
                        children=[
                            html.Div([html.Span("Status"), status_tag(row_status(row), row_tone(row))], className="redflag-status-tile"),
                            html.Div([html.Span("Confidence"), status_tag(format_confidence(safe_value(row, "confidence", "-")), "info")], className="redflag-status-tile"),
                            html.Div([html.Span("Severity"), status_tag(severity, severity_tone)], className="redflag-status-tile"),
                        ],
                    ),
                ],
            ),
            html.Div(
                className="redflag-accordion",
                children=[
                    html.Details(
                        className="redflag-drawer",
                        open=True,
                        children=[
                            html.Summary("Calculation"),
                            html.Div(
                                className="calculation-card",
                                children=[
                                    html.Div([html.Span("Computed value"), html.Strong(format_number(safe_value(row, "computed_value")))]),
                                    html.Div([html.Span("Threshold"), html.Strong(str(safe_value(row, "threshold_value", "Configured in rule registry")))]),
                                    html.Div([html.Span("Execution status"), html.Strong(str(safe_value(row, "execution_status", "stored")))]),
                                ],
                            ),
                        ],
                    ),
                    html.Details(
                        className="redflag-drawer",
                        open=True,
                        children=[
                            html.Summary("Values used from report"),
                            evidence_value_table_from_rows(evidence_rows, report_path),
                        ],
                    ),
                    html.Details(
                        className="redflag-drawer insight",
                        open=True,
                        children=[
                            html.Summary("Why it matters"),
                            html.Div(className="side-block important", children=[html.Span(str(safe_value(row, "explanation", "Review the stored evidence and rule result.")))]),
                        ],
                    ),
                    html.Details(
                        className="redflag-drawer",
                        children=[
                            html.Summary("Report page number(s)"),
                            html.Div(
                                className="side-block",
                                children=[
                                    html.Strong(report_page_label(report_path)),
                                    html.Span(page_summary_for_rule(evidence_rows)),
                                ],
                            ),
                        ],
                    ),
                ],
            ),
        ],
    )


def red_flag_preview(rule_ids: list[str], run_state: dict[str, Any], report_path: str = "", report_ctx: Optional[dict[str, Any]] = None):
    red_df = (report_ctx or {}).get("red_flags", pd.DataFrame())
    rules_df = (report_ctx or {}).get("rules", pd.DataFrame())
    review_df = (report_ctx or {}).get("review", pd.DataFrame())
    evidence_df = (report_ctx or {}).get("evidence", pd.DataFrame())
    if (report_ctx or {}).get("run_id"):
        if review_df.empty and not rules_df.empty:
            review_df = rules_df[review_rule_mask(rules_df)].copy()

        display_frames = []
        if not red_df.empty:
            triggered_display_df = red_df.copy()
            triggered_display_df["finding_type"] = "threshold_breach"
            triggered_display_df["concern_label"] = triggered_display_df.apply(rule_concern_label, axis=1)
            triggered_display_df["associated_rule"] = triggered_display_df["rule_id"].astype(str)
            display_frames.append(triggered_display_df)
        if not review_df.empty:
            review_display_df = review_df.copy()
            review_display_df["finding_type"] = "review_watchlist"
            review_display_df["concern_label"] = review_display_df.apply(rule_concern_label, axis=1)
            if not red_df.empty:
                associated_by_domain = {
                    rule_domain(str(row.get("rule_id", ""))): f"{row.get('rule_id')} - {row.get('rule_name', row.get('rule_id'))}"
                    for _, row in red_df.iterrows()
                }
                review_display_df["associated_rule"] = review_display_df["rule_id"].map(
                    lambda value: associated_by_domain.get(rule_domain(str(value)), "")
                )
            else:
                review_display_df["associated_rule"] = ""
            display_frames.append(review_display_df)

        if display_frames:
            display_df = pd.concat(display_frames, ignore_index=True, sort=False)
            return html.Div(
                className="redflag-investigation-workbench",
                children=[
                    html.Div(
                        className="section-purpose investigation",
                        children=[
                            html.Strong("Why did it trigger, and what should be reviewed?"),
                            html.Span("Investigation cards combine the stored rationale, calculation, source evidence, page references, and analyst checklist."),
                        ],
                    ),
                    html.Div(
                        className="compact-finding-list",
                        children=[compact_rule_card(row, evidence_df, report_path) for _, row in display_df.head(6).iterrows()],
                    ),
                ],
            )

        if red_df.empty:
            summary = report_summary_row(report_ctx)
            if summary_int(summary, "triggered_rules") > 0 or str(safe_value(summary, "report_status", "")).upper() == "RED_FLAG":
                return report_detail_warning(report_ctx, "red-flag")
            return html.Div("No red-flag or review-required rules were stored for this run.", className="empty-state")

    details = selected_rule_details(rule_ids)
    high_rules = [rule for rule in details if rule["severity"] == "High"]
    if not high_rules:
        return html.Div("No high-severity rules selected.", className="empty-state")
    return html.Div("Waiting for database-backed red-flag details for this run.", className="empty-state")


def top_findings_preview(report_path: str, report_ctx: Optional[dict[str, Any]] = None):
    rules_df = (report_ctx or {}).get("rules", pd.DataFrame())
    red_df = (report_ctx or {}).get("red_flags", pd.DataFrame())
    summary = report_summary_row(report_ctx)
    if red_df is not None and not red_df.empty:
        finding_rows = [row for _, row in red_df.head(3).iterrows()]
    elif not rules_df.empty:
        finding_rows = [row for _, row in rules_df[triggered_rule_mask(rules_df)].head(3).iterrows()]
    else:
        finding_rows = []
    finding_children = []
    for rank, row in enumerate(finding_rows, start=1):
        rule_id = str(safe_value(row, "rule_id"))
        finding_children.append(
            html.Article(
                className=f"executive-finding {row_tone(row)}",
                children=[
                    html.Div(str(rank), className="executive-finding-rank"),
                    html.Div(
                        className="executive-finding-copy",
                        children=[
                            html.Div(
                                className="executive-finding-kicker",
                                children=[html.Strong(rule_id), html.Span(str(safe_value(row, "category", "Risk signal")))],
                            ),
                            html.H4(str(safe_value(row, "rule_name", rule_id))),
                            html.P(str(safe_value(row, "explanation", rule_concern_label(row)))),
                        ],
                    ),
                    html.Div(
                        className="executive-finding-metrics",
                        children=[
                            html.Div([html.Span("Value"), html.Strong(format_number(safe_value(row, "computed_value")))]),
                            html.Div([html.Span("Severity"), html.Strong(display_rule_severity(row))]),
                            status_tag(row_status(row), row_tone(row)),
                        ],
                    ),
                ],
            )
        )
    if not finding_children and (report_ctx or {}).get("run_id") and str(safe_value(summary, "report_status", "")).upper() in {"RED_FLAG", "REVIEW_REQUIRED", "FIX_REQUIRED"}:
        finding_children = [report_detail_warning(report_ctx, "rule result")]
    return html.Div(
        className="top-findings-workbench",
        children=[
            html.Div(
                className="section-purpose",
                children=[
                    html.Strong("Executive priority list"),
                    html.Span("A concise ranking only. Use Red Flag Investigation for evidence, calculations, and analyst actions."),
                ],
            ),
            *(finding_children or [html.Div("No findings loaded for this run.", className="empty-state compact")]),
        ],
    )


def report_preview(company: str, report_path: str, rule_ids: list[str], run_state: dict[str, Any], report_ctx: Optional[dict[str, Any]] = None):
    status = str((run_state or {}).get("status", "not_started"))
    report_names = [str(path).lstrip("/").rsplit("/", 1)[-1] for path in selected_report_paths(report_path)]
    report_name = ", ".join(report_names) if report_names else "No report selected"
    run_ref = (report_ctx or {}).get("run_id") or (run_state or {}).get("scenario_run_id", "-")
    summary = report_summary_row(report_ctx)
    return html.Div(
        className="report-preview",
        children=[
            html.Div(
                className="preview-status",
                children=[
                    status_tag(f"Status: {status.replace('_', ' ').title()}", "low" if status == "completed" else "medium"),
                    status_tag(f"Run: {run_ref}", "info"),
                ],
            ),
            html.Div(
                className="report-compact-grid",
                children=[
                    html.Div([html.Span("Entity"), html.Strong(str(safe_value(summary, "entity_id", company or "-")))]),
                    html.Div([html.Span("Report"), html.Strong(str(safe_value(summary, "file_names", report_name)))]),
                    html.Div([html.Span("Status"), html.Strong(str(safe_value(summary, "report_status", "Pending")))]),
                    html.Div([html.Span("Triggered"), html.Strong(str(summary_int(summary, "triggered_rules")))]),
                ],
            ),
        ],
    )


def audit_trail(company: str, report_path: str, rule_ids: list[str], run_state: dict[str, Any], report_ctx: Optional[dict[str, Any]] = None):
    status = str((run_state or {}).get("status", "not_started"))
    report_names = [str(path).lstrip("/").rsplit("/", 1)[-1] for path in selected_report_paths(report_path)]
    report_name = ", ".join(report_names) if report_names else "No report selected"
    events = [
        ("Setup", f"Company selected: {company or 'not selected'}"),
        ("Report", f"Report selected: {report_name}"),
        ("Rules", f"{len(rule_ids or [])} rule(s) selected for execution"),
    ]
    if status in {"started", "running", "completed", "failed"}:
        events.append(("Pipeline", f"Assessment pipeline started at {(run_state or {}).get('started_at', '-')}"))
        events.append(("UI Run Ref", str((run_state or {}).get("scenario_run_id", "-"))))
    if (report_ctx or {}).get("run_id"):
        events.append(("DB Report Run", str((report_ctx or {}).get("run_id"))))
    if status == "failed":
        events.append(("Error", user_friendly_pipeline_error((run_state or {}).get("error", "Assessment pipeline failed to start"))))
    return html.Div(
        className="timeline",
        children=[html.Div([html.Strong(label), html.Span(text)]) for label, text in events],
    )


CONFIG_ROWS = [
    {
        "key": "profile:FSRE-SGX",
        "area": "Profile",
        "table": "fsre_config.deployment_profiles",
        "id": "FSRE-SGX",
        "version": "1.0",
        "status": "active",
        "scope": "SGX listed-company assessment",
        "title": "FSRE-SGX Deployment Profile",
        "description": "Binds runtime, connectors, prompts, active rules, scoring and validation gates.",
        "json_column": "config_json",
        "config_json": {
            "profile_id": "FSRE-SGX",
            "runtime": {"environment": "dev", "assessment_mode": "manual_annual_report_upload"},
            "connectors": [
                {"connector_id": "manual_annual_report_upload", "required": True, "mode": "batch"},
                {"connector_id": "ollama_llama32", "required": True, "mode": "batch"},
                {"connector_id": "sgx_filings_connector", "required": False, "mode": "on_demand"},
                {"connector_id": "market_data_connector", "required": False, "mode": "on_demand"},
                {"connector_id": "ownership_graph_connector", "required": False, "mode": "on_demand"},
            ],
            "prompt": {"prompt_id": "annual_report_financial_extraction_v1", "prompt_version": "1.0"},
            "rules": {"source_table": "fsre_config.profile_active_rules", "active_rule_count": 17},
            "scoring": {"scoring_config_id": "severity_points_v1", "scoring_config_version": "1.0"},
            "validation_gates": [
                "required_field_manifest_complete",
                "triggered_rules_have_evidence",
                "unexpected_blocked_rules_zero",
            ],
        },
        "supporting_json": {
            "editable_columns": ["profile_name", "config_json", "status", "is_active", "approved_by", "approved_at"],
            "activation_table": "fsre_config.profile_active_rules",
        },
    },
    {
        "key": "rule:FIN-CMP-001",
        "area": "Rule Config",
        "table": "fsre_rules.rule_registry",
        "id": "FIN-CMP-001",
        "version": "1.0",
        "status": "active",
        "scope": "composite_fraud_score",
        "title": "Beneish M-Score Earnings Manipulation Probability",
        "description": "Threshold config for Beneish proxy scoring.",
        "json_column": "threshold_config_json",
        "config_json": {
            "metric": "beneish_m_score",
            "threshold": -1.78,
            "trigger_when": "m_score_gt_threshold",
            "formula_reference": "Beneish 1999 methodology",
            "input_contract_version": "beneish_proxy_required_fields_v2",
            "bands": [{"severity": "HIGH", "gt": -1.78}],
        },
        "supporting_json": {
            "required_fields_json": [
                "financials.revenue.current",
                "financials.revenue.prior",
                "financials.accounts_receivable.current",
                "financials.accounts_receivable.prior",
                "financials.total_assets.current",
                "financials.total_assets.prior",
                "financials.total_liabilities.current",
                "financials.total_liabilities.prior",
                "financials.net_profit.current",
                "financials.operating_cash_flow.current",
            ],
            "required_connectors_json": ["manual_annual_report_upload"],
            "implementation_key": "rules.fin_cmp_001",
        },
    },
    {
        "key": "rule:FIN-LIA-002",
        "area": "Rule Config",
        "table": "fsre_rules.rule_registry",
        "id": "FIN-LIA-002",
        "version": "1.0",
        "status": "active",
        "scope": "liability_concealment",
        "title": "Understated Provisions",
        "description": "Provision decrease and benchmark threshold bands.",
        "json_column": "threshold_config_json",
        "config_json": {
            "metric": "provision_change_and_benchmark",
            "bands": [
                {"severity": "HIGH", "provision_decrease_gt": 0.20, "prior_event_unresolved": True},
                {"severity": "MEDIUM", "sector_percentile_lt": 25},
            ],
        },
        "supporting_json": {
            "required_fields_json": [
                "financials.provisions_and_contingent_liabilities.current",
                "financials.provisions_and_contingent_liabilities.prior",
                "events.litigation",
                "benchmarks.sector_provision_ratio",
            ],
            "required_connectors_json": ["manual_annual_report_upload", "court_records_connector", "sector_benchmark_connector"],
            "implementation_key": "rules.fin_lia_002",
        },
    },
    {
        "key": "activation:FIN-LIA-002",
        "area": "Profile Rule",
        "table": "fsre_config.profile_active_rules",
        "id": "FIN-LIA-002",
        "version": "1.0",
        "status": "active",
        "scope": "execution_order 100",
        "title": "Profile Rule Activation",
        "description": "Profile-level enablement and override JSON for a rule.",
        "json_column": "rule_config_json",
        "config_json": {
            "enabled": True,
            "activation_group": "current_calculable",
            "review_policy": "needs_analyst_signoff_when_warning_present",
        },
        "supporting_json": {"profile_id": "FSRE-SGX", "profile_version": "1.0", "execution_order": 100},
    },
    {
        "key": "scoring:severity_points_v1",
        "area": "Scoring Config",
        "table": "fsre_config.scoring_config",
        "id": "severity_points_v1",
        "version": "1.0",
        "status": "active",
        "scope": "weighted_severity_points",
        "title": "Severity Points Weightage",
        "description": "Global score weightage and risk-tier bands after rule severity is calculated.",
        "json_column": "config_json",
        "config_json": {
            "severity_points": {"CRITICAL": 40, "HIGH": 20, "MEDIUM": 8, "LOW": 3, "NONE": 0},
            "risk_tier_bands": [
                {"tier": "CRITICAL", "gte": 60},
                {"tier": "HIGH", "gte": 35},
                {"tier": "MEDIUM", "gte": 15},
                {"tier": "LOW_WATCH", "gte": 1},
                {"tier": "NONE", "gte": 0},
            ],
            "critical_override_enabled": True,
            "minimum_evidence_confidence_for_auto_approve": 0.85,
            "missing_evidence_behavior": "fail_validation",
        },
        "supporting_json": {"scoring_model": "weighted_severity_points", "output_table": "fsre_scoring.entity_scores"},
    },
    {
        "key": "runtime:llm",
        "area": "Runtime",
        "table": "fsre_config.runtime_parameter_sets",
        "id": "default_llm_extraction_runtime",
        "version": "1.0",
        "status": "active",
        "scope": "llm_extraction",
        "title": "Default LLM Extraction Runtime",
        "description": "Dataiku/Ollama extraction runtime parameters.",
        "json_column": "parameters_json",
        "config_json": {
            "prompt_id": "annual_report_financial_extraction_v1",
            "prompt_version": "1.0",
            "model_provider": "ollama",
            "model_name": "llama3.2",
            "ollama_base_url": "http://host.docker.internal:11434",
            "max_chunks": 18,
            "max_context_chars": 48000,
        },
        "supporting_json": {"environment": "dev", "parameter_scope": "llm_extraction", "is_default": True},
    },
    {
        "key": "runtime:validation",
        "area": "Runtime",
        "table": "fsre_config.runtime_parameter_sets",
        "id": "default_rule_input_validation",
        "version": "1.0",
        "status": "active",
        "scope": "rule_input_validation",
        "title": "Rule Input Validation Policy",
        "description": "Controls unresolved inputs, external evidence, warnings and confidence floors.",
        "json_column": "parameters_json",
        "config_json": {
            "missing_required_input_behavior": "block_rule",
            "external_connector_missing_behavior": "warn_and_continue_when_configured",
            "allow_financial_statement_period_fallback": True,
            "min_confidence_score": 0.85,
            "warn_only_fields": [
                "sgx_announcements.shareholder_approval",
                "financials.quarterly_revenue",
                "financials.accounts_receivable.next_period",
            ],
        },
        "supporting_json": {"environment": "dev", "parameter_scope": "rule_input_validation"},
    },
    {
        "key": "connector:manual_upload",
        "area": "Connector",
        "table": "fsre_config.connector_registry",
        "id": "manual_annual_report_upload",
        "version": "1.0",
        "status": "active",
        "scope": "document_input",
        "title": "Manual Annual Report Upload",
        "description": "Connector defaults for uploaded annual-report PDFs and text files.",
        "json_column": "default_config_json",
        "config_json": {
            "requires_document_hash": True,
            "stores_original_file_reference": True,
            "accepted_document_types": ["annual_report", "financial_statement"],
            "max_file_mb": 100,
        },
        "supporting_json": {"implementation_key": "connectors.manual_annual_report_upload", "supported_modes": ["batch", "on_demand"]},
    },
    {
        "key": "extraction:synonyms",
        "area": "Extraction",
        "table": "fsre_config.field_synonym_registry",
        "id": "financials.revenue",
        "version": "*",
        "status": "active",
        "scope": "field_resolution",
        "title": "Field Synonym Registry",
        "description": "Label matching config used by extraction and field resolution.",
        "json_column": "metadata_json",
        "config_json": {
            "canonical_field_path": "financials.revenue",
            "synonyms": ["revenue", "operating revenue", "total revenue", "sales"],
            "profile_id": "*",
            "connector_id": "*",
            "priority": 100,
        },
        "supporting_json": {
            "field_catalog": "fsre_config.field_catalog",
            "negative_synonyms": "fsre_config.field_synonym_negative_registry",
            "numeric_zero_policy": "fsre_config.numeric_zero_evidence_registry",
        },
    },
    {
        "key": "extraction:narrative",
        "area": "Extraction",
        "table": "fsre_config.narrative_evidence_registry",
        "id": "related_party_note14",
        "version": "1.0",
        "status": "active",
        "scope": "narrative_evidence",
        "title": "Narrative Evidence Rule",
        "description": "Profile-scoped note evidence pattern matching.",
        "json_column": "metadata_json",
        "config_json": {
            "profile_id": "FSRE-SGX",
            "profile_version": "1.0",
            "field_path": "related_party_register",
            "pattern": "RELATED PARTY TRANSACTIONS",
            "required_any_terms": ["subsidiaries of ultimate holding company", "associates", "joint ventures"],
            "candidate_decision": "accepted",
        },
        "supporting_json": {"source_table": "fsre_config.narrative_evidence_registry", "output_usage": "fsre_audit.evidence_log"},
    },
]


FUTURE_CONFIG_AREAS = [
    ("Assessment Profile", "Controls the market scope, runtime mode, connector mix, scoring model and validation gates for each deployment profile.", "Profile", "profile"),
    ("Rule Activation", "Lets admins enable, disable, order and override rules for a selected profile without code changes.", "Rules", "rules"),
    ("Rule Thresholds", "Maintains formulas, severity bands, required inputs and connector requirements used by the engine.", "Thresholds", "thresholds"),
    ("Scoring And Weightage", "Controls severity points, risk-tier cutoffs, critical overrides and confidence requirements.", "Scoring", "scoring"),
    ("Runtime Policies", "Configures extraction, rule validation, reporting and assessment behavior used during pipeline execution.", "Runtime", "runtime"),
    ("Rerun Requests", "Creates controlled rerun requests for extraction, field resolution, rule execution or report refresh.", "Requests", "requests"),
    ("Connector Defaults", "Maintains source connector behavior such as upload limits, supported formats and enabled modes.", "Connectors", "connectors"),
    ("Document Classification", "Maps uploaded files to entity, document type, period and routing rules.", "Classification", "classification"),
    ("Canonical Field Dictionary", "Defines the financial and narrative fields the engine can resolve and validate.", "Fields", "fields"),
    ("Synonym Matching", "Tunes report label matching so extraction recognizes client-specific financial-statement wording.", "Synonyms", "synonyms"),
    ("Narrative Evidence", "Controls note/disclosure pattern matching used as evidence for review and rule checks.", "Evidence", "evidence"),
]


def config_display_label(row: dict[str, Any]) -> str:
    table_labels = {
        "fsre_config.deployment_profiles": "Deployment profile",
        "fsre_rules.rule_registry": "Rule thresholds",
        "fsre_config.profile_active_rules": "Active rule setup",
        "fsre_config.scoring_config": "Scoring and weightage",
        "fsre_config.runtime_parameter_sets": "Runtime settings",
        "fsre_config.connector_registry": "Connector setup",
        "fsre_config.field_synonym_registry": "Field matching",
        "fsre_config.narrative_evidence_registry": "Narrative evidence",
    }
    readable_table = table_labels.get(row["table"], row["table"].split(".")[-1].replace("_", " ").title())
    return f"{row['title']} - {readable_table}"


def config_options() -> list[dict[str, str]]:
    return [{"label": config_display_label(row), "value": row["key"]} for row in CONFIG_ROWS]


def get_config_row(config_key: Optional[str]) -> dict[str, Any]:
    return next((row for row in CONFIG_ROWS if row["key"] == config_key), CONFIG_ROWS[0])


def json_pretty(value: Any) -> str:
    return json.dumps(value, indent=2, sort_keys=False)


def parse_json_text(text: str) -> Any:
    if not str(text or "").strip():
        return {}
    return json.loads(text)


def sql_literal(value: Any) -> str:
    return str(value).replace("'", "''")


def compact_json(value: Any) -> str:
    return json.dumps(value, separators=(",", ":"))


def config_save_supported(row: dict[str, Any]) -> bool:
    return row["table"] in {
        "fsre_config.deployment_profiles",
        "fsre_rules.rule_registry",
        "fsre_config.profile_active_rules",
        "fsre_config.scoring_config",
        "fsre_config.runtime_parameter_sets",
        "fsre_config.connector_registry",
    }


def validate_config_status(row: dict[str, Any], status: str) -> str:
    table = row["table"]
    if table == "fsre_config.profile_active_rules":
        return status or row["status"]
    allowed = {"draft", "active", "deprecated", "retired"}
    if table == "fsre_config.connector_registry":
        allowed = {"active", "inactive", "deprecated"}
    effective_status = status or row["status"]
    if effective_status not in allowed:
        raise ValueError(f"Status '{effective_status}' is not valid for {table}. Allowed: {', '.join(sorted(allowed))}.")
    return effective_status


def open_postgres_connection_for_config():
    try:
        import psycopg2
        import psycopg2.extras
    except Exception as exc:
        raise RuntimeError(f"psycopg2 is not available in this Dataiku code environment: {exc}") from exc

    variables = project_variables()
    return psycopg2.connect(
        host=postgres_setting(variables, "fsre_pg_host", "PGHOST", "fsre-postgres"),
        port=int(postgres_setting(variables, "fsre_pg_port", "PGPORT", "5432") or "5432"),
        dbname=postgres_setting(variables, "fsre_pg_database", "PGDATABASE", "fsre"),
        user=postgres_setting(variables, "fsre_pg_user", "PGUSER", "fsre_admin"),
        password=postgres_setting(variables, "fsre_pg_password", "PGPASSWORD", None),
        cursor_factory=psycopg2.extras.RealDictCursor,
    )


def execute_config_update(row: dict[str, Any], config_json: dict[str, Any], supporting_json: dict[str, Any], status: str) -> dict[str, Any]:
    if not config_save_supported(row):
        raise ValueError(f"Direct save is not enabled for {row['table']}. Use the generated SQL after adding exact key support.")

    table = row["table"]
    status = validate_config_status(row, status)
    conn = open_postgres_connection_for_config()
    try:
        with conn:
            with conn.cursor() as cur:
                if table == "fsre_rules.rule_registry":
                    cur.execute(
                        """
                        UPDATE fsre_rules.rule_registry
                        SET threshold_config_json = %s::jsonb,
                            required_fields_json = COALESCE(%s::jsonb, required_fields_json),
                            required_connectors_json = COALESCE(%s::jsonb, required_connectors_json),
                            implementation_key = COALESCE(%s, implementation_key),
                            status = %s,
                            updated_at = now()
                        WHERE rule_id = %s
                          AND rule_version = %s
                        RETURNING rule_id, rule_version, status, updated_at
                        """,
                        (
                            compact_json(config_json),
                            compact_json(supporting_json["required_fields_json"]) if isinstance(supporting_json.get("required_fields_json"), list) else None,
                            compact_json(supporting_json["required_connectors_json"]) if isinstance(supporting_json.get("required_connectors_json"), list) else None,
                            supporting_json.get("implementation_key"),
                            status,
                            row["id"],
                            row["version"],
                        ),
                    )
                elif table == "fsre_config.profile_active_rules":
                    cur.execute(
                        """
                        UPDATE fsre_config.profile_active_rules par
                        SET execution_order = COALESCE(%s, execution_order),
                            rule_config_json = %s::jsonb
                        FROM fsre_config.deployment_profiles dp
                        WHERE dp.profile_pk = par.profile_pk
                          AND dp.profile_id = %s
                          AND dp.profile_version = %s
                          AND par.rule_id = %s
                          AND par.rule_version = %s
                        RETURNING par.rule_id, par.rule_version, par.execution_order, par.rule_config_json
                        """,
                        (
                            supporting_json.get("execution_order"),
                            compact_json(config_json),
                            supporting_json.get("profile_id", "FSRE-SGX"),
                            supporting_json.get("profile_version", "1.0"),
                            row["id"],
                            row["version"],
                        ),
                    )
                elif table == "fsre_config.scoring_config":
                    cur.execute(
                        """
                        UPDATE fsre_config.scoring_config
                        SET config_json = %s::jsonb,
                            config_hash = encode(digest(%s, 'sha256'), 'hex'),
                            status = %s,
                            updated_at = now()
                        WHERE scoring_config_id = %s
                          AND scoring_config_version = %s
                        RETURNING scoring_config_id, scoring_config_version, status, updated_at
                        """,
                        (compact_json(config_json), compact_json(config_json), status, row["id"], row["version"]),
                    )
                elif table == "fsre_config.deployment_profiles":
                    cur.execute(
                        """
                        UPDATE fsre_config.deployment_profiles
                        SET config_json = %s::jsonb,
                            config_hash = encode(digest(%s, 'sha256'), 'hex'),
                            status = %s,
                            updated_at = now()
                        WHERE profile_id = %s
                          AND profile_version = %s
                        RETURNING profile_id, profile_version, status, is_active, updated_at
                        """,
                        (compact_json(config_json), compact_json(config_json), status, row["id"], row["version"]),
                    )
                elif table == "fsre_config.runtime_parameter_sets":
                    cur.execute(
                        """
                        UPDATE fsre_config.runtime_parameter_sets
                        SET parameters_json = %s::jsonb,
                            parameters_hash = encode(digest(%s, 'sha256'), 'hex'),
                            status = %s,
                            updated_at = now()
                        WHERE parameter_set_id = %s
                          AND parameter_set_version = %s
                        RETURNING parameter_set_id, parameter_set_version, parameter_scope, status, updated_at
                        """,
                        (compact_json(config_json), compact_json(config_json), status, row["id"], row["version"]),
                    )
                elif table == "fsre_config.connector_registry":
                    cur.execute(
                        """
                        UPDATE fsre_config.connector_registry
                        SET default_config_json = %s::jsonb,
                            status = %s,
                            updated_at = now()
                        WHERE connector_id = %s
                        RETURNING connector_id, connector_version, status, updated_at
                        """,
                        (compact_json(config_json), status, row["id"]),
                    )
                updated = cur.fetchone()
                if not updated:
                    raise ValueError(f"No database row matched {row['table']} / {row['id']} / {row['version']}.")
                return dict(updated)
    finally:
        try:
            conn.close()
        except Exception:
            pass


def generate_config_sql(row: dict[str, Any], config_json: dict[str, Any], supporting_json: dict[str, Any], status: str) -> str:
    json_sql = sql_literal(compact_json(config_json))
    status_sql = sql_literal(status or row["status"])
    table = row["table"]
    row_id = sql_literal(row["id"])
    version = sql_literal(row["version"])

    if table == "fsre_rules.rule_registry":
        extra_sets = []
        if isinstance(supporting_json.get("required_fields_json"), list):
            extra_sets.append(f"    required_fields_json = '{sql_literal(compact_json(supporting_json['required_fields_json']))}'::jsonb")
        if isinstance(supporting_json.get("required_connectors_json"), list):
            extra_sets.append(f"    required_connectors_json = '{sql_literal(compact_json(supporting_json['required_connectors_json']))}'::jsonb")
        if supporting_json.get("implementation_key"):
            extra_sets.append(f"    implementation_key = '{sql_literal(supporting_json['implementation_key'])}'")
        extra_sql = (",\n" + ",\n".join(extra_sets)) if extra_sets else ""
        return (
            "UPDATE fsre_rules.rule_registry\n"
            "SET\n"
            f"    threshold_config_json = '{json_sql}'::jsonb,\n"
            f"    status = '{status_sql}'{extra_sql},\n"
            "    updated_at = now()\n"
            f"WHERE rule_id = '{row_id}'\n"
            f"  AND rule_version = '{version}';\n\n"
            "SELECT rule_id, rule_version, threshold_config_json\n"
            "FROM fsre_rules.rule_registry\n"
            f"WHERE rule_id = '{row_id}'\n"
            f"  AND rule_version = '{version}';"
        )

    if table == "fsre_config.profile_active_rules":
        profile_id = sql_literal(supporting_json.get("profile_id", "FSRE-SGX"))
        profile_version = sql_literal(supporting_json.get("profile_version", "1.0"))
        execution_order = supporting_json.get("execution_order", "NULL")
        return (
            "UPDATE fsre_config.profile_active_rules par\n"
            "SET\n"
            f"    execution_order = {execution_order},\n"
            f"    rule_config_json = '{json_sql}'::jsonb\n"
            "FROM fsre_config.deployment_profiles dp\n"
            "WHERE dp.profile_pk = par.profile_pk\n"
            f"  AND dp.profile_id = '{profile_id}'\n"
            f"  AND dp.profile_version = '{profile_version}'\n"
            f"  AND par.rule_id = '{row_id}'\n"
            f"  AND par.rule_version = '{version}';"
        )

    if table == "fsre_config.scoring_config":
        return (
            "UPDATE fsre_config.scoring_config\n"
            "SET\n"
            f"    config_json = '{json_sql}'::jsonb,\n"
            f"    config_hash = encode(digest('{json_sql}', 'sha256'), 'hex'),\n"
            f"    status = '{status_sql}',\n"
            "    updated_at = now()\n"
            f"WHERE scoring_config_id = '{row_id}'\n"
            f"  AND scoring_config_version = '{version}';"
        )

    if table == "fsre_config.deployment_profiles":
        return (
            "UPDATE fsre_config.deployment_profiles\n"
            "SET\n"
            f"    config_json = '{json_sql}'::jsonb,\n"
            f"    config_hash = encode(digest('{json_sql}', 'sha256'), 'hex'),\n"
            f"    status = '{status_sql}',\n"
            "    updated_at = now()\n"
            f"WHERE profile_id = '{row_id}'\n"
            f"  AND profile_version = '{version}';"
        )

    if table == "fsre_config.runtime_parameter_sets":
        return (
            "UPDATE fsre_config.runtime_parameter_sets\n"
            "SET\n"
            f"    parameter_scope = '{sql_literal(row['scope'])}',\n"
            f"    parameters_json = '{json_sql}'::jsonb,\n"
            f"    parameters_hash = encode(digest('{json_sql}', 'sha256'), 'hex'),\n"
            f"    status = '{status_sql}',\n"
            "    updated_at = now()\n"
            f"WHERE parameter_set_id = '{row_id}'\n"
            f"  AND parameter_set_version = '{version}';"
        )

    if table == "fsre_config.connector_registry":
        return (
            "UPDATE fsre_config.connector_registry\n"
            "SET\n"
            f"    default_config_json = '{json_sql}'::jsonb,\n"
            f"    status = '{status_sql}',\n"
            "    updated_at = now()\n"
            f"WHERE connector_id = '{row_id}';"
        )

    return (
        f"-- Generic governed config patch for {table}.\n"
        "-- Confirm key columns before execution because this table may use a composite primary key.\n"
        f"UPDATE {table}\n"
        "SET\n"
        f"    {row['json_column']} = '{json_sql}'::jsonb,\n"
        f"    status = '{status_sql}',\n"
        "    updated_at = now()\n"
        f"WHERE /* TODO: add exact primary key predicate for */ '{row_id}' = '{row_id}';"
    )


def future_config_tiles():
    return html.Div(
        className="future-config-grid",
        children=[
            html.Article(
                className=f"future-config-tile {tone}",
                children=[
                    html.Div(className="future-tile-icon", children=badge),
                    html.Div(
                        className="future-tile-copy",
                        children=[
                            html.H4(name),
                            html.P(use),
                        ],
                    ),
                ],
            )
            for name, use, badge, tone in FUTURE_CONFIG_AREAS
        ],
    )


def quick_control_values(row: dict[str, Any]) -> dict[str, Any]:
    cfg = row.get("config_json") or {}
    supporting = row.get("supporting_json") or {}
    title = f"Friendly update controls for {row['title']}"
    help_text = "Use these common controls for safe edits. Advanced JSON remains available below."
    number_label = "Primary value"
    number_help = "Context-specific numeric setting."
    number_value = None
    high_points = None
    medium_points = None
    enabled = "na"

    if row["table"] == "fsre_rules.rule_registry":
        bands = cfg.get("bands") or []
        first_band = bands[0] if bands else {}
        number_label = "Threshold / band value"
        number_help = "Updates threshold and the first severity band value where possible."
        number_value = cfg.get("threshold")
        if number_value is None:
            for key in ("gt", "gte", "lt", "lte", "provision_decrease_gt", "sector_percentile_lt"):
                if key in first_band:
                    number_value = first_band.get(key)
                    break
    elif row["table"] == "fsre_config.scoring_config":
        points = cfg.get("severity_points") or {}
        number_label = "High risk tier starts at"
        number_help = "Updates the HIGH tier gte threshold."
        high_band = next((band for band in cfg.get("risk_tier_bands", []) if band.get("tier") == "HIGH"), {})
        number_value = high_band.get("gte")
        high_points = points.get("HIGH")
        medium_points = points.get("MEDIUM")
    elif row["table"] == "fsre_config.runtime_parameter_sets":
        number_label = "Confidence / limit value"
        number_help = "Updates min_confidence_score, max_chunks or max_context_chars depending on this runtime config."
        number_value = cfg.get("min_confidence_score", cfg.get("max_chunks", cfg.get("max_context_chars")))
    elif row["table"] == "fsre_config.profile_active_rules":
        number_label = "Execution order"
        number_help = "Updates rule order for this profile."
        number_value = supporting.get("execution_order")
        enabled = "true" if cfg.get("enabled") is True else "false" if cfg.get("enabled") is False else "na"
    elif row["table"] == "fsre_config.connector_registry":
        number_label = "Max file size MB"
        number_help = "Updates max_file_mb for upload connector config."
        number_value = cfg.get("max_file_mb")
    return {
        "title": title,
        "help": help_text,
        "number_label": number_label,
        "number_help": number_help,
        "number_value": number_value,
        "high_points": high_points,
        "medium_points": medium_points,
        "enabled": enabled,
    }


def quick_control_field_styles(row: dict[str, Any]) -> tuple[dict[str, str], dict[str, str], dict[str, str], dict[str, str], str]:
    visible = {"display": "grid"}
    hidden = {"display": "none"}
    table = row["table"]
    if table == "fsre_config.scoring_config":
        return visible, visible, visible, hidden, "friendly-field-grid scoring-grid"
    if table == "fsre_config.profile_active_rules":
        return visible, hidden, hidden, visible, "friendly-field-grid profile-rule-grid"
    if table in {"fsre_rules.rule_registry", "fsre_config.runtime_parameter_sets", "fsre_config.connector_registry"}:
        return visible, hidden, hidden, hidden, "friendly-field-grid single-grid"
    return hidden, hidden, hidden, hidden, "friendly-field-grid single-grid"


def quick_controls(row: dict[str, Any]):
    quick = quick_control_values(row)
    table = row["table"]
    fields = []
    if table in {
        "fsre_rules.rule_registry",
        "fsre_config.runtime_parameter_sets",
        "fsre_config.connector_registry",
    }:
        fields.append(
            html.Label(
                className="field-label quick-field",
                children=[
                    html.Span(id="quick-number-label", children=quick["number_label"]),
                    dcc.Input(id="quick-number-value", type="number", step=0.01, value=quick["number_value"], className="quick-input"),
                    html.Small(id="quick-number-help", children=quick["number_help"], className="field-help"),
                ],
            )
        )
    elif table == "fsre_config.scoring_config":
        fields.extend(
            [
                html.Label(
                    className="field-label quick-field",
                    children=[
                        html.Span(id="quick-number-label", children=quick["number_label"]),
                        dcc.Input(id="quick-number-value", type="number", step=1, value=quick["number_value"], className="quick-input"),
                        html.Small(id="quick-number-help", children=quick["number_help"], className="field-help"),
                    ],
                ),
                html.Label(
                    className="field-label quick-field",
                    children=[
                        "High severity points",
                        dcc.Input(id="quick-high-points", type="number", step=1, value=quick["high_points"], className="quick-input"),
                        html.Small("Score added when a rule returns HIGH severity.", className="field-help"),
                    ],
                ),
                html.Label(
                    className="field-label quick-field",
                    children=[
                        "Medium severity points",
                        dcc.Input(id="quick-medium-points", type="number", step=1, value=quick["medium_points"], className="quick-input"),
                        html.Small("Score added when a rule returns MEDIUM severity.", className="field-help"),
                    ],
                ),
            ]
        )
    elif table == "fsre_config.profile_active_rules":
        fields.extend(
            [
                html.Label(
                    className="field-label quick-field",
                    children=[
                        html.Span(id="quick-number-label", children=quick["number_label"]),
                        dcc.Input(id="quick-number-value", type="number", step=1, value=quick["number_value"], className="quick-input"),
                        html.Small(id="quick-number-help", children=quick["number_help"], className="field-help"),
                    ],
                ),
                html.Label(
                    className="field-label quick-field",
                    children=[
                        "Enabled",
                        dcc.Dropdown(
                            id="quick-enabled",
                            options=[
                                {"label": "Enabled", "value": "true"},
                                {"label": "Disabled", "value": "false"},
                                {"label": "Not applicable", "value": "na"},
                            ],
                            value=quick["enabled"],
                            clearable=False,
                        ),
                        html.Small("Controls whether this rule is active for the selected profile.", className="field-help"),
                    ],
                ),
            ]
        )
    else:
        fields.append(html.Div("Use the advanced JSON editor for this configuration type.", className="message summary compact-message"))

    return html.Div(
        className="friendly-config-fields",
        children=[
            html.Div(
                className="friendly-field-head",
                children=[html.H4(quick["title"]), html.P(quick["help"])],
            ),
            html.Div(className="friendly-field-grid", children=fields),
        ],
    )


def quick_control_hidden_bank():
    return html.Div(
        style={"display": "none"},
        children=[
            html.Span(id="quick-number-label"),
            html.Small(id="quick-number-help"),
            dcc.Input(id="quick-number-value", type="number"),
            dcc.Input(id="quick-high-points", type="number"),
            dcc.Input(id="quick-medium-points", type="number"),
            dcc.Dropdown(
                id="quick-enabled",
                options=[
                    {"label": "Enabled", "value": "true"},
                    {"label": "Disabled", "value": "false"},
                    {"label": "Not applicable", "value": "na"},
                ],
                value="na",
            ),
        ],
    )


def apply_quick_values_to_config(
    row: dict[str, Any],
    config_json: dict[str, Any],
    supporting_json: dict[str, Any],
    quick_number,
    high_points,
    medium_points,
    enabled,
) -> tuple[dict[str, Any], dict[str, Any]]:
    cfg = dict(config_json or {})
    support = dict(supporting_json or {})
    table = row["table"]

    if table == "fsre_rules.rule_registry" and quick_number is not None:
        bands = list(cfg.get("bands") or [])
        first_band = dict(bands[0]) if bands else {}
        if "threshold" in cfg:
            cfg["threshold"] = quick_number
        target_key = next((key for key in ("gt", "gte", "lt", "lte", "provision_decrease_gt", "sector_percentile_lt") if key in first_band), None)
        if target_key:
            first_band[target_key] = quick_number
            bands[0] = first_band
            cfg["bands"] = bands
    elif table == "fsre_config.scoring_config":
        points = dict(cfg.get("severity_points") or {})
        if high_points is not None:
            points["HIGH"] = high_points
        if medium_points is not None:
            points["MEDIUM"] = medium_points
        if points:
            cfg["severity_points"] = points
        if quick_number is not None:
            bands = []
            for band in cfg.get("risk_tier_bands", []):
                updated = dict(band)
                if updated.get("tier") == "HIGH":
                    updated["gte"] = quick_number
                bands.append(updated)
            if bands:
                cfg["risk_tier_bands"] = bands
    elif table == "fsre_config.runtime_parameter_sets" and quick_number is not None:
        if "min_confidence_score" in cfg:
            cfg["min_confidence_score"] = quick_number
        elif "max_chunks" in cfg:
            cfg["max_chunks"] = int(quick_number)
        elif "max_context_chars" in cfg:
            cfg["max_context_chars"] = int(quick_number)
    elif table == "fsre_config.profile_active_rules":
        if quick_number is not None:
            support["execution_order"] = int(quick_number)
        if enabled in {"true", "false"}:
            cfg["enabled"] = enabled == "true"
    elif table == "fsre_config.connector_registry" and quick_number is not None:
        cfg["max_file_mb"] = int(quick_number)
    return cfg, support


app.layout = html.Div(
    className="app",
    children=[
        dcc.Store(id="folder-refresh-token", data=0),
        dcc.Store(id="run-state", data={"status": "not_started"}),
        dcc.Interval(id="monitor-poll", interval=6000, n_intervals=0),
        html.Div(
            id="evidence-modal",
            className="evidence-modal",
            **{"aria-hidden": "true"},
            children=[
                html.Div(className="evidence-modal-backdrop"),
                html.Section(
                    className="evidence-modal-panel",
                    **{"role": "dialog", "aria-modal": "true", "aria-label": "Evidence details"},
                    children=[
                        html.Div(
                            className="evidence-modal-toolbar",
                            children=[
                                html.Div([html.Strong("Evidence details"), html.Span("Full source record")]),
                                html.Button(
                                    "Close",
                                    id="evidence-modal-close",
                                    type="button",
                                    className="button compact",
                                ),
                            ],
                        ),
                        html.Div(id="evidence-modal-content", className="evidence-modal-content"),
                    ],
                ),
            ],
        ),
        html.Div(
            id="risk-fullscreen-modal",
            className="risk-fullscreen-modal",
            **{"aria-hidden": "true"},
            children=[
                html.Div(className="risk-fullscreen-backdrop"),
                html.Section(
                    className="risk-fullscreen-panel",
                    **{"role": "dialog", "aria-modal": "true", "aria-label": "Risk dashboard full-screen view"},
                    children=[
                        html.Div(
                            className="risk-fullscreen-header",
                            children=[
                                html.Div([html.Strong("Risk Dashboard"), html.Span("Executive assessment overview")]),
                                html.Button("Close", id="risk-fullscreen-close", type="button", className="button secondary compact"),
                            ],
                        ),
                        html.Div(id="risk-fullscreen-content", className="risk-fullscreen-content"),
                    ],
                ),
            ],
        ),
        html.Aside(
            className="sidebar",
            children=[
                html.Div(
                    className="brand",
                    children=[
                        company_brand_mark(),
                        html.Div(
                            [
                                html.H1([html.Span("Financial Statement Risk Engine"), html.Span("Assessment Workbench")]),
                            ]
                        ),
                    ],
                ),
                html.Nav(
                    className="nav",
                    children=[
                        html.A([html.Span("1"), html.Span("New Assessment")], href="#step-report-setup", className="active", title="Upload or select the source report for this assessment."),
                        html.A([html.Span("2"), html.Span("Rules")], href="#step-rule-selection", title="Choose which FSRE checks should run for the selected report."),
                        html.A([html.Span("3"), html.Span("Execution")], href="#step-execution-monitor", title="Track backend pipeline progress and completed steps."),
                        html.A([html.Span("4"), html.Span("Report")], href="#step-report-preview", title="Preview the sections that will appear in the final assessment report."),
                        html.A([html.Span("5"), html.Span("Configuration")], href="#step-configuration", title="Inspect and draft governed engine configuration changes."),
                    ],
                ),
                html.Details(
                    className="company-switcher",
                    children=[
                        html.Summary(
                            [
                                html.Span("Active Company"),
                                html.Strong("Auto from report"),
                            ],
                            title="Expand to view current and future company slots.",
                        ),
                        html.Div(
                            className="company-switcher-body",
                            children=[
                                html.Div([html.Strong("Auto"), html.Span("Infer company from uploaded filename")], className="company-card active", title="Uses the selected report filename to infer the company/entity."),
                                html.Div([html.Strong("Singtel"), html.Span("Enabled")], className="company-card", title="Singtel reports remain supported."),
                                html.Div([html.Strong("Enron"), html.Span("Enabled")], className="company-card", title="Enron annual reports are grouped when selected or inferred from filename."),
                                html.Div([html.Strong("DBS"), html.Span("Enabled")], className="company-card", title="DBS reports are supported when selected or inferred from filename."),
                                html.Div([html.Strong("Hyflux"), html.Span("Enabled")], className="company-card", title="Hyflux reports are supported when selected or inferred from filename."),
                                html.Div([html.Strong("Noble"), html.Span("Enabled")], className="company-card", title="Noble reports are supported when selected or inferred from filename."),
                            ],
                        ),
                    ],
                ),
                html.Div(
                    "Upload report, choose rules, run the assessment, then review results and audit trail.",
                    className="sidebar-footer",
                ),
            ],
        ),
        html.Main(
            className="main",
            children=[
                html.Header(
                    className="topbar",
                    children=[
                        html.Div(
                            className="topbar-title",
                            children=[
                                html.H2("New Assessment"),
                                html.Span("Upload a company report, select rules, and trigger the FSRE pipeline"),
                            ],
                        ),
                        html.Div(
                            className="status-strip",
                            children=[
                                html.Button("Refresh Queue", id="refresh-folder-button", type="button", className="button secondary", title="Reload the uploaded report list."),
                                html.A(
                                    "Open Final Report",
                                    href=get_report_dashboard_url() or "#",
                                    target="_blank",
                                    className="button primary link-button",
                                    title="Open the final report dashboard in a new tab.",
                                ),
                            ],
                        ),
                    ],
                ),
                html.Section(
                    className="workspace",
                    children=[
                        html.Div(
                            className="column",
                            children=[
                                html.Section(
                                    id="step-report-setup",
                                    className="panel upload-panel",
                                    children=[
                                        html.Div(
                                            className="panel-header",
                                            children=[html.H3("Step 1 - Report Setup"), status_tag("Required", "high")],
                                        ),
                                        html.Div(
                                            className="panel-body",
                                            children=[
                                                html.Label(
                                                    className="field-label",
                                                    children=[
                                                        "Recent assessment run",
                                                        dcc.Dropdown(
                                                            id="recent-run-selector",
                                                            placeholder="Select one of the latest 15 runs",
                                                            clearable=True,
                                                        ),
                                                        html.Small(
                                                            "Select a completed database run to review its report and findings.",
                                                            className="field-help",
                                                        ),
                                                    ],
                                                ),
                                                html.Label(
                                                    className="field-label",
                                                    children=[
                                                        "Company",
                                                        dcc.Dropdown(
                                                            id="company-selector",
                                                            options=[
                                                                {"label": "Auto from selected report", "value": "Auto from selected report"},
                                                                {"label": "Singtel", "value": "Singtel"},
                                                                {"label": "Enron", "value": "Enron"},
                                                                {"label": "DBS", "value": "DBS"},
                                                                {"label": "Hyflux", "value": "Hyflux"},
                                                                {"label": "Noble", "value": "Noble"},
                                                            ],
                                                            value="Auto from selected report",
                                                            clearable=False,
                                                        ),
                                                        html.Small("Use Auto to infer the company/entity from the selected report filename.", className="field-help"),
                                                    ],
                                                ),
                                                html.Div(
                                                    id="fast-upload-form",
                                                    className="fast-upload-form upload-box",
                                                    **{"data-endpoint": "fsre-fast-upload"},
                                                    children=[
                                                        html.Div(
                                                            [
                                                                html.Strong("Upload report to managed folder"),
                                                                html.Span("Choose PDF/XLS/XLSX files"),
                                                                html.Small("Uses binary upload to avoid Dash base64 overhead. Existing files with the same name are replaced."),
                                                            ]
                                                        ),
                                                        html.Div(id="fast-upload-input-host"),
                                                        html.Button("Upload", id="fast-upload-trigger", type="button", className="button primary fast-upload-button"),
                                                    ],
                                                ),
                                                html.Details(
                                                    className="upload-fallback",
                                                    children=[
                                                        html.Summary("Fallback uploader"),
                                                        dcc.Upload(
                                                            id="file-upload",
                                                            multiple=True,
                                                            className="upload-box fallback-upload-box",
                                                            children=html.Div(
                                                                [
                                                                    html.Strong("Fallback upload"),
                                                                    html.Span("or click to browse"),
                                                                    html.Small("Use this only if the fast managed-folder uploader is blocked by the webapp proxy."),
                                                                ]
                                                            ),
                                                        ),
                                                    ],
                                                ),
                                                dcc.Loading(
                                                    id="upload-loading",
                                                    type="default",
                                                    children=html.Div(id="upload-status", className="status-box"),
                                                ),
                                                html.Label(
                                                    className="field-label",
                                                    children=[
                                                        "Select uploaded report",
                                                        dcc.Dropdown(
                                                            id="report-selector",
                                                            placeholder="Choose up to three uploaded reports",
                                                            multi=True,
                                                            clearable=False,
                                                        ),
                                                        html.Small("Select up to three reports for the same customer. The first selected report remains the primary run context.", className="field-help"),
                                                    ],
                                                ),
                                                html.Div(id="selected-report-card"),
                                                html.Div(
                                                    className="setup-meta",
                                                    style={"display": "none"},
                                                    children=[
                                                        html.Div([html.Span(get_upload_folder_label()), html.Strong(get_upload_folder_id())]),
                                                        html.Div([html.Span("Scenario"), html.Strong(get_scenario_id())]),
                                                    ],
                                                ),
                                            ],
                                        ),
                                    ],
                                ),
                                html.Section(
                                    id="step-execution-monitor",
                                    className="panel monitor-panel",
                                    children=[
                                        html.Div(
                                            className="panel-header",
                                            children=[html.H3("Execution Monitor"), status_tag("Live", "info")],
                                        ),
                                        html.Div(id="execution-monitor", className="panel-body"),
                                    ],
                                ),
                            ],
                        ),
                        html.Div(
                            className="column",
                            children=[
                                html.Section(
                                    id="step-rule-selection",
                                    className="panel rules-panel",
                                    children=[
                                        html.Div(
                                            className="panel-header",
                                            children=[html.H3("Step 2 - Rule Selection"), status_tag("User friendly", "low")],
                                        ),
                                        html.Div(
                                            className="panel-body",
                                            children=[
                                                html.Div(
                                                    className="rule-toolbar",
                                                    children=[
                                                        dcc.Dropdown(
                                                            id="rule-category-filter",
                                                            options=rule_categories(),
                                                            value="all",
                                                            clearable=False,
                                                            className="rule-filter",
                                                        ),
                                                        dcc.Dropdown(
                                                            id="rule-severity-filter",
                                                            options=rule_severities(),
                                                            value="all",
                                                            clearable=False,
                                                            className="rule-filter",
                                                        ),
                                                        html.Small("Filter rules by category and severity before selecting checks.", className="toolbar-help"),
                                                        html.Button("Select Recommended", id="select-recommended-button", className="button secondary", title="Select the default recommended FSRE rule set."),
                                                        html.Button("Clear Rules", id="clear-rules-button", className="button secondary", title="Clear all selected rules."),
                                                    ],
                                                ),
                                                html.Div(id="selected-rule-summary"),
                                                dcc.Checklist(
                                                    id="rule-selector",
                                                    options=rule_options(),
                                                    value=default_rule_ids(),
                                                    className="rule-checklist",
                                                ),
                                            ],
                                        ),
                                    ],
                                ),
                                html.Section(
                                    className="panel run-panel",
                                    children=[
                                        html.Div(
                                            className="panel-header",
                                            children=[html.H3("Run Assessment"), status_tag("Pipeline trigger", "high")],
                                        ),
                                        html.Div(
                                            className="panel-body",
                                            children=[
                                                html.Div(id="run-readiness", className="message"),
                                                html.Button("Run Assessment", id="run-scenario-button", className="button run-button", title="Start the backend assessment pipeline. Disabled while another run is active."),
                                                html.Div(id="scenario-status", className="status-box"),
                                            ],
                                        ),
                                    ],
                                ),
                            ],
                        ),
                        html.Div(
                            className="column results",
                            children=[
                                html.Section(
                                    className="panel risk-panel",
                                    children=[
                                        html.Div(
                                            className="panel-header",
                                            children=[html.H3("Risk Dashboard"), status_tag("Preview", "medium")],
                                        ),
                                        html.Div(id="risk-dashboard", className="panel-body"),
                                    ],
                                ),
                                html.Section(
                                    className="panel triggered-panel",
                                    children=[
                                        html.Div(
                                            className="panel-header",
                                            children=[html.Div([html.H3("Triggered Rule Results"), html.Small("Rule-level index")]), status_tag("What triggered", "info")],
                                        ),
                                        html.Div(id="triggered-rule-summary", className="panel-body table-body"),
                                    ],
                                ),
                                html.Section(
                                    className="panel redflag-panel",
                                    children=[
                                        html.Div(
                                            className="panel-header",
                                            children=[html.Div([html.H3("Red Flag Investigation"), html.Small("Evidence and review actions")]), status_tag("Why it matters", "high")],
                                        ),
                                        html.Div(id="red-flag-details", className="panel-body"),
                                    ],
                                ),
                                html.Section(
                                    className="panel top-findings-panel",
                                    children=[
                                        html.Div(
                                            className="panel-header",
                                            children=[html.H3("Top Findings"), status_tag("Priority review", "medium")],
                                        ),
                                        html.Div(id="top-findings", className="panel-body"),
                                    ],
                                ),
                                html.Section(
                                    id="step-report-preview",
                                    className="panel preview-panel",
                                    children=[
                                        html.Div(
                                            className="panel-header",
                                            children=[html.H3("Report Preview"), status_tag("Draft sections", "low")],
                                        ),
                                        html.Div(id="report-preview", className="panel-body"),
                                    ],
                                ),
                            ],
                        ),
                    ],
                ),
                html.Section(
                    id="step-configuration",
                    className="config-workbench",
                    children=[
                        html.Section(
                            className="panel full-panel",
                            children=[
                                html.Div(
                                    className="panel-header",
                                    children=[html.H3("Step 5 - Configuration"), status_tag("SQL draft", "info")],
                                ),
                                html.Div(
                                    className="panel-body",
                                    children=[
                                        html.Div(
                                            className="config-guide",
                                            children=[
                                                html.Article(
                                                    [html.H4("Profile"), html.P("Deployment profile, active rules, connector choices, validation gates and runtime shape.")],
                                                    className="guide-card",
                                                ),
                                                html.Article(
                                                    [html.H4("Rule Config"), html.P("Thresholds, formulas, required fields, connector requirements and severity bands.")],
                                                    className="guide-card",
                                                ),
                                                html.Article(
                                                    [html.H4("Scoring"), html.P("Severity weightage, risk-tier bands, critical override and evidence confidence floors.")],
                                                    className="guide-card",
                                                ),
                                                html.Article(
                                                    [html.H4("Other Config"), html.P("Runtime parameters, prompts, synonyms, intake, document classification and narrative evidence.")],
                                                    className="guide-card",
                                                ),
                                            ],
                                        ),
                                    ],
                                ),
                            ],
                        ),
                        html.Section(
                            className="panel config-editor-panel",
                            children=[
                                html.Div(
                                    className="panel-header",
                                    children=[html.H3("Config Editor"), status_tag("Review before DB", "medium")],
                                ),
                                html.Div(
                                    className="panel-body config-editor",
                                    children=[
                                        html.Label(
                                            className="field-label",
                                            children=[
                                                "Config row",
                                                dcc.Dropdown(
                                                    id="config-selector",
                                                    options=config_options(),
                                                    value=CONFIG_ROWS[0]["key"],
                                                    clearable=False,
                                                ),
                                            ],
                                        ),
                                        html.Div(id="config-selected-meta", className="config-selected-meta"),
                                        html.Div(
                                            className="config-form-grid",
                                            children=[
                                                html.Label(
                                                    className="field-label",
                                                    children=[
                                                        "Status",
                                                        dcc.Dropdown(
                                                            id="config-status",
                                                            options=[
                                                                {"label": "active", "value": "active"},
                                                                {"label": "draft", "value": "draft"},
                                                                {"label": "deprecated", "value": "deprecated"},
                                                                {"label": "retired", "value": "retired"},
                                                                {"label": "inactive", "value": "inactive"},
                                                            ],
                                                            value="active",
                                                            clearable=False,
                                                        ),
                                                    ],
                                                ),
                                                html.Div(
                                                    className="field-label",
                                                    children=[
                                                        html.Span("Table"),
                                                        html.Div(id="config-table-name", className="readonly-box"),
                                                    ],
                                                ),
                                            ],
                                        ),
                                        html.Div(
                                            id="config-friendly-fields",
                                            className="friendly-config-fields",
                                            children=[
                                                html.Div(
                                                    className="friendly-field-head",
                                                    children=[
                                                        html.H4(id="config-friendly-title"),
                                                        html.P(id="config-friendly-help"),
                                                    ],
                                                ),
                                                html.Div(
                                                    id="friendly-field-grid",
                                                    className="friendly-field-grid",
                                                    children=[
                                                        html.Label(
                                                            id="quick-number-field",
                                                            className="field-label quick-field",
                                                            children=[
                                                                html.Span(id="quick-number-label"),
                                                                dcc.Input(id="quick-number-value", type="number", step=0.01, className="quick-input"),
                                                                html.Small(id="quick-number-help", className="field-help"),
                                                            ],
                                                        ),
                                                        html.Label(
                                                            id="quick-high-points-field",
                                                            className="field-label quick-field",
                                                            children=[
                                                                "High severity points",
                                                                dcc.Input(id="quick-high-points", type="number", step=1, className="quick-input"),
                                                                html.Small("Used by scoring config only.", className="field-help"),
                                                            ],
                                                        ),
                                                        html.Label(
                                                            id="quick-medium-points-field",
                                                            className="field-label quick-field",
                                                            children=[
                                                                "Medium severity points",
                                                                dcc.Input(id="quick-medium-points", type="number", step=1, className="quick-input"),
                                                                html.Small("Used by scoring config only.", className="field-help"),
                                                            ],
                                                        ),
                                                        html.Label(
                                                            id="quick-enabled-field",
                                                            className="field-label quick-field",
                                                            children=[
                                                                "Enabled",
                                                                dcc.Dropdown(
                                                                    id="quick-enabled",
                                                                    options=[
                                                                        {"label": "Enabled", "value": "true"},
                                                                        {"label": "Disabled", "value": "false"},
                                                                        {"label": "Not applicable", "value": "na"},
                                                                    ],
                                                                    value="na",
                                                                    clearable=False,
                                                                ),
                                                                html.Small("Used by profile active rule config.", className="field-help"),
                                                            ],
                                                        ),
                                                    ],
                                                ),
                                            ],
                                        ),
                                        html.Div(
                                            className="config-action-row",
                                            children=[
                                                html.Button("Apply quick changes", id="config-apply-quick-button", type="button", className="button secondary"),
                                                html.Button("Save Configuration", id="config-save-button", type="button", className="button primary"),
                                                html.Div(id="config-save-result", className="config-save-result"),
                                            ],
                                        ),
                                        html.Div(
                                            className="advanced-toggle-panel",
                                            children=[
                                                html.Div(
                                                    className="advanced-toggle-copy",
                                                    children=[
                                                        html.Strong("Advanced configuration view"),
                                                        html.Span("Show JSON or SQL only when you need technical detail."),
                                                    ],
                                                ),
                                                dcc.Checklist(
                                                    id="advanced-config-toggle",
                                                    options=[
                                                        {"label": "Config JSON", "value": "config_json"},
                                                        {"label": "Supporting JSON", "value": "supporting_json"},
                                                        {"label": "Generated SQL Patch", "value": "sql_patch"},
                                                    ],
                                                    value=[],
                                                    className="advanced-toggle-list",
                                                    labelClassName="advanced-toggle-item",
                                                ),
                                            ],
                                        ),
                                        html.Div(
                                            id="config-json-grid",
                                            className="config-json-grid",
                                            children=[
                                                html.Label(
                                                    id="config-json-field",
                                                    className="field-label",
                                                    children=[
                                                        "Config JSON",
                                                        dcc.Textarea(id="config-json-editor", className="json-textarea"),
                                                    ],
                                                ),
                                                html.Label(
                                                    id="config-supporting-json-field",
                                                    className="field-label",
                                                    children=[
                                                        "Supporting JSON",
                                                        dcc.Textarea(id="config-supporting-json-editor", className="json-textarea"),
                                                    ],
                                                ),
                                            ],
                                        ),
                                    ],
                                ),
                            ],
                        ),
                        html.Section(
                            className="panel config-sql-panel",
                            children=[
                                html.Div(
                                    className="panel-header",
                                    children=[html.H3("Generated SQL Patch"), status_tag("Admin execute", "low")],
                                ),
                                html.Div(
                                    id="config-sql-body",
                                    className="panel-body",
                                    children=[
                                        html.Div(id="config-json-status", className="config-json-status"),
                                        html.Pre(id="config-sql-output", className="sql-output"),
                                    ],
                                ),
                            ],
                        ),
                        html.Section(
                            className="panel full-panel",
                            children=[
                                html.Div(
                                    className="panel-header",
                                    children=[html.H3("Future Configuration Areas"), status_tag("Advanced config", "info")],
                                ),
                                html.Div(future_config_tiles(), className="panel-body"),
                            ],
                        ),
                    ],
                ),
                html.Section(
                    className="post-workbench-section",
                    children=[
                        html.Section(
                            className="panel audit-panel",
                            children=[
                                html.Div(
                                    className="panel-header",
                                    children=[html.H3("Audit Trail"), status_tag("Traceable", "low")],
                                ),
                                html.Div(id="audit-trail", className="panel-body"),
                            ],
                        ),
                    ],
                ),
                html.Section(
                    className="post-workbench-section uploaded-reports-final",
                    children=[
                        html.Section(
                            className="panel queue-panel",
                            children=[
                                html.Div(
                                    className="panel-header",
                                    children=[
                                        html.H3("Uploaded Reports"),
                                        html.Div(
                                            className="panel-actions",
                                            children=[
                                                html.Button("Refresh Queue", id="refresh-folder-panel-button", type="button", className="button secondary compact", title="Reload the uploaded report list."),
                                                status_tag("Ready", "info"),
                                            ],
                                        ),
                                    ],
                                ),
                                html.Div(id="folder-queue", className="panel-body table-body"),
                                html.Div(id="folder-refresh-status", className="queue-refresh-status"),
                            ],
                        ),
                    ],
                ),
            ],
        ),
    ],
)


@app.callback(
    Output("folder-refresh-token", "data"),
    Output("upload-status", "children"),
    Input("file-upload", "contents"),
    State("file-upload", "filename"),
    State("folder-refresh-token", "data"),
    prevent_initial_call=True,
)
def upload_files(contents, filenames, token):
    if not contents:
        return token, html.Div("No files selected.", className="message warn")

    folder_id = get_upload_folder_id()
    messages = []
    filenames = filenames or []
    if isinstance(contents, str):
        contents = [contents]
    if isinstance(filenames, str):
        filenames = [filenames]

    uploaded_count = 0
    for content, filename in zip(contents, filenames):
        safe_name = clean_filename(filename)
        ext = extension(safe_name)
        if ext not in ALLOWED_EXTENSIONS:
            messages.append(html.Div(f"Skipped unsupported file: {safe_name}", className="message warn"))
            continue

        try:
            file_bytes = decode_upload(content)
            target_path = managed_folder_path(safe_name)
            written_path = upload_bytes_to_folder(folder_id, target_path, file_bytes)
            uploaded_count += 1
            messages.append(upload_progress_card(safe_name, get_upload_folder_label(), folder_id, written_path, False))
        except Exception as exc:
            messages.append(html.Div(f"Failed: {safe_name} - {exc}", className="message error"))

    summary = html.Div(
        f"{uploaded_count} report file(s) uploaded and ready for assessment.",
        className="message summary",
    )
    return int(token or 0) + 1, html.Div([summary, *messages])


@app.callback(
    Output("recent-run-selector", "options"),
    Input("monitor-poll", "n_intervals"),
    State("run-state", "data"),
)
def refresh_recent_run_options(_, run_state):
    try:
        return recent_run_options(15, run_state)
    except Exception:
        return []


@app.callback(
    Output("folder-queue", "children"),
    Output("folder-refresh-status", "children"),
    Output("report-selector", "options"),
    Output("report-selector", "value"),
    Input("folder-refresh-token", "data"),
    Input("refresh-folder-button", "n_clicks"),
    Input("refresh-folder-panel-button", "n_clicks"),
    Input("monitor-poll", "n_intervals"),
    State("report-selector", "value"),
)
def refresh_folder_queue(refresh_token, refresh_clicks, panel_refresh_clicks, poll_count, selected_report):
    rows = folder_file_rows(get_upload_folder_id())
    options = ready_report_options(rows)
    valid_values = {item["value"] for item in options}
    selected_values = [item for item in selected_report_paths(selected_report) if item in valid_values]
    value = selected_values[:3]
    ready_count = sum(1 for row in rows if row.get("status") == "ready")
    status = html.Div(
        f"Queue refreshed at {datetime.now().strftime('%H:%M:%S')} - {ready_count} ready report(s).",
        className="message summary compact-message",
    )
    return uploaded_reports_panel(rows), status, options, value


@app.callback(
    Output("config-json-grid", "style"),
    Output("config-json-field", "style"),
    Output("config-supporting-json-field", "style"),
    Output("config-sql-body", "style"),
    Input("advanced-config-toggle", "value"),
)
def toggle_advanced_config_sections(selected_sections):
    selected = set(selected_sections or [])
    config_visible = "config_json" in selected
    supporting_visible = "supporting_json" in selected
    sql_visible = "sql_patch" in selected
    grid_style = {"display": "grid"} if config_visible or supporting_visible else {"display": "none"}
    return (
        grid_style,
        {"display": "grid"} if config_visible else {"display": "none"},
        {"display": "grid"} if supporting_visible else {"display": "none"},
        {"display": "block"} if sql_visible else {"display": "none"},
    )


@app.callback(
    Output("config-selected-meta", "children"),
    Output("config-table-name", "children"),
    Output("config-status", "value"),
    Output("config-json-editor", "value"),
    Output("config-supporting-json-editor", "value"),
    Output("config-friendly-title", "children"),
    Output("config-friendly-help", "children"),
    Output("quick-number-label", "children"),
    Output("quick-number-help", "children"),
    Output("quick-number-value", "value"),
    Output("quick-high-points", "value"),
    Output("quick-medium-points", "value"),
    Output("quick-enabled", "value"),
    Output("quick-number-field", "style"),
    Output("quick-high-points-field", "style"),
    Output("quick-medium-points-field", "style"),
    Output("quick-enabled-field", "style"),
    Output("friendly-field-grid", "className"),
    Input("config-selector", "value"),
)
def load_config_editor(config_key):
    row = get_config_row(config_key)
    quick = quick_control_values(row)
    number_style, high_style, medium_style, enabled_style, grid_class = quick_control_field_styles(row)
    meta = html.Div(
        className="config-meta-grid",
        children=[
            html.Div([html.Span("Area"), html.Strong(row["area"])]),
            html.Div([html.Span("Primary ID"), html.Strong(row["id"])]),
            html.Div([html.Span("Version"), html.Strong(row["version"])]),
            html.Div([html.Span("Scope"), html.Strong(row["scope"])]),
            html.Div([html.Span("JSON Column"), html.Strong(row["json_column"])]),
            html.Div([html.Span("Purpose"), html.Strong(row["description"])]),
        ],
    )
    return (
        meta,
        row["table"],
        row["status"],
        json_pretty(row["config_json"]),
        json_pretty(row["supporting_json"]),
        quick["title"],
        quick["help"],
        quick["number_label"],
        quick["number_help"],
        quick["number_value"],
        quick["high_points"],
        quick["medium_points"],
        quick["enabled"],
        number_style,
        high_style,
        medium_style,
        enabled_style,
        grid_class,
    )


@app.callback(
    Output("config-json-editor", "value", allow_duplicate=True),
    Output("config-supporting-json-editor", "value", allow_duplicate=True),
    Output("config-save-result", "children", allow_duplicate=True),
    Input("config-apply-quick-button", "n_clicks"),
    State("config-selector", "value"),
    State("config-json-editor", "value"),
    State("config-supporting-json-editor", "value"),
    State("quick-number-value", "value"),
    State("quick-high-points", "value"),
    State("quick-medium-points", "value"),
    State("quick-enabled", "value"),
    prevent_initial_call=True,
)
def apply_quick_config_changes(_, config_key, config_text, supporting_text, quick_number, high_points, medium_points, enabled):
    row = get_config_row(config_key)
    try:
        config_json = parse_json_text(config_text)
        supporting_json = parse_json_text(supporting_text)
        updated_config, updated_supporting = apply_quick_values_to_config(
            row,
            config_json,
            supporting_json,
            quick_number,
            high_points,
            medium_points,
            enabled,
        )
        return (
            json_pretty(updated_config),
            json_pretty(updated_supporting),
            html.Div("Quick changes applied to JSON. Review, then Save Configuration.", className="message success compact-message"),
        )
    except Exception as exc:
        return no_update, no_update, html.Div(f"Could not apply quick changes: {exc}", className="message error compact-message")


@app.callback(
    Output("config-save-result", "children"),
    Input("config-save-button", "n_clicks"),
    State("config-selector", "value"),
    State("config-status", "value"),
    State("config-json-editor", "value"),
    State("config-supporting-json-editor", "value"),
    prevent_initial_call=True,
)
def save_config_to_database(_, config_key, status, config_text, supporting_text):
    row = get_config_row(config_key)
    try:
        config_json = parse_json_text(config_text)
        supporting_json = parse_json_text(supporting_text)
        updated = execute_config_update(row, config_json, supporting_json, status)
        return html.Div(
            [
                html.Strong("Configuration saved to PostgreSQL."),
                html.Span(f" Updated {row['table']} for {row['id']} {row['version']}."),
                html.Small(f" Database returned: {json.dumps(updated, default=str)}"),
            ],
            className="message success compact-message",
        )
    except Exception as exc:
        return html.Div(
            [
                html.Strong("Configuration was not saved."),
                html.Span(f" {exc}"),
            ],
            className="message error compact-message",
        )


@app.callback(
    Output("config-json-status", "children"),
    Output("config-sql-output", "children"),
    Input("config-selector", "value"),
    Input("config-status", "value"),
    Input("config-json-editor", "value"),
    Input("config-supporting-json-editor", "value"),
)
def render_config_sql(config_key, status, config_text, supporting_text):
    row = get_config_row(config_key)
    try:
        config_json = parse_json_text(config_text)
        supporting_json = parse_json_text(supporting_text)
        sql = generate_config_sql(row, config_json, supporting_json, status)
        return (
            html.Div(
                className="status-tags",
                children=[
                    status_tag("Valid JSON", "low"),
                    status_tag(row["table"], "info"),
                    status_tag("Preview only - Save writes to DB", "medium"),
                ],
            ),
            sql,
        )
    except Exception as exc:
        return (
            html.Div(
                className="status-tags",
                children=[status_tag("Invalid JSON", "high"), html.Span(str(exc), className="json-error-text")],
            ),
            "-- Fix JSON before SQL can be generated.",
        )


@app.callback(
    Output("rule-selector", "options"),
    Input("rule-category-filter", "value"),
    Input("rule-severity-filter", "value"),
)
def update_rule_options(category, severity):
    return rule_options(category, severity)


@app.callback(
    Output("selected-rule-summary", "children"),
    Input("rule-selector", "value"),
)
def update_selected_rule_summary(rule_ids):
    return selected_rule_summary(rule_ids or [])


@app.callback(
    Output("selected-report-card", "children"),
    Input("report-selector", "value"),
)
def update_selected_report_card(report_path):
    return selected_report_card(report_path)


@app.callback(
    Output("report-selector", "value", allow_duplicate=True),
    Input("report-selector", "value"),
    prevent_initial_call=True,
)
def limit_selected_reports(report_path):
    report_paths = selected_report_paths(report_path)
    if len(report_paths) <= 3:
        return no_update
    return report_paths[:3]


@app.callback(
    Output("rule-selector", "value"),
    Input("select-recommended-button", "n_clicks"),
    Input("clear-rules-button", "n_clicks"),
    prevent_initial_call=True,
)
def update_rule_selection(_, __):
    if ctx.triggered_id == "clear-rules-button":
        return []
    return default_rule_ids()


@app.callback(
    Output("scenario-status", "children"),
    Output("run-state", "data"),
    Input("run-scenario-button", "n_clicks"),
    State("company-selector", "value"),
    State("report-selector", "value"),
    State("rule-selector", "value"),
    prevent_initial_call=True,
)
def run_assessment(_, company, report_path, rule_ids):
    report_paths = selected_report_paths(report_path)[:3]
    effective_company = resolve_company_selection(company, report_path)
    if not report_paths:
        state = {
            "status": "failed",
            "error": "Select or upload a report before running the assessment.",
            "company": effective_company,
            "report_path": "",
            "report_paths": [],
            "rule_ids": rule_ids or [],
        }
        return html.Div("Select or upload a report before running the assessment.", className="message error"), state
    if not rule_ids:
        state = {
            "status": "failed",
            "error": "Select at least one rule before running the assessment.",
            "company": effective_company,
            "report_path": report_paths[0],
            "report_paths": report_paths,
            "rule_ids": [],
        }
        return html.Div("Select at least one rule before running the assessment.", className="message error"), state

    scenario_id = get_scenario_id()
    try:
        active_state = active_run_state() or active_project_run_state()
        if active_state:
            return html.Div(
                [
                    html.Div("An assessment is already running. Please wait for it to finish.", className="message warn"),
                    html.Div(f"Active run: {active_state.get('scenario_run_id', active_state.get('run_id', '-'))}", className="message summary"),
                ]
            ), active_state

        context_warning = persist_assessment_context(effective_company, report_paths, rule_ids or [])
        run_id = "direct-" + uuid.uuid4().hex[:12]
        state = {
            "run_id": run_id,
            "scenario_id": scenario_id,
            "scenario_run_id": run_id,
            "started_at": datetime.utcnow().isoformat(timespec="seconds") + "Z",
            "status": "running",
            "trigger_mode": "pending",
            "company": effective_company,
            "report_path": report_paths[0],
            "report_paths": report_paths,
            "rule_ids": rule_ids or [],
            "selected_rule_count": len(rule_ids or []),
            "completed_datasets": [],
            "completed_count": 0,
            "total_count": len(FLOW_DATASET_SEQUENCE),
            "report_count": len(report_paths),
            "message": "Assessment pipeline queued.",
        }
        update_tracked_run(run_id, **state)
        worker = Thread(
            target=assessment_worker,
            args=(run_id, scenario_id, effective_company, report_paths, rule_ids or []),
            daemon=True,
        )
        worker.start()

        return html.Div(
            [
                html.Div("Assessment started. Progress will update in the Execution Monitor.", className="message ok"),
                html.Div(f"Run reference: {run_id}", className="message summary"),
                html.Div(f"Company: {effective_company}", className="message"),
                html.Div(f"Reports queued: {', '.join(str(path).lstrip('/').rsplit('/', 1)[-1] for path in report_paths)}", className="message"),
                html.Div(f"Rules selected: {len(rule_ids or [])}", className="message"),
                html.Div(
                    f"Selection context warning: {context_warning}",
                    className="message warn",
                )
                if context_warning
                else html.Div("Selection context saved to project variables.", className="message ok"),
            ]
        ), state
    except Exception as exc:
        state = {
            "status": "failed",
            "error": str(exc),
            "company": effective_company,
            "report_path": report_paths[0] if report_paths else "",
            "report_paths": report_paths,
            "rule_ids": rule_ids or [],
        }
        return html.Div(f"Assessment start failed: {exc}", className="message error"), state


@app.callback(
    Output("run-scenario-button", "disabled"),
    Output("run-scenario-button", "children"),
    Input("monitor-poll", "n_intervals"),
    State("run-state", "data"),
)
def update_run_button(_, run_state):
    run_id = (run_state or {}).get("run_id")
    latest = get_tracked_run(run_id) if run_id else {}
    if latest.get("status") == "running" or active_run_state() or active_project_run_state():
        return True, "Assessment Running"
    return False, "Run Assessment"


def latest_visible_run_state(run_state):
    run_id = (run_state or {}).get("run_id")
    latest = get_tracked_run(run_id) if run_id else {}
    if latest:
        merged = dict(run_state or {})
        merged.update(latest)
        return merged
    project_state = project_run_state()
    if project_state:
        merged = dict(run_state or {})
        merged.update(project_state)
        return merged
    return run_state or {}


@app.callback(
    Output("scenario-status", "children", allow_duplicate=True),
    Input("monitor-poll", "n_intervals"),
    State("run-state", "data"),
    prevent_initial_call=True,
)
def refresh_scenario_status(_, run_state):
    latest = latest_visible_run_state(run_state)
    status = latest.get("status", "not_started")
    if status == "running":
        _, _, current = visible_stage_progress(latest)
        current = current or "Waiting for next pipeline step"
        completed_steps = as_int_value(latest.get("completed_count"), 0)
        total_steps = as_int_value(latest.get("total_count"), len(FLOW_DATASET_SEQUENCE))
        current_report = str(latest.get("current_report") or "")
        report_index = as_int_value(latest.get("report_index"), 0)
        report_count = as_int_value(latest.get("report_count"), 0)
        return html.Div(
            [
                html.Div("Assessment is running.", className="message ok"),
                html.Div(
                    f"Report {report_index} of {report_count}: {current_report}",
                    className="message summary",
                )
                if report_count > 1 and current_report
                else html.Div(),
                html.Div(f"Current step: {current}", className="message summary"),
                html.Div(f"Completed {completed_steps} of {total_steps} recipe executions.", className="message"),
            ]
        )
    if status == "completed":
        completed_steps = as_int_value(latest.get("completed_count"), 0)
        total_steps = as_int_value(latest.get("total_count"), len(FLOW_DATASET_SEQUENCE))
        report_count = as_int_value(latest.get("report_count"), 1)
        result_warning = str(latest.get("result_warning") or "").strip()
        return html.Div(
            [
                html.Div("Assessment completed.", className="message ok"),
                html.Div("Pipeline mode: Direct assessment pipeline", className="message summary"),
                html.Div(
                    f"Completed {completed_steps or total_steps} recipe executions for {report_count} report(s).",
                    className="message",
                ),
                html.Div(
                    f"Results pending: {user_friendly_pipeline_error(result_warning)}",
                    className="message warn",
                )
                if result_warning
                else html.Div(),
            ]
        )
    if status == "failed":
        return html.Div(f"Assessment failed: {user_friendly_pipeline_error(latest.get('error', 'Unknown error'))}", className="message error")
    return html.Div("Assessment has not started.", className="message")


@app.callback(
    Output("recent-run-selector", "value"),
    Input("report-selector", "value"),
    Input("run-state", "data"),
    Input("monitor-poll", "n_intervals"),
    State("recent-run-selector", "value"),
    prevent_initial_call=True,
)
def sync_recent_run_selection(report_path, run_state, _, current_value):
    latest = latest_visible_run_state(run_state)
    if str(latest.get("status", "")).lower() != "completed":
        if ctx.triggered_id == "report-selector":
            return None
        return no_update
    database_run_id = latest.get("database_run_id") or latest.get("db_run_id")
    if database_run_id and str(database_run_id) != str(current_value or ""):
        return str(database_run_id)
    return no_update


@app.callback(
    Output("run-readiness", "children"),
    Output("risk-dashboard", "children"),
    Output("triggered-rule-summary", "children"),
    Output("red-flag-details", "children"),
    Output("top-findings", "children"),
    Output("report-preview", "children"),
    Output("audit-trail", "children"),
    Input("company-selector", "value"),
    Input("recent-run-selector", "value"),
    Input("report-selector", "value"),
    Input("rule-selector", "value"),
    Input("run-state", "data"),
    Input("monitor-poll", "n_intervals"),
)
def render_assessment_outputs(company, selected_database_run_id, report_path, rule_ids, run_state, _):
    rule_ids = rule_ids or []
    report_paths = selected_report_paths(report_path)
    effective_company = resolve_company_selection(company, report_path)
    latest_state = latest_visible_run_state(run_state)
    if not selected_database_run_id and not report_paths:
        readiness = "Upload or select a report before running the assessment."
        blank = blank_dashboard_panel()
        return readiness, blank, blank, blank, blank, blank, blank
    if selected_database_run_id:
        latest_state = dict(latest_state)
        latest_state["selected_database_run_id"] = selected_database_run_id
    report_error = ""
    try:
        report_ctx = dashboard_context(rule_ids, latest_state, report_path)
    except Exception as exc:
        report_ctx = {"run_id": None, "summary": {}, "rules": pd.DataFrame(), "red_flags": pd.DataFrame(), "review": pd.DataFrame(), "external": pd.DataFrame(), "evidence": pd.DataFrame()}
        report_error = str(exc)
    result_warning = str(report_ctx.get("result_warning") or latest_state.get("result_warning") or "").strip()
    if selected_database_run_id:
        readiness = html.Div(
            [
                html.Strong("Viewing saved assessment. "),
                html.Span(f"Database run: {selected_database_run_id}"),
                html.Span(f" Report data warning: {report_error}") if report_error else html.Span(),
                html.Span(f" Results pending: {user_friendly_pipeline_error(result_warning)}") if result_warning else html.Span(),
            ]
        )
    elif report_paths and rule_ids:
        readiness = html.Div(
            [
                html.Strong("Ready to run. "),
                html.Span(f"{effective_company}: {selected_report_count_text(report_paths)} selected with {len(rule_ids)} rule(s)."),
                html.Span(f" Database run: {report_ctx['run_id']}" if report_ctx.get("run_id") else " Database run pending."),
                html.Span(f" Report data warning: {report_error}") if report_error else html.Span(),
                html.Span(f" Results pending: {user_friendly_pipeline_error(result_warning)}") if result_warning else html.Span(),
            ]
        )
    elif not report_paths:
        readiness = "Upload or select a report before running the assessment."
    else:
        readiness = "Select at least one rule before running the assessment."

    return (
        readiness,
        risk_preview(rule_ids, latest_state, report_ctx),
        triggered_summary(rule_ids, latest_state, report_path, report_ctx),
        red_flag_preview(rule_ids, latest_state, report_path, report_ctx),
        top_findings_preview(report_path, report_ctx),
        report_preview(effective_company, report_path, rule_ids, latest_state, report_ctx),
        audit_trail(effective_company, report_path, rule_ids, latest_state, report_ctx),
    )


@app.callback(
    Output("execution-monitor", "children"),
    Input("run-state", "data"),
    Input("monitor-poll", "n_intervals"),
)
def render_execution_monitor(run_state, _):
    return monitor_steps(latest_visible_run_state(run_state))


app.index_string = """
<!DOCTYPE html>
<html>
  <head>
    {%metas%}
    <title>FSRE New Assessment</title>
    {%favicon%}
    {%css%}
    <style>
      :root {
        /* layered dark surfaces, deep navy-slate base */
        --bg: #0a0d13;
        --bg-elevated: #0f131b;
        --panel: #131822;
        --panel-alt: #171d29;
        --panel-hover: #1b2230;
        --ink: #e7ebf3;
        --muted: #8b95a8;
        --muted-2: #64707f;
        --line: #232b3a;
        --line-soft: rgba(255, 255, 255, 0.07);

        /* brand + semantic accents, tuned for contrast on dark surfaces */
        --accent: #ff5b4d;
        --accent-strong: #ff7a6c;
        --accent-soft: rgba(255, 91, 77, 0.14);
        --danger: #f2635a;
        --warn: #f5a623;
        --ok: #2fd97d;
        --blue: #4d9bf5;
        --violet: #9d7bf0;

        --soft-danger: rgba(242, 99, 90, 0.13);
        --soft-warn: rgba(245, 166, 35, 0.13);
        --soft-ok: rgba(47, 217, 125, 0.12);
        --soft-blue: rgba(77, 155, 245, 0.13);

        --radius-sm: 8px;
        --radius-md: 12px;
        --radius-lg: 16px;
        --shadow: 0 8px 24px rgba(0, 0, 0, 0.35);
        --shadow-lg: 0 24px 60px rgba(0, 0, 0, 0.5);
        --shadow-glow: 0 0 0 1px rgba(255, 91, 77, 0.18), 0 8px 28px rgba(255, 91, 77, 0.12);
        --ease: cubic-bezier(0.22, 1, 0.36, 1);
      }

      /* Corporate light theme and executive risk workspace */
      :root {
        --bg: #f4f7fb;
        --bg-elevated: #ffffff;
        --panel: #ffffff;
        --panel-alt: #f8fafc;
        --panel-hover: #eef4fb;
        --ink: #172033;
        --muted: #66758c;
        --muted-2: #8290a3;
        --line: #dbe3ee;
        --line-soft: rgba(20, 48, 83, 0.09);
        --accent: #1768ac;
        --accent-strong: #0f4f88;
        --accent-soft: rgba(23, 104, 172, 0.09);
        --danger: #c63f4b;
        --warn: #a9660d;
        --ok: #16805d;
        --blue: #1768ac;
        --violet: #6853b5;
        --soft-danger: #fff1f2;
        --soft-warn: #fff8e8;
        --soft-ok: #edf9f4;
        --soft-blue: #edf6ff;
        --radius-sm: 8px;
        --radius-md: 12px;
        --radius-lg: 16px;
        --shadow: 0 8px 24px rgba(30, 55, 84, 0.08);
        --shadow-lg: 0 24px 70px rgba(30, 55, 84, 0.18);
        --shadow-glow: 0 0 0 1px rgba(23, 104, 172, 0.14), 0 10px 30px rgba(23, 104, 172, 0.1);
      }

      body {
        background: radial-gradient(900px 420px at 100% 0%, rgba(23, 104, 172, 0.08), transparent 62%), var(--bg);
        color: var(--ink);
      }
      ::selection { background: rgba(23, 104, 172, 0.2); color: var(--ink); }
      ::-webkit-scrollbar-thumb { background: #bcc8d8; border-color: var(--bg); }
      .app { grid-template-columns: 252px minmax(0, 1fr); }
      .sidebar {
        background: linear-gradient(180deg, #123a61 0%, #0d2f50 100%);
        border-right: 0;
        box-shadow: 8px 0 28px rgba(15, 50, 83, 0.1);
      }
      .topbar {
        background: rgba(255, 255, 255, 0.9);
        border-color: var(--line);
        box-shadow: 0 4px 18px rgba(30, 55, 84, 0.05);
      }
      .workspace {
        grid-template-columns: repeat(2, minmax(360px, 1fr));
        max-width: 1540px;
        width: 100%;
        margin: 0 auto;
        align-items: start;
      }
      .column.results {
        grid-column: 1 / -1;
        width: 100%;
        grid-template-columns: repeat(2, minmax(0, 1fr));
      }
      .column.results > .risk-panel { grid-column: 1 / -1; }
      .panel {
        background: var(--panel);
        border-color: var(--line);
        box-shadow: var(--shadow);
      }
      .panel-header, .file-table td, .file-table th { border-color: var(--line); }
      .panel-header { background: linear-gradient(180deg, #ffffff, #fbfcfe); }
      .panel-header h3, .topbar-title h2, .risk-hero h3 { color: var(--ink); }
      .field-label, .run-copy p, .topbar-title span { color: var(--muted); }
      .upload-box, .fast-upload-input, .message, .upload-fallback, .report-switcher,
      .report-switcher-summary div, .hero-meta, .guide-card {
        background: var(--panel-alt);
        border-color: var(--line);
      }
      .button.primary, .run-button {
        background: linear-gradient(135deg, var(--accent-strong), var(--accent));
        color: #fff;
        box-shadow: 0 8px 20px rgba(23, 104, 172, 0.22);
      }
      .button.secondary { background: #fff; color: var(--ink); border-color: var(--line); }
      .button.secondary:hover { border-color: #93b4d3; background: #f6faff; }

      .risk-panel {
        width: min(1180px, 100%);
        justify-self: center;
        border-color: #cbd9e8;
        box-shadow: 0 14px 42px rgba(30, 55, 84, 0.11);
      }
      .risk-board { gap: 14px; }
      .risk-board-toolbar {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 16px;
        padding-bottom: 2px;
      }
      .risk-board-toolbar > div { display: grid; gap: 2px; }
      .risk-board-eyebrow { color: var(--accent); font-size: 11px; font-weight: 800; letter-spacing: .08em; text-transform: uppercase; }
      .risk-board-caption { color: var(--muted); font-size: 12px; }
      .risk-fullscreen-trigger { gap: 7px; }
      .risk-hero { background: linear-gradient(135deg, #f9fbfe, #eef5fb); border-color: #cfdae7; }
      .risk-board.risk .risk-hero { background: linear-gradient(135deg, #fff4f5, #fff); border-color: #efc2c7; box-shadow: 0 8px 28px rgba(198, 63, 75, .08); }
      .risk-board.warn .risk-hero { background: linear-gradient(135deg, #fff9ec, #fff); border-color: #ecd6ad; box-shadow: 0 8px 28px rgba(169, 102, 13, .08); }
      .risk-board.ok .risk-hero { background: linear-gradient(135deg, #effaf5, #fff); border-color: #bcded0; box-shadow: 0 8px 28px rgba(22, 128, 93, .08); }
      .risk-score-strip div, .risk-chip, .risk-overflow-list, .risk-empty { background: rgba(255,255,255,.86); border-color: var(--line); }
      .risk-score-strip strong, .risk-insight-head strong { color: var(--ink); }
      .risk-insight { background: #fff; border-color: var(--line); padding: 14px; }
      .risk-insight.risk { border-color: #efc2c7; background: #fff7f8; }
      .risk-insight.warn { border-color: #ecd6ad; background: #fffbf2; }
      .risk-insight.info { border-color: #bfd6ea; background: #f5faff; }
      .risk-chip { color: #42536a; }
      .info-dot, .risk-insight-head a { background: #fff; border-color: #bfd6ea; color: var(--accent) !important; }
      .info-popover-text { background: #fff; border-color: var(--line); color: var(--ink) !important; box-shadow: var(--shadow-lg); }

      .risk-fullscreen-modal { display: none; position: fixed; inset: 0; z-index: 11000; padding: 18px; }
      .risk-fullscreen-modal.is-open { display: flex; align-items: center; justify-content: center; }
      .risk-fullscreen-backdrop { position: absolute; inset: 0; background: rgba(15, 35, 56, .48); backdrop-filter: blur(7px); }
      .risk-fullscreen-panel {
        position: relative; display: flex; flex-direction: column; width: min(1500px, 98vw); height: min(940px, 96vh);
        overflow: hidden; border: 1px solid #c9d6e4; border-radius: 18px; background: var(--bg); box-shadow: var(--shadow-lg);
      }
      .risk-fullscreen-header { display: flex; align-items: center; justify-content: space-between; gap: 18px; padding: 16px 20px; background: #fff; border-bottom: 1px solid var(--line); }
      .risk-fullscreen-header > div { display: grid; gap: 2px; }
      .risk-fullscreen-header strong { color: var(--ink); font-size: 17px; }
      .risk-fullscreen-header span { color: var(--muted); font-size: 12px; }
      .risk-fullscreen-content { flex: 1; overflow: auto; padding: clamp(18px, 3vw, 42px); }
      .risk-fullscreen-content .risk-board { width: min(1280px, 100%); margin: 0 auto; }
      .risk-fullscreen-content .risk-fullscreen-trigger { display: none; }
      body.risk-fullscreen-open { overflow: hidden; }

      @media (max-width: 1100px) {
        .workspace { grid-template-columns: 1fr; }
        .column.results { grid-column: auto; grid-template-columns: 1fr; }
        .column.results > .risk-panel { grid-column: auto; }
      }
      @media (max-width: 860px) {
        .app { grid-template-columns: 1fr; }
        .workspace { padding: 14px; }
        .risk-fullscreen-modal { padding: 0; }
        .risk-fullscreen-panel { width: 100%; height: 100%; border-radius: 0; }
        .risk-board-toolbar { align-items: flex-start; }
      }

      * { box-sizing: border-box; }
      html { scroll-behavior: smooth; }
      body {
        margin: 0;
        min-height: 100vh;
        background:
          radial-gradient(1100px 640px at 14% -8%, rgba(255, 91, 77, 0.06), transparent 60%),
          radial-gradient(900px 560px at 100% 0%, rgba(77, 155, 245, 0.05), transparent 55%),
          var(--bg);
        background-attachment: fixed;
        color: var(--ink);
        font-family: "Segoe UI", "Inter", -apple-system, BlinkMacSystemFont, Roboto, Helvetica, Arial, sans-serif;
        font-size: 14px;
        letter-spacing: 0;
        -webkit-font-smoothing: antialiased;
      }
      button, input, select { font: inherit; }

      ::selection { background: rgba(255, 91, 77, 0.32); color: #fff; }

      ::-webkit-scrollbar { width: 10px; height: 10px; }
      ::-webkit-scrollbar-track { background: transparent; }
      ::-webkit-scrollbar-thumb {
        background: #262e3f;
        border-radius: 999px;
        border: 2px solid var(--bg);
      }
      ::-webkit-scrollbar-thumb:hover { background: #333e54; }

      a, button, input, select, textarea, summary {
        outline-color: var(--accent);
      }
      a:focus-visible, button:focus-visible, input:focus-visible,
      select:focus-visible, textarea:focus-visible, summary:focus-visible {
        outline: 2px solid var(--accent);
        outline-offset: 2px;
        border-radius: 4px;
      }

      @keyframes fsre-fade-up {
        from { opacity: 0; transform: translateY(6px); }
        to { opacity: 1; transform: translateY(0); }
      }

      .app {
        display: grid;
        grid-template-columns: 240px minmax(780px, 1fr);
        min-height: 100vh;
      }

      .sidebar {
        background: linear-gradient(180deg, #0d1118 0%, #0a0d13 100%);
        color: #e5e7eb;
        padding: 20px 14px;
        display: flex;
        flex-direction: column;
        gap: 20px;
        border-right: 1px solid var(--line-soft);
        position: sticky;
        top: 0;
        height: 100vh;
        overflow-y: auto;
      }

      .brand {
        display: grid;
        align-items: start;
        justify-items: start;
        gap: 10px;
        padding: 4px 6px 14px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.12);
      }

      .company-logo {
        width: 134px;
        height: 50px;
        border-radius: 8px;
        background: #ffffff;
        object-fit: contain;
        object-position: center;
        padding: 5px 10px;
        box-shadow: 0 4px 16px rgba(0, 0, 0, 0.35);
      }

      .brand h1 {
        margin: 0;
        max-width: 180px;
        font-size: 13px;
        line-height: 1.06;
        text-transform: uppercase;
      }

      .brand h1 span {
        display: block;
        overflow-wrap: anywhere;
      }

      .brand h1 span + span {
        margin-top: 5px;
        color: #9ca3af;
        font-size: 11px;
        font-weight: 400;
        line-height: 1.15;
        text-transform: none;
      }

      .nav {
        display: grid;
        gap: 4px;
      }

      .nav button,
      .nav a {
        border: 0;
        background: transparent;
        color: #cbd5e1;
        display: grid;
        grid-template-columns: 24px 1fr;
        align-items: center;
        gap: 8px;
        width: 100%;
        min-height: 40px;
        padding: 8px 10px;
        border-radius: 9px;
        text-align: left;
        cursor: pointer;
        text-decoration: none;
        transition: background 0.16s var(--ease), color 0.16s var(--ease), transform 0.16s var(--ease);
      }

      .nav button:hover,
      .nav a:hover {
        background: rgba(255, 255, 255, 0.06);
        color: #ffffff;
        transform: translateX(2px);
      }

      .nav button.active,
      .nav a.active {
        background: linear-gradient(90deg, rgba(255, 91, 77, 0.24), rgba(255, 91, 77, 0.08));
        color: #ffffff;
        box-shadow: inset 2px 0 0 var(--accent);
      }

      .company-list {
        display: grid;
        gap: 8px;
      }

      .company-list h2 {
        color: #9ca3af;
        font-size: 12px;
        text-transform: uppercase;
        margin: 0 6px 2px;
      }

      .company-card {
        border: 1px solid rgba(255, 255, 255, 0.10);
        background: rgba(255, 255, 255, 0.045);
        border-radius: var(--radius-md);
        padding: 11px 12px;
        color: #d1d5db;
        transition: border-color 0.16s var(--ease), background 0.16s var(--ease);
      }

      .company-card.active {
        border-color: rgba(255, 91, 77, 0.55);
        background: linear-gradient(135deg, rgba(255, 91, 77, 0.16), rgba(255, 91, 77, 0.04));
        color: #ffffff;
      }

      .company-card strong,
      .company-card span {
        display: block;
      }

      .company-card span {
        margin-top: 4px;
        color: #a5b4c4;
        font-size: 12px;
      }

      .company-switcher {
        border: 1px solid rgba(255, 255, 255, 0.12);
        border-radius: 8px;
        background: rgba(255, 255, 255, 0.05);
        overflow: hidden;
      }

      .company-switcher summary {
        position: relative;
        list-style: none;
        cursor: pointer;
        padding: 11px 10px;
        display: grid;
        gap: 4px;
      }

      .company-switcher summary::-webkit-details-marker {
        display: none;
      }

      .company-switcher summary:after {
        content: "+";
        position: absolute;
        right: 22px;
        margin-top: 8px;
        color: #9ca3af;
        font-weight: 700;
      }

      .company-switcher[open] summary:after {
        content: "-";
      }

      .company-switcher summary span {
        color: #9ca3af;
        font-size: 12px;
        text-transform: uppercase;
      }

      .company-switcher summary strong {
        color: #ffffff;
        font-size: 14px;
      }

      .company-switcher-body {
        display: grid;
        gap: 8px;
        padding: 0 8px 10px;
      }

      .company-switcher .company-card {
        box-shadow: none;
      }

      .panel,
      .button,
      .selected-report-card,
      .upload-progress-card {
        transition: border-color 0.16s ease, box-shadow 0.16s ease, transform 0.16s ease;
      }

      .panel:hover,
      .selected-report-card:hover,
      .upload-progress-card:hover {
        border-color: rgba(77, 155, 245, 0.38);
        box-shadow: var(--shadow);
      }

      .sidebar-footer {
        margin-top: auto;
        padding: 12px 8px;
        border-top: 1px solid rgba(255, 255, 255, 0.12);
        color: #a5b4c4;
        font-size: 12px;
        line-height: 1.45;
      }

      .main {
        display: grid;
        grid-template-rows: 64px 1fr;
        min-width: 0;
      }

      .topbar {
        background: rgba(19, 24, 34, 0.86);
        backdrop-filter: blur(10px);
        -webkit-backdrop-filter: blur(10px);
        border-bottom: 1px solid var(--line);
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 0 26px;
        gap: 16px;
        position: sticky;
        top: 0;
        z-index: 20;
      }

      .topbar-title h2 {
        margin: 0;
        font-size: 18px;
      }

      .topbar-title span {
        color: var(--muted);
        font-size: 12px;
      }

      .status-strip {
        display: flex;
        align-items: center;
        gap: 8px;
        min-width: 0;
      }

      .workspace {
        padding: 22px 26px 30px;
        display: grid;
        grid-template-columns: minmax(330px, 0.9fr) minmax(430px, 1.15fr) minmax(380px, 1fr);
        gap: 18px;
        min-width: 0;
      }

      .column {
        min-width: 0;
        display: grid;
        align-content: start;
        gap: 18px;
      }

      .field-label {
        display: grid;
        gap: 7px;
        color: #abb7cb;
        font-size: 12px;
        font-weight: 700;
        margin-bottom: 12px;
      }

      .field-help,
      .toolbar-help {
        display: block;
        color: var(--muted);
        font-size: 12px;
        font-weight: 400;
        line-height: 1.35;
      }

      .toolbar-help {
        flex: 1 1 100%;
        margin-top: -2px;
      }

      .setup-meta {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 8px;
        margin-top: 12px;
      }

      .setup-meta div {
        border: 1px solid var(--line);
        border-radius: 8px;
        background: #131a20;
        padding: 10px;
      }

      .setup-meta span,
      .kpi span {
        display: block;
        color: var(--muted);
        font-size: 12px;
        margin-bottom: 5px;
      }

      .setup-meta strong {
        display: block;
        overflow-wrap: anywhere;
        font-size: 12px;
      }

      .selected-report-card {
        border: 1px solid #172948;
        border-radius: 8px;
        background: #0d1826;
        padding: 11px;
        margin: -2px 0 12px;
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: 10px;
      }

      .selected-report-card span,
      .selected-report-card small {
        display: block;
        color: var(--muted);
        font-size: 12px;
      }

      .selected-report-card strong {
        display: block;
        margin: 3px 0;
        overflow-wrap: anywhere;
      }

      .rule-toolbar {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
        margin-bottom: 12px;
      }

      .rule-filter {
        min-width: 170px;
        flex: 1 1 170px;
      }

      .selected-rule-summary {
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 8px;
        margin-bottom: 12px;
      }

      .summary-chip {
        border: 1px solid var(--line);
        border-radius: 8px;
        background: var(--panel-alt);
        padding: 10px;
      }

      .summary-chip span {
        display: block;
        color: var(--muted);
        font-size: 11px;
        margin-bottom: 4px;
      }

      .summary-chip strong {
        display: block;
        font-size: 18px;
      }

      .summary-chip.risk { background: var(--soft-danger); border-color: #540900; }
      .summary-chip.warn { background: var(--soft-warn); border-color: #754600; }
      .summary-chip.info { background: var(--soft-blue); border-color: #172948; }

      .rule-checklist {
        display: grid;
        gap: 8px;
        max-height: 440px;
        overflow: auto;
        padding-right: 4px;
      }

      .rule-checklist label {
        display: grid;
        grid-template-columns: 20px 1fr;
        gap: 9px;
        align-items: start;
        border: 1px solid var(--line);
        border-radius: var(--radius-md);
        background: var(--panel-alt);
        padding: 11px 12px;
        transition: border-color 0.15s var(--ease), background 0.15s var(--ease), transform 0.15s var(--ease);
      }

      .rule-checklist label:hover {
        border-color: rgba(255, 91, 77, 0.4);
        background: var(--panel-hover);
        transform: translateY(-1px);
      }

      .rule-option {
        display: flex;
        justify-content: space-between;
        gap: 8px;
        align-items: flex-start;
      }

      .rule-option strong,
      .rule-option span {
        display: block;
      }

      .rule-option > div > span {
        margin-top: 4px;
        color: #7a8499;
        font-size: 12px;
        line-height: 1.35;
      }

      .progress {
        display: grid;
        gap: 2px;
      }

      .progress .step {
        display: grid;
        grid-template-columns: 18px 1fr;
        column-gap: 8px;
        padding: 8px 0;
      }

      .progress .step:before {
        display: none;
      }

      .progress .step strong {
        display: block;
      }

      .progress .step span:last-child {
        grid-column: 2;
        color: var(--muted);
        font-size: 12px;
        margin-top: 2px;
      }

      .dot {
        width: 10px;
        height: 10px;
        border-radius: 50%;
        background: #1e2834;
        margin-top: 4px;
      }

      .step.done .dot {
        background: var(--ok);
      }

      .step.active .dot {
        background: var(--warn);
        animation: pulseDot 1.2s ease-in-out infinite;
      }

      @keyframes pulseDot {
        0%, 100% { box-shadow: 0 0 0 0 rgba(245, 166, 35, 0.32); }
        50% { box-shadow: 0 0 0 6px rgba(245, 166, 35, 0.08); }
      }

      .kpi-grid {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 10px;
      }

      .kpi {
        border: 1px solid var(--line);
        border-radius: var(--radius-md);
        background: var(--panel-alt);
        padding: 13px 14px;
        min-height: 96px;
      }

      .kpi strong {
        display: block;
        font-size: 22px;
        line-height: 1.1;
        overflow-wrap: anywhere;
        letter-spacing: -0.2px;
      }

      .kpi small {
        display: block;
        margin-top: 7px;
        color: #7a8499;
        font-size: 11px;
        line-height: 1.35;
        overflow-wrap: anywhere;
      }

      .kpi.ok { background: var(--soft-ok); border-color: rgba(47, 217, 125, 0.28); }
      .kpi.warn { background: var(--soft-warn); border-color: rgba(245, 166, 35, 0.28); }
      .kpi.risk { background: var(--soft-danger); border-color: rgba(242, 99, 90, 0.28); }
      .kpi.info { background: var(--soft-blue); border-color: rgba(77, 155, 245, 0.28); }
      .kpi.neutral { background: var(--panel-alt); border-color: var(--line); }

      .kpi.action {
        transition: transform 0.16s var(--ease), border-color 0.16s var(--ease), box-shadow 0.16s var(--ease);
      }

      .kpi-link {
        color: inherit;
        text-decoration: none;
        display: block;
        min-width: 0;
      }

      .kpi-link .kpi.action:hover {
        border-color: rgba(77, 155, 245, 0.5);
        box-shadow: var(--shadow);
        transform: translateY(-2px);
      }

      .risk-board {
        display: grid;
        gap: 10px;
      }

      .risk-hero {
        display: grid;
        grid-template-columns: minmax(0, 1.3fr) minmax(160px, 0.7fr);
        gap: 12px;
        border: 1px solid var(--line);
        border-radius: var(--radius-lg);
        background: linear-gradient(135deg, var(--panel-alt), var(--bg-elevated));
        padding: 16px;
        box-shadow: var(--shadow);
      }

      .risk-board.risk .risk-hero {
        border-color: rgba(242, 99, 90, 0.35);
        background: linear-gradient(135deg, rgba(242, 99, 90, 0.14), var(--panel-alt));
        box-shadow: 0 8px 28px rgba(242, 99, 90, 0.14);
      }

      .risk-board.warn .risk-hero {
        border-color: rgba(245, 166, 35, 0.35);
        background: linear-gradient(135deg, rgba(245, 166, 35, 0.14), var(--panel-alt));
        box-shadow: 0 8px 28px rgba(245, 166, 35, 0.12);
      }

      .risk-board.ok .risk-hero {
        border-color: rgba(47, 217, 125, 0.35);
        background: linear-gradient(135deg, rgba(47, 217, 125, 0.14), var(--panel-alt));
        box-shadow: 0 8px 28px rgba(47, 217, 125, 0.12);
      }

      .risk-hero span {
        color: var(--muted);
        font-size: 11px;
        text-transform: uppercase;
        font-weight: 800;
      }

      .risk-status-label {
        display: inline-flex;
        align-items: center;
        gap: 7px;
        min-width: 0;
      }

      .info-popover {
        position: relative;
        display: inline-flex;
        align-items: center;
        flex: 0 0 auto;
        outline: none;
      }

      .info-dot {
        display: inline-grid;
        flex: 0 0 16px;
        width: 16px;
        min-width: 16px;
        max-width: 16px;
        height: 16px;
        min-height: 16px;
        max-height: 16px;
        place-items: center;
        border: 1px solid #172948;
        border-radius: 999px;
        background: var(--panel-alt);
        color: #74a7e8 !important;
        font-size: 10px !important;
        font-weight: 900 !important;
        line-height: 1;
        text-transform: none !important;
        cursor: help;
      }

      .info-popover-text {
        position: absolute;
        left: 50%;
        bottom: calc(100% + 8px);
        z-index: 30;
        width: max-content;
        max-width: 240px;
        min-width: 190px;
        padding: 8px 10px;
        border: 1px solid #091a30;
        border-radius: 8px;
        background: var(--panel-alt);
        box-shadow: 0 12px 28px rgba(0, 0, 0, 0.24);
        color: #abb7cb !important;
        font-size: 12px !important;
        font-weight: 700 !important;
        line-height: 1.35;
        opacity: 0;
        pointer-events: none;
        text-align: left;
        text-transform: none !important;
        transform: translate(-50%, 4px);
        transition: opacity 0.14s ease, transform 0.14s ease;
        white-space: normal;
      }

      .info-popover-text::after {
        content: "";
        position: absolute;
        left: 50%;
        top: 100%;
        width: 8px;
        height: 8px;
        border-right: 1px solid #091a30;
        border-bottom: 1px solid #091a30;
        background: var(--panel-alt);
        transform: translate(-50%, -4px) rotate(45deg);
      }

      .info-popover:hover .info-popover-text,
      .info-popover:focus-within .info-popover-text,
      .info-popover:focus .info-popover-text {
        opacity: 1;
        transform: translate(-50%, 0);
      }

      .risk-hero h3 {
        margin: 4px 0;
        font-size: 20px;
        line-height: 1.15;
      }

      .risk-hero p {
        margin: 0;
        color: #8898ad;
        font-size: 13px;
        line-height: 1.4;
      }

      .risk-score-strip {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 6px;
        align-content: stretch;
      }

      .risk-score-strip div {
        border: 1px solid rgba(23, 74, 139, 0.12);
        border-radius: 8px;
        background: rgba(19, 23, 32, 0.78);
        padding: 8px;
        text-align: center;
      }

      .risk-score-strip strong,
      .risk-score-strip span {
        display: block;
      }

      .risk-score-strip strong {
        font-size: 18px;
        color: #cfd9e7;
      }

      .risk-score-strip span {
        color: var(--muted);
        font-size: 10px;
        text-transform: none;
      }

      .risk-insight-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
        gap: 10px;
      }

      .risk-insight {
        border: 1px solid var(--line);
        border-radius: 8px;
        background: var(--panel-alt);
        padding: 10px;
        min-width: 0;
      }

      .risk-insight.risk { border-color: #540900; background: #2e0505; }
      .risk-insight.warn { border-color: #754600; background: #2e2405; }
      .risk-insight.info { border-color: #172948; background: #05172e; }

      .risk-insight-head {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: 8px;
        margin-bottom: 8px;
      }

      .risk-insight-head span,
      .risk-insight-head strong {
        display: block;
      }

      .risk-insight-head span {
        color: var(--muted);
        font-size: 11px;
        font-weight: 800;
        text-transform: uppercase;
      }

      .risk-insight-label {
        display: inline-flex;
        align-items: center;
        gap: 7px;
        min-width: 0;
      }

      .risk-insight-label span,
      .risk-insight-label .info-popover {
        display: inline-flex;
      }

      .risk-insight-label .info-dot,
      .risk-status-label .info-dot {
        display: inline-grid;
      }

      .risk-insight-head strong {
        margin-top: 2px;
        color: #cfd9e7;
        font-size: 19px;
      }

      .risk-insight-head a {
        color: #74a7e8;
        font-size: 11px;
        font-weight: 800;
        text-decoration: none;
        padding: 4px 7px;
        border: 1px solid #091a30;
        border-radius: 999px;
        background: var(--panel-alt);
      }

      .risk-mini-list {
        display: flex;
        flex-wrap: wrap;
        gap: 6px;
        align-items: center;
      }

      .risk-chip {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 5px;
        min-height: 28px;
        max-width: 100%;
        color: #b8c3da;
        text-decoration: none;
        border: 1px solid #171d27;
        border-radius: 999px;
        background: rgba(19, 23, 32, 0.74);
        padding: 5px 9px;
        font-size: 11px;
        font-weight: 800;
        line-height: 1.1;
        overflow-wrap: anywhere;
        min-width: 0;
      }

      .risk-chip:hover {
        border-color: #173962;
        background: var(--panel-alt);
      }

      .risk-chip.risk {
        color: var(--danger);
        background: var(--soft-danger);
        border-color: #540900;
      }

      .risk-chip.warn {
        color: var(--warn);
        background: var(--soft-warn);
        border-color: #754600;
      }

      .risk-chip.info {
        color: #74a7e8;
        background: var(--soft-blue);
        border-color: #172948;
      }

      .risk-chip.more {
        min-width: 34px;
        justify-content: center;
        background: var(--panel-alt);
      }

      .risk-more-details {
        display: inline-block;
        max-width: 100%;
      }

      .risk-more-details summary {
        list-style: none;
        cursor: pointer;
      }

      .risk-more-details summary::-webkit-details-marker {
        display: none;
      }

      .risk-overflow-list {
        display: flex;
        flex-wrap: wrap;
        gap: 6px;
        margin-top: 6px;
        padding: 7px;
        border: 1px dashed #171d27;
        border-radius: 8px;
        background: rgba(19, 23, 32, 0.72);
      }

      .risk-empty {
        color: var(--muted);
        font-size: 12px;
        border: 1px dashed #171d27;
        border-radius: 7px;
        padding: 9px;
        background: rgba(19, 23, 32, 0.65);
      }

      .result-table {
        width: 100%;
        border-collapse: collapse;
        table-layout: fixed;
      }

      .result-table th,
      .result-table td {
        padding: 10px 12px;
        border-bottom: 1px solid var(--line);
        text-align: left;
        vertical-align: top;
        overflow-wrap: anywhere;
      }

      .result-table th {
        color: var(--muted);
        font-size: 12px;
        background: #14191f;
      }

      .trigger-summary-list {
        display: grid;
        gap: 12px;
      }

      .trigger-summary-card {
        border: 1px solid #102036;
        border-radius: 8px;
        background: var(--panel-alt);
        overflow: hidden;
        box-shadow: 0 8px 22px rgba(0, 0, 0, 0.12);
      }

      .trigger-summary-card summary {
        position: relative;
        list-style: none;
        cursor: pointer;
        display: grid;
        grid-template-columns: 1fr;
        gap: 14px;
        align-items: stretch;
        padding: 15px 48px 14px 16px;
        background: linear-gradient(180deg, var(--panel-alt) 0%, #05172e 100%);
      }

      .trigger-summary-card summary::-webkit-details-marker,
      .flag-disclosure summary::-webkit-details-marker {
        display: none;
      }

      .trigger-summary-card summary:after,
      .flag-disclosure summary:after {
        content: "+";
        position: absolute;
        right: 15px;
        top: 15px;
        width: 24px;
        height: 24px;
        border: 1px solid #102036;
        border-radius: 999px;
        display: grid;
        place-items: center;
        background: var(--panel-alt);
        color: #6591d0;
        font-weight: 700;
        line-height: 1;
      }

      .trigger-summary-card[open] summary:after,
      .flag-disclosure[open] summary:after {
        content: "-";
      }

      .trigger-title-block,
      .trigger-title-block strong,
      .trigger-title-block span {
        display: block;
      }

      .trigger-title-block strong {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
        align-items: center;
        color: #cfd9e7;
        font-size: 16px;
        font-weight: 800;
        line-height: 1.25;
        letter-spacing: 0;
        min-width: 0;
      }

      .trigger-title-block strong span:first-child {
        flex: 0 0 auto;
        color: #74a7e8;
        font-size: 12px;
        font-weight: 800;
        text-transform: uppercase;
        background: #05172e;
        border: 1px solid #091a30;
        border-radius: 6px;
        padding: 4px 7px;
      }

      .trigger-title-block strong span:last-child {
        min-width: 180px;
        flex: 1 1 240px;
        overflow-wrap: anywhere;
      }

      .trigger-title-block > span {
        color: #8591a0;
        margin-top: 8px;
        line-height: 1.45;
        max-width: 900px;
        overflow-wrap: anywhere;
      }

      .summary-metrics {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(126px, 1fr));
        gap: 10px;
        align-items: stretch;
      }

      .metric-pill {
        border: 1px solid #0d1826;
        border-radius: 8px;
        background: var(--panel-alt);
        padding: 10px 12px;
        min-width: 0;
      }

      .metric-pill.wide {
        grid-column: 1 / -1;
        min-width: 0;
      }

      .metric-pill span,
      .metric-pill strong {
        display: block;
      }

      .metric-pill > span:first-child {
        color: #74849a;
        font-size: 11px;
        font-weight: 700;
        text-transform: uppercase;
        margin-bottom: 6px;
        line-height: 1.25;
      }

      .metric-pill strong {
        color: #c2cde0;
        font-size: 13px;
        font-weight: 800;
        line-height: 1.35;
        overflow-wrap: anywhere;
      }

      .metric-pill strong small,
      .metric-pill strong span {
        display: block;
      }

      .metric-pill strong small {
        color: #74849a;
        font-size: 11px;
        font-weight: 700;
        margin-bottom: 3px;
      }

      .metric-pill .tag {
        display: inline-flex;
        width: 100%;
        justify-content: center;
        min-height: 28px;
        align-items: center;
      }

      .trigger-summary-body {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
        gap: 10px;
        padding: 0 16px 16px;
        background: #051a2e;
      }

      .trigger-summary-body div {
        border: 1px solid #0d1826;
        border-radius: 8px;
        background: var(--panel-alt);
        padding: 12px 13px;
      }

      .trigger-summary-body span,
      .trigger-summary-body strong {
        display: block;
      }

      .trigger-summary-body span {
        color: #7a8499;
        font-size: 12px;
        font-weight: 700;
        text-transform: uppercase;
        margin-bottom: 4px;
      }

      .trigger-summary-body strong {
        color: #cfd9e7;
        font-size: 14px;
        font-weight: 800;
        line-height: 1.35;
        overflow-wrap: anywhere;
      }

      .flag-list {
        display: grid;
        gap: 10px;
      }

      .redflag-workbench {
        border: 1px solid #102036;
        border-radius: 8px;
        background: var(--panel-alt);
        overflow: hidden;
        box-shadow: 0 8px 22px rgba(0, 0, 0, 0.12);
      }

      .redflag-workbench-head {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: 12px;
        padding: 15px 16px;
        border-bottom: 1px solid #102036;
        background: linear-gradient(180deg, var(--panel-alt) 0%, #05172e 100%);
      }

      .redflag-workbench-head strong,
      .redflag-workbench-head span {
        display: block;
      }

      .redflag-workbench-head span {
        color: #8591a0;
        margin-top: 5px;
        line-height: 1.4;
      }

      .redflag-tabs-wrap {
        display: grid;
        background: #051a2e;
      }

      .redflag-tabs .tab {
        border: 0 !important;
        border-right: 1px solid #0d1826 !important;
        border-bottom: 1px solid #0d1826 !important;
        background: #0d1826 !important;
        color: #99a9bf !important;
        padding: 11px 14px !important;
        font-weight: 700;
        letter-spacing: 0;
      }

      .redflag-tabs .tab--selected,
      .redflag-tabs .redflag-tab.selected {
        background: var(--panel-alt) !important;
        color: #e7564b !important;
        border-bottom: 3px solid #e7564b !important;
      }

      .redflag-detail-screen {
        padding: 16px;
        display: grid;
        gap: 18px;
        background: #05172e;
      }

      .redflag-detail-header {
        display: grid;
        grid-template-columns: minmax(0, 1fr);
        gap: 16px;
        padding: 18px;
        border: 1px solid #102036;
        border-radius: 8px;
        background: var(--panel-alt);
        box-shadow: 0 8px 22px rgba(0, 0, 0, 0.1);
      }

      .redflag-detail-header span,
      .redflag-detail-header h4,
      .redflag-detail-header p {
        display: block;
        margin: 0;
      }

      .redflag-category {
        color: #74849a;
        font-size: 12px;
        font-weight: 800;
        text-transform: uppercase;
        letter-spacing: 0;
      }

      .redflag-rule-badge {
        display: inline-flex !important;
        width: max-content;
        margin-top: 8px !important;
        color: #e87870;
        font-size: 12px;
        font-weight: 800;
        background: #2e0805;
        border: 1px solid #380500;
        border-radius: 6px;
        padding: 5px 8px;
      }

      .redflag-detail-header h4 {
        margin-top: 12px;
        max-width: 900px;
        font-size: 21px;
        font-weight: 800;
        line-height: 1.18;
        color: #cfd9e7;
        overflow-wrap: anywhere;
      }

      .redflag-detail-header p {
        margin-top: 10px;
        max-width: 720px;
        color: #8591a0;
        font-size: 15px;
        line-height: 1.45;
        overflow-wrap: anywhere;
      }

      .redflag-status-stack {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
        gap: 12px;
        min-width: 0;
      }

      .redflag-status-tile {
        border: 1px solid #091a30;
        border-radius: 8px;
        background: var(--panel-alt);
        padding: 13px 14px;
      }

      .redflag-status-tile > span:first-child {
        display: block;
        color: #74849a;
        font-size: 12px;
        font-weight: 800;
        text-transform: uppercase;
        margin-bottom: 9px;
      }

      .redflag-status-tile .tag {
        display: inline-flex;
        width: 100%;
        justify-content: center;
        min-height: 30px;
        align-items: center;
      }

      .redflag-focus-grid {
        display: grid;
        grid-template-columns: minmax(0, 1.25fr) minmax(280px, 0.75fr);
        gap: 18px;
      }

      .redflag-accordion {
        display: grid;
        gap: 12px;
        min-width: 0;
      }

      .redflag-drawer {
        border: 1px solid #091a30;
        border-radius: 8px;
        background: var(--panel-alt);
        overflow: hidden;
        box-shadow: 0 6px 18px rgba(0, 0, 0, 0.09);
      }

      .redflag-drawer[open] {
        animation: detailFlash 0.75s ease-out;
      }

      .redflag-drawer summary {
        position: relative;
        list-style: none;
        cursor: pointer;
        min-height: 46px;
        padding: 13px 46px 12px 14px;
        color: #cfd9e7;
        font-size: 13px;
        font-weight: 800;
        text-transform: uppercase;
        background: linear-gradient(180deg, var(--panel-alt) 0%, #05172e 100%);
        border-bottom: 1px solid #0e1825;
      }

      .redflag-drawer summary::-webkit-details-marker {
        display: none;
      }

      .redflag-drawer summary:after {
        content: "+";
        position: absolute;
        right: 14px;
        top: 10px;
        width: 26px;
        height: 26px;
        display: grid;
        place-items: center;
        border: 1px solid #102036;
        border-radius: 999px;
        background: var(--panel-alt);
        color: #6591d0;
        line-height: 1;
      }

      .redflag-drawer[open] summary:after {
        content: "-";
      }

      .redflag-drawer:not([open]) summary {
        border-bottom: 0;
      }

      .redflag-drawer > .calculation-card,
      .redflag-drawer > .evidence-table-wrap,
      .redflag-drawer > .side-block {
        margin: 14px;
      }

      .redflag-drawer.insight {
        border-color: #380500;
      }

      @keyframes detailFlash {
        0% { box-shadow: 0 0 0 0 rgba(22, 106, 98, 0.28); background: #092a17; }
        45% { box-shadow: 0 0 0 5px rgba(22, 106, 98, 0.10); }
        100% { box-shadow: 0 6px 18px rgba(0, 0, 0, 0.09); background: var(--panel-alt); }
      }

      .redflag-main-panel,
      .redflag-side-panel {
        min-width: 0;
      }

      .redflag-main-panel h5 {
        margin: 0 0 10px;
        font-size: 13px;
        font-weight: 800;
        text-transform: uppercase;
        color: #74849a;
      }

      .redflag-main-panel h5 + .evidence-table {
        margin-top: 0;
      }

      .calculation-card {
        display: grid;
        grid-template-columns: 1fr;
        gap: 12px;
        margin-bottom: 0;
      }

      .calculation-card div {
        border: 1px solid #091a30;
        border-radius: 8px;
        background: var(--panel-alt);
        padding: 14px 15px;
        box-shadow: 0 5px 16px rgba(0, 0, 0, 0.07);
      }

      .calculation-card span,
      .calculation-card strong {
        display: block;
      }

      .calculation-card span {
        color: #74849a;
        font-size: 12px;
        font-weight: 800;
        text-transform: uppercase;
      }

      .calculation-card strong {
        margin-top: 7px;
        color: #cfd9e7;
        font-size: 15px;
        font-weight: 800;
        line-height: 1.38;
        overflow-wrap: break-word;
        word-break: normal;
      }

      .redflag-side-panel {
        display: grid;
        align-content: start;
        gap: 12px;
      }

      .side-block.important {
        border-color: #091a30;
        background: var(--panel-alt);
      }

      .flag {
        border: 1px solid #754600;
        border-left: 4px solid var(--warn);
        border-radius: 8px;
        background: #2e2205;
        padding: 12px;
      }

      .flag.high {
        border-color: #540900;
        border-left-color: var(--danger);
        background: #2e0a05;
      }

      .flag h4 {
        margin: 0 0 6px;
        font-size: 14px;
      }

      .flag-disclosure {
        padding: 0;
        overflow: hidden;
      }

      .flag-disclosure summary {
        position: relative;
        list-style: none;
        cursor: pointer;
        display: grid;
        grid-template-columns: minmax(0, 1fr) auto;
        gap: 12px;
        align-items: start;
        padding: 13px 40px 13px 14px;
      }

      .flag-summary-main p {
        margin: 0;
      }

      .flag-summary-meta {
        display: flex;
        flex-wrap: wrap;
        justify-content: flex-end;
        gap: 6px;
        max-width: 260px;
      }

      .flag-detail-panel {
        display: grid;
        grid-template-columns: minmax(0, 1.35fr) minmax(220px, 0.65fr);
        gap: 12px;
        padding: 0 14px 14px;
      }

      .explain-main {
        min-width: 0;
      }

      .explain-side {
        display: grid;
        align-content: start;
        gap: 9px;
        min-width: 0;
      }

      .side-block {
        border: 1px solid #101823;
        border-radius: 8px;
        background: var(--panel-alt);
        padding: 10px;
      }

      .side-block strong,
      .side-block span {
        display: block;
      }

      .side-block strong {
        color: var(--ink);
        margin-bottom: 5px;
      }

      .side-block span {
        color: #98a5b8;
        line-height: 1.45;
      }

      .flag-header {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: 10px;
      }

      .explain-grid {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 8px;
        margin: 10px 0;
      }

      .explain-grid div,
      .analyst-action,
      .snapshot-item {
        border: 1px solid #101823;
        border-radius: 8px;
        background: var(--panel-alt);
        padding: 9px 10px;
      }

      .explain-grid span,
      .explain-grid strong,
      .analyst-action span,
      .analyst-action strong,
      .snapshot-item span,
      .snapshot-item strong,
      .snapshot-item small {
        display: block;
      }

      .explain-grid span,
      .analyst-action strong,
      .snapshot-item small {
        color: var(--muted);
        font-size: 12px;
      }

      .explain-grid strong,
      .analyst-action span,
      .snapshot-item span {
        margin-top: 3px;
        color: #abb7cb;
        line-height: 1.4;
      }

      .evidence-table {
        width: 100%;
        border-collapse: collapse;
        table-layout: fixed;
        margin: 10px 0;
        background: var(--panel-alt);
        border: 1px solid var(--line);
        border-radius: var(--radius-md);
        overflow: hidden;
      }

      .evidence-table th,
      .evidence-table td {
        padding: 9px 10px;
        border-bottom: 1px solid var(--line-soft);
        text-align: left;
        vertical-align: top;
        overflow-wrap: anywhere;
      }

      .evidence-table th {
        color: var(--muted);
        font-size: 11.5px;
        letter-spacing: 0.3px;
        text-transform: uppercase;
        background: var(--bg-elevated);
      }

      .evidence-table tbody tr:hover td {
        background: rgba(255, 255, 255, 0.025);
      }

      .evidence-table tr:last-child td {
        border-bottom: 0;
      }

      .evidence-record-list {
        display: grid;
        gap: 10px;
        margin-top: 8px;
      }

      .evidence-record {
        border: 1px solid #0f1a28;
        border-radius: 8px;
        background: var(--panel-alt);
        overflow: hidden;
      }

      .evidence-record-header {
        display: grid;
        grid-template-columns: minmax(0, 1fr) minmax(120px, 0.6fr) auto;
        gap: 14px;
        align-items: start;
        padding: 12px 14px;
        background: #101823;
        border-bottom: 1px solid #111822;
      }

      .evidence-record-meta {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 12px;
        padding: 11px 14px;
      }

      .evidence-record-header > div,
      .evidence-record-meta > div,
      .evidence-raw-value {
        min-width: 0;
      }

      .evidence-record span {
        display: block;
        margin-bottom: 3px;
        color: #7a8499;
        font-size: 11px;
        font-weight: 700;
        text-transform: uppercase;
      }

      .evidence-record strong {
        display: block;
        color: #b8c3da;
        font-size: 13px;
        line-height: 1.4;
        overflow-wrap: break-word;
        word-break: normal;
      }

      .evidence-record .evidence-inline-text,
      .evidence-record .evidence-full-text {
        margin: 0;
        color: inherit;
        font: inherit;
        line-height: inherit;
        text-transform: none;
        white-space: pre-wrap;
      }

      .evidence-record .evidence-full-text {
        display: none;
      }

      .evidence-primary-value strong {
        color: #74a7e8;
        font-size: 15px;
      }

      .evidence-raw-value {
        padding: 10px 14px 13px;
        border-top: 1px solid #121921;
      }

      .evidence-report-name strong {
        font-weight: 600;
      }

      .evidence-expand-button {
        min-height: 30px;
        padding: 5px 10px;
        border: 1px solid #1c2e46;
        border-radius: 6px;
        background: var(--panel-alt);
        color: #74a7e8;
        font-size: 12px;
        font-weight: 700;
        cursor: pointer;
      }

      .evidence-expand-button:hover {
        background: #05152e;
        border-color: #2b5182;
      }

      .evidence-modal {
        display: none;
        position: fixed;
        inset: 0;
        z-index: 10000;
        align-items: center;
        justify-content: center;
        padding: 24px;
      }

      .evidence-modal.is-open {
        display: flex;
      }

      .evidence-modal-backdrop {
        position: absolute;
        inset: 0;
        background: rgba(3, 5, 10, 0.72);
        backdrop-filter: blur(4px);
        -webkit-backdrop-filter: blur(4px);
      }

      .evidence-modal-panel {
        position: relative;
        display: flex;
        flex-direction: column;
        width: min(1120px, 96vw);
        max-height: 92vh;
        border: 1px solid #202838;
        border-radius: var(--radius-lg);
        background: var(--panel-alt);
        box-shadow: var(--shadow-lg);
        overflow: hidden;
        animation: fsre-fade-up 0.22s var(--ease) both;
      }

      .evidence-modal-toolbar {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 16px;
        padding: 14px 18px;
        border-bottom: 1px solid #121921;
        background: #101823;
      }

      .evidence-modal-toolbar strong,
      .evidence-modal-toolbar span {
        display: block;
      }

      .evidence-modal-toolbar span {
        margin-top: 2px;
        color: #7a8499;
        font-size: 12px;
      }

      .evidence-modal-content {
        padding: 24px;
        overflow: auto;
        background: #101823;
      }

      .evidence-modal-content .evidence-record {
        border: 0;
        background: transparent;
      }

      .evidence-modal-content .evidence-record-header {
        grid-template-columns: 1fr;
        gap: 0;
        padding: 0;
        border: 1px solid #0f1a28;
        border-radius: 8px;
        background: var(--panel-alt);
        overflow: hidden;
      }

      .evidence-modal-content .evidence-record-header > div {
        padding: 18px 20px;
      }

      .evidence-modal-content .evidence-primary-value {
        border-top: 1px solid #111822;
        background: #0d1526;
      }

      .evidence-modal-content .evidence-expand-button {
        display: none;
      }

      .evidence-modal-content .evidence-record strong {
        max-width: 100ch;
        font-size: 15px;
        line-height: 1.7;
        white-space: pre-wrap;
      }

      .evidence-modal-content .evidence-record-header > div:first-child strong {
        font-size: 18px;
        line-height: 1.4;
      }

      .evidence-modal-content .evidence-primary-value strong {
        color: #b8c3da;
        font-weight: 600;
      }

      .evidence-modal-content .evidence-record-meta {
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 12px;
        margin-top: 14px;
        padding: 0;
      }

      .evidence-modal-content .evidence-record-meta > div {
        min-height: 78px;
        padding: 14px 16px;
        border: 1px solid #0f1a28;
        border-radius: 8px;
        background: var(--panel-alt);
      }

      .evidence-modal-content .evidence-raw-value {
        margin-top: 14px;
        padding: 18px 20px;
        border: 1px solid #0f1a28;
        border-radius: 8px;
        background: var(--panel-alt);
      }

      .evidence-modal-content .evidence-raw-value > span {
        margin-bottom: 8px;
      }

      .evidence-modal-content .evidence-inline-text {
        display: none;
      }

      .evidence-modal-content .evidence-full-text {
        display: block;
      }

      body.evidence-modal-open {
        overflow: hidden;
      }

      @media (max-width: 720px) {
        .evidence-record-header,
        .evidence-record-meta {
          grid-template-columns: 1fr;
          gap: 9px;
        }

        .evidence-modal {
          padding: 10px;
        }

        .evidence-modal-panel {
          width: 100%;
          max-height: 94vh;
        }

        .evidence-modal-content {
          padding: 12px;
        }

        .evidence-modal-content .evidence-record-meta {
          grid-template-columns: 1fr;
        }
      }

      .redflag-workbench .side-block {
        border: 1px solid #091a30;
        border-radius: 8px;
        background: var(--panel-alt);
        padding: 15px;
        box-shadow: 0 8px 22px rgba(0, 0, 0, 0.1);
      }

      .redflag-workbench .side-block strong {
        color: #cfd9e7;
        font-size: 14px;
        font-weight: 800;
        text-transform: uppercase;
        margin-bottom: 10px;
      }

      .redflag-workbench .side-block span {
        color: #8898ad;
        font-size: 15px;
        line-height: 1.55;
        overflow-wrap: anywhere;
      }

      .redflag-workbench .evidence-table-wrap {
        margin: 0;
        border: 1px solid #091a30;
        border-radius: 8px;
        box-shadow: 0 8px 22px rgba(0, 0, 0, 0.09);
        overflow-x: auto;
        background: var(--panel-alt);
      }

      .redflag-workbench .evidence-table {
        margin: 0;
        border: 0;
        box-shadow: none;
        min-width: 560px;
      }

      .redflag-workbench .evidence-table th {
        color: #74849a;
        font-size: 11px;
        font-weight: 800;
        text-transform: uppercase;
        background: #0d1826;
      }

      .redflag-workbench .evidence-table td {
        color: #b8c3da;
        font-weight: 700;
        background: var(--panel-alt);
      }

      .redflag-workbench .evidence-table td:nth-child(2),
      .redflag-workbench .evidence-table td:nth-child(4) {
        color: #74a7e8;
        font-weight: 800;
      }

      .snapshot-list {
        display: grid;
        gap: 8px;
      }

      .flag p {
        margin: 0 0 10px;
        color: #98a5b8;
        line-height: 1.45;
      }

      .evidence,
      .preview-status {
        display: flex;
        flex-wrap: wrap;
        gap: 6px;
      }

      .report-preview {
        border: 1px solid var(--line);
        border-radius: 8px;
        overflow: hidden;
        background: var(--panel-alt);
      }

      .preview-status {
        padding: 12px;
        background: #131a20;
        border-bottom: 1px solid var(--line);
      }

      .report-section {
        padding: 12px;
        border-bottom: 1px solid var(--line);
      }

      .report-section:last-child {
        border-bottom: 0;
      }

      .report-section h4 {
        margin: 0 0 6px;
        font-size: 14px;
      }

      .report-section-drawer {
        padding: 0;
      }

      .report-section-drawer summary {
        position: relative;
        list-style: none;
        cursor: pointer;
        padding: 12px 38px 12px 12px;
      }

      .report-section-drawer summary::-webkit-details-marker {
        display: none;
      }

      .report-section-drawer summary:after {
        content: "+";
        position: absolute;
        right: 14px;
        top: 13px;
        color: var(--muted);
        font-weight: 700;
      }

      .report-section-drawer[open] summary:after {
        content: "-";
      }

      .report-section-drawer h4 {
        margin: 0;
      }

      .report-section-drawer p {
        padding: 0 12px 12px;
      }

      .report-section p {
        margin: 0;
        color: #98a5b8;
        line-height: 1.45;
      }

      .compact-finding-list {
        display: grid;
        gap: 8px;
      }

      .compact-finding {
        border: 1px solid var(--line);
        border-left: 4px solid #4c5667;
        border-radius: 8px;
        background: var(--panel-alt);
        padding: 12px;
        min-width: 0;
        box-shadow: 0 8px 18px rgba(0, 0, 0, 0.09);
      }

      .compact-finding.high {
        border-left-color: var(--danger);
        background: #2e0505;
      }

      .compact-finding.medium {
        border-left-color: var(--warn);
        background: #2e2405;
      }

      .compact-finding.low {
        border-left-color: var(--ok);
        background: #052e1a;
      }

      .compact-finding-head {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
        min-width: 0;
      }

      .compact-finding-head strong {
        color: #74a7e8;
        font-size: 12px;
        font-weight: 800;
      }

      .compact-finding h4 {
        margin: 7px 0 4px;
        font-size: 14px;
        line-height: 1.3;
        overflow-wrap: anywhere;
      }

      .compact-finding p {
        margin: 0;
        color: #8898ad;
        font-size: 13px;
        line-height: 1.4;
        overflow-wrap: anywhere;
      }

      .compact-finding-meta {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(132px, 1fr));
        gap: 6px;
        margin-top: 8px;
      }

      .field-chip {
        border: 1px solid #0d1927;
        border-radius: 7px;
        background: #131a20;
        padding: 7px 8px;
        min-width: 0;
      }

      .field-chip.value {
        background: #0d1826;
        border-color: #102238;
      }

      .field-chip.high {
        background: var(--soft-danger);
        border-color: #540900;
      }

      .field-chip.medium {
        background: var(--soft-warn);
        border-color: #754600;
      }

      .field-chip.low {
        background: var(--soft-ok);
        border-color: #285846;
      }

      .field-chip span,
      .report-compact-grid span {
        display: block;
        color: var(--muted);
        font-size: 11px;
        line-height: 1.3;
        overflow-wrap: anywhere;
      }

      .field-chip strong {
        display: block;
        margin-top: 2px;
        color: #cfd9e7;
        font-size: 12px;
        line-height: 1.3;
        overflow-wrap: anywhere;
      }

      .calculation-snapshot {
        margin-top: 9px;
        border: 1px solid #0d1927;
        border-radius: 8px;
        background: #051a2e;
        padding: 9px;
      }

      .calculation-snapshot h5 {
        margin: 0;
        color: #abb7cb;
        font-size: 12px;
      }

      .concern-panel {
        margin-top: 9px;
        border: 1px solid #0d1927;
        border-left: 4px solid #4c5667;
        border-radius: 8px;
        background: #051a2e;
        padding: 9px;
      }

      .concern-panel.high {
        border-color: #540900;
        border-left-color: var(--danger);
        background: #2e0d05;
      }

      .concern-panel.medium {
        border-color: #754600;
        border-left-color: var(--warn);
        background: #2e2005;
      }

      .concern-panel h5 {
        margin: 0 0 6px;
        color: #abb7cb;
        font-size: 12px;
      }

      .concern-panel p {
        margin: 0;
        color: #b8c3da;
        font-size: 13px;
        line-height: 1.42;
      }

      .review-checklist {
        margin-top: 9px;
        border: 1px solid #754600;
        border-radius: 8px;
        background: #2e2005;
        padding: 9px;
      }

      .review-checklist h5 {
        margin: 0 0 6px;
        color: #ffc075;
        font-size: 12px;
      }

      .review-reason {
        margin: 0 0 8px;
        color: #f7daa0;
        font-size: 13px;
        line-height: 1.4;
      }

      .review-input-list {
        display: grid;
        gap: 6px;
      }

      .review-input-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
        border: 1px solid #65450b;
        border-radius: 7px;
        background: var(--panel-alt);
        padding: 7px 8px;
      }

      .review-input-row span:first-child {
        color: #abb7cb;
        font-size: 12px;
        font-weight: 700;
        overflow-wrap: anywhere;
      }

      .finding-details {
        margin-top: 9px;
        border-top: 1px solid #121921;
        padding-top: 8px;
      }

      .finding-details summary {
        cursor: pointer;
        color: #74a7e8;
        font-size: 12px;
        font-weight: 800;
        list-style: none;
      }

      .finding-details summary::-webkit-details-marker {
        display: none;
      }

      .finding-details summary:after {
        content: "+";
        margin-left: 6px;
      }

      .finding-details[open] summary:after {
        content: "-";
      }

      .detail-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
        gap: 7px;
        margin-top: 8px;
      }

      .detail-row {
        border: 1px solid #121821;
        border-radius: 7px;
        background: var(--panel-alt);
        padding: 7px 8px;
        min-width: 0;
      }

      .detail-row span,
      .detail-row strong {
        display: block;
        overflow-wrap: anywhere;
      }

      .detail-row span {
        color: var(--muted);
        font-size: 11px;
        margin-bottom: 2px;
      }

      .detail-row strong {
        color: #b8c3da;
        font-size: 12px;
        line-height: 1.35;
      }

      .evidence-mini {
        margin-top: 10px;
      }

      .evidence-visible {
        border: 1px solid #0d1927;
        border-radius: 8px;
        background: var(--panel-alt);
        padding: 9px;
      }

      .evidence-mini h5 {
        margin: 0 0 6px;
        font-size: 12px;
        color: #abb7cb;
      }

      .report-compact-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(130px, 1fr));
        gap: 8px;
        padding: 12px;
        border-bottom: 1px solid var(--line);
      }

      .report-compact-grid div {
        border: 1px solid var(--line);
        border-radius: 8px;
        background: #131a20;
        padding: 9px;
        min-width: 0;
      }

      .report-compact-grid strong {
        display: block;
        margin-top: 3px;
        font-size: 13px;
        overflow-wrap: anywhere;
      }

      .compact-section {
        padding: 12px;
      }

      .compact-section h4 {
        margin: 0 0 8px;
        font-size: 14px;
      }

      .fraud-area-section {
        border: 1px solid #0d1927;
        border-radius: 8px;
        background: #051a2e;
        margin-bottom: 12px;
      }

      .compact-section-title {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: 12px;
        margin-bottom: 10px;
      }

      .compact-section-title h4 {
        margin: 0;
      }

      .compact-section-title span {
        color: #7a8499;
        font-size: 12px;
        line-height: 1.4;
        text-align: right;
      }

      .fraud-area-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
        gap: 10px;
      }

      .fraud-area-card {
        border: 1px solid var(--line);
        border-left: 4px solid #f68f08;
        border-radius: 8px;
        background: var(--panel-alt);
        padding: 12px;
        min-width: 0;
        box-shadow: 0 8px 18px rgba(0, 0, 0, 0.09);
      }

      .fraud-area-card.high {
        border-left-color: var(--danger);
        background: #2e0505;
      }

      .fraud-area-card.medium {
        border-left-color: var(--warn);
        background: #2e2405;
      }

      .fraud-area-head {
        display: block;
      }

      .fraud-area-head h4 {
        margin: 0 0 5px;
        color: #d8dfee;
        font-size: 14px;
        line-height: 1.25;
        overflow-wrap: anywhere;
      }

      .fraud-area-head p {
        margin: 0;
        color: #8898ad;
        font-size: 12px;
        line-height: 1.35;
      }

      .fraud-rule-list {
        display: grid;
        gap: 6px;
        margin-top: 10px;
      }

      .fraud-rule-chip {
        display: grid;
        grid-template-columns: auto minmax(0, 1fr) auto;
        align-items: center;
        gap: 8px;
        border: 1px solid #0d1927;
        border-radius: 7px;
        background: var(--panel-alt);
        padding: 7px 8px;
        min-width: 0;
      }

      .fraud-rule-chip.triggered {
        border-color: #540900;
        background: #2e0d05;
      }

      .fraud-rule-chip.review {
        border-color: #754600;
        background: #2e2005;
      }

      .fraud-rule-chip strong {
        color: #74a7e8;
        font-size: 11px;
        white-space: nowrap;
      }

      .fraud-rule-chip span {
        color: #abb7cb;
        font-size: 12px;
        line-height: 1.25;
        overflow-wrap: anywhere;
      }

      .fraud-review-focus {
        display: grid;
        gap: 4px;
        margin-top: 10px;
        border-top: 1px solid #101823;
        padding-top: 9px;
      }

      .fraud-review-focus span {
        color: #7a8499;
        font-size: 10px;
        font-weight: 800;
        letter-spacing: 0;
        text-transform: uppercase;
      }

      .fraud-review-focus strong {
        color: #b8c3da;
        font-size: 12px;
        line-height: 1.35;
        overflow-wrap: anywhere;
      }

      .timeline {
        display: grid;
        gap: 10px;
      }

      .timeline div {
        display: grid;
        grid-template-columns: 84px 1fr;
        gap: 10px;
        color: #98a5b8;
      }

      .timeline strong {
        color: var(--ink);
      }

      .assessment-app {
        min-height: 100vh;
      }

      .assessment-header {
        min-height: 76px;
        padding: 14px 24px;
        border-bottom: 1px solid var(--line);
        background: rgba(19, 23, 32, 0.96);
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 18px;
      }

      .brand-block {
        display: flex;
        align-items: center;
        gap: 12px;
      }

      .mark {
        width: 38px;
        height: 38px;
        border-radius: 6px;
        background: var(--accent);
        color: #1a1a1a;
        display: grid;
        place-items: center;
        font-weight: 700;
      }

      .brand-block h1 {
        margin: 0;
        font-size: 18px;
        line-height: 1.15;
      }

      .brand-block span {
        display: block;
        margin-top: 3px;
        color: var(--muted);
        font-size: 12px;
      }

      .header-actions {
        display: flex;
        align-items: center;
        gap: 10px;
      }

      .assessment-main {
        padding: 20px 24px 28px;
        display: grid;
        gap: 16px;
      }

      .hero-panel {
        background: var(--panel);
        border: 1px solid var(--line);
        border-radius: 8px;
        box-shadow: var(--shadow);
        padding: 18px;
        display: grid;
        grid-template-columns: minmax(420px, 1fr) minmax(320px, 0.55fr);
        gap: 18px;
      }

      .hero-copy {
        display: grid;
        align-content: center;
        gap: 10px;
      }

      .eyebrow-row {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
      }

      .hero-copy h2 {
        margin: 0;
        font-size: 28px;
        line-height: 1.15;
      }

      .hero-copy p {
        margin: 0;
        max-width: 880px;
        color: #98a5b8;
        line-height: 1.5;
      }

      .hero-meta {
        border: 1px solid #131820;
        border-radius: 8px;
        background: #0d1526;
        padding: 12px;
        display: grid;
        gap: 10px;
      }

      .hero-meta div {
        display: grid;
        gap: 4px;
      }

      .hero-meta span {
        color: var(--muted);
        font-size: 12px;
      }

      .hero-meta strong {
        overflow-wrap: anywhere;
      }

      .workflow-grid {
        display: grid;
        grid-template-columns: minmax(420px, 0.9fr) minmax(420px, 0.9fr) minmax(520px, 1.2fr);
        gap: 16px;
        align-items: start;
      }

      .config-workbench {
        padding: 0 22px 26px;
        display: grid;
        grid-template-columns: minmax(520px, 1fr) minmax(520px, 1fr);
        gap: 16px;
        min-width: 0;
      }

      .config-workbench .full-panel {
        grid-column: 1 / -1;
      }

      .config-guide {
        display: grid;
        grid-template-columns: repeat(4, minmax(180px, 1fr));
        gap: 10px;
      }

      .guide-card {
        border: 1px solid var(--line);
        border-radius: 8px;
        background: #131a20;
        padding: 12px;
        min-height: 122px;
      }

      .guide-card h4 {
        margin: 0 0 8px;
        font-size: 14px;
      }

      .guide-card p {
        margin: 0;
        color: #98a5b8;
        line-height: 1.45;
        font-size: 13px;
      }

      .config-editor {
        display: grid;
        gap: 14px;
      }

      .friendly-config-fields {
        border: 1px solid #152d40;
        border-radius: 8px;
        background: linear-gradient(180deg, #05192e 0%, var(--panel-alt) 100%);
        padding: 14px;
        display: grid;
        gap: 12px;
      }

      .friendly-field-head {
        display: grid;
        gap: 4px;
      }

      .friendly-field-head h4 {
        margin: 0;
        font-size: 15px;
      }

      .friendly-field-head p {
        margin: 0;
        color: #98a5b8;
        line-height: 1.45;
      }

      .friendly-field-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
        gap: 10px;
      }

      .friendly-field-grid.single-grid {
        grid-template-columns: minmax(220px, 360px);
      }

      .friendly-field-grid.scoring-grid {
        grid-template-columns: repeat(3, minmax(180px, 1fr));
      }

      .friendly-field-grid.profile-rule-grid {
        grid-template-columns: minmax(180px, 260px) minmax(220px, 280px);
      }

      .quick-field {
        align-content: start;
      }

      .quick-input {
        min-height: 38px;
        border: 1px solid #1d2430;
        border-radius: 6px;
        padding: 8px 10px;
      }

      .config-form-grid,
      .config-json-grid {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 12px;
      }

      .config-action-row {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 10px;
        padding: 12px;
        border: 1px solid #0d1927;
        border-radius: 8px;
        background: #131a20;
      }

      .config-save-result {
        flex: 1 1 280px;
        min-width: 0;
      }

      .advanced-toggle-panel {
        border: 1px solid #0d1927;
        border-radius: 8px;
        background: var(--panel-alt);
        padding: 12px;
        display: grid;
        grid-template-columns: minmax(220px, 1fr) auto;
        align-items: center;
        gap: 12px;
      }

      .advanced-toggle-copy {
        display: grid;
        gap: 3px;
      }

      .advanced-toggle-copy strong {
        color: #cfd9e7;
        font-size: 14px;
      }

      .advanced-toggle-copy span {
        color: var(--muted);
        font-size: 12px;
        line-height: 1.35;
      }

      .advanced-toggle-list {
        display: flex;
        flex-wrap: wrap;
        justify-content: flex-end;
        gap: 8px;
      }

      .advanced-toggle-item {
        min-height: 32px;
        border: 1px solid #1d2430;
        border-radius: 999px;
        background: #14191f;
        color: #abb7cb;
        padding: 6px 10px;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        font-size: 12px;
        font-weight: 800;
        cursor: pointer;
      }

      .advanced-toggle-item input {
        width: 14px;
        height: 14px;
        accent-color: var(--accent);
      }

      .readonly-box {
        min-height: 38px;
        border: 1px solid #1d2430;
        border-radius: 6px;
        background: #14191f;
        padding: 9px 10px;
        color: #98a5b8;
        overflow-wrap: anywhere;
      }

      .json-textarea {
        width: 100%;
        min-height: 310px;
        border: 1px solid #1d2430;
        border-radius: 6px;
        padding: 10px;
        font-family: Consolas, "Courier New", monospace;
        font-size: 12px;
        line-height: 1.45;
        resize: vertical;
      }

      .config-meta-grid {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 10px;
      }

      .config-meta-grid div {
        border: 1px solid #121821;
        border-radius: 8px;
        background: #131a20;
        padding: 10px;
        min-height: 66px;
      }

      .config-meta-grid span {
        display: block;
        color: var(--muted);
        font-size: 12px;
        margin-bottom: 5px;
      }

      .config-meta-grid strong {
        display: block;
        font-size: 13px;
        line-height: 1.35;
        overflow-wrap: anywhere;
      }

      .status-tags {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 7px;
        margin-bottom: 10px;
      }

      .json-error-text {
        color: var(--danger);
        font-size: 12px;
        font-weight: 700;
      }

      .sql-output {
        min-height: 424px;
        max-height: 620px;
        overflow: auto;
        margin: 0;
        border-radius: 8px;
        background: #0f172a;
        color: #dbeafe;
        padding: 14px;
        white-space: pre-wrap;
        font-family: Consolas, "Courier New", monospace;
        font-size: 12px;
        line-height: 1.5;
      }

      .future-config-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(285px, 1fr));
        gap: 12px;
      }

      .future-config-tile {
        position: relative;
        min-height: 150px;
        border: 1px solid #0d1826;
        border-radius: 8px;
        background: linear-gradient(180deg, var(--panel-alt) 0%, #05172e 100%);
        padding: 14px 14px 14px 18px;
        display: grid;
        grid-template-columns: 86px minmax(0, 1fr);
        gap: 14px;
        align-items: start;
        overflow: visible;
      }

      .future-config-tile:before {
        content: "";
        position: absolute;
        inset: 0 auto 0 0;
        width: 4px;
        background: #6591d0;
      }

      .future-config-tile.scoring:before,
      .future-config-tile.thresholds:before {
        background: #95e9e1;
      }

      .future-config-tile.runtime:before,
      .future-config-tile.requests:before,
      .future-config-tile.connectors:before {
        background: #ffb648;
      }

      .future-config-tile.evidence:before,
      .future-config-tile.synonyms:before,
      .future-config-tile.zero:before {
        background: #6b3db3;
      }

      .future-tile-icon {
        width: 76px;
        min-height: 34px;
        border: 1px solid #0f1d32;
        border-radius: 999px;
        background: #0d1826;
        color: #6591d0;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 11px;
        font-weight: 800;
        text-align: center;
        line-height: 1.15;
        padding: 6px 8px;
        overflow-wrap: anywhere;
        white-space: normal;
      }

      .future-tile-copy {
        display: grid;
        align-content: start;
        gap: 7px;
        min-width: 0;
      }

      .future-tile-copy h4 {
        margin: 0;
        color: #cfd9e7;
        font-size: 15px;
        line-height: 1.25;
      }

      .future-tile-copy p {
        margin: 0;
        color: #98a5b8;
        font-size: 13px;
        line-height: 1.45;
      }

      .panel {
        background: linear-gradient(180deg, var(--panel-alt) 0%, var(--panel) 100%);
        border: 1px solid var(--line);
        border-radius: var(--radius-lg);
        box-shadow: var(--shadow);
        min-width: 0;
        animation: fsre-fade-up 0.32s var(--ease) both;
      }

      .queue-panel {
        grid-row: span 2;
      }

      .panel-header {
        min-height: 50px;
        padding: 14px 16px;
        border-bottom: 1px solid var(--line);
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
      }

      .panel-header h3 {
        margin: 0;
        font-size: 15px;
      }

      .panel-actions {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        flex: 0 0 auto;
      }

      .button.compact {
        min-height: 30px;
        padding: 0 10px;
        font-size: 12px;
      }

      .panel-body {
        padding: 16px;
      }

      .table-body {
        padding: 0;
      }

      .queue-refresh-status {
        padding: 0 16px 14px;
      }

      .compact-message {
        margin: 0;
        font-size: 12px;
      }

      .upload-box {
        min-height: 190px;
        border: 2px dashed #37414f;
        border-radius: var(--radius-lg);
        background: var(--bg-elevated);
        display: grid;
        place-items: center;
        text-align: center;
        cursor: pointer;
        padding: 22px;
        transition: border-color 0.18s var(--ease), background 0.18s var(--ease), transform 0.18s var(--ease);
      }

      .upload-box:hover {
        border-color: var(--accent);
        background: var(--accent-soft);
        transform: translateY(-1px);
      }

      .upload-box strong {
        display: block;
        font-size: 20px;
        margin-bottom: 7px;
      }

      .upload-box span {
        display: block;
        color: var(--accent);
        font-weight: 700;
        margin-bottom: 8px;
      }

      .upload-box small {
        display: block;
        color: var(--muted);
        max-width: 440px;
        line-height: 1.4;
      }

      .fast-upload-form {
        gap: 14px;
      }

      .fast-upload-input {
        max-width: 100%;
        border: 1px solid #171d27;
        border-radius: 6px;
        background: var(--panel-alt);
        padding: 9px;
      }

      .fast-upload-button {
        min-width: 130px;
      }

      .upload-fallback {
        margin-top: 10px;
        border: 1px solid var(--line);
        border-radius: 8px;
        background: #131a20;
        overflow: hidden;
      }

      .upload-fallback summary {
        cursor: pointer;
        list-style: none;
        padding: 10px 12px;
        color: #74a7e8;
        font-size: 12px;
        font-weight: 800;
      }

      .upload-fallback summary::-webkit-details-marker {
        display: none;
      }

      .fallback-upload-box {
        min-height: 120px;
        border-width: 1px;
        border-radius: 0;
      }

      .button {
        border: 0;
        border-radius: var(--radius-sm);
        min-height: 36px;
        padding: 0 16px;
        cursor: pointer;
        font-weight: 700;
        white-space: nowrap;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        transition: transform 0.14s var(--ease), box-shadow 0.14s var(--ease), background 0.14s var(--ease), border-color 0.14s var(--ease);
      }

      .button:active { transform: translateY(1px) scale(0.99); }

      .button.primary {
        background: linear-gradient(135deg, var(--accent-strong), var(--accent));
        color: #17110f;
        box-shadow: 0 6px 18px rgba(255, 91, 77, 0.28);
      }

      .button.primary:hover {
        transform: translateY(-1px);
        box-shadow: 0 10px 26px rgba(255, 91, 77, 0.38);
      }

      .button.secondary {
        background: var(--panel-hover);
        border: 1px solid var(--line);
        color: var(--ink);
      }

      .button.secondary:hover {
        border-color: rgba(255, 255, 255, 0.22);
        transform: translateY(-1px);
      }

      .run-button {
        width: 100%;
        min-height: 48px;
        background: linear-gradient(135deg, var(--accent-strong), var(--accent));
        color: #17110f;
        margin-top: 12px;
        font-size: 15px;
        box-shadow: 0 10px 26px rgba(255, 91, 77, 0.3);
      }

      .run-button:hover {
        transform: translateY(-1px);
        box-shadow: 0 14px 32px rgba(255, 91, 77, 0.4);
      }

      .run-copy h4 {
        margin: 0 0 6px;
        font-size: 16px;
      }

      .run-copy p {
        margin: 0;
        color: var(--muted);
        line-height: 1.45;
      }

      .tag {
        display: inline-flex;
        align-items: center;
        min-height: 24px;
        padding: 0 10px;
        border-radius: 999px;
        background: var(--panel-hover);
        border: 1px solid var(--line-soft);
        color: var(--muted);
        font-size: 11.5px;
        font-weight: 700;
        letter-spacing: 0.2px;
        white-space: nowrap;
      }

      .tag.high { background: var(--soft-danger); color: var(--danger); border-color: rgba(242, 99, 90, 0.3); }
      .tag.medium { background: var(--soft-warn); color: var(--warn); border-color: rgba(245, 166, 35, 0.3); }
      .tag.low { background: var(--soft-ok); color: var(--ok); border-color: rgba(47, 217, 125, 0.3); }
      .tag.info { background: var(--soft-blue); color: var(--blue); border-color: rgba(77, 155, 245, 0.3); }

      .status-box {
        margin-top: 12px;
        display: grid;
        gap: 6px;
      }

      .message {
        border: 1px solid #171d27;
        background: var(--panel-alt);
        border-radius: 6px;
        padding: 9px 10px;
        color: #98a5b8;
        overflow-wrap: anywhere;
      }

      .message.ok { border-color: #285846; background: var(--soft-ok); color: var(--ok); }
      .message.warn { border-color: #754600; background: var(--soft-warn); color: var(--warn); }
      .message.error { border-color: #540900; background: var(--soft-danger); color: var(--danger); }
      .message.summary { background: #0d1826; border-color: #172948; color: var(--blue); font-weight: 700; }

      .upload-progress-card {
        border: 1px solid #285846;
        background: #052e1a;
        border-radius: 8px;
        padding: 11px;
        display: grid;
        gap: 8px;
      }

      .upload-progress-head {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
      }

      .upload-progress-head strong {
        overflow-wrap: anywhere;
      }

      .progress-bar {
        height: 9px;
        border-radius: 999px;
        background: var(--line);
        overflow: hidden;
      }

      .progress-fill {
        height: 100%;
        border-radius: inherit;
        background: linear-gradient(90deg, var(--accent), var(--accent-strong));
        box-shadow: 0 0 10px rgba(255, 91, 77, 0.5);
        transition: width 0.35s var(--ease);
      }

      .progress-bar.complete .progress-fill {
        animation: uploadComplete 0.7s ease-out;
      }

      .upload-progress-meta {
        color: var(--muted);
        font-size: 12px;
        overflow-wrap: anywhere;
      }

      @keyframes uploadComplete {
        from { width: 18%; }
        to { width: 100%; }
      }

      .report-switcher {
        border: 1px solid var(--line);
        border-radius: 8px;
        background: #0d1526;
        overflow: hidden;
      }

      .report-switcher summary {
        position: relative;
        list-style: none;
        cursor: pointer;
        padding: 12px 14px;
        display: grid;
        gap: 4px;
      }

      .report-switcher summary::-webkit-details-marker {
        display: none;
      }

      .report-switcher summary:after {
        content: "+";
        position: absolute;
        right: 16px;
        top: 17px;
        color: var(--muted);
        font-weight: 700;
      }

      .report-switcher[open] summary:after {
        content: "-";
      }

      .report-switcher summary span {
        color: var(--muted);
        font-size: 12px;
        text-transform: uppercase;
      }

      .report-switcher summary strong {
        font-size: 15px;
        padding-right: 24px;
      }

      .report-switcher-body {
        display: grid;
        gap: 10px;
        padding: 0 12px 12px;
      }

      .report-switcher-summary {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 8px;
      }

      .report-switcher-summary div {
        border: 1px solid #101823;
        border-radius: 8px;
        background: var(--panel-alt);
        padding: 9px 10px;
      }

      .report-switcher-summary span,
      .report-switcher-summary strong {
        display: block;
      }

      .report-switcher-summary span {
        color: var(--muted);
        font-size: 12px;
      }

      .file-table {
        width: 100%;
        border-collapse: collapse;
        table-layout: fixed;
      }

      .file-table th,
      .file-table td {
        padding: 11px 12px;
        border-bottom: 1px solid var(--line);
        text-align: left;
        vertical-align: top;
        overflow-wrap: anywhere;
      }

      .file-table th {
        color: var(--muted);
        font-size: 12px;
        background: #14191f;
      }

      .file-table td small {
        display: block;
        margin-top: 4px;
        color: var(--muted);
        font-size: 11px;
      }

      .step {
        position: relative;
        padding: 9px 0 9px 26px;
        color: #98a5b8;
      }

      .step:before {
        content: "";
        position: absolute;
        left: 4px;
        top: 14px;
        width: 10px;
        height: 10px;
        border-radius: 50%;
        background: var(--ok);
      }

      .empty-state {
        min-height: 120px;
        display: grid;
        place-items: center;
        color: var(--muted);
      }

      @media (max-width: 1320px) {
        .workflow-grid {
          grid-template-columns: minmax(420px, 1fr) minmax(420px, 1fr);
        }
        .config-workbench,
        .config-guide {
          grid-template-columns: 1fr;
        }
        .queue-panel {
          grid-column: 1 / -1;
          grid-row: auto;
        }
        .hero-panel {
          grid-template-columns: 1fr;
        }
        .risk-insight-grid {
          grid-template-columns: 1fr;
        }
      }

      @media (max-width: 860px) {
        .app {
          grid-template-columns: 1fr;
        }
        .main {
          grid-template-rows: auto 1fr;
        }
        .topbar {
          min-height: 104px;
          padding: 14px 16px;
          align-items: stretch;
          flex-direction: column;
        }
        .risk-hero {
          grid-template-columns: 1fr;
        }
        .risk-score-strip {
          grid-template-columns: repeat(3, minmax(0, 1fr));
        }
        .status-strip {
          flex-wrap: wrap;
        }
        .workspace {
          grid-template-columns: 1fr;
          padding: 14px;
        }
        .config-workbench {
          grid-template-columns: 1fr;
          padding: 0 14px 18px;
        }
        .config-form-grid,
        .config-json-grid,
        .friendly-field-grid,
        .config-meta-grid,
        .setup-meta,
        .kpi-grid {
          grid-template-columns: 1fr;
        }
        .advanced-toggle-panel {
          grid-template-columns: 1fr;
        }
        .advanced-toggle-list {
          justify-content: flex-start;
        }
        .trigger-summary-card summary,
        .flag-disclosure summary {
          grid-template-columns: 1fr;
        }
        .redflag-workbench-head,
        .redflag-detail-header {
          flex-direction: column;
        }
        .redflag-status-stack {
          justify-content: flex-start;
          grid-template-columns: 1fr;
          min-width: 0;
        }
        .redflag-detail-screen,
        .redflag-detail-header {
          padding: 12px;
        }
        .redflag-detail-header h4 {
          font-size: 19px;
        }
        .summary-metrics,
        .flag-summary-meta {
          justify-content: flex-start;
          max-width: none;
        }
        .summary-metrics {
          grid-template-columns: 1fr;
        }
        .trigger-summary-body,
        .flag-detail-panel,
        .redflag-focus-grid,
        .explain-grid {
          grid-template-columns: 1fr;
        }
        .assessment-header {
          flex-direction: column;
          align-items: stretch;
        }
        .header-actions {
          align-items: stretch;
          flex-direction: column;
        }
        .workflow-grid {
          grid-template-columns: 1fr;
        }
        .hero-copy h2 {
          font-size: 22px;
        }
      }

      /* Final cascade layer keeps the light theme authoritative over legacy component rules. */
      .app { grid-template-columns: 252px minmax(0, 1fr); }
      .sidebar {
        background: linear-gradient(180deg, #ffffff, #f4f8fc);
        color: var(--ink);
        border-right: 1px solid var(--line);
        box-shadow: 8px 0 28px rgba(30,55,84,.06);
      }
      .brand h1, .brand h1 span, .sidebar strong { color: var(--ink); }
      .company-logo { background: #fff; border-color: var(--line); }
      .nav a { color: #42536a; border-color: transparent; }
      .nav a:hover { color: var(--accent); background: #edf6ff; border-color: #c9ddeb; }
      .nav a.active { color: #0f4f88; background: #e8f3fc; border-color: #b9d5e9; box-shadow: none; }
      .nav a > span:first-child { background: #fff; color: var(--accent); border: 1px solid #bfd6ea; }
      .company-switcher, .company-card, .sidebar-footer {
        background: #fff;
        color: var(--ink);
        border-color: var(--line);
      }
      .company-switcher summary span, .company-card span, .sidebar-footer { color: var(--muted); }
      .company-card.active { background: #edf6ff; border-color: #b9d5e9; }
      .topbar { background: rgba(255,255,255,.92); border-color: var(--line); }
      .workspace { grid-template-columns: repeat(2, minmax(360px, 1fr)); max-width: 1540px; width: 100%; margin: 0 auto; }
      .column.results { grid-column: 1 / -1; grid-template-columns: repeat(2, minmax(0, 1fr)); }
      .column.results > .risk-panel { grid-column: 1 / -1; }
      .panel, .risk-insight { background: var(--panel); border-color: var(--line); box-shadow: var(--shadow); }
      .panel-header { background: linear-gradient(180deg, #fff, #fbfcfe); border-color: var(--line); }
      .button.secondary { background: #fff; color: var(--ink); border-color: var(--line); }
      .button.primary, .run-button { background: linear-gradient(135deg, var(--accent-strong), var(--accent)); color: #fff; }
      .risk-panel { width: min(1180px, 100%); justify-self: center; }
      .risk-hero { background: linear-gradient(135deg, #f9fbfe, #eef5fb); border-color: #cfdae7; }
      .risk-board.risk .risk-hero { background: linear-gradient(135deg, #fff4f5, #fff); border-color: #efc2c7; }
      .risk-board.warn .risk-hero { background: linear-gradient(135deg, #fff9ec, #fff); border-color: #ecd6ad; }
      .risk-board.ok .risk-hero { background: linear-gradient(135deg, #effaf5, #fff); border-color: #bcded0; }
      .risk-score-strip div, .risk-chip, .risk-overflow-list, .risk-empty { background: rgba(255,255,255,.9); border-color: var(--line); }
      .risk-score-strip strong, .risk-insight-head strong, .risk-chip { color: var(--ink); }
      .risk-insight.risk { border-color: #efc2c7; background: #fff7f8; }
      .risk-insight.warn { border-color: #ecd6ad; background: #fffbf2; }
      .risk-insight.info { border-color: #bfd6ea; background: #f5faff; }
      input, select, textarea, .Select-control, .Select-menu-outer, .Select-menu,
      .upload-box, .fast-upload-input, .upload-fallback, .report-switcher,
      .report-switcher-summary div, .hero-meta, .guide-card, .message,
      .advanced-toggle-panel, .config-form-card, .config-json-card,
      .trigger-summary-card, .flag-disclosure, .side-block,
      .redflag-detail-screen, .redflag-detail-header, .redflag-drawer,
      .calculation-card, .evidence-record, .evidence-record-header,
      .evidence-record-meta > div, .evidence-raw-value {
        background: #fff !important;
        color: var(--ink) !important;
        border-color: var(--line) !important;
      }
      .Select-value-label, .Select-placeholder, .Select-input input,
      .Select-option, label, td, th, h1, h2, h3, h4, h5, strong { color: var(--ink); }
      .Select-option.is-focused, .Select-option:hover { background: #edf6ff; color: var(--ink); }
      .Select-option.is-selected { background: #dfeefa; color: #0f4f88; }
      .file-table th, .result-table th { background: #f4f7fb; color: #53647a; }
      .file-table tr:hover td, .result-table tr:hover td { background: #f8fbfe; }
      .tag { background: #f4f7fb; border-color: var(--line-soft); color: var(--muted); }
      .evidence-modal-backdrop { background: rgba(45,66,89,.32); }
      .evidence-modal-panel, .evidence-modal-toolbar, .evidence-modal-content,
      .risk-fullscreen-panel, .risk-fullscreen-header, .risk-fullscreen-content {
        background: #f7f9fc !important;
        color: var(--ink);
        border-color: var(--line);
      }
      .evidence-modal-toolbar, .risk-fullscreen-header { background: #fff !important; }

      /* Hard light-mode guard: no legacy black/navy surface may leak through. */
      html, body, #react-entry-point, .app, .main, .workspace,
      .main section, .main article, .main details, .main summary, .main pre,
      .main div:not(.progress-fill):not(.status-dot) {
        background-color: #ffffff !important;
        background-image: none !important;
      }
      body, .workspace, .main { background-color: #f4f7fb !important; }
      .topbar, .panel, .panel-header, .risk-fullscreen-header,
      .evidence-modal-toolbar, .evidence-modal-content { background-color: #fff !important; }
      .risk-board.risk .risk-hero, .risk-insight.risk, .tag.high,
      .compact-finding.high, .message.error { background-color: #fff1f2 !important; }
      .risk-board.warn .risk-hero, .risk-insight.warn, .tag.medium,
      .compact-finding.medium, .message.warn { background-color: #fff8e8 !important; }
      .risk-board.ok .risk-hero, .tag.low, .compact-finding.low,
      .message.ok, .upload-progress-card { background-color: #edf9f4 !important; }
      .risk-insight.info, .tag.info, .field-chip.value, .message.summary,
      .selected-report-card, .section-purpose { background-color: #edf6ff !important; }
      .section-purpose.investigation { background-color: #fffbf2 !important; }
      .risk-fullscreen-backdrop, .evidence-modal-backdrop {
        background-color: rgba(60, 79, 99, .28) !important;
        background-image: none !important;
      }
      pre, code, .config-code, .json-preview {
        background: #f2f5f9 !important;
        color: #26364a !important;
        border-color: var(--line) !important;
      }
      .panel-header > div { min-width: 0; }
      .panel-header h3 { margin: 0; }
      .panel-header small { display: block; margin-top: 3px; color: var(--muted); font-size: 11px; font-weight: 600; }
      .triggered-panel { grid-column: 1 / -1; }
      .redflag-panel, .top-findings-panel { grid-column: span 1; min-width: 0; }
      .preview-panel { grid-column: 1 / -1; }
      .post-workbench-section {
        width: 100%; max-width: 1540px; margin: 0 auto; padding: 0 26px 26px;
      }
      .post-workbench-section .panel { width: 100%; }
      .uploaded-reports-final { padding-bottom: 34px; }
      .section-purpose {
        display: grid; gap: 4px; margin: 16px; padding: 13px 15px;
        border: 1px solid #bfd6ea; border-radius: 10px; background: #f5faff;
      }
      .section-purpose strong { color: #174f7e; font-size: 13px; }
      .section-purpose span { color: var(--muted); font-size: 12px; line-height: 1.45; }
      .section-purpose.investigation { margin: 0 0 14px; border-color: #ecd6ad; background: #fffbf2; }
      .section-purpose.investigation strong { color: #80500d; }
      .table-scroll { width: 100%; overflow-x: auto; }
      .triggered-result-table { min-width: 800px; }
      .triggered-result-table th:nth-child(1) { width: 14%; }
      .triggered-result-table th:nth-child(2) { width: 38%; }
      .triggered-result-table th:nth-child(3) { width: 15%; }
      .triggered-result-table th:nth-child(4) { width: 11%; }
      .triggered-result-table th:nth-child(5) { width: 13%; }
      .triggered-result-table th:nth-child(6) { width: 9%; }
      .triggered-result-table td { vertical-align: middle; color: var(--ink); }
      .triggered-result-table td small { display: block; margin-top: 4px; color: var(--muted); }
      .table-footnote { padding: 10px 16px 14px; color: var(--muted); font-size: 11px; }
      .redflag-investigation-workbench { padding: 0; }

      /* Uploaded reports: explicit high-contrast light treatment. */
      .queue-panel .report-switcher {
        background: #ffffff !important;
        border: 1px solid #cbd8e6 !important;
        border-radius: 12px;
        box-shadow: 0 5px 16px rgba(30,55,84,.07);
      }
      .queue-panel .report-switcher > summary {
        min-height: 70px;
        padding: 14px 48px 14px 16px;
        background: #f7faff !important;
        background-image: none !important;
        border-bottom: 1px solid #dce5ef;
      }
      .queue-panel .report-switcher > summary span {
        color: #587089 !important;
        font-size: 11px;
        font-weight: 800;
        letter-spacing: .07em;
      }
      .queue-panel .report-switcher > summary strong {
        color: #172033 !important;
        font-size: 16px;
        font-weight: 800;
        line-height: 1.35;
      }
      .queue-panel .report-switcher > summary::after {
        top: 21px;
        color: #1768ac !important;
        font-size: 20px;
      }
      .queue-panel .report-switcher-body,
      .queue-panel .report-switcher-summary,
      .queue-panel .report-switcher-summary > div {
        background: #ffffff !important;
        color: #172033 !important;
      }
      .queue-panel .queue-refresh-status { padding: 12px 0 0; }
      .queue-panel .queue-refresh-status .message.summary {
        margin: 0;
        padding: 11px 13px;
        background: #edf6ff !important;
        color: #155b91 !important;
        border: 1px solid #bdd8ec !important;
        border-radius: 9px;
        font-weight: 700;
        line-height: 1.45;
      }

      /* Light corporate blue identity: blue accents without dark surfaces. */
      body, .workspace, .main { background-color: #eef5fb !important; }
      .sidebar {
        background: linear-gradient(180deg, #f3f8fd, #e7f1fa) !important;
        border-right: 1px solid #bfd3e5;
      }
      .topbar {
        background: #f7fbff !important;
        border-bottom-color: #c7d9e8;
      }
      .panel { border-color: #c9d9e7; }
      .panel-header {
        background: #f0f7fd !important;
        border-bottom-color: #c9d9e7;
      }
      .panel-header h3 { color: #123f68; }
      .nav a.active {
        background: #dcecf8 !important;
        color: #0f4f88;
        border-color: #aecaE1;
      }
      .nav a:hover { background: #e7f2fb !important; }
      .button.primary, .run-button {
        background: linear-gradient(135deg, #0f4f88, #2378b9) !important;
        color: #ffffff !important;
      }
      .button.secondary {
        background: #f3f8fd !important;
        color: #174f7e;
        border-color: #b8d0e4;
      }
      .tag.info, .message.summary, .selected-report-card,
      .section-purpose, .risk-insight.info, .field-chip.value {
        background: #e6f2fb !important;
        color: #155b91 !important;
        border-color: #b9d7eb !important;
      }
      .queue-panel .report-switcher > summary { background: #edf6fd !important; }
      .queue-panel .queue-refresh-status .message.summary { background: #e2f1fc !important; }

      /* Advanced visual system: clearer hierarchy, depth and data readability. */
      .panel {
        border-radius: 16px;
        box-shadow: 0 10px 30px rgba(25, 71, 110, .09);
        overflow: hidden;
      }
      .panel-header { min-height: 62px; padding: 16px 20px; }
      .panel-header h3 { font-size: 17px; letter-spacing: -.015em; }
      .panel-body { padding: 20px; }

      .brand { gap: 14px; padding: 4px 8px 8px; }
      .company-logo {
        width: 100%; max-width: 162px; min-height: 62px; padding: 14px;
        border-radius: 13px; box-shadow: 0 8px 22px rgba(20,61,96,.13);
      }
      .brand h1 { font-size: 14px; line-height: 1.1; letter-spacing: -.01em; }
      .brand h1 span + span { margin-top: 7px; color: #71839a; font-size: 12px; font-weight: 600; }
      .nav { gap: 7px; }
      .nav a {
        min-height: 48px; padding: 8px 11px; border-radius: 11px;
        font-size: 14px; font-weight: 650; transition: all .18s ease;
      }
      .nav a > span:first-child {
        width: 29px; height: 29px; border-radius: 8px; display: inline-grid; place-items: center;
        box-shadow: 0 2px 5px rgba(23,104,172,.08);
      }
      .nav a.active { box-shadow: inset 3px 0 0 #1768ac, 0 5px 13px rgba(23,104,172,.08); }
      .company-switcher { border-radius: 12px; box-shadow: 0 6px 18px rgba(25,71,110,.06); }
      .sidebar-footer { border-radius: 12px; line-height: 1.55; }

      .selected-rule-summary {
        grid-template-columns: repeat(5, minmax(116px, 1fr));
        gap: 10px; margin-top: 15px;
      }
      .summary-chip {
        min-height: 76px; padding: 13px 14px; border-radius: 11px;
        background: #f8fbfe !important; border: 1px solid #cbdbea !important;
        box-shadow: 0 4px 12px rgba(25,71,110,.05);
      }
      .summary-chip span { color: #60758e !important; font-size: 11px; font-weight: 750; text-transform: uppercase; letter-spacing: .04em; }
      .summary-chip strong { margin-top: 7px; color: #132a43 !important; font-size: 22px; line-height: 1; }
      .summary-chip.risk { background: #fff3f4 !important; border-color: #edb9bf !important; }
      .summary-chip.warn { background: #fff9ed !important; border-color: #ead09f !important; }
      .summary-chip.info { background: #edf6ff !important; border-color: #b9d7eb !important; }

      .compact-finding-list { gap: 18px; }
      .compact-finding {
        padding: 18px; border: 1px solid #cedbe8; border-left-width: 5px;
        border-radius: 13px; box-shadow: 0 8px 22px rgba(25,71,110,.07);
      }
      .compact-finding-head { padding-bottom: 10px; border-bottom: 1px solid rgba(112,139,165,.18); }
      .compact-finding-head strong { color: #1768ac !important; font-size: 12px; letter-spacing: .03em; }
      .compact-finding h4 { margin: 12px 0 7px; color: #132238 !important; font-size: 17px; line-height: 1.3; }
      .compact-finding > p { color: #526a84 !important; font-size: 14px; line-height: 1.5; }
      .compact-finding-meta { grid-template-columns: repeat(auto-fit, minmax(170px, 1fr)); gap: 9px; }
      .field-chip {
        min-height: 72px; padding: 11px 12px; border: 1px solid #c8d7e5 !important;
        border-radius: 10px; background: #f8fbfe !important;
      }
      .field-chip span { color: #61758d !important; font-size: 11px; font-weight: 700; }
      .field-chip strong { margin-top: 5px; color: #253b53 !important; font-size: 13px; line-height: 1.4; font-weight: 750; }
      .field-chip.value { background: #eaf5fd !important; border-color: #acd3ed !important; }
      .field-chip.high { background: #fff2f3 !important; border-color: #e9b4ba !important; }
      .field-chip.medium { background: #fff9ec !important; border-color: #e7cb93 !important; }
      .field-chip.low { background: #eef9f4 !important; border-color: #abd8c8 !important; }
      .calculation-snapshot, .concern-panel, .review-checklist {
        margin-top: 13px; padding: 14px; border-radius: 11px;
        background: #f8fbfe !important; border: 1px solid #cfdeea !important;
      }
      .calculation-snapshot h5, .concern-panel h5, .review-checklist h5 {
        color: #35536f !important; font-size: 12px; font-weight: 800;
      }
      .concern-panel p, .detail-grid span { color: #526a84 !important; }
      .detail-grid strong { color: #253b53 !important; }
      .review-checklist { background: #fffaf0 !important; border-color: #e7cb93 !important; }

      .status-tag, .tag {
        min-height: 27px; padding: 4px 11px; border-radius: 999px;
        font-weight: 800; letter-spacing: .01em;
      }
      .button { border-radius: 9px; min-height: 40px; font-weight: 750; }
      .button:hover { transform: translateY(-1px); box-shadow: 0 7px 16px rgba(23,104,172,.13); }

      @media (max-width: 1250px) {
        .selected-rule-summary { grid-template-columns: repeat(3, minmax(116px, 1fr)); }
      }
      @media (max-width: 1100px) {
        .workspace { grid-template-columns: 1fr; }
        .column.results { grid-column: auto; grid-template-columns: 1fr; }
        .column.results > .risk-panel { grid-column: auto; }
      }
      @media (max-width: 860px) { .app { grid-template-columns: 1fr; } }
      @media (max-width: 620px) {
        .selected-rule-summary { grid-template-columns: repeat(2, minmax(0, 1fr)); }
        .compact-finding-meta { grid-template-columns: 1fr; }
      }

      /* Enterprise section language and final legacy-surface cleanup. */
      .panel-header h3,
      .compact-section-title h4,
      .calculation-snapshot h5,
      .concern-panel h5,
      .review-checklist h5,
      .evidence-mini h5 {
        position: relative;
        padding-left: 14px;
      }
      .panel-header h3::before,
      .compact-section-title h4::before,
      .calculation-snapshot h5::before,
      .concern-panel h5::before,
      .review-checklist h5::before,
      .evidence-mini h5::before {
        content: "";
        position: absolute;
        left: 0;
        top: 12%;
        width: 4px;
        height: 76%;
        border-radius: 999px;
        background: linear-gradient(180deg, #2f8dcb, #0f4f88);
        box-shadow: 0 0 0 3px rgba(47,141,203,.1);
      }
      .panel-header h3 { font-weight: 800; }
      .compact-section-title h4 { color: #123f68 !important; font-size: 16px; font-weight: 800; }
      .compact-section-title span { color: #60758e !important; }

      .risk-dashboard .message,
      #risk-dashboard .message,
      #triggered-rule-summary .message,
      #red-flag-details .message {
        padding: 11px 14px;
        border-radius: 9px;
        box-shadow: none;
        font-weight: 700;
      }
      #risk-dashboard .message.summary,
      #triggered-rule-summary .message.summary,
      #red-flag-details .message.summary {
        background: #e8f4fd !important;
        color: #155b91 !important;
        border: 1px solid #b7d7ec !important;
      }
      #risk-dashboard .message.warn,
      #triggered-rule-summary .message.warn,
      #red-flag-details .message.warn {
        background: #fff8e8 !important;
        color: #8b570f !important;
        border: 1px solid #e8cd96 !important;
      }
      .fraud-area-section {
        margin: 14px 0 !important;
        padding: 16px !important;
        background: #f5f9fd !important;
        border: 1px solid #c4d8e8 !important;
        border-radius: 13px;
        box-shadow: 0 7px 20px rgba(25,71,110,.06);
      }
      .fraud-area-grid { gap: 14px; }
      .fraud-area-card {
        padding: 15px;
        background: #ffffff !important;
        border: 1px solid #ccdae7 !important;
        border-left: 5px solid #cc8a23 !important;
        border-radius: 12px;
        box-shadow: 0 6px 16px rgba(25,71,110,.06);
      }
      .fraud-area-card.high { background: #fff5f6 !important; border-left-color: #c63f4b !important; }
      .fraud-area-card.medium { background: #fffaf0 !important; border-left-color: #b27618 !important; }
      .fraud-area-head h4 { color: #18324c !important; font-size: 15px; font-weight: 800; }
      .fraud-area-head p { color: #5b7088 !important; font-size: 13px; line-height: 1.45; }
      .fraud-rule-chip {
        background: #fff !important;
        border: 1px solid #cbd9e6 !important;
        border-radius: 9px;
      }
      .fraud-rule-chip.triggered { background: #fff0f2 !important; border-color: #e8b1b7 !important; }
      .fraud-rule-chip.review { background: #fff8e8 !important; border-color: #e7c98e !important; }
      .fraud-rule-chip strong { color: #1768ac !important; }
      .fraud-rule-chip span, .fraud-review-focus strong { color: #405972 !important; }
      .fraud-review-focus { border-top-color: #d5e0ea; }

      .compact-finding,
      .compact-finding.high,
      .compact-finding.medium,
      .compact-finding.low { color: #172033 !important; }
      .compact-finding.high { background: #fff5f6 !important; border-color: #e4aeb5 !important; }
      .compact-finding.medium { background: #fffaf0 !important; border-color: #e4c78d !important; }
      .compact-finding.low { background: #f1faf6 !important; border-color: #add8c8 !important; }
      .compact-finding .calculation-snapshot,
      .compact-finding .evidence-mini,
      .compact-finding .detail-grid,
      .compact-finding .review-checklist,
      .compact-finding .concern-panel {
        background: #ffffff !important;
        color: #253b53 !important;
        border-color: #cbd9e6 !important;
      }
      .compact-finding .detail-grid > div {
        background: #f6f9fc !important;
        border: 1px solid #d1dde8 !important;
        border-radius: 9px;
      }
      .compact-finding .detail-grid span { color: #60758e !important; }
      .compact-finding .detail-grid strong { color: #253b53 !important; }
      .compact-finding .review-checklist { background: #fffaf0 !important; border-color: #e4c78d !important; }
      .compact-finding .concern-panel { background: #f7fbff !important; }
      .compact-finding .concern-panel.high { border-left-color: #c63f4b !important; }

      .risk-hero, .risk-insight, .risk-score-strip > div {
        color: #172033 !important;
        border-color: #c9d9e7 !important;
      }
      .risk-score-strip > div { background: #ffffff !important; box-shadow: 0 4px 12px rgba(25,71,110,.05); }
      .risk-score-strip strong { color: #123f68 !important; font-size: 22px; }

      /* Classified tile language: distinct accents with accessible text contrast. */
      .summary-chip, .field-chip, .detail-grid > div,
      .report-compact-grid > div, .risk-score-strip > div,
      .setup-meta > div, .config-meta-grid > div {
        position: relative;
        overflow: hidden;
        transition: transform .18s ease, box-shadow .18s ease, border-color .18s ease;
      }
      .summary-chip::before, .field-chip::before, .detail-grid > div::before,
      .report-compact-grid > div::before, .risk-score-strip > div::before,
      .setup-meta > div::before, .config-meta-grid > div::before {
        content: "";
        position: absolute;
        left: 0; right: 0; top: 0;
        height: 4px;
        background: var(--tile-accent, #1768ac);
      }
      .summary-chip:hover, .field-chip:hover, .detail-grid > div:hover,
      .report-compact-grid > div:hover, .risk-score-strip > div:hover {
        transform: translateY(-2px);
        border-color: var(--tile-border, #a9c9df) !important;
        box-shadow: 0 9px 20px rgba(25,71,110,.11);
      }

      .summary-chip:nth-child(5n+1), .field-chip:nth-child(7n+1),
      .detail-grid > div:nth-child(6n+1), .report-compact-grid > div:nth-child(4n+1) {
        --tile-accent: #1768ac; --tile-border: #a9cce3;
        background: #f4faff !important;
      }
      .summary-chip:nth-child(5n+2), .field-chip:nth-child(7n+2),
      .detail-grid > div:nth-child(6n+2), .report-compact-grid > div:nth-child(4n+2) {
        --tile-accent: #6853b5; --tile-border: #c7bde9;
        background: #f8f6ff !important;
      }
      .summary-chip:nth-child(5n+3), .field-chip:nth-child(7n+3),
      .detail-grid > div:nth-child(6n+3), .report-compact-grid > div:nth-child(4n+3) {
        --tile-accent: #16805d; --tile-border: #add8c8;
        background: #f3fbf7 !important;
      }
      .summary-chip:nth-child(5n+4), .field-chip:nth-child(7n+4),
      .detail-grid > div:nth-child(6n+4), .report-compact-grid > div:nth-child(4n+4) {
        --tile-accent: #b27618; --tile-border: #e3c78f;
        background: #fffaf1 !important;
      }
      .summary-chip:nth-child(5n+5), .field-chip:nth-child(7n+5),
      .detail-grid > div:nth-child(6n+5) {
        --tile-accent: #c04e69; --tile-border: #e6b9c4;
        background: #fff6f8 !important;
      }
      .field-chip:nth-child(7n+6), .detail-grid > div:nth-child(6n+6) {
        --tile-accent: #267b92; --tile-border: #acd3dd;
        background: #f2fafc !important;
      }
      .field-chip:nth-child(7n+7) {
        --tile-accent: #7a5a9e; --tile-border: #cfbfdf;
        background: #faf7fd !important;
      }

      .summary-chip span, .field-chip span, .detail-grid span,
      .report-compact-grid span, .risk-score-strip span,
      .setup-meta span, .config-meta-grid span {
        color: var(--tile-label, #60758e) !important;
        font-weight: 750 !important;
        letter-spacing: .015em;
      }
      .summary-chip strong, .field-chip strong, .detail-grid strong,
      .report-compact-grid strong, .risk-score-strip strong,
      .setup-meta strong, .config-meta-grid strong {
        color: var(--tile-value, #203b55) !important;
        font-weight: 800 !important;
      }
      .field-chip:nth-child(7n+1), .detail-grid > div:nth-child(6n+1) { --tile-label: #477493; --tile-value: #155b91; }
      .field-chip:nth-child(7n+2), .detail-grid > div:nth-child(6n+2) { --tile-label: #74639f; --tile-value: #574292; }
      .field-chip:nth-child(7n+3), .detail-grid > div:nth-child(6n+3) { --tile-label: #4e7e6c; --tile-value: #126a4e; }
      .field-chip:nth-child(7n+4), .detail-grid > div:nth-child(6n+4) { --tile-label: #8f6b2d; --tile-value: #8a590e; }
      .field-chip:nth-child(7n+5), .detail-grid > div:nth-child(6n+5) { --tile-label: #9b6170; --tile-value: #a53e58; }
      .field-chip:nth-child(7n+6), .detail-grid > div:nth-child(6n+6) { --tile-label: #527d89; --tile-value: #1e6d82; }
      .field-chip:nth-child(7n+7) { --tile-label: #7b668f; --tile-value: #674584; }

      .field-chip.high, .summary-chip.risk {
        --tile-accent: #c63f4b; --tile-label: #9e5a62; --tile-value: #a72f3b;
        background: #fff4f5 !important; border-color: #e8b5bb !important;
      }
      .field-chip.medium, .summary-chip.warn {
        --tile-accent: #b27618; --tile-label: #8f6b2d; --tile-value: #8a590e;
        background: #fff9ed !important; border-color: #e4ca96 !important;
      }
      .field-chip.low {
        --tile-accent: #16805d; --tile-label: #4e7e6c; --tile-value: #126a4e;
        background: #f1faf6 !important; border-color: #add8c8 !important;
      }
      .top-findings-workbench > .section-purpose { margin: 0 0 2px; }
      .executive-finding {
        display: grid;
        grid-template-columns: 42px minmax(0, 1fr) minmax(150px, auto);
        gap: 14px;
        align-items: center;
        padding: 15px;
        background: #ffffff !important;
        border: 1px solid #cad9e6;
        border-left: 5px solid #1768ac;
        border-radius: 12px;
        box-shadow: 0 6px 16px rgba(25,71,110,.06);
      }
      .executive-finding.high { border-left-color: #c63f4b; background: #fff8f8 !important; }
      .executive-finding.medium { border-left-color: #b27618; background: #fffbf3 !important; }
      .executive-finding.low { border-left-color: #16805d; background: #f5fbf8 !important; }
      .executive-finding-rank {
        display: grid; place-items: center; width: 38px; height: 38px;
        border-radius: 10px; background: #e7f2fb !important;
        color: #155b91 !important; font-size: 17px; font-weight: 850;
      }
      .executive-finding-copy { min-width: 0; }
      .executive-finding-kicker { display: flex; align-items: center; flex-wrap: wrap; gap: 8px; }
      .executive-finding-kicker strong { color: #1768ac !important; font-size: 11px; letter-spacing: .04em; }
      .executive-finding-kicker span { color: #6b7f93 !important; font-size: 11px; }
      .executive-finding h4 { margin: 5px 0 4px; color: #163a5f !important; font-size: 15px; line-height: 1.3; }
      .executive-finding p {
        display: -webkit-box; margin: 0; overflow: hidden;
        color: #526b82 !important; font-size: 12px; line-height: 1.45;
        -webkit-line-clamp: 2; -webkit-box-orient: vertical;
      }
      .executive-finding-metrics {
        display: grid; grid-template-columns: repeat(2, minmax(68px, 1fr));
        gap: 7px; min-width: 150px;
      }
      .executive-finding-metrics > div {
        padding: 8px 9px; border: 1px solid #d1deea; border-radius: 9px;
        background: #f6f9fc !important;
      }
      .executive-finding-metrics span { display: block; color: #6b7f93 !important; font-size: 10px; }
      .executive-finding-metrics strong { display: block; margin-top: 3px; color: #294a68 !important; font-size: 12px; }
      .executive-finding-metrics > .tag { grid-column: 1 / -1; justify-self: end; }
      .evidence-page-link, .evidence-report-link {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        width: fit-content;
        color: #1768ac !important;
        font-weight: 800;
        line-height: 1.4;
        text-decoration: none;
        overflow-wrap: anywhere;
      }
      .evidence-page-link::after, .evidence-report-link::after {
        content: "↗";
        display: inline-grid;
        place-items: center;
        flex: 0 0 20px;
        width: 20px;
        height: 20px;
        border-radius: 6px;
        background: #e7f2fb;
        color: #1768ac;
        font-size: 11px;
      }
      .evidence-page-link:hover, .evidence-report-link:hover {
        color: #0f4f88 !important;
        text-decoration: underline;
        text-underline-offset: 3px;
      }
      .evidence-page-link:focus-visible, .evidence-report-link:focus-visible {
        border-radius: 5px;
        outline: 3px solid rgba(23,104,172,.22);
        outline-offset: 3px;
      }
      @media (max-width: 720px) {
        .executive-finding { grid-template-columns: 38px minmax(0, 1fr); }
        .executive-finding-metrics { grid-column: 2; width: 100%; }
      }
      .top-findings-workbench { display: grid; gap: 16px; }
      .top-findings-panel .compact-finding,
      .redflag-panel .compact-finding { height: auto; }
      .evidence-record, .evidence-record-header, .evidence-record-meta,
      .evidence-record-meta > div, .evidence-primary-value, .evidence-raw-value {
        background: #ffffff !important;
        color: #243b53 !important;
        border-color: #ccd9e6 !important;
      }
      .evidence-record span, .evidence-record-meta span,
      .evidence-record-header span, .evidence-raw-value span {
        color: #60758e !important;
      }
      .evidence-record strong, .evidence-record-meta strong,
      .evidence-record-header strong, .evidence-primary-value strong,
      .evidence-raw-value strong {
        color: #253b53 !important;
      }
      .evidence-primary-value strong { color: #1768ac !important; }
      .evidence-expand-button {
        background: #edf6ff !important; color: #1768ac !important;
        border-color: #aecaE1 !important;
      }
      @media (max-width: 1180px) {
        .redflag-panel, .top-findings-panel { grid-column: 1 / -1; }
      }
      @media (max-width: 860px) {
        .post-workbench-section { padding: 0 14px 18px; }
      }
    </style>
  </head>
  <body>
    {%app_entry%}
    <script>
      function ensureFastUploadInput() {
        let input = document.getElementById("fast-upload-file");
        const host = document.getElementById("fast-upload-input-host");
        if (!input && host) {
          input = document.createElement("input");
          input.id = "fast-upload-file";
          input.name = "files";
          input.type = "file";
          input.multiple = true;
          input.accept = ".pdf,.xlsx,.xls";
          input.className = "fast-upload-input";
          host.appendChild(input);
        }
        return input;
      }

      function watchFastUploadInput() {
        ensureFastUploadInput();
        let attempts = 0;
        const interval = window.setInterval(function() {
          attempts += 1;
          const input = ensureFastUploadInput();
          if (input || attempts > 60) {
            window.clearInterval(interval);
          }
        }, 500);
        if (window.MutationObserver) {
          const observer = new MutationObserver(function() {
            if (ensureFastUploadInput()) {
              observer.disconnect();
            }
          });
          observer.observe(document.body, { childList: true, subtree: true });
        }
      }

      if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", watchFastUploadInput);
      } else {
        watchFastUploadInput();
      }

      function closeEvidenceModal() {
        const modal = document.getElementById("evidence-modal");
        const content = document.getElementById("evidence-modal-content");
        if (!modal) {
          return;
        }
        modal.classList.remove("is-open");
        modal.setAttribute("aria-hidden", "true");
        document.body.classList.remove("evidence-modal-open");
        if (content) {
          content.replaceChildren();
        }
      }

      function closeRiskFullscreen() {
        const modal = document.getElementById("risk-fullscreen-modal");
        const content = document.getElementById("risk-fullscreen-content");
        if (!modal) return;
        modal.classList.remove("is-open");
        modal.setAttribute("aria-hidden", "true");
        document.body.classList.remove("risk-fullscreen-open");
        if (content) content.replaceChildren();
      }

      function openRiskFullscreen(source) {
        const modal = document.getElementById("risk-fullscreen-modal");
        const content = document.getElementById("risk-fullscreen-content");
        if (!source || !modal || !content) return;
        content.replaceChildren(source.cloneNode(true));
        modal.classList.add("is-open");
        modal.setAttribute("aria-hidden", "false");
        document.body.classList.add("risk-fullscreen-open");
        const closeButton = document.getElementById("risk-fullscreen-close");
        if (closeButton) closeButton.focus();
      }

      document.addEventListener("keydown", function(event) {
        if (event.key === "Escape") {
          closeEvidenceModal();
          closeRiskFullscreen();
        }
      });

      document.addEventListener("click", async function(event) {
        const riskExpand = event.target && event.target.closest
          ? event.target.closest(".risk-fullscreen-trigger")
          : null;
        if (riskExpand) {
          openRiskFullscreen(riskExpand.closest(".risk-board"));
          return;
        }

        const closeRisk = event.target && event.target.closest
          ? event.target.closest("#risk-fullscreen-close, .risk-fullscreen-backdrop")
          : null;
        if (closeRisk) {
          closeRiskFullscreen();
          return;
        }

        const expandEvidence = event.target && event.target.closest
          ? event.target.closest(".evidence-expand-button")
          : null;
        if (expandEvidence) {
          const source = expandEvidence.closest(".evidence-record");
          const modal = document.getElementById("evidence-modal");
          const content = document.getElementById("evidence-modal-content");
          if (source && modal && content) {
            content.replaceChildren(source.cloneNode(true));
            modal.classList.add("is-open");
            modal.setAttribute("aria-hidden", "false");
            document.body.classList.add("evidence-modal-open");
            const closeButton = document.getElementById("evidence-modal-close");
            if (closeButton) {
              closeButton.focus();
            }
          }
          return;
        }

        const closeEvidence = event.target && event.target.closest
          ? event.target.closest("#evidence-modal-close, .evidence-modal-backdrop")
          : null;
        if (closeEvidence) {
          closeEvidenceModal();
          return;
        }

        const uploadPanel = event.target && event.target.closest ? event.target.closest("#fast-upload-form") : null;
        if (uploadPanel && !event.target.closest("#fast-upload-trigger") && event.target.id !== "fast-upload-file") {
          const input = ensureFastUploadInput();
          if (input) {
            input.click();
          }
          return;
        }

        const trigger = event.target && event.target.closest ? event.target.closest("#fast-upload-trigger") : null;
        if (!trigger) {
          return;
        }
        event.preventDefault();

        const form = document.getElementById("fast-upload-form");
        const input = ensureFastUploadInput();
        const status = document.getElementById("upload-status");
        if (!input || !input.files || input.files.length === 0) {
          if (status) {
            status.innerHTML = '<div class="message warn">Choose at least one report file to upload.</div>';
          }
          return;
        }

        const setStatus = function(html) {
          if (status) {
            status.innerHTML = html;
          }
        };
        const buildFormData = function() {
          const data = new FormData();
          Array.from(input.files).forEach(function(file) {
            data.append("files", file, file.name);
          });
          return data;
        };
        const uploadTo = async function(endpoint) {
          return fetch(endpoint, { method: "POST", body: buildFormData() });
        };

        const fileCount = input.files.length;
        const totalBytes = Array.from(input.files).reduce(function(total, file) { return total + file.size; }, 0);
        const totalMb = (totalBytes / 1024 / 1024).toFixed(1);
        setStatus('<div class="message summary">Uploading ' + fileCount + ' file(s), ' + totalMb + ' MB, directly to the managed folder...</div>');

        form.querySelectorAll("button, input").forEach(function(el) { el.disabled = true; });
        try {
          const configuredEndpoint = form.getAttribute("data-endpoint") || "fsre-fast-upload";
          let response;
          try {
            response = await uploadTo(configuredEndpoint);
          } catch (firstError) {
            response = await uploadTo("/fsre-fast-upload");
          }
          if (response && response.status === 404 && configuredEndpoint !== "/fsre-fast-upload") {
            response = await uploadTo("/fsre-fast-upload");
          }
          const payload = await response.json().catch(function() { return {}; });
          if (!response.ok || !payload.ok) {
            const error = payload.error || (payload.results || []).map(function(item) { return item.error; }).filter(Boolean).join("; ") || response.statusText || "Upload failed";
            setStatus('<div class="message error">Upload failed: ' + error + '</div>');
            return;
          }

          const rows = (payload.results || []).map(function(item) {
            if (item.ok) {
              return '<div class="message ok">' + item.file + ' stored at ' + item.path + '</div>';
            }
            return '<div class="message warn">' + item.file + ': ' + item.error + '</div>';
          }).join("");
          setStatus('<div class="message summary">' + payload.uploaded_count + ' file(s) uploaded to managed folder ' + payload.folder_id + '.</div>' + rows);
          input.value = "";
          setTimeout(function() {
            const refresh = document.getElementById("refresh-folder-button");
            if (refresh) {
              refresh.click();
            }
          }, 300);
        } catch (error) {
          setStatus('<div class="message error">Upload failed: ' + error + '</div>');
        } finally {
          form.querySelectorAll("button, input").forEach(function(el) { el.disabled = false; });
        }
      });
    </script>
    <footer>
      {%config%}
      {%scripts%}
      {%renderer%}
    </footer>
  </body>
</html>
"""
