from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Iterable


@dataclass(frozen=True)
class VariableContext:
    scopes: tuple[tuple[str, str], ...]
    lifecycle_state: str


def resolve_variables(cursor, tenant_id: str, context: VariableContext) -> dict[str, Any]:
    """Resolve variables in priority order; the first scope has highest priority."""
    resolved: dict[str, Any] = {}
    now = datetime.now(timezone.utc)
    for variable_scope, scope_key in context.scopes:
        cursor.execute(
            """SELECT DISTINCT ON (variable_key)
                      variable_key,value_json,value_type,version
               FROM financial_risk_intelligence.database_variables
               WHERE tenant_id=%s AND variable_scope=%s AND scope_key=%s
                 AND lifecycle_state=%s
                 AND (effective_from IS NULL OR effective_from<=%s)
                 AND (effective_to IS NULL OR effective_to>%s)
               ORDER BY variable_key,version DESC""",
            (tenant_id, variable_scope, scope_key, context.lifecycle_state, now, now),
        )
        for row in cursor.fetchall():
            resolved.setdefault(row["variable_key"], row["value_json"])
    return resolved


def require_variables(variables: dict[str, Any], keys: Iterable[str]) -> dict[str, Any]:
    missing = [key for key in keys if key not in variables or variables[key] in (None, "")]
    if missing:
        raise LookupError("Required database variables are missing: " + ", ".join(sorted(missing)))
    return variables
