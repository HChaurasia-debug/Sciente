"""Create runs from request rows; operational variables are resolved from PostgreSQL."""

import json
import os
import sys

import dataiku

PROJECT_FOLDER = os.getenv("FRI_PROJECT_FOLDER", "/fsre_project")
SRC_FOLDER = os.path.join(PROJECT_FOLDER, "src")
if SRC_FOLDER not in sys.path:
    sys.path.insert(0, SRC_FOLDER)

from financial_risk_intelligence.database_configured_run import RunIntake, create_database_configured_run


def recipe_dataset(role):
    config = dataiku.get_recipe_config()
    value = config.get(role)
    if not value:
        raise RuntimeError(f"Recipe configuration must define {role}")
    return str(value)


input_name = recipe_dataset("request_input_dataset")
output_name = recipe_dataset("run_output_dataset")
rows = dataiku.Dataset(input_name).get_dataframe().to_dict(orient="records")
results = []

for row in rows:
    scopes_value = row.get("variable_scopes")
    scopes = json.loads(scopes_value) if isinstance(scopes_value, str) else scopes_value
    if not isinstance(scopes, list) or not scopes:
        raise ValueError("variable_scopes must be a non-empty JSON array")
    payload_value = row.get("request_payload") or {}
    payload = json.loads(payload_value) if isinstance(payload_value, str) else payload_value
    result = create_database_configured_run(
        RunIntake(
            tenant_id=str(row["tenant_id"]),
            customer_id=str(row["customer_id"]),
            report_id=str(row["report_id"]),
            configuration_set_id=str(row["configuration_set_id"]),
            requested_by=str(row["requested_by"]) if row.get("requested_by") else None,
            idempotency_key=str(row["idempotency_key"]),
            variable_lifecycle_state=str(row["variable_lifecycle_state"]),
            variable_scopes=tuple((str(item["scope"]), str(item["key"])) for item in scopes),
            request_payload=payload,
        )
    )
    results.append(result)

import pandas as pd
dataiku.Dataset(output_name).write_with_schema(pd.DataFrame(results))
