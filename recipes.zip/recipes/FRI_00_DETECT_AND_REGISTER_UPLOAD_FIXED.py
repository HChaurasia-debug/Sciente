"""Register uploaded financial reports without tenant/company hardcoding.

Input managed folder: FRI_ANNUAL_REPORT_UPLOADS_FOLDER
Output managed folder: FRI_REGISTERED_REPORTS_FOLDER
Output dataset: FRI_UPLOAD_REGISTRATION_RESULTS

For an ordinary flat filename, the recipe selects the sole active tenant from
PostgreSQL and derives a provisional entity key from the filename. If multiple
active tenants exist, it fails instead of risking cross-tenant data mixing.
"""

from __future__ import annotations

import hashlib
import json
import os
import posixpath
import re
import traceback
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

import dataiku
import pandas as pd
import psycopg2

from financial_risk_intelligence.database import DatabaseSettings


INPUT_FOLDER_ID = "avBJ7Lwp"
REGISTERED_FOLDER_ID = "t4d04GkB"
OUTPUT_DATASET_NAME = "FRI_UPLOAD_REGISTRATION_RESULTS"
FAIL_RECIPE_WHEN_ANY_DOCUMENT_FAILS = False

SUPPORTED_EXTENSIONS = {
    ".pdf", ".xlsx", ".xls", ".csv", ".xml", ".xbrl", ".html", ".htm"
}

OUTPUT_COLUMNS = [
    "source_path", "registered_path", "file_name", "file_extension",
    "file_size_bytes", "document_checksum", "tenant_key", "tenant_id",
    "entity_key", "entity_id", "assessment_run_id", "source_document_id",
    "processing_status", "registration_status", "duplicate_document",
    "message", "registered_at",
]


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def clean_path(path: str) -> str:
    value = str(path or "").strip()
    if not value.startswith("/"):
        value = "/" + value
    return posixpath.normpath(value)


def derive_entity_key(file_name: str) -> str:
    stem = os.path.splitext(posixpath.basename(file_name))[0]
    value = re.sub(
        r"\b(annual\s+report|integrated\s+report|financial\s+statements?|"
        r"financial\s+report|yearly\s+report)\b",
        " ",
        stem,
        flags=re.IGNORECASE,
    )
    value = re.sub(r"\b(?:19|20)\d{2}\b", " ", value)
    value = re.sub(r"[^A-Za-z0-9]+", "_", value).strip("_").upper()
    if not value:
        raise ValueError(
            f"Could not derive an entity key from uploaded filename '{file_name}'"
        )
    return value


def parse_upload_path(path: str) -> Tuple[Optional[str], str, str]:
    """Return optional tenant key, entity key and original filename."""
    parts = [part for part in clean_path(path).split("/") if part]
    if not parts:
        raise ValueError(f"Invalid upload path: {path}")

    file_name = parts[-1].strip()
    if not file_name:
        raise ValueError("Uploaded filename is empty")

    # Optional nested path supplied by a future tenant-aware upload channel.
    if len(parts) >= 3:
        tenant_key = parts[0].strip().upper()
        entity_key = parts[1].strip().upper()
        return tenant_key, entity_key, file_name

    # Backward-compatible explicit metadata filename, when supplied.
    explicit = file_name.split("__", 2)
    if len(explicit) == 3 and all(item.strip() for item in explicit):
        return explicit[0].strip().upper(), explicit[1].strip().upper(), explicit[2].strip()

    # Normal user filename: tenant is resolved safely from the database.
    return None, derive_entity_key(file_name), file_name


def calculate_sha256(folder: dataiku.Folder, path: str) -> Tuple[str, int]:
    digest = hashlib.sha256()
    total = 0
    with folder.get_download_stream(path) as stream:
        while True:
            block = stream.read(1024 * 1024)
            if not block:
                break
            digest.update(block)
            total += len(block)
    return digest.hexdigest(), total


def copy_file(source_folder, source_path, destination_folder, destination_path):
    with source_folder.get_download_stream(source_path) as source:
        with destination_folder.get_writer(destination_path) as destination:
            while True:
                block = source.read(1024 * 1024)
                if not block:
                    break
                destination.write(block)


def connect_database():
    settings = DatabaseSettings.from_runtime()
    return psycopg2.connect(
        host=settings.host,
        port=settings.port,
        dbname=settings.database,
        user=settings.user,
        password=settings.password,
        application_name=settings.application_name,
        connect_timeout=30,
    )


def resolve_single_active_tenant(cursor) -> Tuple[str, str]:
    cursor.execute(
        """
        SELECT tenant_id, tenant_key
        FROM financial_risk_intelligence.tenants
        WHERE LOWER(lifecycle_state) = 'active'
        ORDER BY created_at
        """
    )
    rows = cursor.fetchall()
    if not rows:
        raise LookupError("No active tenant exists in the database")
    if len(rows) > 1:
        raise LookupError(
            "Multiple active tenants exist. A tenant-aware upload channel is required; "
            "the recipe will not guess and risk mixing customer data."
        )
    row = rows[0]
    if isinstance(row, dict):
        return str(row["tenant_id"]), str(row["tenant_key"])
    return str(row[0]), str(row[1])


def resolve_or_create_tenant(cursor, tenant_key: str) -> str:
    cursor.execute(
        """SELECT tenant_id FROM financial_risk_intelligence.tenants
           WHERE tenant_key = %s""",
        (tenant_key,),
    )
    row = cursor.fetchone()
    if row:
        return str(row["tenant_id"] if isinstance(row, dict) else row[0])

    tenant_id = str(uuid.uuid4())
    cursor.execute(
        """
        INSERT INTO financial_risk_intelligence.tenants
            (tenant_id, tenant_key, display_name, lifecycle_state, settings,
             created_at, updated_at)
        VALUES (%s, %s, %s, 'active', %s::jsonb,
                CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
        """,
        (
            tenant_id, tenant_key, tenant_key.replace("_", " ").title(),
            json.dumps({"provisioning_source": "tenant_aware_upload"}),
        ),
    )
    return tenant_id


def resolve_or_create_entity(cursor, tenant_id: str, entity_key: str) -> str:
    cursor.execute(
        """SELECT entity_id FROM financial_risk_intelligence.entities
           WHERE tenant_id = %s AND entity_key = %s""",
        (tenant_id, entity_key),
    )
    row = cursor.fetchone()
    if row:
        return str(row["entity_id"] if isinstance(row, dict) else row[0])

    entity_id = str(uuid.uuid4())
    cursor.execute(
        """
        INSERT INTO financial_risk_intelligence.entities
            (entity_id, tenant_id, entity_key, legal_name, lifecycle_state,
             attributes, created_at, updated_at)
        VALUES (%s, %s, %s, %s, 'active', %s::jsonb,
                CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
        """,
        (
            entity_id, tenant_id, entity_key,
            entity_key.replace("_", " ").title(),
            json.dumps({"identity_status": "provisional", "source": "filename"}),
        ),
    )
    return entity_id


def find_existing_document(cursor, tenant_id: str, checksum: str):
    cursor.execute(
        """
        SELECT source_document_id, assessment_run_id, registered_path
        FROM financial_risk_intelligence.source_documents
        WHERE tenant_id = %s AND document_checksum = %s
        ORDER BY created_at DESC LIMIT 1
        """,
        (tenant_id, checksum),
    )
    return cursor.fetchone()


def create_assessment_run(cursor, tenant_id: str, entity_id: str) -> str:
    run_id = str(uuid.uuid4())
    cursor.execute(
        """
        INSERT INTO financial_risk_intelligence.assessment_runs
            (assessment_run_id, tenant_id, entity_id, run_status, run_type,
             requested_at, created_at, updated_at)
        VALUES (%s, %s, %s, 'QUEUED', 'FINANCIAL_STATEMENT_ASSESSMENT',
                CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
        """,
        (run_id, tenant_id, entity_id),
    )
    return run_id


def create_source_document(
    cursor, tenant_id, entity_id, run_id, file_name, source_path,
    registered_path, extension, checksum, size_bytes,
) -> str:
    document_id = str(uuid.uuid4())
    cursor.execute(
        """
        INSERT INTO financial_risk_intelligence.source_documents
            (source_document_id, tenant_id, entity_id, assessment_run_id,
             original_file_name, source_path, registered_path, file_extension,
             file_size_bytes, document_checksum, ingestion_status,
             document_metadata, created_at, updated_at)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 'REGISTERED',
                %s::jsonb, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
        """,
        (
            document_id, tenant_id, entity_id, run_id, file_name, source_path,
            registered_path, extension, size_bytes, checksum,
            json.dumps({"registration_source": "dataiku_managed_folder"}),
        ),
    )
    return document_id


def row_value(row, key, index):
    return row[key] if isinstance(row, dict) else row[index]


def register_file(input_folder, registered_folder, source_path) -> Dict[str, Any]:
    registered_at = utc_now()
    tenant_key = tenant_id = entity_key = entity_id = None
    run_id = document_id = registered_path = None
    file_name = posixpath.basename(source_path)
    extension = os.path.splitext(file_name)[1].lower()
    checksum = None
    file_size = None
    stage = "PARSE_UPLOAD_PATH"

    try:
        tenant_key, entity_key, file_name = parse_upload_path(source_path)
        extension = os.path.splitext(file_name)[1].lower()
        if extension not in SUPPORTED_EXTENSIONS:
            raise ValueError(f"Unsupported file extension '{extension}'")

        stage = "CALCULATE_CHECKSUM"
        checksum, file_size = calculate_sha256(input_folder, source_path)
        stage = "CONNECT_DATABASE"
        connection = connect_database()

        try:
            connection.autocommit = False
            with connection.cursor() as cursor:
                stage = "RESOLVE_TENANT"
                if tenant_key:
                    tenant_id = resolve_or_create_tenant(cursor, tenant_key)
                else:
                    tenant_id, tenant_key = resolve_single_active_tenant(cursor)

                cursor.execute(
                    "SELECT set_config('fsre.tenant_id', %s, true)",
                    (tenant_id,),
                )
                stage = "RESOLVE_ENTITY"
                entity_id = resolve_or_create_entity(cursor, tenant_id, entity_key)
                stage = "CHECK_DUPLICATE"
                existing = find_existing_document(cursor, tenant_id, checksum)

                if existing:
                    document_id = str(row_value(existing, "source_document_id", 0))
                    run_value = row_value(existing, "assessment_run_id", 1)
                    path_value = row_value(existing, "registered_path", 2)
                    run_id = str(run_value) if run_value else None
                    registered_path = str(path_value) if path_value else None
                    connection.commit()
                    status = "ALREADY_REGISTERED"
                    duplicate = True
                    message = "Document checksum is already registered"
                else:
                    stage = "CREATE_ASSESSMENT_RUN"
                    run_id = create_assessment_run(cursor, tenant_id, entity_id)
                    registered_path = f"/{tenant_key}/{entity_key}/{run_id}/{file_name}"
                    stage = "CREATE_SOURCE_DOCUMENT"
                    document_id = create_source_document(
                        cursor, tenant_id, entity_id, run_id, file_name, source_path,
                        registered_path, extension, checksum, file_size,
                    )
                    stage = "COPY_REGISTERED_FILE"
                    copy_file(input_folder, source_path, registered_folder, registered_path)
                    connection.commit()
                    status = "QUEUED"
                    duplicate = False
                    message = "Upload registered successfully"

                return {
                    "source_path": source_path, "registered_path": registered_path,
                    "file_name": file_name, "file_extension": extension,
                    "file_size_bytes": file_size, "document_checksum": checksum,
                    "tenant_key": tenant_key, "tenant_id": tenant_id,
                    "entity_key": entity_key, "entity_id": entity_id,
                    "assessment_run_id": run_id, "source_document_id": document_id,
                    "processing_status": status, "registration_status": "SUCCESS",
                    "duplicate_document": duplicate, "message": message,
                    "registered_at": registered_at,
                }
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    except Exception as exc:
        print(f"Registration failed at {stage} for {source_path}: {exc}")
        print(traceback.format_exc())
        return {
            "source_path": source_path, "registered_path": registered_path,
            "file_name": file_name, "file_extension": extension,
            "file_size_bytes": file_size, "document_checksum": checksum,
            "tenant_key": tenant_key, "tenant_id": tenant_id,
            "entity_key": entity_key, "entity_id": entity_id,
            "assessment_run_id": run_id, "source_document_id": document_id,
            "processing_status": "FAILED", "registration_status": "FAILED",
            "duplicate_document": False,
            "message": f"Stage={stage}; {type(exc).__name__}: {exc}",
            "registered_at": registered_at,
        }


def main() -> None:
    input_folder = dataiku.Folder(INPUT_FOLDER_ID)
    registered_folder = dataiku.Folder(REGISTERED_FOLDER_ID)
    output_dataset = dataiku.Dataset(OUTPUT_DATASET_NAME)
    paths = sorted(input_folder.list_paths_in_partition())
    report_paths = [
        path for path in paths
        if not path.endswith("/")
        and os.path.splitext(path)[1].lower() in SUPPORTED_EXTENSIONS
    ]
    results: List[Dict[str, Any]] = [
        register_file(input_folder, registered_folder, path)
        for path in report_paths
    ]
    result_df = pd.DataFrame(results, columns=OUTPUT_COLUMNS)
    output_dataset.write_with_schema(result_df)
    failed = (
        result_df[result_df["registration_status"] == "FAILED"]
        if not result_df.empty else result_df
    )
    print(json.dumps({
        "files_discovered": len(report_paths),
        "successful": int((result_df["registration_status"] == "SUCCESS").sum())
        if not result_df.empty else 0,
        "failed": len(failed),
    }, indent=2))
    if not failed.empty and FAIL_RECIPE_WHEN_ANY_DOCUMENT_FAILS:
        raise RuntimeError(
            f"{len(failed)} document(s) failed registration. Review the output dataset."
        )


main()
