-- Generic, evidence-driven Beneish prerequisites.
-- No filing values are stored here: only concepts, aliases and derivations.
BEGIN;

INSERT INTO financial_risk_intelligence.financial_concepts
 (concept_key,statement_type,canonical_label,is_required,active)
VALUES
 ('depreciation_ppe','CASH_FLOW_STATEMENT','Depreciation of PP&E',false,true),
 ('depreciation_rou','CASH_FLOW_STATEMENT','Depreciation of right-of-use assets',false,true),
 ('amortization_intangibles','CASH_FLOW_STATEMENT','Amortisation of intangible assets',false,true),
 ('non_current_borrowings','BALANCE_SHEET','Non-current borrowings',false,true),
 ('non_current_lease_liabilities','BALANCE_SHEET','Non-current lease liabilities',false,true)
ON CONFLICT(concept_key) DO UPDATE SET
 statement_type=EXCLUDED.statement_type,
 canonical_label=EXCLUDED.canonical_label,
 active=true,
 updated_at=now();

-- Component disclosures must not also resolve the aggregate target directly;
-- otherwise the first component can incorrectly displace the configured sum.
DELETE FROM financial_risk_intelligence.financial_concept_aliases
WHERE concept_key='depreciation_amortization'
  AND normalized_alias_text IN (
    financial_risk_intelligence.normalize_financial_alias_text('Depreciation of property, plant and equipment'),
    financial_risk_intelligence.normalize_financial_alias_text('Depreciation of property plant and equipment'),
    financial_risk_intelligence.normalize_financial_alias_text('Depreciation of PP&E'),
    financial_risk_intelligence.normalize_financial_alias_text('Depreciation of right-of-use assets'),
    financial_risk_intelligence.normalize_financial_alias_text('Depreciation of right of use assets'),
    financial_risk_intelligence.normalize_financial_alias_text('Amortisation of intangible assets'),
    financial_risk_intelligence.normalize_financial_alias_text('Amortization of intangible assets')
  );

INSERT INTO financial_risk_intelligence.financial_concept_aliases
 (concept_key,alias_text,normalized_alias_text,sector_key,priority,active,
  approval_status,approved_by,approved_at)
SELECT concept_key,alias_text,
       financial_risk_intelligence.normalize_financial_alias_text(alias_text),
       NULL,priority,true,'APPROVED','BENEISH_GENERIC_FIX',now()
FROM (VALUES
 ('depreciation_ppe','Depreciation of property, plant and equipment',1),
 ('depreciation_ppe','Depreciation of property plant and equipment',2),
 ('depreciation_ppe','Depreciation of PP&E',3),
 ('depreciation_rou','Depreciation of right-of-use assets',1),
 ('depreciation_rou','Depreciation of right of use assets',2),
 ('amortization_intangibles','Amortisation of intangible assets',1),
 ('amortization_intangibles','Amortization of intangible assets',2),
 ('non_current_borrowings','Non-current borrowings',1),
 ('non_current_borrowings','Non-current loans and borrowings',2),
 ('non_current_lease_liabilities','Non-current lease liabilities',1)
) v(concept_key,alias_text,priority)
ON CONFLICT DO NOTHING;

INSERT INTO financial_risk_intelligence.financial_template_rules
 (rule_key,template_key,target_concept_key,operator,priority,output_sign,active,approval_status)
VALUES
 ('DA_COMPONENTS','MANUFACTURING_INDUSTRIALS_GENERIC','depreciation_amortization','LINEAR_COMBINATION',20,'ABSOLUTE',true,'APPROVED'),
 ('DA_PPE_ONLY','MANUFACTURING_INDUSTRIALS_GENERIC','depreciation_amortization','LINEAR_COMBINATION',30,'ABSOLUTE',true,'APPROVED'),
 ('LTD_SUM','MANUFACTURING_INDUSTRIALS_GENERIC','long_term_debt','LINEAR_COMBINATION',5,'ABSOLUTE',true,'APPROVED')
ON CONFLICT(rule_key) DO UPDATE SET
 template_key=EXCLUDED.template_key,
 target_concept_key=EXCLUDED.target_concept_key,
 operator=EXCLUDED.operator,
 priority=EXCLUDED.priority,
 output_sign=EXCLUDED.output_sign,
 active=true,
 approval_status='APPROVED',
 updated_at=now();

INSERT INTO financial_risk_intelligence.financial_rule_components
 (rule_key,component_concept_key,coefficient,component_sign,component_order)
VALUES
 ('DA_COMPONENTS','depreciation_ppe',1,'ABSOLUTE',1),
 ('DA_COMPONENTS','depreciation_rou',1,'ABSOLUTE',2),
 ('DA_COMPONENTS','amortization_intangibles',1,'ABSOLUTE',3),
 ('DA_PPE_ONLY','depreciation_ppe',1,'ABSOLUTE',1),
 ('LTD_SUM','non_current_borrowings',1,'ABSOLUTE',1),
 ('LTD_SUM','non_current_lease_liabilities',1,'ABSOLUTE',2)
ON CONFLICT(rule_key,component_concept_key) DO UPDATE SET
 coefficient=EXCLUDED.coefficient,
 component_sign=EXCLUDED.component_sign,
 component_order=EXCLUDED.component_order;

COMMIT;

SELECT r.rule_key,r.target_concept_key,r.priority,r.operator,
       c.component_concept_key,c.coefficient,c.component_sign,c.component_order
FROM financial_risk_intelligence.financial_template_rules r
JOIN financial_risk_intelligence.financial_rule_components c USING(rule_key)
WHERE r.rule_key IN ('DA_COMPONENTS','DA_PPE_ONLY','LTD_SUM')
ORDER BY r.rule_key,c.component_order;
