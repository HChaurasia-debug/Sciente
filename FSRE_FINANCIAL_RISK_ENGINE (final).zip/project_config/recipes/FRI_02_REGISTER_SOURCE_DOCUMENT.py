"""
Dataiku recipe: ingest selected annual report/financial statement document.

Input:
- Preferred: PostgreSQL fsre_config.runtime_requests row with request_type='document_ingestion'
- Optional: FSRE_DOCUMENT_REQUEST_ID may point at one exact database request.
- Dataiku variables are only for PostgreSQL bootstrap.

Output:
- Optional Dataiku dataset named document_ingestion_log for UI visibility.
  PostgreSQL remains the system of record.
"""

import json
import os
import sys
import tempfile
from urllib.parse import urlparse

import dataiku
import pandas as pd
import requests

PROJECT_FOLDER = os.getenv("FSRE_PROJECT_FOLDER", "/fsre_project")
SRC_FOLDER = os.path.join(PROJECT_FOLDER, "src")
if SRC_FOLDER not in sys.path:
    sys.path.insert(0, SRC_FOLDER)

from fsre.db import PostgresConfig, connect
from fsre.document_ingestion import DocumentIngestionRequest, ingest_document
from fsre.runtime_control import (
    complete_runtime_request,
    create_runtime_request,
    get_bootstrap_request_id,
    load_runtime_request,
)


def current_assessment_run_id():
    try:
        variables = dataiku.get_custom_variables()
        value = variables.get("FSRE_ASSESSMENT_DB_RUN_ID") or variables.get("FSRE_LAST_DATABASE_RUN_ID")
        return str(value).strip() if value else None
    except Exception:
        return None


def load_pending_document_request(cur, request_id=None):
    if request_id:
        return load_runtime_request(
            cur,
            request_type="document_ingestion",
            request_id=request_id,
        )
    run_id = current_assessment_run_id()
    if run_id:
        cur.execute(
            """
            SELECT *
            FROM fsre_config.runtime_requests
            WHERE request_type = 'document_ingestion'
              AND status = 'pending'
              AND run_id = %s
            ORDER BY priority ASC, created_at ASC
            LIMIT 1
            """,
            (run_id,),
        )
        row = cur.fetchone()
        if row:
            row = dict(row)
            cur.execute(
                """
                UPDATE fsre_config.runtime_requests
                SET status = 'running',
                    started_at = COALESCE(started_at, now()),
                    consumed_at = COALESCE(consumed_at, now())
                WHERE request_id = %s
                """,
                (row["request_id"],),
            )
            return row
    return load_runtime_request(
        cur,
        request_type="document_ingestion",
        request_id=None,
    )


def materialize_document_payload(request_payload):
    temporary_file = None
    if (
        not request_payload.get("document_path")
        and not (request_payload.get("managed_folder_id") and request_payload.get("file_name"))
        and request_payload.get("source_url")
    ):
        source_url = request_payload["source_url"]
        file_name = request_payload.get("file_name") or os.path.basename(urlparse(source_url).path)
        suffix = os.path.splitext(file_name)[1] or ".pdf"
        temporary_file = tempfile.NamedTemporaryFile(delete=False, suffix=suffix)
        response = requests.get(source_url, timeout=120)
        response.raise_for_status()
        temporary_file.write(response.content)
        temporary_file.close()
        request_payload["document_path"] = temporary_file.name
        request_payload["original_file_name"] = file_name
        request_payload["storage_uri"] = request_payload.get("storage_uri") or source_url

    if not request_payload.get("document_path"):
        managed_folder_id = request_payload.get("managed_folder_id")
        file_name = request_payload.get("file_name")
        if not managed_folder_id or not file_name:
            raise ValueError(
                "document_ingestion request_json must contain either document_path "
                "or managed_folder_id + file_name"
            )

        folder = dataiku.Folder(managed_folder_id)
        suffix = os.path.splitext(file_name)[1] or ".pdf"
        temporary_file = tempfile.NamedTemporaryFile(delete=False, suffix=suffix)
        try:
            with folder.get_download_stream(file_name) as stream:
                temporary_file.write(stream.read())
        except Exception:
            with folder.get_download_stream(str(file_name).lstrip("/")) as stream:
                temporary_file.write(stream.read())
        temporary_file.close()
        request_payload["document_path"] = temporary_file.name
        request_payload["original_file_name"] = file_name
        request_payload["storage_uri"] = f"dataiku-managed-folder://{managed_folder_id}/{file_name}"

    return request_payload, temporary_file


results = []
explicit_request_id = get_bootstrap_request_id("FSRE_DOCUMENT_REQUEST_ID")

with connect(PostgresConfig.from_env()) as conn:
    with conn.cursor() as cur:
        while True:
            try:
                runtime_row = load_pending_document_request(cur, explicit_request_id)
            except ValueError:
                if results:
                    break
                raise

            runtime_request_id = str(runtime_row["request_id"])
            request_payload = dict(runtime_row["request_json"])
            temporary_file = None
            try:
                request_payload, temporary_file = materialize_document_payload(request_payload)
                request = DocumentIngestionRequest.from_payload(request_payload)
                result = ingest_document(cur, request)
                complete_runtime_request(cur, runtime_request_id, run_id=str(result["run_id"]))

                field_manifest_payload = {
                    "run_id": str(result["run_id"]),
                    "raw_document_id": str(result["raw_document_id"]),
                    "requested_by": request.requested_by,
                }
                field_manifest_request = create_runtime_request(
                    cur,
                    request_type="field_manifest",
                    request_name=f"Required field manifest for {result['file_name']}",
                    requested_by=request.requested_by,
                    environment=runtime_row.get("environment"),
                    run_id=str(result["run_id"]),
                    parent_request_id=runtime_request_id,
                    request_json=field_manifest_payload,
                )
                result["document_request_id"] = runtime_request_id
                result["next_field_manifest_request_id"] = field_manifest_request["request_id"]
                results.append(result)
            except Exception as exc:
                complete_runtime_request(
                    cur,
                    runtime_request_id,
                    status="failed",
                    error_message=str(exc),
                )
                raise
            finally:
                if temporary_file is not None:
                    try:
                        os.unlink(temporary_file.name)
                    except OSError:
                        pass

            if explicit_request_id:
                break

result = {
    "status": "completed",
    "processed_document_request_count": len(results),
    "results": results,
}

print(json.dumps(result, default=str, indent=2))

output_df = pd.DataFrame(
    [
        {
            "run_id": str(item["run_id"]),
            "raw_document_id": str(item["raw_document_id"]),
            "document_request_id": str(item.get("document_request_id", "")),
            "source_document_id": item["source_document_id"],
            "entity_id": item["entity_id"],
            "document_name": item["document_name"],
            "file_name": item["file_name"],
            "file_size_bytes": item["file_size_bytes"],
            "checksum_sha256": item["checksum_sha256"],
            "page_count": item["page_count"],
            "chunk_count": item["chunk_count"],
            "status": item["status"],
            "next_field_manifest_request_id": str(item.get("next_field_manifest_request_id", "")),
        }
        for item in results
    ]
)

try:
    output_dataset = dataiku.Dataset("document_ingestion_log")
    output_dataset.write_with_schema(output_df)
except Exception as exc:
    print(f"Skipping Dataiku output dataset write: {exc}")
