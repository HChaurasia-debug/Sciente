from __future__ import annotations

import json
import re
from string import Formatter
from typing import Any, Optional

from fsre.runtime_control import create_runtime_request


UNKNOWN_REPORTING_PERIOD_LABEL = "UNKNOWN_PERIOD"


def list_active_intake_configs(cur: Any) -> list[dict[str, Any]]:
    cur.execute(
        """
        SELECT *
        FROM fsre_config.managed_folder_intake_configs
        WHERE status = 'active'
        ORDER BY priority ASC, updated_at DESC, created_at DESC
        """
    )
    return [dict(row) for row in cur.fetchall()]


def get_default_intake_settings(cur: Any) -> dict[str, Any]:
    cur.execute(
        """
        SELECT profile_id, profile_version
        FROM fsre_config.deployment_profiles
        WHERE status = 'active'
          AND is_active = TRUE
        ORDER BY effective_from DESC NULLS LAST, created_at DESC
        LIMIT 1
        """
    )
    profile = cur.fetchone()
    if not profile:
        raise ValueError("No active deployment profile found for automatic intake.")

    cur.execute(
        """
        SELECT connector_id, connector_version
        FROM fsre_config.connector_registry
        WHERE status = 'active'
          AND connector_type = 'document_input'
          AND supported_formats ? 'pdf'
        ORDER BY updated_at DESC, created_at DESC
        LIMIT 1
        """
    )
    connector = cur.fetchone()
    if not connector:
        raise ValueError("No active PDF document_input connector found for automatic intake.")

    defaults = {}
    cur.execute(
        """
        SELECT parameters_json
        FROM fsre_config.runtime_parameter_sets
        WHERE parameter_scope = 'assessment'
          AND status = 'active'
          AND is_default = TRUE
        ORDER BY updated_at DESC, created_at DESC
        LIMIT 1
        """
    )
    row = cur.fetchone()
    if row:
        defaults = row["parameters_json"]
        if isinstance(defaults, str):
            defaults = json.loads(defaults)
    required_defaults = [
        "requested_by",
        "environment",
        "run_source",
        "run_mode",
        "evidence_depth",
    ]
    missing_defaults = [
        key
        for key in required_defaults
        if not isinstance(defaults, dict) or defaults.get(key) in (None, "")
    ]
    if missing_defaults:
        raise ValueError(
            "Default assessment runtime parameters are missing in "
            "fsre_config.runtime_parameter_sets: "
            + ", ".join(missing_defaults)
        )

    return {
        "profile_id": profile["profile_id"],
        "profile_version": profile["profile_version"],
        "connector_id": connector["connector_id"],
        "connector_version": connector["connector_version"],
        "requested_by": defaults["requested_by"],
        "environment": defaults["environment"],
        "run_source": defaults["run_source"],
        "run_mode": defaults["run_mode"],
        "evidence_depth": defaults["evidence_depth"],
    }


def normalize_folder_path(path: str) -> str:
    return path.lstrip("/")


def matches_intake_config(config: dict[str, Any], file_path: str) -> dict[str, str] | None:
    normalized = normalize_folder_path(file_path)
    prefix = (config.get("folder_path_prefix") or "").strip("/")
    if prefix and not normalized.startswith(prefix + "/"):
        return None

    pattern = config["file_name_regex"]
    match = re.match(pattern, normalized)
    if not match:
        return None
    return {key: value for key, value in match.groupdict().items() if value is not None}


def render_template(template: str | None, context: dict[str, Any]) -> str | None:
    if template in (None, ""):
        return None

    required = {
        field_name
        for _, field_name, _, _ in Formatter().parse(template)
        if field_name
    }
    missing = sorted(field for field in required if field not in context)
    if missing:
        raise ValueError(
            f"Template {template!r} is missing values for: {', '.join(missing)}"
        )
    return template.format(**context)


def normalize_template_context(context: dict[str, Any]) -> dict[str, Any]:
    normalized = dict(context)
    if normalized.get("fy_year") and not normalized.get("year"):
        normalized["year"] = normalized["fy_year"]
    if normalized.get("year") and not normalized.get("yy"):
        normalized["yy"] = str(normalized["year"])[-2:]
    if normalized.get("yy") and not normalized.get("year"):
        normalized["year"] = f"20{normalized['yy']}"
    if normalized.get("year") and not normalized.get("reporting_period_label"):
        normalized["reporting_period_label"] = f"FY{normalized['year']}"
    if normalized.get("entity_id") and not normalized.get("entity_slug"):
        normalized["entity_slug"] = slug(str(normalized["entity_id"]).replace("ENT-", ""))
    if normalized.get("entity_name") and not normalized.get("entity_slug"):
        normalized["entity_slug"] = slug(str(normalized["entity_name"]))
    return normalized


def _jsonb(value: Any) -> str:
    return json.dumps(value or {}, sort_keys=True, default=str)


def assessment_request_exists(
    cur: Any,
    selected_entity_id: str,
    selected_document_id: str,
    profile_id: str,
    profile_version: str,
) -> bool:
    cur.execute(
        """
        SELECT 1
        FROM fsre_config.runtime_requests
        WHERE request_type = 'assessment'
          AND profile_id = %s
          AND profile_version = %s
          AND request_json ->> 'selected_entity_id' = %s
          AND request_json ->> 'selected_document_id' = %s
          AND status IN ('pending','running')
        LIMIT 1
        """,
        (profile_id, profile_version, selected_entity_id, selected_document_id),
    )
    return cur.fetchone() is not None


def get_active_profile_rule_ids(
    cur: Any,
    profile_id: str,
    profile_version: str,
) -> list[str]:
    cur.execute(
        """
        SELECT par.rule_id
        FROM fsre_config.profile_active_rules par
        JOIN fsre_config.deployment_profiles dp
          ON dp.profile_pk = par.profile_pk
        JOIN fsre_rules.rule_registry rr
          ON rr.rule_id = par.rule_id
         AND rr.rule_version = par.rule_version
        WHERE dp.profile_id = %s
          AND dp.profile_version = %s
          AND dp.status = 'active'
          AND rr.status = 'active'
          AND COALESCE((par.rule_config_json ->> 'enabled')::boolean, TRUE) = TRUE
        ORDER BY par.execution_order NULLS LAST, par.rule_id
        """,
        (profile_id, profile_version),
    )
    return [row["rule_id"] for row in cur.fetchall()]


def slug(value: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9]+", "-", value).strip("-")
    return cleaned.upper() or "UNKNOWN"


GENERIC_FILE_NAME_TOKENS = {
    "annual",
    "ar",
    "fy",
    "financial",
    "final",
    "full",
    "integrated",
    "interim",
    "limited",
    "ltd",
    "plc",
    "report",
    "reports",
    "statement",
    "statements",
    "sustainability",
}


def display_entity_name(value: str) -> str:
    words = []
    for word in re.split(r"\s+", value.strip()):
        if not word:
            continue
        words.append(word.upper() if len(word) <= 4 else word.capitalize())
    return " ".join(words)


def title_from_file_name(file_path: str) -> str:
    name = normalize_folder_path(file_path).rsplit("/", 1)[-1]
    stem = name.rsplit(".", 1)[0]
    stem = re.sub(r"[_\-+.]+", " ", stem)
    tokens = []
    for token in re.split(r"\s+", stem):
        cleaned = re.sub(r"[^A-Za-z0-9&]+", "", token).strip()
        if not cleaned:
            continue
        lower = cleaned.lower()
        if re.fullmatch(r"20\d{2}", cleaned) or re.fullmatch(r"\d{2}", cleaned):
            continue
        if (
            re.fullmatch(r"ar\d{2,4}", lower)
            or re.fullmatch(r"fy\d{2,4}", lower)
            or re.fullmatch(r"h[12]fy\d{2,4}", lower)
        ):
            continue
        if lower in GENERIC_FILE_NAME_TOKENS:
            continue
        tokens.append(cleaned)
    return display_entity_name(" ".join(tokens))


def add_inferred_entity_context(
    context: dict[str, Any],
    file_path: str,
    config_metadata: Optional[dict[str, Any]] = None,
) -> dict[str, Any]:
    updated = dict(context)
    metadata = dict(config_metadata or {})
    default_entity_id = metadata.get("default_entity_id")
    default_entity_name = metadata.get("default_entity_name")
    if default_entity_id:
        updated["entity_id"] = default_entity_id
        if default_entity_name:
            updated["entity_name"] = default_entity_name
        return normalize_template_context(updated)

    company_name = title_from_file_name(file_path)
    if company_name:
        updated["entity_name"] = company_name
        updated["entity_id"] = f"ENT-{slug(company_name)}"
    else:
        if default_entity_name:
            updated.setdefault("entity_name", default_entity_name)
    return normalize_template_context(updated)


def infer_document_type(file_path: str, preview_text: str = "") -> str:
    text = re.sub(r"[_\-+.]+", " ", f"{file_path}\n{preview_text}" or "")
    if re.search(r"\bannual\s+report\b|\bAR\s*\d{2,4}\b|\bAR\s+report\b", text, flags=re.IGNORECASE):
        return "annual_report"
    if re.search(r"\bfinancial\s+statements?\b|\bSGX\b", text, flags=re.IGNORECASE):
        return "financial_statement"
    if re.search(r"\bmanagement\s+discussion\b|\bMDA\b", text, flags=re.IGNORECASE):
        return "management_discussion_analysis"
    return "document"


def document_type_label(document_type: str) -> str:
    labels = {
        "annual_report": "Annual Report",
        "financial_statement": "Financial Statement",
        "management_discussion_analysis": "Management Discussion and Analysis",
        "document": "Document",
    }
    return labels.get(document_type, document_type.replace("_", " ").title())


def extract_pdf_preview_text(file_bytes: bytes, max_pages: int = 3) -> str:
    try:
        from io import BytesIO
        from pypdf import PdfReader

        reader = PdfReader(BytesIO(file_bytes))
        texts = []
        for page in reader.pages[:max_pages]:
            texts.append(page.extract_text() or "")
        return "\n".join(texts)
    except Exception:
        return ""


def extract_excel_preview_text(file_bytes: bytes, max_sheets: int = 5, max_rows: int = 12) -> str:
    try:
        from io import BytesIO

        import pandas as pd

        workbook = pd.ExcelFile(BytesIO(file_bytes))
        parts = [f"Workbook sheets: {', '.join(workbook.sheet_names)}"]
        for sheet_name in workbook.sheet_names[:max_sheets]:
            frame = pd.read_excel(
                BytesIO(file_bytes),
                sheet_name=sheet_name,
                header=None,
                nrows=max_rows,
            )
            parts.append(f"Sheet: {sheet_name}")
            for _, row in frame.iterrows():
                values = [
                    str(value).strip()
                    for value in row.tolist()
                    if value is not None and str(value).strip() and str(value) != "nan"
                ]
                if values:
                    parts.append(" | ".join(values[:8]))
        return "\n".join(parts)
    except Exception:
        return ""


def extract_document_preview_text(file_path: str, file_bytes: bytes) -> str:
    extension = file_path.rsplit(".", 1)[-1].lower() if "." in file_path else ""
    if extension == "pdf":
        return extract_pdf_preview_text(file_bytes)
    if extension in {"xlsx", "xls"}:
        return extract_excel_preview_text(file_bytes)
    return ""


def infer_reporting_period(file_path: str, preview_text: str) -> str:
    file_period = infer_reporting_period_from_text(file_path, allow_generic_year=True)
    if file_period:
        return file_period
    preview_period = infer_reporting_period_from_text(preview_text, allow_generic_year=False)
    if preview_period:
        return preview_period
    return UNKNOWN_REPORTING_PERIOD_LABEL


def infer_reporting_period_from_text(text: str, allow_generic_year: bool) -> Optional[str]:
    searchable = re.sub(r"[_\-]+", " ", text or "")
    match = re.search(r"\bH([12])\s*FY\s*(\d{2})\b", searchable, flags=re.IGNORECASE)
    if match:
        return f"H{match.group(1)}FY20{match.group(2)}"
    match = re.search(r"\bH([12])\s*FY\s*((?:19|20)\d{2})\b", searchable, flags=re.IGNORECASE)
    if match:
        return f"H{match.group(1)}FY{match.group(2)}"
    match = re.search(r"\bFY\s*((?:19|20)\d{2})\b", searchable, flags=re.IGNORECASE)
    if match:
        return f"FY{match.group(1)}"
    match = re.search(r"\bFY\s*(\d{2})\b", searchable, flags=re.IGNORECASE)
    if match:
        return f"FY20{match.group(1)}"
    match = re.search(r"\bAR\s*(\d{2})\b", searchable, flags=re.IGNORECASE)
    if match:
        return f"FY20{match.group(1)}"
    match = re.search(r"\bMar\s+(\d{2})\b", searchable, flags=re.IGNORECASE)
    if match:
        return f"FY20{match.group(1)}"
    match = re.search(r"\b((?:19|20)\d{2})\s+annual\s+report\b", searchable, flags=re.IGNORECASE)
    if match:
        return f"FY{match.group(1)}"
    match = re.search(r"\bannual\s+report\s+((?:19|20)\d{2})\b", searchable, flags=re.IGNORECASE)
    if match:
        return f"FY{match.group(1)}"
    if allow_generic_year:
        match = re.search(r"\b((?:19|20)\d{2})\b", searchable)
        if match:
            return f"FY{match.group(1)}"
    return None


def add_inferred_period_context(context: dict[str, Any], file_path: str, preview_text: str) -> dict[str, Any]:
    updated = dict(context)
    period = infer_reporting_period(file_path, preview_text)
    if period != UNKNOWN_REPORTING_PERIOD_LABEL:
        updated.setdefault("reporting_period_label", period)
        year_match = re.search(r"(?:19|20)\d{2}", period)
        if year_match:
            updated.setdefault("year", year_match.group(0))
            updated.setdefault("yy", year_match.group(0)[-2:])
    haystack = file_path if updated.get("reporting_period_label") else f"{file_path}\n{preview_text}"
    match = re.search(r"\bH([12])\s*FY\s*(\d{2})\b", haystack, flags=re.IGNORECASE)
    if match:
        updated.setdefault("half", match.group(1))
        updated.setdefault("yy", match.group(2))
        updated.setdefault("year", f"20{match.group(2)}")
        updated.setdefault("reporting_period_label", f"H{match.group(1)}FY20{match.group(2)}")
    match = re.search(r"\bFY\s*((?:19|20)\d{2})\b", haystack, flags=re.IGNORECASE)
    if match:
        updated.setdefault("year", match.group(1))
    match = re.search(r"\bFY\s*(\d{2})\b", haystack, flags=re.IGNORECASE)
    if match:
        updated.setdefault("yy", match.group(1))
        updated.setdefault("year", f"20{match.group(1)}")
    match = re.search(r"\bAR\s*(\d{2})\b", haystack, flags=re.IGNORECASE)
    if match:
        updated.setdefault("yy", match.group(1))
        updated.setdefault("year", f"20{match.group(1)}")
    match = re.search(r"\bMar[_\-\s]+(\d{2})\b", haystack, flags=re.IGNORECASE)
    if match:
        updated.setdefault("yy", match.group(1))
        updated.setdefault("year", f"20{match.group(1)}")
    match = re.search(r"\bH([12])\s*FY\s*((?:19|20)\d{2})\b", haystack, flags=re.IGNORECASE)
    if match:
        updated.setdefault("half", match.group(1))
        updated.setdefault("year", match.group(2))
        updated.setdefault("reporting_period_label", f"H{match.group(1)}FY{match.group(2)}")
    match = re.search(r"\b((?:19|20)\d{2})\b", haystack)
    if match:
        updated.setdefault("year", match.group(1))
    normalized = normalize_template_context(updated)
    if not normalized.get("reporting_period_label"):
        normalized["reporting_period_label"] = UNKNOWN_REPORTING_PERIOD_LABEL
        normalized["reporting_period_inference_status"] = "fallback_unknown"
    else:
        normalized.setdefault("reporting_period_inference_status", "inferred")
    return normalized


def infer_document_metadata(file_path: str, file_bytes: bytes, checksum_sha256: str) -> dict[str, str]:
    preview_text = extract_document_preview_text(file_path, file_bytes)
    reporting_period_label = infer_reporting_period(file_path, preview_text)
    company_name = title_from_file_name(file_path)
    entity_id = f"ENT-{slug(company_name)}"
    source_document_id = f"DOC-{slug(company_name)}-{reporting_period_label}-{checksum_sha256[:12]}"
    document_name = f"{company_name} Annual Report {reporting_period_label}"
    return {
        "selected_entity_id": entity_id,
        "source_document_id": source_document_id,
        "document_name": document_name,
        "reporting_period_label": reporting_period_label,
        "company_name": company_name,
        "preview_text_found": "true" if preview_text.strip() else "false",
    }


def list_active_document_classification_rules(
    cur: Any,
    config: dict[str, Any],
) -> list[dict[str, Any]]:
    cur.execute(
        """
        SELECT *
        FROM fsre_config.document_classification_rules
        WHERE status = 'active'
          AND profile_id IN ('*', %s)
          AND profile_version IN ('*', %s)
          AND connector_id IN ('*', %s)
          AND connector_version IN ('*', COALESCE(%s, '*'))
          AND environment IN ('*', %s)
        ORDER BY
          CASE WHEN profile_id = %s THEN 0 ELSE 1 END,
          CASE WHEN profile_version = %s THEN 0 ELSE 1 END,
          CASE WHEN connector_id = %s THEN 0 ELSE 1 END,
          CASE WHEN connector_version = COALESCE(%s, '*') THEN 0 ELSE 1 END,
          CASE WHEN environment = %s THEN 0 ELSE 1 END,
          priority ASC,
          updated_at DESC,
          created_at DESC
        """,
        (
            config["profile_id"],
            config["profile_version"],
            config["connector_id"],
            config.get("connector_version"),
            config["environment"],
            config["profile_id"],
            config["profile_version"],
            config["connector_id"],
            config.get("connector_version"),
            config["environment"],
        ),
    )
    return [dict(row) for row in cur.fetchall()]


def regex_match(pattern: str | None, value: str) -> re.Match[str] | None:
    if not pattern:
        return None
    return re.search(pattern, value, flags=re.IGNORECASE | re.MULTILINE)


def match_document_classification_rule(
    rule: dict[str, Any],
    file_path: str,
    extension: str,
    preview_text: str,
) -> dict[str, str] | None:
    expected_extension = (rule.get("file_extension") or "").strip().lower().lstrip(".")
    if expected_extension and expected_extension != extension:
        return None

    values: dict[str, str] = {}
    matched = bool(expected_extension)

    file_match = regex_match(rule.get("file_name_regex"), normalize_folder_path(file_path))
    if rule.get("file_name_regex") and not file_match:
        return None
    if file_match:
        values.update({key: value for key, value in file_match.groupdict().items() if value})
        matched = True

    preview_match = regex_match(rule.get("preview_text_regex"), preview_text)
    if rule.get("preview_text_regex") and not preview_match:
        return None
    if preview_match:
        values.update({key: value for key, value in preview_match.groupdict().items() if value})
        matched = True

    return values if matched else None


def classify_document_from_rules(
    cur: Any,
    config: dict[str, Any],
    file_path: str,
    file_bytes: bytes,
    checksum_sha256: str,
    regex_values: dict[str, str],
) -> dict[str, Any] | None:
    file_name = normalize_folder_path(file_path)
    file_stem = file_name.rsplit("/", 1)[-1].rsplit(".", 1)[0]
    extension = file_name.rsplit(".", 1)[-1].lower() if "." in file_name else ""
    preview_text = extract_document_preview_text(file_name, file_bytes)
    config_metadata = dict(config.get("metadata_json") or {})

    base_context = normalize_template_context(
        {
            **regex_values,
            "file_name": file_name,
            "file_stem": file_stem,
            "file_extension": extension,
            "checksum_sha256": checksum_sha256,
            "checksum12": checksum_sha256[:12],
        }
    )
    base_context = add_inferred_entity_context(base_context, file_name, config_metadata)
    base_context = add_inferred_period_context(base_context, file_name, preview_text)

    for rule in list_active_document_classification_rules(cur, config):
        rule_values = match_document_classification_rule(
            rule,
            file_name,
            extension,
            preview_text,
        )
        if rule_values is None:
            continue

        context = normalize_template_context(
            {
                **base_context,
                **rule_values,
                "document_type": rule["document_type"],
                "classification_rule_id": rule["classification_rule_id"],
            }
        )
        context = add_inferred_period_context(context, file_name, preview_text)

        return {
            "document_type": rule["document_type"],
            "selected_entity_id": render_template(rule["entity_id_template"], context),
            "selected_document_id": render_template(rule["source_document_id_template"], context),
            "document_name": render_template(rule["document_name_template"], context),
            "reporting_period_label": render_template(
                rule.get("reporting_period_label_template"),
                context,
            ),
            "classification_rule_id": rule["classification_rule_id"],
            "classification_confidence": str(rule["confidence"]),
            "reporting_period_inference_status": context.get("reporting_period_inference_status", "inferred"),
            "preview_text_found": "true" if preview_text.strip() else "false",
        }

    return None


def should_use_document_classifier(config: dict[str, Any]) -> bool:
    metadata = dict(config.get("metadata_json") or {})
    return (
        str(config.get("document_type") or "").lower() in {"auto", "classified"}
        or metadata.get("classification_mode") == "document_classifier"
    )


def register_document_and_create_assessment(
    cur: Any,
    config: dict[str, Any],
    file_path: str,
    checksum_sha256: str,
    file_size_bytes: int,
    regex_values: dict[str, str],
    file_bytes: Optional[bytes] = None,
    selected_company_name: Optional[str] = None,
) -> dict[str, Any] | None:
    file_name = normalize_folder_path(file_path)
    file_stem = file_name.rsplit("/", 1)[-1].rsplit(".", 1)[0]
    context = {
        **regex_values,
        "file_name": file_name,
        "file_stem": file_stem,
        "checksum_sha256": checksum_sha256,
        "checksum12": checksum_sha256[:12],
    }

    classification = None
    if file_bytes is not None and should_use_document_classifier(config):
        classification = classify_document_from_rules(
            cur,
            config,
            file_path,
            file_bytes,
            checksum_sha256,
            regex_values,
        )
        if classification is None:
            print(
                "No document classification rule matched "
                f"{file_name}; falling back to intake config document_type."
            )

    if classification:
        document_type = classification["document_type"]
        selected_entity_id = classification["selected_entity_id"]
        selected_document_id = classification["selected_document_id"]
        document_name = classification["document_name"]
        reporting_period_label = classification["reporting_period_label"]
        reporting_period_inference_status = classification.get("reporting_period_inference_status", "inferred")
    else:
        context = add_inferred_entity_context(context, file_name, dict(config.get("metadata_json") or {}))
        context = add_inferred_period_context(context, file_name, "")
        configured_document_type = str(config.get("document_type") or "").strip()
        document_type = (
            infer_document_type(file_name, "")
            if configured_document_type.lower() in {"", "auto", "classified"}
            else configured_document_type
        )
        context["document_type"] = document_type
        selected_entity_id = render_template(config["entity_id_template"], context)
        selected_document_id = render_template(config["source_document_id_template"], context)
        document_name = render_template(config["document_name_template"], context)
        if document_name:
            document_name = document_name.replace(document_type, document_type_label(document_type))
        reporting_period_label = render_template(
            config.get("reporting_period_label_template"),
            context,
        )
        reporting_period_inference_status = context.get("reporting_period_inference_status", "inferred")

    selected_company_name = str(selected_company_name or "").strip()
    if selected_company_name:
        selected_entity_id = f"ENT-{slug(selected_company_name)}"
        selected_document_id = f"DOC-{slug(selected_company_name)}-{reporting_period_label}-{checksum_sha256[:12]}"
        document_name = f"{selected_company_name} {document_type_label(document_type)} {reporting_period_label}".strip()

    if not selected_entity_id or not selected_document_id or not document_name:
        raise ValueError(
            f"Intake config {config['intake_config_id']} produced incomplete document values"
        )

    if not config.get("reprocess_existing") and assessment_request_exists(
        cur,
        selected_entity_id,
        selected_document_id,
        config["profile_id"],
        config["profile_version"],
    ):
        return None

    metadata = dict(config.get("metadata_json") or {})
    metadata.update(
        {
            "intake_config_id": config["intake_config_id"],
            "file_size_bytes": file_size_bytes,
            "checksum_sha256": checksum_sha256,
            "classification": classification or {},
            "reporting_period_inference_status": reporting_period_inference_status,
            "company_name_selected": selected_company_name or None,
            "entity_selection_mode": "explicit_company" if selected_company_name else "inferred",
        }
    )

    cur.execute(
        """
        SELECT *
        FROM fsre_config.register_source_document(
            %s, %s, %s, %s, %s,
            'dataiku_managed_folder',
            %s, %s,
            NULL::text,
            NULL::text,
            %s, %s, %s,
            NULL::date,
            %s::jsonb
        )
        """,
        (
            selected_document_id,
            selected_entity_id,
            document_type,
            document_name,
            reporting_period_label,
            config["managed_folder_id"],
            file_name,
            config["connector_id"],
            config["connector_version"],
            config["requested_by"],
            _jsonb(metadata),
        ),
    )
    cur.fetchone()

    assessment_driver_types = metadata.get("assessment_driver_document_types")
    if isinstance(assessment_driver_types, str):
        assessment_driver_types = json.loads(assessment_driver_types)
    if assessment_driver_types and document_type not in assessment_driver_types:
        print(
            f"Registered {file_name} as {document_type}; "
            "skipping assessment request because it is not configured as an "
            "assessment driver document type."
        )
        return None

    selected_rule_ids = config.get("selected_rule_ids_json")
    if isinstance(selected_rule_ids, str):
        selected_rule_ids = json.loads(selected_rule_ids)
    if not selected_rule_ids:
        selected_rule_ids = get_active_profile_rule_ids(
            cur,
            config["profile_id"],
            config["profile_version"],
        )
    if not selected_rule_ids:
        raise ValueError(
            f"No active rules found for profile {config['profile_id']}/{config['profile_version']}"
        )

    request_json = {
        "selected_entity_id": selected_entity_id,
        "selected_document_id": selected_document_id,
        "selected_rule_ids": selected_rule_ids,
        "requested_by": config["requested_by"],
        "run_source": config["run_source"],
        "run_mode": config["run_mode"],
        "environment": config["environment"],
        "evidence_depth": config["evidence_depth"],
        "selected_profile_id": config["profile_id"],
        "selected_profile_version": config["profile_version"],
    }
    return create_runtime_request(
        cur,
        request_type="assessment",
        request_name=f"Assessment request for {selected_document_id}",
        requested_by=config["requested_by"],
        environment=config["environment"],
        profile_id=config["profile_id"],
        profile_version=config["profile_version"],
        request_json=request_json,
    )


def find_registered_document_by_checksum(cur: Any, checksum_sha256: str) -> dict[str, Any] | None:
    cur.execute(
        """
        SELECT *
        FROM fsre_config.source_document_registry
        WHERE metadata_json ->> 'checksum_sha256' = %s
          AND status = 'ready'
        ORDER BY updated_at DESC, created_at DESC
        LIMIT 1
        """,
        (checksum_sha256,),
    )
    row = cur.fetchone()
    return dict(row) if row else None


def create_assessment_request_for_document(
    cur: Any,
    document: dict[str, Any],
    defaults: dict[str, Any],
) -> dict[str, Any] | None:
    selected_entity_id = document["entity_id"]
    selected_document_id = document["source_document_id"]
    if not selected_entity_id or not selected_document_id:
        raise ValueError(
            "Registered source document must have entity_id and source_document_id "
            "before assessment request creation."
        )

    if assessment_request_exists(
        cur,
        selected_entity_id,
        selected_document_id,
        defaults["profile_id"],
        defaults["profile_version"],
    ):
        return None

    selected_rule_ids = get_active_profile_rule_ids(
        cur,
        defaults["profile_id"],
        defaults["profile_version"],
    )
    if not selected_rule_ids:
        raise ValueError(
            f"No active rules found for profile {defaults['profile_id']}/{defaults['profile_version']}"
        )

    request_json = {
        "selected_entity_id": selected_entity_id,
        "selected_document_id": selected_document_id,
        "selected_rule_ids": selected_rule_ids,
        "requested_by": defaults["requested_by"],
        "run_source": defaults["run_source"],
        "run_mode": defaults["run_mode"],
        "environment": defaults["environment"],
        "evidence_depth": defaults["evidence_depth"],
        "selected_profile_id": defaults["profile_id"],
        "selected_profile_version": defaults["profile_version"],
    }
    return create_runtime_request(
        cur,
        request_type="assessment",
        request_name=f"Assessment request for {selected_document_id}",
        requested_by=defaults["requested_by"],
        environment=defaults["environment"],
        profile_id=defaults["profile_id"],
        profile_version=defaults["profile_version"],
        request_json=request_json,
    )


def register_auto_discovered_document_and_create_assessment(
    cur: Any,
    managed_folder_id: str,
    file_path: str,
    checksum_sha256: str,
    file_size_bytes: int,
    file_bytes: bytes,
    selected_company_name: Optional[str] = None,
) -> dict[str, Any] | None:
    defaults = get_default_intake_settings(cur)
    selected_company_name = str(selected_company_name or "").strip()
    selected_entity_id = f"ENT-{slug(selected_company_name)}" if selected_company_name else ""
    existing_document = find_registered_document_by_checksum(cur, checksum_sha256)
    if existing_document and (
        not selected_entity_id or str(existing_document.get("entity_id") or "") == selected_entity_id
    ):
        return create_assessment_request_for_document(cur, existing_document, defaults)

    inferred = infer_document_metadata(file_path, file_bytes, checksum_sha256)
    if selected_company_name:
        inferred["company_name"] = selected_company_name
        inferred["selected_entity_id"] = selected_entity_id
        inferred["source_document_id"] = f"DOC-{slug(selected_company_name)}-{inferred['reporting_period_label']}-{checksum_sha256[:12]}"
        inferred["document_name"] = f"{selected_company_name} Annual Report {inferred['reporting_period_label']}"
    metadata = {
        "intake_mode": "auto_discovered_managed_folder",
        "managed_folder_id": managed_folder_id,
        "file_size_bytes": file_size_bytes,
        "checksum_sha256": checksum_sha256,
        "company_name_inferred": inferred["company_name"],
        "company_name_selected": selected_company_name or None,
        "entity_selection_mode": "explicit_company" if selected_company_name else "inferred",
        "preview_text_found": inferred["preview_text_found"],
    }

    cur.execute(
        """
        SELECT *
        FROM fsre_config.register_source_document(
            %s, %s, 'annual_report', %s, %s,
            'dataiku_managed_folder',
            %s, %s,
            NULL::text,
            NULL::text,
            %s, %s, %s,
            NULL::date,
            %s::jsonb
        )
        """,
        (
            inferred["source_document_id"],
            inferred["selected_entity_id"],
            inferred["document_name"],
            inferred["reporting_period_label"],
            managed_folder_id,
            normalize_folder_path(file_path),
            defaults["connector_id"],
            defaults["connector_version"],
            defaults["requested_by"],
            _jsonb(metadata),
        ),
    )
    cur.fetchone()

    document = {
        "entity_id": inferred["selected_entity_id"],
        "source_document_id": inferred["source_document_id"],
    }
    return create_assessment_request_for_document(cur, document, defaults)
