"""FRI_03C_VALIDATE_TABLE_STRUCTURE

Dataiku Python recipe bindings
------------------------------
Inputs:
    FRI_EXTRACTED_TABLES
    FRI_EXTRACTED_TABLE_CELLS

Outputs:
    FRI_VALIDATED_TABLE_ARTIFACTS
    FRI_VALIDATED_TABLE_CELLS
    FRI_TABLE_VALIDATION_EXCEPTIONS

This recipe performs deterministic structural validation only. It does not
calculate financial risk, run Tier 1 accounting reconciliations, or call an
LLM. The output contains only non-empty cells while retaining row/column
coordinates, so the original logical grid can be reconstructed.
"""

from __future__ import annotations

import hashlib
import json
import math
import re
from datetime import datetime, timezone
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import dataiku
import pandas as pd


INPUT_TABLES = "FRI_EXTRACTED_TABLES"
INPUT_CELLS = "FRI_EXTRACTED_TABLE_CELLS"

OUTPUT_ARTIFACTS = "FRI_VALIDATED_TABLE_ARTIFACTS"
OUTPUT_CELLS = "FRI_VALIDATED_TABLE_CELLS"
OUTPUT_EXCEPTIONS = "FRI_TABLE_VALIDATION_EXCEPTIONS"

VALIDATOR_VERSION = "fri-table-structure-validator-1.0.0"

# These are structural safety limits, not financial rules. They prevent a
# complete narrative page from being accepted as one enormous table.
MAX_REASONABLE_ROWS = 250
MAX_REASONABLE_COLUMNS = 30
MAX_REASONABLE_NON_EMPTY_CELLS = 3500
MIN_NON_EMPTY_CELLS = 4
MIN_NUMERIC_RATIO_FOR_FINANCIAL_TABLE = 0.08
MIN_ACCEPTED_SCORE = 70.0
MIN_WARNING_SCORE = 50.0


ARTIFACT_COLUMNS = [
    "tenant_id", "entity_id", "assessment_run_id", "source_document_id",
    "table_artifact_id", "source_table_id", "page_number", "table_number",
    "table_title", "statement_type", "table_bbox_json", "page_image_path",
    "table_crop_path", "reporting_date", "presentation_currency",
    "presentation_unit", "row_count", "column_count", "non_empty_cell_count",
    "numeric_cell_count", "numeric_cell_ratio", "header_cell_count",
    "period_labels_json", "entity_scopes_json", "grid_json",
    "header_tree_json", "merged_cells_json", "extraction_method", "model_name",
    "extractor_version", "validator_version", "structure_score",
    "table_confidence", "validation_status", "exception_count",
    "validated_at",
]

CELL_COLUMNS = [
    "tenant_id", "entity_id", "assessment_run_id", "source_document_id",
    "table_artifact_id", "source_table_id", "page_number", "table_number",
    "row_index", "column_index", "row_span", "column_span", "cell_role",
    "row_label", "header_path", "entity_scope", "period_label",
    "note_reference", "raw_text", "normalized_text", "numeric_value",
    "currency", "unit", "cell_bbox_json", "extraction_confidence",
    "structure_score", "validation_status", "validator_version",
]

EXCEPTION_COLUMNS = [
    "tenant_id", "entity_id", "assessment_run_id", "source_document_id",
    "table_artifact_id", "source_table_id", "page_number", "table_number",
    "exception_code", "severity", "field_name", "observed_value",
    "message", "recommended_action", "validator_version", "created_at",
]


ALIASES = {
    "tenant_id": ["tenant_id"],
    "entity_id": ["entity_id"],
    "assessment_run_id": ["assessment_run_id", "run_id"],
    "source_document_id": ["source_document_id", "document_id"],
    "source_table_id": ["source_table_id", "table_artifact_id", "table_id"],
    "page_number": ["page_number", "page_no", "page_index"],
    "table_number": ["table_number", "table_index", "table_no"],
    "table_title": ["table_title", "title", "caption"],
    "statement_type": ["statement_type", "table_type", "document_section"],
    "table_bbox_json": ["table_bbox_json", "table_bbox", "bbox_json", "bbox"],
    "page_image_path": ["page_image_path", "page_image_uri"],
    "table_crop_path": ["table_crop_path", "crop_image_path", "table_image_path"],
    "reporting_date": ["reporting_date", "period_end"],
    "presentation_currency": ["presentation_currency", "currency"],
    "presentation_unit": ["presentation_unit", "unit"],
    "row_count": ["row_count", "number_of_rows"],
    "column_count": ["column_count", "number_of_columns", "col_count"],
    "grid_json": ["grid_json", "table_grid_json", "layout_json"],
    "header_tree_json": ["header_tree_json", "headers_json"],
    "merged_cells_json": ["merged_cells_json", "merged_ranges_json"],
    "extraction_method": ["extraction_method", "extractor", "strategy"],
    "model_name": ["model_name", "llm_model", "vision_model"],
    "extractor_version": ["extractor_version", "extraction_version"],
    "row_index": ["row_index", "row_number", "row_no"],
    "column_index": ["column_index", "column_number", "column_no", "col_index"],
    "row_span": ["row_span", "rowspan"],
    "column_span": ["column_span", "col_span", "colspan"],
    "cell_role": ["cell_role", "role", "cell_type"],
    "row_label": ["row_label", "line_item", "line_item_label"],
    "header_path": ["header_path", "column_header", "header"],
    "entity_scope": ["entity_scope", "column_scope", "scope"],
    "period_label": ["period_label", "period", "year"],
    "note_reference": ["note_reference", "note_ref", "note"],
    "raw_text": ["raw_text", "cell_text", "text", "value_text"],
    "normalized_text": ["normalized_text", "clean_text"],
    "numeric_value": ["numeric_value", "parsed_numeric_value", "value_numeric"],
    "currency": ["currency", "presentation_currency"],
    "unit": ["unit", "presentation_unit"],
    "cell_bbox_json": ["cell_bbox_json", "cell_bbox", "bbox_json", "bbox"],
    "extraction_confidence": ["extraction_confidence", "confidence"],
}


FINANCIAL_TITLE_PATTERNS = {
    "BALANCE_SHEET": [
        r"\bbalance\s+sheets?\b", r"\bstatements?\s+of\s+financial\s+position\b",
    ],
    "INCOME_STATEMENT": [
        r"\bincome\s+statements?\b", r"\bprofit\s+and\s+loss\b",
        r"\b(?:consolidated\s+)?statements?\s+of\s+profit\s+or\s+loss(?:\s+and\s+other\s+comprehensive\s+income)?\b",
        r"\bstatement\s+of\s+(?:comprehensive\s+)?income\b",
    ],
    "CASH_FLOW_STATEMENT": [
        r"\bcash\s+flow\s+statements?\b", r"\bstatement\s+of\s+cash\s+flows?\b",
    ],
    "CHANGES_IN_EQUITY": [
        r"\bchanges?\s+in\s+equity\b", r"\bshareholders['’]?\s+equity\b",
    ],
    "NOTES_TABLE": [r"\bnotes?\s+to\s+the\s+financial\s+statements?\b"],
}

PERIOD_PATTERN = re.compile(r"\b(?:19|20)\d{2}\b")
NUMBER_PATTERN = re.compile(
    r"^\s*[\(\-+]?\s*(?:[$€£₹]\s*)?(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?%?\s*\)?\s*$"
)
FRAGMENT_PATTERN = re.compile(r"^[A-Za-z]{1,2}$")


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def is_missing(value: Any) -> bool:
    if value is None:
        return True
    try:
        if pd.isna(value):
            return True
    except (TypeError, ValueError):
        pass
    return str(value).strip().lower() in {"", "nan", "none", "null", "nat"}


def text_value(value: Any, default: str = "") -> str:
    return default if is_missing(value) else str(value).strip()


def first_present(row: Dict[str, Any], canonical_name: str, default: Any = None) -> Any:
    for candidate in ALIASES.get(canonical_name, [canonical_name]):
        if candidate in row and not is_missing(row.get(candidate)):
            return row.get(candidate)
    return default


def integer_value(value: Any, default: int = 0) -> int:
    if is_missing(value):
        return default
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return default


def float_value(value: Any) -> Optional[float]:
    if is_missing(value):
        return None
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        try:
            return float(value)
        except (TypeError, ValueError):
            return None
    candidate = str(value).strip()
    negative = candidate.startswith("(") and candidate.endswith(")")
    candidate = candidate.strip("()").replace(",", "")
    candidate = re.sub(r"[$€£₹%]", "", candidate).strip()
    if candidate in {"", "-", "–", "—"}:
        return None
    try:
        parsed = float(candidate)
        return -parsed if negative else parsed
    except ValueError:
        return None


def json_text(value: Any, default: Any) -> str:
    if is_missing(value):
        return json.dumps(default, ensure_ascii=False, sort_keys=True)
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False, sort_keys=True)
    candidate = str(value).strip()
    try:
        return json.dumps(json.loads(candidate), ensure_ascii=False, sort_keys=True)
    except (json.JSONDecodeError, TypeError):
        return json.dumps(value, ensure_ascii=False)


def stable_id(parts: Sequence[Any]) -> str:
    material = "|".join(text_value(part) for part in parts)
    return hashlib.sha256(material.encode("utf-8")).hexdigest()[:32]


def canonical_source_table_id(row: Dict[str, Any]) -> str:
    existing = first_present(row, "source_table_id")
    if not is_missing(existing):
        return text_value(existing)
    return stable_id([
        first_present(row, "tenant_id"), first_present(row, "assessment_run_id"),
        first_present(row, "source_document_id"), first_present(row, "page_number"),
        first_present(row, "table_number"),
    ])


def classify_statement(title: str, existing: str, cell_text: str) -> str:
    if existing and existing.upper() not in {"UNKNOWN", "UNSPECIFIED", "NONE"}:
        return existing.upper().replace(" ", "_")
    searchable = f"{title} {cell_text[:3000]}".lower()
    for statement_type, patterns in FINANCIAL_TITLE_PATTERNS.items():
        if any(re.search(pattern, searchable, re.IGNORECASE) for pattern in patterns):
            return statement_type
    return "UNCLASSIFIED"


def cell_is_numeric(row: Dict[str, Any], raw_text: str) -> bool:
    if float_value(first_present(row, "numeric_value")) is not None:
        return True
    return bool(NUMBER_PATTERN.match(raw_text))


def make_exception(
    context: Dict[str, Any], code: str, severity: str, field_name: str,
    observed_value: Any, message: str, recommended_action: str,
) -> Dict[str, Any]:
    return {
        "tenant_id": context["tenant_id"],
        "entity_id": context["entity_id"],
        "assessment_run_id": context["assessment_run_id"],
        "source_document_id": context["source_document_id"],
        "table_artifact_id": context["table_artifact_id"],
        "source_table_id": context["source_table_id"],
        "page_number": context["page_number"],
        "table_number": context["table_number"],
        "exception_code": code,
        "severity": severity,
        "field_name": field_name,
        "observed_value": text_value(observed_value),
        "message": message,
        "recommended_action": recommended_action,
        "validator_version": VALIDATOR_VERSION,
        "created_at": utc_now(),
    }


def read_dataset(name: str) -> pd.DataFrame:
    try:
        return dataiku.Dataset(name).get_dataframe(infer_with_pandas=False)
    except TypeError:
        return dataiku.Dataset(name).get_dataframe()


tables_df = read_dataset(INPUT_TABLES)
cells_df = read_dataset(INPUT_CELLS)

print(json.dumps({
    "input_tables_dataset": INPUT_TABLES,
    "input_tables_row_count": len(tables_df),
    "input_tables_columns": list(tables_df.columns),
    "input_cells_dataset": INPUT_CELLS,
    "input_cells_row_count": len(cells_df),
    "input_cells_columns": list(cells_df.columns),
}, indent=2, default=str))

if tables_df.empty and cells_df.empty:
    raise RuntimeError(
        "Both FRI_EXTRACTED_TABLES and FRI_EXTRACTED_TABLE_CELLS are empty. "
        "Run FRI_03B_EXTRACT_TABLE_LAYOUTS successfully before Recipe 03C."
    )

if cells_df.empty:
    raise RuntimeError(
        "FRI_EXTRACTED_TABLE_CELLS is empty. Table structure cannot be "
        "validated without extracted non-empty cells."
    )

table_records = tables_df.to_dict(orient="records") if not tables_df.empty else []
cell_records = cells_df.to_dict(orient="records") if not cells_df.empty else []

cells_by_table: Dict[str, List[Dict[str, Any]]] = {}
for cell in cell_records:
    cells_by_table.setdefault(canonical_source_table_id(cell), []).append(cell)

table_by_id: Dict[str, Dict[str, Any]] = {}
for table in table_records:
    table_by_id[canonical_source_table_id(table)] = table

# If the table-level input is empty or incomplete, derive table records from the
# cell input. This keeps the validator usable while the extraction flow evolves.
for source_table_id, grouped_cells in cells_by_table.items():
    if source_table_id not in table_by_id and grouped_cells:
        table_by_id[source_table_id] = dict(grouped_cells[0])

artifact_rows: List[Dict[str, Any]] = []
validated_cell_rows: List[Dict[str, Any]] = []
exception_rows: List[Dict[str, Any]] = []

for source_table_id, table in table_by_id.items():
    source_cells = cells_by_table.get(source_table_id, [])
    tenant_id = text_value(first_present(table, "tenant_id"))
    entity_id = text_value(first_present(table, "entity_id"))
    run_id = text_value(first_present(table, "assessment_run_id"))
    document_id = text_value(first_present(table, "source_document_id"))
    page_number = integer_value(first_present(table, "page_number"), -1)
    table_number = integer_value(first_present(table, "table_number"), 0)
    artifact_id = stable_id([tenant_id, run_id, document_id, page_number, table_number, source_table_id])

    context = {
        "tenant_id": tenant_id,
        "entity_id": entity_id,
        "assessment_run_id": run_id,
        "source_document_id": document_id,
        "table_artifact_id": artifact_id,
        "source_table_id": source_table_id,
        "page_number": page_number,
        "table_number": table_number,
    }

    normalized_cells: List[Dict[str, Any]] = []
    coordinates: List[Tuple[int, int]] = []
    periods = set()
    scopes = set()
    header_count = 0
    numeric_count = 0
    fragment_count = 0

    for source_cell in source_cells:
        raw = text_value(first_present(source_cell, "raw_text"))
        normalized = text_value(first_present(source_cell, "normalized_text"), raw)
        if not raw and not normalized:
            continue

        row_index = integer_value(first_present(source_cell, "row_index"), -1)
        column_index = integer_value(first_present(source_cell, "column_index"), -1)
        coordinates.append((row_index, column_index))
        role = text_value(first_present(source_cell, "cell_role"), "DATA").upper()
        header_path = text_value(first_present(source_cell, "header_path"))
        period = text_value(first_present(source_cell, "period_label"))
        scope = text_value(first_present(source_cell, "entity_scope"))
        numeric = float_value(first_present(source_cell, "numeric_value"))
        if numeric is None:
            numeric = float_value(raw) if NUMBER_PATTERN.match(raw) else None

        if role in {"HEADER", "COLUMN_HEADER", "ROW_HEADER", "TITLE"} or header_path:
            header_count += 1
        if numeric is not None:
            numeric_count += 1
        if FRAGMENT_PATTERN.match(raw):
            fragment_count += 1
        if period:
            periods.update(PERIOD_PATTERN.findall(period) or [period])
        else:
            periods.update(PERIOD_PATTERN.findall(f"{header_path} {raw}"))
        if scope and scope.lower() not in {"unspecified", "unknown", "none"}:
            scopes.add(scope)

        normalized_cells.append({
            **context,
            "row_index": row_index,
            "column_index": column_index,
            "row_span": max(1, integer_value(first_present(source_cell, "row_span"), 1)),
            "column_span": max(1, integer_value(first_present(source_cell, "column_span"), 1)),
            "cell_role": role,
            "row_label": text_value(first_present(source_cell, "row_label")),
            "header_path": header_path,
            "entity_scope": scope,
            "period_label": period,
            "note_reference": text_value(first_present(source_cell, "note_reference")),
            "raw_text": raw,
            "normalized_text": normalized,
            "numeric_value": numeric,
            "currency": text_value(first_present(source_cell, "currency")),
            "unit": text_value(first_present(source_cell, "unit")),
            "cell_bbox_json": json_text(first_present(source_cell, "cell_bbox_json"), {}),
            "extraction_confidence": float_value(first_present(source_cell, "extraction_confidence")),
        })

    inferred_rows = max((r for r, _ in coordinates if r >= 0), default=-1) + 1
    inferred_columns = max((c for _, c in coordinates if c >= 0), default=-1) + 1
    row_count = max(integer_value(first_present(table, "row_count"), 0), inferred_rows)
    column_count = max(integer_value(first_present(table, "column_count"), 0), inferred_columns)
    non_empty_count = len(normalized_cells)
    numeric_ratio = numeric_count / non_empty_count if non_empty_count else 0.0
    fragment_ratio = fragment_count / non_empty_count if non_empty_count else 0.0
    duplicate_coordinate_count = len(coordinates) - len(set(coordinates))
    title = text_value(first_present(table, "table_title"))
    complete_text = " ".join(cell["raw_text"] for cell in normalized_cells)
    statement_type = classify_statement(
        title,
        text_value(first_present(table, "statement_type")),
        complete_text,
    )

    score_box = [100.0]
    current_exceptions: List[Dict[str, Any]] = []

    def issue(code: str, severity: str, field: str, value: Any,
              message: str, action: str, penalty: float) -> None:
        score_box[0] -= penalty
        current_exceptions.append(
            make_exception(context, code, severity, field, value, message, action)
        )

    missing_ids = [name for name, value in [
        ("tenant_id", tenant_id), ("assessment_run_id", run_id),
        ("source_document_id", document_id),
    ] if not value]
    if missing_ids:
        issue("MISSING_LINEAGE", "ERROR", ",".join(missing_ids), "",
              "Required lineage identifiers are missing.",
              "Return the table to extraction/registration before financial resolution.", 45)
    if page_number < 0:
        issue("INVALID_PAGE_NUMBER", "ERROR", "page_number", page_number,
              "The source page number is missing or invalid.",
              "Populate the original PDF page number.", 25)
    if non_empty_count < MIN_NON_EMPTY_CELLS:
        issue("TABLE_TOO_SPARSE", "ERROR", "non_empty_cell_count", non_empty_count,
              "Too few non-empty cells exist to represent a useful table.",
              "Reject the region or retry table detection.", 50)
    if row_count <= 0 or column_count <= 0:
        issue("INVALID_DIMENSIONS", "ERROR", "row_count/column_count",
              f"{row_count}/{column_count}", "Table dimensions cannot be reconstructed.",
              "Retry extraction with row and column coordinates.", 50)
    if row_count > MAX_REASONABLE_ROWS:
        issue("EXCESSIVE_ROWS", "ERROR", "row_count", row_count,
              "The detected table probably contains an entire page or multiple tables.",
              "Redetect table regions and extract each crop independently.", 35)
    if column_count > MAX_REASONABLE_COLUMNS:
        issue("EXCESSIVE_COLUMNS", "ERROR", "column_count", column_count,
              "The detected table has an implausible number of columns.",
              "Redetect the table bounding box or resolve merged headers.", 35)
    if non_empty_count > MAX_REASONABLE_NON_EMPTY_CELLS:
        issue("EXCESSIVE_CELL_COUNT", "ERROR", "non_empty_cell_count", non_empty_count,
              "The region is too large to be accepted as a single financial table.",
              "Split the page into genuine table regions.", 30)
    if duplicate_coordinate_count > 0:
        issue("DUPLICATE_CELL_COORDINATE", "ERROR", "cell_coordinates",
              duplicate_coordinate_count, "Multiple cells occupy the same grid coordinate.",
              "Deduplicate cells or rerun layout extraction.", 25)
    if header_count == 0:
        issue("HEADER_NOT_RESOLVED", "WARNING", "header_cell_count", header_count,
              "No table headers or header paths were resolved.",
              "Retry header detection; use vision only if deterministic recovery fails.", 20)
    if statement_type != "UNCLASSIFIED" and numeric_ratio < MIN_NUMERIC_RATIO_FOR_FINANCIAL_TABLE:
        issue("LOW_NUMERIC_DENSITY", "WARNING", "numeric_cell_ratio",
              round(numeric_ratio, 4), "The proposed financial table has low numeric density.",
              "Verify that the region is not narrative text.", 25)
    if fragment_ratio > 0.20:
        issue("FRAGMENTED_TEXT", "WARNING", "fragment_ratio", round(fragment_ratio, 4),
              "Many cells contain one- or two-character fragments.",
              "Retry extraction using the cropped table image and layout-aware OCR.", 20)
    if statement_type in {
        "BALANCE_SHEET", "INCOME_STATEMENT", "CASH_FLOW_STATEMENT", "CHANGES_IN_EQUITY"
    } and not periods:
        issue("PERIOD_HEADER_NOT_RESOLVED", "WARNING", "period_labels", "",
              "No reporting period was resolved for a primary financial statement.",
              "Resolve multi-row headers before financial fact extraction.", 20)
    if column_count >= 3 and not scopes:
        issue("ENTITY_SCOPE_NOT_RESOLVED", "INFO", "entity_scopes", "",
              "Group/Company or Consolidated/Standalone scope was not resolved.",
              "Resolve entity scope when the source table contains multiple scopes.", 5)
    if statement_type == "UNCLASSIFIED":
        issue("STATEMENT_TYPE_UNCLASSIFIED", "INFO", "statement_type", statement_type,
              "The table was not classified as a primary statement or notes table.",
              "Retain as a general table or classify it before concept resolution.", 5)

    score = max(0.0, round(score_box[0], 2))
    has_error = any(item["severity"] == "ERROR" for item in current_exceptions)
    if has_error or score < MIN_WARNING_SCORE:
        status = "RETRY_REQUIRED"
    elif score < MIN_ACCEPTED_SCORE:
        status = "MANUAL_REVIEW"
    elif current_exceptions:
        status = "VALIDATED_WITH_WARNINGS"
    else:
        status = "VALIDATED"

    # A compact reconstruction grid. Empty positions remain null; blank cell
    # records are not written to the cell output.
    safe_rows = min(max(row_count, 0), MAX_REASONABLE_ROWS)
    safe_columns = min(max(column_count, 0), MAX_REASONABLE_COLUMNS)
    grid: List[List[Optional[str]]] = [
        [None for _ in range(safe_columns)] for _ in range(safe_rows)
    ]
    if safe_rows and safe_columns:
        for cell in normalized_cells:
            r = cell["row_index"]
            c = cell["column_index"]
            if 0 <= r < safe_rows and 0 <= c < safe_columns and grid[r][c] is None:
                grid[r][c] = cell["raw_text"]

    table_confidence = float_value(first_present(table, "extraction_confidence"))
    if table_confidence is None:
        table_confidence = score / 100.0

    artifact_rows.append({
        **context,
        "table_title": title,
        "statement_type": statement_type,
        "table_bbox_json": json_text(first_present(table, "table_bbox_json"), {}),
        "page_image_path": text_value(first_present(table, "page_image_path")),
        "table_crop_path": text_value(first_present(table, "table_crop_path")),
        "reporting_date": text_value(first_present(table, "reporting_date")),
        "presentation_currency": text_value(first_present(table, "presentation_currency")),
        "presentation_unit": text_value(first_present(table, "presentation_unit")),
        "row_count": row_count,
        "column_count": column_count,
        "non_empty_cell_count": non_empty_count,
        "numeric_cell_count": numeric_count,
        "numeric_cell_ratio": round(numeric_ratio, 6),
        "header_cell_count": header_count,
        "period_labels_json": json.dumps(sorted(periods), ensure_ascii=False),
        "entity_scopes_json": json.dumps(sorted(scopes), ensure_ascii=False),
        "grid_json": json.dumps(grid, ensure_ascii=False),
        "header_tree_json": json_text(first_present(table, "header_tree_json"), {}),
        "merged_cells_json": json_text(first_present(table, "merged_cells_json"), []),
        "extraction_method": text_value(first_present(table, "extraction_method")),
        "model_name": text_value(first_present(table, "model_name")),
        "extractor_version": text_value(first_present(table, "extractor_version")),
        "validator_version": VALIDATOR_VERSION,
        "structure_score": score,
        "table_confidence": table_confidence,
        "validation_status": status,
        "exception_count": len(current_exceptions),
        "validated_at": utc_now(),
    })

    for cell in normalized_cells:
        cell.update({
            "structure_score": score,
            "validation_status": status,
            "validator_version": VALIDATOR_VERSION,
        })
        validated_cell_rows.append(cell)
    exception_rows.extend(current_exceptions)


if not artifact_rows:
    raise RuntimeError(
        "Recipe 03C received input cells but produced no table artifacts. "
        "Confirm that table_id or table_artifact_id, page_number and "
        "source_document_id are populated in FRI_EXTRACTED_TABLE_CELLS."
    )

artifact_df = pd.DataFrame(artifact_rows, columns=ARTIFACT_COLUMNS)
validated_cells_df = pd.DataFrame(validated_cell_rows, columns=CELL_COLUMNS)
exceptions_df = pd.DataFrame(exception_rows, columns=EXCEPTION_COLUMNS)

dataiku.Dataset(OUTPUT_ARTIFACTS).write_with_schema(artifact_df)
dataiku.Dataset(OUTPUT_CELLS).write_with_schema(validated_cells_df)
dataiku.Dataset(OUTPUT_EXCEPTIONS).write_with_schema(exceptions_df)

status_counts = (
    artifact_df["validation_status"].value_counts(dropna=False).to_dict()
    if not artifact_df.empty else {}
)
print(json.dumps({
    "validator_version": VALIDATOR_VERSION,
    "input_table_count": len(table_records),
    "input_cell_count": len(cell_records),
    "validated_table_count": len(artifact_rows),
    "non_empty_output_cell_count": len(validated_cell_rows),
    "exception_count": len(exception_rows),
    "status_counts": status_counts,
}, indent=2, default=str))
