-- Guarantee current-asset/current-liability resolution for the active
-- Manufacturing & Industrials template. Safe to run repeatedly.
--
-- Direct facts are preferred. If a filing exposes only non-current and grand
-- totals, the approved accounting identities are used:
--   current assets      = total assets - non-current assets
--   current liabilities = total liabilities - non-current liabilities

BEGIN;

INSERT INTO financial_risk_intelligence.financial_concepts
    (concept_key, statement_type, canonical_label, is_required, active)
VALUES
    ('total_current_assets', 'BALANCE_SHEET', 'Total current assets', true, true),
    ('total_non_current_assets', 'BALANCE_SHEET', 'Total non-current assets', false, true),
    ('total_current_liabilities', 'BALANCE_SHEET', 'Total current liabilities', true, true),
    ('total_non_current_liabilities', 'BALANCE_SHEET', 'Total non-current liabilities', false, true)
ON CONFLICT (concept_key) DO UPDATE SET
    statement_type = EXCLUDED.statement_type,
    canonical_label = EXCLUDED.canonical_label,
    active = true,
    updated_at = now();

SELECT financial_risk_intelligence.upsert_concept_alias(
    concept_key, alias_text, 'MANUFACTURING_INDUSTRIALS_GENERIC', NULL,
    priority, NULL, 100, 'CURRENT_TOTALS_ACTIVE_MAPPING'
)
FROM (VALUES
    ('total_current_assets', 'Total current assets', 1),
    ('total_current_assets', 'Current assets', 2),
    ('total_non_current_assets', 'Total non-current assets', 1),
    ('total_non_current_assets', 'Non-current assets', 2),
    ('total_current_liabilities', 'Total current liabilities', 1),
    ('total_current_liabilities', 'Current liabilities', 2),
    ('total_non_current_liabilities', 'Total non-current liabilities', 1),
    ('total_non_current_liabilities', 'Non-current liabilities', 2)
) AS alias_rows(concept_key, alias_text, priority);

INSERT INTO financial_risk_intelligence.financial_template_rules
    (rule_key, template_key, target_concept_key, operator, priority,
     output_sign, active, approval_status)
VALUES
    ('TCA_DIRECT', 'MANUFACTURING_INDUSTRIALS_GENERIC',
     'total_current_assets', 'DIRECT', 10, 'ABSOLUTE', true, 'APPROVED'),
    ('TCA_FROM_ASSET_SPLIT', 'MANUFACTURING_INDUSTRIALS_GENERIC',
     'total_current_assets', 'LINEAR_COMBINATION', 20, 'ABSOLUTE', true, 'APPROVED'),
    ('TCL_DIRECT', 'MANUFACTURING_INDUSTRIALS_GENERIC',
     'total_current_liabilities', 'DIRECT', 10, 'ABSOLUTE', true, 'APPROVED'),
    ('TCL_FROM_LIABILITY_SPLIT', 'MANUFACTURING_INDUSTRIALS_GENERIC',
     'total_current_liabilities', 'LINEAR_COMBINATION', 20, 'ABSOLUTE', true, 'APPROVED')
ON CONFLICT (rule_key) DO UPDATE SET
    template_key = EXCLUDED.template_key,
    target_concept_key = EXCLUDED.target_concept_key,
    operator = EXCLUDED.operator,
    priority = EXCLUDED.priority,
    output_sign = EXCLUDED.output_sign,
    active = true,
    approval_status = 'APPROVED',
    updated_at = now();

INSERT INTO financial_risk_intelligence.financial_rule_components
    (rule_key, component_concept_key, coefficient, component_sign, component_order)
VALUES
    ('TCA_FROM_ASSET_SPLIT', 'total_assets', 1, 'ABSOLUTE', 1),
    ('TCA_FROM_ASSET_SPLIT', 'total_non_current_assets', -1, 'ABSOLUTE', 2),
    ('TCL_FROM_LIABILITY_SPLIT', 'total_liabilities', 1, 'ABSOLUTE', 1),
    ('TCL_FROM_LIABILITY_SPLIT', 'total_non_current_liabilities', -1, 'ABSOLUTE', 2)
ON CONFLICT (rule_key, component_concept_key) DO UPDATE SET
    coefficient = EXCLUDED.coefficient,
    component_sign = EXCLUDED.component_sign,
    component_order = EXCLUDED.component_order;

COMMIT;

-- Verification: expect four active aliases, four approved rules, and four
-- rule components (additional synonym rows are acceptable).
SELECT concept_key, alias_text, sector_key, active, approval_status
FROM financial_risk_intelligence.financial_concept_aliases
WHERE concept_key IN (
    'total_current_assets', 'total_non_current_assets',
    'total_current_liabilities', 'total_non_current_liabilities'
)
  AND active = true
ORDER BY concept_key, priority, alias_text;

SELECT rule_key, template_key, target_concept_key, operator, priority,
       output_sign, active, approval_status
FROM financial_risk_intelligence.financial_template_rules
WHERE rule_key IN (
    'TCA_DIRECT', 'TCA_FROM_ASSET_SPLIT',
    'TCL_DIRECT', 'TCL_FROM_LIABILITY_SPLIT'
)
ORDER BY target_concept_key, priority;

SELECT rule_key, component_concept_key, coefficient, component_sign,
       component_order
FROM financial_risk_intelligence.financial_rule_components
WHERE rule_key IN ('TCA_FROM_ASSET_SPLIT', 'TCL_FROM_LIABILITY_SPLIT')
ORDER BY rule_key, component_order;
