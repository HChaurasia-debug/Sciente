BEGIN;

CREATE SCHEMA IF NOT EXISTS financial_risk_intelligence;

CREATE TABLE IF NOT EXISTS financial_risk_intelligence.runtime_settings (
    setting_key TEXT PRIMARY KEY,
    setting_value TEXT NOT NULL,
    is_secret BOOLEAN NOT NULL DEFAULT FALSE,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO financial_risk_intelligence.runtime_settings
    (setting_key, setting_value, is_secret, active, updated_at)
VALUES
    ('fri_llm_provider', 'groq', FALSE, TRUE, CURRENT_TIMESTAMP),
    ('fri_groq_base_url', 'https://api.groq.com/openai/v1', FALSE, TRUE, CURRENT_TIMESTAMP),
    ('fri_groq_model', 'groq/compound', FALSE, TRUE, CURRENT_TIMESTAMP),
    ('fri_groq_timeout_seconds', '120', FALSE, TRUE, CURRENT_TIMESTAMP),
    ('fri_llm_governance_enabled', 'false', FALSE, TRUE, CURRENT_TIMESTAMP),
    ('fri_llm_narrative_enabled', 'false', FALSE, TRUE, CURRENT_TIMESTAMP),
    ('fri_llm_debug_validation_enabled', 'false', FALSE, TRUE, CURRENT_TIMESTAMP)
ON CONFLICT (setting_key) DO UPDATE SET
    setting_value = EXCLUDED.setting_value,
    is_secret = EXCLUDED.is_secret,
    active = TRUE,
    updated_at = CURRENT_TIMESTAMP;

-- The API key is intentionally excluded from this checked-in migration.
-- Store it separately as setting_key=fri_groq_api_key, is_secret=TRUE,
-- active=TRUE through the approved Dataiku/PostgreSQL secret workflow.

COMMIT;

SELECT setting_key,
       CASE WHEN is_secret THEN '[SECRET PRESENT]' ELSE setting_value END AS effective_value,
       is_secret,
       active,
       updated_at
  FROM financial_risk_intelligence.runtime_settings
 WHERE setting_key IN (
       'fri_llm_provider', 'fri_groq_base_url', 'fri_groq_model',
       'fri_groq_timeout_seconds', 'fri_groq_api_key'
       ,'fri_llm_governance_enabled', 'fri_llm_narrative_enabled',
       'fri_llm_debug_validation_enabled'
 )
 ORDER BY setting_key;
