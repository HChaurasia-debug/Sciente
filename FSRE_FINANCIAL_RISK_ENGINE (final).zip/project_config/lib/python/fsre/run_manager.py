from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from typing import Any, Iterable, Optional


@dataclass(frozen=True)
class AssessmentSelection:
    selected_entity_id: str
    selected_document_id: str
    selected_rule_ids: list[str]
    requested_by: str
    run_source: str
    run_mode: str
    environment: str
    selected_profile_id: str
    selected_profile_version: str
    evidence_depth: str
    selected_document_ids: Optional[list[str]] = None

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "AssessmentSelection":
        allowed_fields = set(cls.__dataclass_fields__)
        filtered_payload = {
            key: value
            for key, value in payload.items()
            if key in allowed_fields
        }
        return cls(**filtered_payload)

    def to_run_config(self) -> dict[str, Any]:
        return {
            "ui_request": {
                "selected_entity_id": self.selected_entity_id,
                "selected_document_id": self.selected_document_id,
                "selected_document_ids": self.selected_document_ids or [self.selected_document_id],
                "selected_rule_ids": self.selected_rule_ids,
                "selected_profile_id": self.selected_profile_id,
                "selected_profile_version": self.selected_profile_version,
                "requested_by": self.requested_by,
                "run_source": self.run_source,
                "evidence_depth": self.evidence_depth,
            }
        }


def stable_json_hash(payload: dict[str, Any]) -> str:
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _fetchone(cur: Any, sql: str, params: Optional[Iterable[Any]] = None) -> Optional[dict[str, Any]]:
    cur.execute(sql, tuple(params or ()))
    row = cur.fetchone()
    return dict(row) if row else None


def _fetchall(cur: Any, sql: str, params: Optional[Iterable[Any]] = None) -> list[dict[str, Any]]:
    cur.execute(sql, tuple(params or ()))
    return [dict(row) for row in cur.fetchall()]


def get_active_profile(cur: Any, profile_id: str = "FSRE-SGX") -> dict[str, Any]:
    row = _fetchone(
        cur,
        """
        SELECT
            profile_pk,
            profile_id,
            profile_version,
            profile_name,
            config_json,
            config_hash,
            status
        FROM fsre_config.deployment_profiles
        WHERE profile_id = %s
          AND is_active = TRUE
          AND status = 'active'
        ORDER BY effective_from DESC NULLS LAST, created_at DESC
        LIMIT 1
        """,
        (profile_id,),
    )
    if not row:
        raise ValueError(f"No active deployment profile found for profile_id={profile_id}")
    return row


def list_active_rules(cur: Any, profile_pk: int) -> list[dict[str, Any]]:
    return _fetchall(
        cur,
        """
        SELECT
            rr.rule_id,
            rr.rule_version,
            rr.rule_name,
            rr.category,
            rr.severity_range,
            rr.required_fields_json,
            rr.required_connectors_json,
            rr.threshold_config_json,
            rr.status,
            par.execution_order
        FROM fsre_config.profile_active_rules par
        JOIN fsre_rules.rule_registry rr
          ON rr.rule_id = par.rule_id
         AND rr.rule_version = par.rule_version
        WHERE par.profile_pk = %s
          AND rr.status = 'active'
          AND COALESCE((par.rule_config_json ->> 'enabled')::boolean, TRUE) = TRUE
        ORDER BY par.execution_order NULLS LAST, rr.rule_id
        """,
        (profile_pk,),
    )


def validate_selected_rules(active_rules: list[dict[str, Any]], selected_rule_ids: list[str]) -> None:
    active_rule_ids = {row["rule_id"] for row in active_rules}
    selected = set(selected_rule_ids)
    missing = sorted(selected - active_rule_ids)
    if missing:
        raise ValueError(
            "Selected rule IDs are not active in the selected profile: "
            + ", ".join(missing)
        )


def create_assessment_run(cur: Any, selection: AssessmentSelection) -> dict[str, Any]:
    profile = get_active_profile(cur, selection.selected_profile_id)
    active_rules = list_active_rules(cur, profile["profile_pk"])
    requested_rule_ids = selection.selected_rule_ids or []
    if requested_rule_ids:
        validate_selected_rules(active_rules, requested_rule_ids)
    selected_rule_ids = [row["rule_id"] for row in active_rules]

    run_config = selection.to_run_config()
    run_config["ui_request"]["requested_rule_ids"] = requested_rule_ids
    run_config["ui_request"]["selected_rule_ids"] = selected_rule_ids
    run_config["rule_source"] = "fsre_config.profile_active_rules"
    run_config["rule_selection_mode"] = "active_profile"
    run_config["resolved_profile"] = {
        "profile_pk": profile["profile_pk"],
        "profile_id": profile["profile_id"],
        "profile_version": profile["profile_version"],
        "profile_hash": profile["config_hash"],
    }
    run_config["resolved_rules"] = [
        {
            "rule_id": row["rule_id"],
            "rule_version": row["rule_version"],
            "execution_order": row["execution_order"],
        }
        for row in active_rules
        if row["rule_id"] in set(selected_rule_ids)
    ]

    run_config_hash = stable_json_hash(run_config)

    cur.execute(
        """
        INSERT INTO fsre_audit.execution_runs (
            profile_id,
            profile_version,
            profile_pk,
            run_mode,
            status,
            run_config,
            run_config_hash,
            requested_by,
            environment,
            input_count
        )
        VALUES (%s, %s, %s, %s, 'created', %s::jsonb, %s, %s, %s, %s)
        RETURNING run_id, profile_id, profile_version, status, started_at, run_config
        """,
        (
            profile["profile_id"],
            profile["profile_version"],
            profile["profile_pk"],
            selection.run_mode,
            json.dumps(run_config),
            run_config_hash,
            selection.requested_by,
            selection.environment,
            len(selection.selected_document_ids or [selection.selected_document_id]),
        ),
    )
    run = dict(cur.fetchone())

    cur.execute(
        """
        INSERT INTO fsre_audit.run_events (
            run_id,
            event_stage,
            event_type,
            severity,
            message,
            event_json
        )
        VALUES (%s, 'run_setup', 'assessment_run_created', 'INFO', %s, %s::jsonb)
        """,
        (
            run["run_id"],
            "Assessment run created from UI selections.",
            json.dumps(
                {
                    "selected_entity_id": selection.selected_entity_id,
                    "selected_document_id": selection.selected_document_id,
                    "selected_rule_ids": selected_rule_ids,
                    "run_config_hash": run_config_hash,
                }
            ),
        ),
    )

    return run
