"""Database-driven financial concept resolver.

This module contains no company- or report-specific mappings.  Recipes should
load aliases/rules from PostgreSQL and pass standardized rows to resolve().
"""
RESOLVER_VERSION = "primary-table-paired-period-evidence-v10"
import re
from typing import Any, Dict, Iterable, List


def _text(value: Any) -> str:
    return "" if value is None else str(value).strip()


def _number(value: Any):
    try:
        if value in (None, "", "—", "–", "-"):
            return None
        return float(str(value).replace(",", "").replace("(", "-").replace(")", ""))
    except (TypeError, ValueError):
        return None


def _normalized(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", " ", _text(value).casefold()).strip()


def _year_key(value: Any) -> int:
    match = re.findall(r"\b(?:19|20)\d{2}\b", _text(value))
    return int(match[-1]) if match else -1


def _period_key(value: Any) -> int:
    """Order explicit years first, then recovered current/prior labels."""
    year = _year_key(value)
    if year >= 0:
        return year
    normalized = _normalized(value)
    return 2 if normalized == "current" else 1 if normalized == "prior" else -1


def _primary_title_score(row: Dict[str, Any], target_statement: str) -> int:
    """Prefer a titled primary statement over a note table with similar rows."""
    title = _normalized(row.get("statement_title") or row.get("table_title"))
    if not title:
        return 0
    if target_statement == "INCOME_STATEMENT":
        # A primary income statement can be titled "Statement of
        # Comprehensive Income", "Income Statement", or "Statement of
        # Profit or Loss".  Explicitly recognise all of them so a similarly
        # labelled note (for example discontinued-operations revenue) cannot
        # outrank the consolidated primary statement.
        return 50000 if re.search(r"\b(?:consolidated )?(?:statements? of (?:comprehensive )?income|income statements?|statements? of profit or loss)\b", title) else 0
    if target_statement == "BALANCE_SHEET":
        return 50000 if re.search(r"\b(?:consolidated )?statements? of financial position\b|\bbalance sheets?\b", title) else 0
    if target_statement == "CASH_FLOW_STATEMENT":
        return 50000 if re.search(r"\b(?:consolidated )?statements? of cash flows?\b", title) else 0
    return 0


def _table_context_score(rows: List[Dict[str, Any]], target_statement: str) -> int:
    """Score a complete source table, rejecting segment/note contexts.

    Page classifiers can stamp an INCOME_STATEMENT type or inherited primary
    title onto a later segment table. Structural anchors distinguish the face
    statement from that note even when its extracted title is unreliable.
    """
    title = " ".join(
        _normalized(row.get("statement_title") or row.get("table_title"))
        for row in rows
    )
    labels = {_normalized(row.get("row_label")) for row in rows}
    sections = " ".join(_normalized(row.get("statement_section")) for row in rows)
    if "segment" in title or "segment" in sections or any("segment" in label for label in labels):
        return -100000
    if target_statement == "BALANCE_SHEET":
        balance_anchors = (
            "total assets", "total liabilities", "total equity", "net assets",
        )
        anchor_count = sum(anchor in labels for anchor in balance_anchors)
        return 25000 if anchor_count >= 3 else anchor_count * 3000
    if target_statement != "INCOME_STATEMENT":
        return 0
    score = 0
    anchors = (
        ("revenue", "operating revenue", "sales"),
        ("cost of revenue", "cost of sales", "cost of goods sold"),
        ("profit loss before income tax", "profit before tax", "loss before tax"),
        ("income tax expense", "income tax benefit"),
    )
    for alternatives in anchors:
        if any(label in alternatives for label in labels):
            score += 5000
    if any(
        ("profit for the year" in label or "loss for the year" in label)
        and "attributable to owners" in label
        for label in labels
    ):
        score += 10000
    # Banks do not present revenue/COGS. Recognise the face banking income
    # statement from its own structural anchors so a geographic segment or a
    # credit-loss note cannot outrank it.
    bank_anchors = (
        ("net interest income", "net interest revenue"),
        ("total income", "operating income"),
        ("operating expenses", "total operating expenses"),
        ("allowances for credit and other losses", "credit impairment losses"),
        ("profit before tax", "profit before taxation"),
        ("net profit", "profit attributable to shareholders"),
    )
    bank_anchor_count = sum(
        any(label in alternatives for label in labels)
        for alternatives in bank_anchors
    )
    if bank_anchor_count >= 3:
        score += 25000 + bank_anchor_count * 3000
    return score


def _alias_score(label: str, alias_text: str) -> int:
    """Exact configured aliases only; ignore a trailing audited note number."""
    if not alias_text:
        return -1
    normalized_label = _normalized(label)
    # Primary statements commonly print a note reference directly after the
    # caption, e.g. "Cash and cash equivalents at the end of the year 18".
    # It is formatting, not a different concept.  We deliberately remove only
    # a final isolated number so broad/fuzzy matching remains disallowed.
    normalized_label = re.sub(r"\s+\d{1,3}(?:\s+[a-z])?$", "", normalized_label)
    normalized_alias = _normalized(alias_text)
    if normalized_label == normalized_alias:
        return 10000
    # PDF line wrapping can cut a caption after a connective, e.g.
    # "Net fee and" / "commission income" or "Profit before" / "tax".
    # Permit only a sufficiently long prefix ending in a connective. This is
    # deliberately narrower than fuzzy/contained matching and cannot turn a
    # generic caption such as "Allowances" into a banking fact.
    connective = re.search(r"\b(?:and|or|before|after|from|to|for|of)$", normalized_label)
    if (
        connective
        and len(normalized_label) >= 10
        and normalized_alias.startswith(normalized_label + " ")
    ):
        return 8500
    return -1


def _is_group(row: Dict[str, Any]) -> bool:
    scope = _text(row.get("entity_scope") or row.get("scope")).upper()
    return "GROUP" in scope or "CONSOLIDATED" in scope


def _is_company(row: Dict[str, Any]) -> bool:
    scope = _text(row.get("entity_scope") or row.get("scope")).upper()
    return any(value in scope for value in ("COMPANY", "STANDALONE", "PARENT"))


def _scope(row: Dict[str, Any]) -> str:
    """Return a canonical scope without trusting inconsistent source labels."""
    value = _text(row.get("entity_scope") or row.get("scope")).upper()
    if "GROUP" in value or "CONSOLIDATED" in value:
        return "GROUP"
    if "COMPANY" in value or "STANDALONE" in value or "PARENT" in value:
        return "COMPANY"
    if "REPORTED" in value or "UNKNOWN" in value or not value:
        return "REPORTED"
    return "REPORTED"


def _scope_rank(row: Dict[str, Any], preference: str = "GROUP_THEN_REPORTED_THEN_COMPANY") -> int:
    """Higher rank wins. REPORTED is an intentional fallback, not a rejection."""
    scope = _scope(row)
    pref = (preference or "GROUP_THEN_REPORTED_THEN_COMPANY").upper()
    order = ("GROUP", "REPORTED", "COMPANY")
    if pref == "REPORTED_THEN_GROUP_THEN_COMPANY":
        order = ("REPORTED", "GROUP", "COMPANY")
    try:
        return 300 - order.index(scope) * 100
    except ValueError:
        return 0


def _placeholder(row: Dict[str, Any]) -> bool:
    label = _text(row.get("row_label") or row.get("raw_text"))
    value = _number(row.get("numeric_value"))
    return not label or label in {"-", "–", "—"} or value is None


def _is_note_candidate(row: Dict[str, Any], table_cols: List[int]) -> bool:
    """Reject note references and note-number columns from financial facts."""
    col = _number(row.get("column_index"))
    value = _number(row.get("numeric_value"))
    note = _number(row.get("note_reference"))
    if note is not None and value is not None and value == note:
        return True
    if col is None or not table_cols:
        return False
    first_col = min(table_cols)
    statement = _text(row.get("statement_type")).upper()
    # Income statements commonly use note/current/prior columns.
    if statement == "INCOME_STATEMENT" and len(table_cols) >= 3 and int(col) == first_col:
        return value is not None and float(value).is_integer() and abs(value) <= 1000
    # Balance sheets commonly use note/group/group/company/company columns.
    if len(table_cols) >= 5 and int(col) == first_col:
        return True
    return False


def _concept_candidate_allowed(key: str, row: Dict[str, Any]) -> bool:
    """Generic semantic guardrails for commonly ambiguous concepts."""
    label = _text(row.get("row_label")).casefold()
    statement = _text(row.get("statement_type")).upper()
    section = _text(row.get("statement_section")).upper()
    income_concepts = {
        "revenue", "total_income", "net_interest_income",
        "non_interest_income", "operating_expenses",
        "provisions_impairment", "profit_before_tax", "net_profit",
        "cost_of_goods_sold", "sg_and_a_expense",
        "depreciation_amortization", "operating_income_ebit",
        "interest_expense",
    }
    if key in income_concepts:
        return statement == "INCOME_STATEMENT"
    balance_concepts = {
        "total_assets", "total_current_assets", "total_current_liabilities",
        "trade_receivables_net", "net_ppe", "long_term_debt",
        "retained_earnings", "total_shareholders_equity", "total_equity",
        "gross_loans_advances", "stage3_npa", "ecl_balance", "investments",
        "customer_deposits", "borrowings", "total_liabilities", "cet1_ratio",
    }
    if key in balance_concepts:
        if statement != "BALANCE_SHEET":
            return False
    cash_concepts = {
        "operating_cash_flow", "investing_cash_flow", "financing_cash_flow",
        "net_change_cash", "ending_cash",
    }
    if key in cash_concepts and statement != "CASH_FLOW_STATEMENT":
        return False
    if key == "long_term_debt":
        is_debt_label = "borrow" in label or "debt" in label or "loan" in label
        is_current = "current" in label or "current" in section
        is_non_current = (
            "non-current" in label or "non current" in label
            or "non-current" in section or "non current" in section
        )
        is_explicit_long_term = "long-term" in label or "long term" in label
        if not is_debt_label:
            return False
        if is_current and not is_non_current:
            return False
        # A generic "Borrowings" or "Loans and borrowings" line is safe only
        # in a non-current section. This prevents a current borrowing balance
        # or a total-liabilities heading from becoming long-term debt.
        return is_non_current or is_explicit_long_term
    if key == "shares_outstanding":
        # Never use the monetary share-capital balance as a share count. The
        # eligible source is a number-of-shares disclosure, normally Note 12.
        has_share = "share" in label
        is_quantity = any(token in label for token in (
            "number of", "no of", "shares in issue", "issued ordinary shares",
            "issued shares at end", "ordinary shares at end",
        ))
        return has_share and is_quantity
    if key in {"issued_shares", "treasury_shares_count"}:
        # Share-capital notes commonly contain both a share quantity and a
        # monetary amount on the same line. Only the quantity is eligible for
        # a share-count derivation; this excludes values such as US$14,000.
        value = _number(row.get("numeric_value"))
        return value is not None and abs(value) >= 1000
    if key == "net_ppe":
        return "property" in label or "plant" in label or "equipment" in label
    if key == "trade_receivables_net":
        if "receivable" not in label:
            return False
        # Prefer the current-assets balance-sheet line; exclude cash-flow
        # movements and non-current disclosure lines.
        if "non-current" in label or "non current" in label or "NON_CURRENT" in section:
            return False
        return statement == "BALANCE_SHEET"
    if key == "total_assets":
        return "total assets" in label
    if key == "total_current_assets":
        return "total current assets" in label or "current assets" in section
    if key == "total_current_liabilities":
        return "total current liabilities" in label or "current liabilities" in section
    return True


def _recover_split_balance_subtotals(rows: List[Dict[str, Any]]) -> None:
    """Name vertically split current/non-current balance-sheet subtotals.

    Some PDF layouts emit each Group subtotal amount as its own numeric-label
    row. Their audited ordering around Total assets and Total liabilities is
    stable even when section-heading rows were removed during standardization.
    """
    scopes: Dict[str, List[Dict[str, Any]]] = {}
    for row in rows:
        if _text(row.get("statement_type")).upper() != "BALANCE_SHEET":
            continue
        page = _number(row.get("page_number"))
        table = _text(row.get("table_artifact_id") or row.get("source_table_id"))
        if page is not None:
            scope = "page:" + str(int(page))
        elif table:
            scope = "table:" + table
        else:
            continue
        scopes.setdefault(scope, []).append(row)

    for table_rows in scopes.values():
        by_index: Dict[int, List[Dict[str, Any]]] = {}
        for row in table_rows:
            try:
                index = int(float(row.get("row_index")))
            except (TypeError, ValueError):
                continue
            by_index.setdefault(index, []).append(row)
        labels = {
            index: {_normalized(row.get("row_label")) for row in indexed_rows}
            for index, indexed_rows in by_index.items()
        }
        total_assets = next((index for index, values in labels.items() if "total assets" in values), None)
        total_liabilities = next((index for index, values in labels.items() if "total liabilities" in values), None)
        if total_assets is None or total_liabilities is None or total_assets >= total_liabilities:
            continue

        numeric_only = []
        for index, indexed_rows in by_index.items():
            eligible = [
                row for row in indexed_rows
                if _number(row.get("numeric_value")) is not None
                and _number(row.get("row_label")) is not None
            ]
            if eligible:
                numeric_only.append(index)
        numeric_only = sorted(set(numeric_only))
        pairs = [
            (left, right) for left, right in zip(numeric_only, numeric_only[1:])
            if right == left + 1
        ]
        asset_pairs = [pair for pair in pairs if pair[1] < total_assets]
        liability_pairs = [pair for pair in pairs if total_assets < pair[0] and pair[1] < total_liabilities]
        repairs = []
        if len(asset_pairs) >= 2:
            repairs.extend([
                (asset_pairs[-2], "Total non-current assets"),
                (asset_pairs[-1], "Total current assets"),
            ])
        elif asset_pairs:
            repairs.append((asset_pairs[-1], "Total current assets"))
        if len(liability_pairs) >= 2:
            repairs.extend([
                (liability_pairs[0], "Total current liabilities"),
                (liability_pairs[-1], "Total non-current liabilities"),
            ])
        elif liability_pairs:
            repairs.append((liability_pairs[0], "Total current liabilities"))

        for (current_index, prior_index), label in repairs:
            for row in by_index[current_index]:
                if _number(row.get("numeric_value")) is not None:
                    row["row_label"] = label
                    row["period_label"] = "CURRENT"
                    row["entity_scope"] = "GROUP"
            for row in by_index[prior_index]:
                if _number(row.get("numeric_value")) is not None:
                    row["row_label"] = label
                    row["period_label"] = "PRIOR"
                    row["entity_scope"] = "GROUP"


def _confirmed_unreported_long_term_debt(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Return primary-statement evidence when no non-current borrowing exists.

    A zero is emitted only when a titled consolidated balance sheet contains a
    non-current-liabilities section, has two reporting periods, and has no
    non-current debt/borrowing/loan line. An extraction failure therefore does
    not silently become zero.
    """
    tables: Dict[str, List[Dict[str, Any]]] = {}
    for row in rows:
        if _text(row.get("statement_type")).upper() != "BALANCE_SHEET":
            continue
        table_key = _text(row.get("table_artifact_id") or row.get("source_table_id") or row.get("statement_title"))
        if table_key:
            tables.setdefault(table_key, []).append(row)
    for table_rows in tables.values():
        if not any(_primary_title_score(row, "BALANCE_SHEET") for row in table_rows):
            continue
        has_non_current_section = any(
            "non current liabilities" in _normalized(row.get("statement_section") or row.get("row_label"))
            for row in table_rows
        )
        has_non_current_debt = any(
            _concept_candidate_allowed("long_term_debt", row)
            for row in table_rows
        )
        periods = sorted(
            {
                _text(row.get("period_label") or row.get("period_end"))
                for row in table_rows
                if _text(row.get("period_label") or row.get("period_end"))
            },
            key=_period_key,
            reverse=True,
        )
        if has_non_current_section and not has_non_current_debt and len(periods) >= 2:
            return {"row": table_rows[0], "current_period": periods[0], "prior_period": periods[1]}
    return {}


def _confirmed_unreported_inventory(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Confirm zero inventory only from a complete titled primary balance sheet."""
    tables: Dict[str, List[Dict[str, Any]]] = {}
    for row in rows:
        if _text(row.get("statement_type")).upper() != "BALANCE_SHEET":
            continue
        table_key = _text(row.get("table_artifact_id") or row.get("source_table_id") or row.get("statement_title"))
        if table_key:
            tables.setdefault(table_key, []).append(row)
    for table_rows in tables.values():
        labels = {_normalized(row.get("row_label")) for row in table_rows}
        # Header text can be lost by PDF extraction.  The three audited
        # balance-sheet anchors are an equally strong structural signature.
        structurally_primary = (
            "total assets" in labels
            and "total liabilities" in labels
            and ("total equity" in labels or "net assets" in labels)
            # A balance-sheet fragment containing only the lower half (assets
            # total, liabilities and equity) cannot prove that inventory is
            # absent. Require the current-assets total as evidence that the
            # asset section itself was extracted completely.
            and "total current assets" in labels
        )
        if not structurally_primary and not any(_primary_title_score(row, "BALANCE_SHEET") for row in table_rows):
            continue
        periods = {_text(row.get("period_label") or row.get("period_end")) for row in table_rows}
        periods.discard("")
        has_inventory = any(
            re.search(r"\b(?:inventor(?:y|ies)|stock|raw materials?|finished goods?|work in progress|consumables?)\b", _normalized(row.get("row_label")))
            for row in table_rows
        )
        if len(periods) >= 2 and not has_inventory:
            return {"row": table_rows[0]}
    return {}


def resolve(
    standardized_rows: Iterable[Dict[str, Any]],
    concepts: Iterable[Dict[str, Any]],
    aliases: Iterable[Dict[str, Any]],
    rules: Iterable[Dict[str, Any]] = (),
    rule_components: Iterable[Dict[str, Any]] = (),
) -> List[Dict[str, Any]]:
    """Resolve concepts using only database-provided aliases and rules."""
    rows = [dict(row) for row in standardized_rows if not _placeholder(row)]
    _recover_split_balance_subtotals(rows)
    # Some consolidated four-column statements label all cells REPORTED.
    # Infer the Group pair from the first two numeric columns per table; the
    # later pair is the Company column pair. This is generic layout handling,
    # not a company-specific rule.
    table_columns = {}
    table_rows: Dict[str, List[Dict[str, Any]]] = {}
    known_years = sorted({
        _year_key(row.get("period_label") or row.get("period_end"))
        for row in rows
        if _year_key(row.get("period_label") or row.get("period_end")) >= 0
    }, reverse=True)
    table_years: Dict[str, List[int]] = {}
    for row in rows:
        table = _text(row.get("table_artifact_id") or row.get("source_table_id") or row.get("statement_type"))
        col = _number(row.get("column_index"))
        if table and col is not None:
            table_columns.setdefault(table, set()).add(int(col))
        if table:
            table_rows.setdefault(table, []).append(row)
            year = _year_key(row.get("period_label") or row.get("period_end"))
            if year >= 0:
                table_years.setdefault(table, []).append(year)
    table_years = {
        table: sorted(set(years), reverse=True)
        for table, years in table_years.items()
    }
    for row in rows:
        table = _text(row.get("table_artifact_id") or row.get("source_table_id") or row.get("statement_type"))
        col = _number(row.get("column_index"))
        cols = sorted(table_columns.get(table, set()))
        title = _text(row.get("statement_title")).upper()
        statement = _text(row.get("statement_type")).upper()
        # Standard SGX layouts are: Note, Group current, Group prior,
        # Company current, Company prior. Metadata frequently marks every
        # cell GROUP, so derive scope from the physical column position.
        # Apply only to financial statements with at least four value columns;
        # cash-flow tables are not altered.
        primary_context = _table_context_score(table_rows.get(table, []), statement) > 0
        paired = "GROUP" in title or "COMPANY" in title or primary_context
        if col is not None and len(cols) >= 4 and paired:
            if len(cols) >= 5:
                note_col = cols[0]
                group_cols = cols[1:3]
                company_cols = cols[3:5]
            else:
                # Standardization may already have removed the Note column,
                # leaving Group current/prior followed by Company current/prior.
                note_col = None
                group_cols = cols[:2]
                company_cols = cols[2:4]
            if note_col is not None and int(col) == note_col:
                row["_note_column"] = True
            elif int(col) in group_cols:
                row["entity_scope"] = "GROUP"
            elif int(col) in company_cols:
                row["entity_scope"] = "COMPANY"
            years = table_years.get(table, known_years)
            if not _text(row.get("period_label") or row.get("period_end")) and len(years) >= 2:
                if int(col) == group_cols[0]:
                    row["period_label"] = str(years[0])
                elif int(col) == group_cols[1]:
                    row["period_label"] = str(years[1])

    # Strict two-column fallback. Some table extractors remove the Note and
    # Company columns but retain the two consolidated Group values. In that
    # layout, assign periods only when the table has exactly two numeric
    # columns and the row is a balance/income-statement row. This avoids
    # treating partial or multi-column note tables as financial periods.
    if len(known_years) >= 2:
        for row in rows:
            statement = _text(row.get("statement_type")).upper()
            table = _text(row.get("table_artifact_id") or row.get("source_table_id") or statement)
            col = _number(row.get("column_index"))
            cols = sorted(table_columns.get(table, set()))
            if statement not in {"BALANCE_SHEET", "INCOME_STATEMENT"} or col is None or len(cols) != 2:
                continue
            if not _text(row.get("period_label") or row.get("period_end")) and int(col) in cols:
                row["entity_scope"] = "GROUP"
                years = table_years.get(table, known_years)
                if len(years) >= 2:
                    row["period_label"] = str(years[0] if int(col) == cols[0] else years[1])
    # Final generic period repair: some extractors preserve scope/columns but
    # omit period_label on balance-sheet rows. Assign the two Group columns
    # from the statement header years, without changing Company rows.
    if len(known_years) >= 2:
        for table, cols_set in table_columns.items():
            group_rows = [
                r for r in rows
                if _text(r.get("table_artifact_id") or r.get("source_table_id") or r.get("statement_type")) == table
                and _scope(r) == "GROUP"
                and _text(r.get("statement_type")).upper() == "BALANCE_SHEET"
            ]
            group_cols = sorted({int(_number(r.get("column_index"))) for r in group_rows if _number(r.get("column_index")) is not None})
            if len(group_cols) >= 2:
                for r in group_rows:
                    if _text(r.get("period_label") or r.get("period_end")):
                        continue
                    c = int(_number(r.get("column_index")))
                    years = table_years.get(table, known_years)
                    if len(years) < 2:
                        continue
                    if c == group_cols[0]:
                        r["period_label"] = str(years[0])
                    elif c == group_cols[1]:
                        r["period_label"] = str(years[1])
    alias_rows = list(aliases)
    concept_rows = list(concepts)
    component_rows = list(rule_components)
    rule_rows = list(rules)
    output: Dict[str, Dict[str, Any]] = {}

    for concept in concept_rows:
        key = _text(concept.get("concept_key"))
        candidates = []
        target_statement = _text(
            concept.get("resolver_statement_type") or concept.get("statement_type")
        ).upper()
        selection_rule = _text(concept.get("selection_rule")).upper()
        allow_note_table = selection_rule in {"NOTE_TABLE_ALLOWED", "SHARE_CAPITAL_NOTE"}
        for row in rows:
            row_statement = _text(row.get("statement_type")).upper()
            # Never resolve an income/balance-sheet concept from a different
            # statement. This prevents cash-flow movements being selected for
            # balance-sheet debt, receivables, cash, or equity fields.
            if target_statement and row_statement and row_statement != target_statement and not allow_note_table:
                continue
            # In four-column Group/Company tables the first numeric column is
            # the note number. It carries the same row label as the values but
            # must never become a financial fact (e.g. revenue=4, COGS=5).
            table = _text(row.get("table_artifact_id") or row.get("source_table_id") or row.get("statement_type"))
            col = _number(row.get("column_index"))
            cols = sorted(table_columns.get(table, set()))
            if col is not None and len(cols) >= 5 and int(col) == cols[0]:
                continue
            if _is_note_candidate(row, cols):
                continue
            if not _concept_candidate_allowed(key, row):
                continue
            label = _text(row.get("row_label")).casefold()
            for alias in alias_rows:
                if _text(alias.get("concept_key")) != key:
                    continue
                alias_text = _text(alias.get("alias_text")).casefold()
                match_score = _alias_score(label, alias_text)
                if match_score >= 0:
                    score = int(_number(alias.get("priority")) or 0)
                    score += match_score
                    score += _primary_title_score(row, target_statement)
                    score += _table_context_score(table_rows.get(table, [row]), target_statement)
                    preference = _text(concept.get("scope_preference") or alias.get("scope_preference"))
                    score += _scope_rank(row, preference or "GROUP_THEN_REPORTED_THEN_COMPANY") * 10
                    if _text(row.get("statement_type")) == _text(concept.get("statement_type")):
                        score += 500
                    if _text(row.get("statement_section")) == _text(concept.get("statement_section")):
                        score += 300
                    configured_scope = _text(concept.get("scope_preference") or alias.get("scope_preference")).upper()
                    if configured_scope in {"GROUP", "GROUP_THEN_REPORTED", "GROUP_THEN_REPORTED_THEN_COMPANY"}:
                        score += _scope_rank(row, configured_scope) * 10
                    rule = _text(concept.get("selection_rule") or alias.get("selection_rule")).upper()
                    section = _text(row.get("statement_section")).upper().replace("_", " ")
                    label_norm = label.replace("_", " ")
                    if rule == "CURRENT_SECTION_ONLY":
                        score += 700 if section == "CURRENT ASSETS" else -700
                    elif rule in {"NON_CURRENT_COMPONENT_SUM", "NON_CURRENT_OR_ZERO_IF_UNREPORTED"}:
                        score += 700 if ("NON CURRENT" in section or "NON CURRENT" in label_norm) else -700
                    elif rule == "ACCUMULATED_DEFICIT":
                        score += 700 if "ACCUMULATED DEFICIT" in label_norm else 0
                    elif rule == "COMPONENT_SUM":
                        score -= 500 if label_norm in {"-", "–", "—"} else 0
                    if key == "trade_receivables_net":
                        score += 1200 if "CURRENT_ASSETS" in section else 0
                        score += 500 if label in {"trade receivables", "trade and other receivables"} else 0
                    if key == "long_term_debt":
                        score += 1200 if ("NON_CURRENT" in section or "non-current" in label_norm) else 0
                    candidates.append((score, row))
        # A zero is allowed only under an explicit configuration rule and only
        # where the complete primary statement evidences the absence of a
        # non-current borrowing line. This preserves an auditable distinction
        # between "not reported" and an extractor failure.
        if (
            not candidates
            and key == "long_term_debt"
            and selection_rule == "NON_CURRENT_OR_ZERO_IF_UNREPORTED"
        ):
            absence = _confirmed_unreported_long_term_debt(rows)
            if absence:
                source = absence["row"]
                output[key] = {
                    "concept_key": key,
                    "statement_type": target_statement or "BALANCE_SHEET",
                    "table_artifact_id": _text(source.get("table_artifact_id")),
                    "source_table_id": _text(source.get("source_table_id")),
                    "source_page_number": _number(source.get("page_number")),
                    "source_row_index": None,
                    "source_column_index": None,
                    "current_source_row_index": None,
                    "current_source_column_index": None,
                    "prior_source_row_index": None,
                    "prior_source_column_index": None,
                    "scope": "GROUP",
                    "currency": _text(source.get("currency")),
                    "unit": _text(source.get("unit")),
                    "current_value": 0.0,
                    "prior_value": 0.0,
                    "current_source_label": "No non-current borrowings reported",
                    "prior_source_label": "No non-current borrowings reported",
                    "resolution_method": "DATABASE_CONFIRMED_ZERO_IF_UNREPORTED",
                }
            continue
        if not candidates and key == "inventory" and selection_rule == "ZERO_IF_ABSENT_PRIMARY":
            absence = _confirmed_unreported_inventory(rows)
            if absence:
                source = absence["row"]
                output[key] = {
                    "concept_key": key, "statement_type": target_statement or "BALANCE_SHEET",
                    "table_artifact_id": _text(source.get("table_artifact_id")),
                    "source_table_id": _text(source.get("source_table_id")),
                    "scope": "GROUP", "currency": _text(source.get("currency")), "unit": _text(source.get("unit")),
                    "current_value": 0.0, "prior_value": 0.0,
                    "current_source_label": "No inventory reported on primary balance sheet",
                    "prior_source_label": "No inventory reported on primary balance sheet",
                    "resolution_method": "DATABASE_CONFIRMED_ZERO_IF_UNREPORTED",
                }
            continue
        # A filing often repeats an alias in a note table (for example
        # discontinued-operations Revenue).  If the filing also contains a
        # recognised primary statement, never allow the note candidate to win
        # merely because it has a cleaner extracted row or a higher alias
        # priority.  This is a source-scope rule, not a value heuristic.
        primary_candidates = [
            candidate for candidate in candidates
            if _primary_title_score(candidate[1], target_statement)
            and _table_context_score(
                table_rows.get(
                    _text(candidate[1].get("table_artifact_id") or candidate[1].get("source_table_id") or candidate[1].get("statement_type")),
                    [candidate[1]],
                ),
                target_statement,
            ) >= 0
        ]
        if primary_candidates:
            candidates = primary_candidates

        # A filing often repeats an alias in note tables.  Select one source
        # table first, based on a primary-statement title and a complete
        # current/prior pair, then select both years within that table.
        by_table: Dict[str, List[Any]] = {}
        for score, row in candidates:
            table_key = _text(
                row.get("table_artifact_id")
                or row.get("source_table_id")
                or row.get("statement_title")
            )
            if table_key:
                by_table.setdefault(table_key, []).append((score, row))
        if by_table:
            def table_score(table_id: str, items: List[Any]) -> Any:
                periods_in_table = {
                    _text(item[1].get("period_label") or item[1].get("period_end"))
                    for item in items
                    if _text(item[1].get("period_label") or item[1].get("period_end"))
                }
                pair_bonus = 20000 if len(periods_in_table) >= 2 else 0
                highest = max(score for score, _ in items)
                title_score = max(
                    _primary_title_score(row, target_statement)
                    for _, row in items
                )
                context_score = _table_context_score(table_rows.get(table_id, []), target_statement)
                return (title_score + context_score + pair_bonus + highest, highest, table_id)

            chosen_table = max(
                by_table,
                key=lambda table: table_score(table, by_table[table]),
            )
            candidates = by_table[chosen_table]

        periods = sorted(
            {
                _text(row.get("period_label") or row.get("period_end"))
                for _, row in candidates
                if _text(row.get("period_label") or row.get("period_end"))
            },
            key=_period_key,
            reverse=True,
        )
        if not periods:
            continue
        selected = {}
        for target in periods[:2]:
            matches = [(score, row) for score, row in candidates if _text(row.get("period_label") or row.get("period_end")) == target]
            if matches:
                selected[target] = max(matches, key=lambda item: item[0])[1]
        if selected:
            current = selected.get(periods[0])
            prior = selected.get(periods[1]) if len(periods) > 1 else None
            output[key] = {
                "concept_key": key,
                "statement_type": target_statement or _text(current.get("statement_type") if current else ""),
                "table_artifact_id": _text(current.get("table_artifact_id") if current else ""),
                "source_table_id": _text(current.get("source_table_id") if current else ""),
                "source_page_number": _number(current.get("page_number") if current else None),
                "source_row_index": _number(current.get("row_index") if current else None),
                "source_column_index": _number(current.get("column_index") if current else None),
                "current_source_row_index": _number(current.get("row_index") if current else None),
                "current_source_column_index": _number(current.get("column_index") if current else None),
                "prior_source_row_index": _number(prior.get("row_index") if prior else None),
                "prior_source_column_index": _number(prior.get("column_index") if prior else None),
                "scope": _scope(current) if current else "GROUP",
                "currency": _text(current.get("currency") if current else ""),
                "unit": _text(current.get("unit") if current else ""),
                "current_value": _number(current.get("numeric_value")) if current else None,
                "prior_value": _number(prior.get("numeric_value")) if prior else None,
                "current_period": periods[0],
                "prior_period": periods[1] if len(periods) > 1 else "",
                "current_source_label": _text(current.get("row_label")) if current else "",
                "prior_source_label": _text(prior.get("row_label")) if prior else "",
                "resolution_method": "DATABASE_ALIAS",
            }

    # Apply configured linear-combination rules only when all components exist.
    for rule in sorted(rule_rows, key=lambda item: int(_number(item.get("priority")) or 0)):
        target = _text(rule.get("target_concept_key"))
        if _text(rule.get("operator")).upper() != "LINEAR_COMBINATION":
            continue
        components = [item for item in component_rows if _text(item.get("rule_key")) == _text(rule.get("rule_key"))]
        if not components or any(_text(item.get("component_concept_key")) not in output for item in components):
            continue
        current = sum((_number(output[_text(item.get("component_concept_key"))].get("current_value")) or 0) * (float(_number(item.get("coefficient")) or 1)) for item in components)
        prior = sum((_number(output[_text(item.get("component_concept_key"))].get("prior_value")) or 0) * (float(_number(item.get("coefficient")) or 1)) for item in components)
        output[target] = {"concept_key": target, "current_value": abs(current), "prior_value": abs(prior), "resolution_method": "DATABASE_DERIVED", "rule_key": _text(rule.get("rule_key"))}
    return list(output.values())
