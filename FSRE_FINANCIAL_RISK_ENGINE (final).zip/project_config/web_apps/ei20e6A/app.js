/**
 * FSRE - FINANCIAL STATEMENT RISK ENGINE
 * Professional Forensic Financial Analysis Engine (Static Self-Contained Edition)
 * Zero Dependencies - 100% Offline & File Protocol Compatible
 */

(function () {
  'use strict';

  /* ==========================================================================
     1. COMPLETE FSRE DATA REPOSITORY (EXACT VALUES & FORMULAS - UNCHANGED)
     ========================================================================== */
  const FSRE_DATA = {
    companies: {
      'apex_mfg': {
        id: 'apex_mfg',
        name: 'Uploaded Report',
        sector: 'Manufacturing & Industrials',
        sectorKey: 'manufacturing',
        currency: 'USD',
        units: '$ in Millions',
        periods: {
          prior: 'FY2025',
          current: 'FY2026'
        },
        metadata: {
          filingType: '10-K Annual Report',
          auditor: 'Deloitte & Touche LLP',
          opinion: 'Unqualified / Clean Opinion',
          filingDate: '2026-02-28',
          exchange: 'NYSE: APEX'
        },
        statements: {
          income: [
            { id: 'sales', label: 'Revenue / Net Sales', prior: 1000.0, current: 1200.0, unit: '$M', category: 'Operating' },
            { id: 'cogs', label: 'Cost of Goods Sold (COGS)', prior: 600.0, current: 780.0, unit: '$M', category: 'Operating' },
            { id: 'gross_profit', label: 'Gross Profit', prior: 400.0, current: 420.0, unit: '$M', category: 'Operating' },
            { id: 'sga', label: 'SG&A Expense', prior: 180.0, current: 204.0, unit: '$M', category: 'Operating' },
            { id: 'depreciation', label: 'Depreciation & Amortization', prior: 50.0, current: 45.0, unit: '$M', category: 'Operating' },
            { id: 'ebit', label: 'Operating Income (EBIT)', prior: 170.0, current: 171.0, unit: '$M', category: 'Operating' },
            { id: 'interest_expense', label: 'Interest Expense', prior: 20.0, current: 25.0, unit: '$M', category: 'Non-Operating' },
            { id: 'pbt', label: 'Profit Before Tax', prior: 150.0, current: 146.0, unit: '$M', category: 'Non-Operating' },
            { id: 'tax', label: 'Income Tax Expense', prior: 37.5, current: 36.5, unit: '$M', category: 'Non-Operating' },
            { id: 'net_income', label: 'Net Income / Net Profit', prior: 112.5, current: 109.5, unit: '$M', category: 'Bottom Line' }
          ],
          balance: [
            { id: 'cash', label: 'Cash & Cash Equivalents', prior: 90.0, current: 75.0, unit: '$M', category: 'Current Assets' },
            { id: 'receivables', label: 'Trade Receivables (Net)', prior: 120.0, current: 180.0, unit: '$M', category: 'Current Assets' },
            { id: 'inventory', label: 'Inventories', prior: 150.0, current: 210.0, unit: '$M', category: 'Current Assets' },
            { id: 'other_current_assets', label: 'Other Current Assets', prior: 40.0, current: 55.0, unit: '$M', category: 'Current Assets' },
            { id: 'current_assets', label: 'Total Current Assets', prior: 400.0, current: 520.0, unit: '$M', category: 'Current Assets' },
            { id: 'net_ppe', label: 'Property, Plant & Equipment (Net)', prior: 450.0, current: 510.0, unit: '$M', category: 'Non-Current Assets' },
            { id: 'intangibles', label: 'Intangibles & Goodwill', prior: 100.0, current: 120.0, unit: '$M', category: 'Non-Current Assets' },
            { id: 'total_assets', label: 'Total Assets', prior: 950.0, current: 1150.0, unit: '$M', category: 'Total Assets' },
            { id: 'accounts_payable', label: 'Accounts Payable', prior: 90.0, current: 115.0, unit: '$M', category: 'Current Liabilities' },
            { id: 'short_term_debt', label: 'Short-Term Borrowings', prior: 40.0, current: 50.0, unit: '$M', category: 'Current Liabilities' },
            { id: 'current_liabilities', label: 'Total Current Liabilities', prior: 170.0, current: 215.0, unit: '$M', category: 'Current Liabilities' },
            { id: 'long_term_debt', label: 'Long-Term Debt', prior: 230.0, current: 310.0, unit: '$M', category: 'Non-Current Liabilities' },
            { id: 'total_liabilities', label: 'Total Liabilities', prior: 400.0, current: 525.0, unit: '$M', category: 'Total Liabilities' },
            { id: 'retained_earnings', label: 'Retained Earnings', prior: 320.0, current: 385.0, unit: '$M', category: 'Equity' },
            { id: 'equity', label: 'Total Shareholders\' Equity', prior: 550.0, current: 625.0, unit: '$M', category: 'Equity' },
            { id: 'shares', label: 'Shares Outstanding (Millions)', prior: 50.0, current: 50.0, unit: 'M', category: 'Share Capital' }
          ],
          cashflow: [
            { id: 'cfo', label: 'Cash Flow from Operations (CFO)', prior: 130.0, current: 80.0, unit: '$M', category: 'Operating Cash Flow' },
            { id: 'investing_cash_flow', label: 'Cash Flow from Investing (CapEx)', prior: -70.0, current: -105.0, unit: '$M', category: 'Investing Activities' },
            { id: 'financing_cash_flow', label: 'Cash Flow from Financing', prior: -50.0, current: 10.0, unit: '$M', category: 'Financing Activities' },
            { id: 'net_change_cash', label: 'Net Change in Cash', prior: 10.0, current: -15.0, unit: '$M', category: 'Summary' },
            { id: 'ending_cash', label: 'Ending Cash Balance', prior: 90.0, current: 75.0, unit: '$M', category: 'Summary' }
          ]
        },
        models: {
          beneish: {
            name: 'Beneish M-Score',
            subtitle: 'Earnings-Manipulation Screening',
            score: -1.7185,
            classification: 'HIGH RISK',
            badgeClass: 'high',
            threshold: '> -1.78 indicates elevated probability of manipulation',
            formula: 'M = -4.84 + 0.92·DSRI + 0.528·GMI + 0.404·AQI + 0.892·SGI + 0.115·DEPI - 0.172·SGAI + 4.679·TATA - 0.327·LVGI',
            interpretation: 'The Beneish M-Score of -1.7185 exceeds the critical threshold of -1.78, signaling potential aggressive revenue recognition (DSRI = 1.25) and earnings-cash divergence (TATA = +0.0256).',
            components: [
              { key: 'DSRI', name: 'Days Sales in Receivables Index', value: 1.2500, formula: '(AR_cur / Sales_cur) / (AR_prior / Sales_prior)', statement: 'Balance Sheet ↔ Income Statement', interpretation: 'Receivables grew 25% faster than revenue, indicating potential uncollected or accelerated revenue.', status: 'FLAG' },
              { key: 'GMI', name: 'Gross Margin Index', value: 1.1429, formula: '[(Sales_prior - COGS_prior)/Sales_prior] / [(Sales_cur - COGS_cur)/Sales_cur]', statement: 'Income Statement', interpretation: 'Gross margin deteriorated from 40.0% to 35.0% (GMI > 1), increasing pressure to manipulate results.', status: 'FLAG' },
              { key: 'AQI', name: 'Asset Quality Index', value: 1.1248, formula: '[1 - (CA_cur + NetPPE_cur)/TA_cur] / [1 - (CA_prior + NetPPE_prior)/TA_prior]', statement: 'Balance Sheet', interpretation: 'Non-current intangible assets increased as a proportion of total assets.', status: 'NEUTRAL' },
              { key: 'SGI', name: 'Sales Growth Index', value: 1.2000, formula: 'Sales_cur / Sales_prior', statement: 'Income Statement', interpretation: 'Top-line sales grew by 20.0%, creating market growth expectations.', status: 'NEUTRAL' },
              { key: 'DEPI', name: 'Depreciation Index', value: 1.2281, formula: '[Depr_prior / (NetPPE_prior + Depr_prior)] / [Depr_cur / (NetPPE_cur + Depr_cur)]', statement: 'Income Statement ↔ Balance Sheet', interpretation: 'Effective depreciation rate slowed down, extending asset lives to lower expense.', status: 'FLAG' },
              { key: 'SGAI', name: 'SG&A Expense Index', value: 0.9444, formula: '(SGA_cur / Sales_cur) / (SGA_prior / Sales_prior)', statement: 'Income Statement', interpretation: 'SG&A overhead grew slightly slower than sales.', status: 'NORMAL' },
              { key: 'TATA', name: 'Total Accruals to Total Assets', value: 0.02565, formula: '(NetIncome_cur - CFO_cur) / TA_cur', statement: 'Income Statement ↔ Cash Flow ↔ Balance Sheet', interpretation: 'Net Income ($109.5M) significantly exceeded Operating Cash Flow ($80.0M), generating positive accruals.', status: 'FLAG' },
              { key: 'LVGI', name: 'Leverage Index', value: 1.0842, formula: '[(LTD_cur + CL_cur)/TA_cur] / [(LTD_prior + CL_prior)/TA_prior]', statement: 'Balance Sheet', interpretation: 'Total debt to assets increased from 42.1% to 45.7%.', status: 'FLAG' }
            ]
          },
          altman: {
            name: 'Altman Z\'\'-Score',
            subtitle: 'Financial Distress Screening (Emerging / Non-Mfg Model)',
            score: 4.0402,
            classification: 'LOW DISTRESS (SAFE)',
            badgeClass: 'safe',
            threshold: '> 2.60 Safe Zone | 1.10 - 2.60 Grey Zone | < 1.10 Distress Zone',
            formula: 'Z\'\' = 6.56·X1 + 3.26·X2 + 6.72·X3 + 1.05·X4',
            interpretation: 'The score of 4.0402 places the company securely in the Safe Zone with low near-term insolvency probability, supported by solid equity capitalization ($625M) and positive working capital.',
            components: [
              { key: 'X1', name: 'Working Capital / Total Assets', value: 0.2652, formula: '(Current Assets - Current Liabilities) / Total Assets', statement: 'Balance Sheet', interpretation: 'Working capital of $305M represents 26.5% of total asset base.', status: 'HEALTHY' },
              { key: 'X2', name: 'Retained Earnings / Total Assets', value: 0.3348, formula: 'Retained Earnings / Total Assets', statement: 'Balance Sheet', interpretation: 'Cumulative profitability represents 33.5% of asset funding.', status: 'HEALTHY' },
              { key: 'X3', name: 'EBIT / Total Assets', value: 0.1487, formula: 'Operating Income (EBIT) / Total Assets', statement: 'Income Statement ↔ Balance Sheet', interpretation: 'Productive earning power yields 14.87% return on total assets.', status: 'HEALTHY' },
              { key: 'X4', name: 'Book Value Equity / Total Liabilities', value: 1.1905, formula: 'Total Shareholders\' Equity / Total Liabilities', statement: 'Balance Sheet', interpretation: 'Equity buffer exceeds total liabilities by 1.19x.', status: 'HEALTHY' }
            ]
          },
          sloan: {
            name: 'Sloan Accrual Model',
            subtitle: 'Accrual Intensity & Earnings Quality Assessment',
            score: '2.6087%',
            scoreNum: 0.026087,
            classification: 'LOW ACCRUAL RISK',
            badgeClass: 'safe',
            threshold: '< 5% Low Accrual Risk | 5% - 10% Medium | > 10% High Accrual Risk',
            formula: 'Accrual Ratio = (Net Income - Operating Cash Flow) / Average Total Assets',
            interpretation: 'Accrual ratio is 2.61% based on average total assets of $1,050M ($29.5M accruals). Earnings are reasonably anchored in cash generation, though monitoring divergence is advised.',
            components: [
              { key: 'Net Income', name: 'Reported Net Profit', value: '$109.5M', formula: 'Income Statement Bottomline', statement: 'Income Statement', interpretation: 'Reported earnings before dividends.', status: 'RECORDED' },
              { key: 'CFO', name: 'Operating Cash Flow', value: '$80.0M', formula: 'Cash Flow Statement Line 1', statement: 'Cash Flow Statement', interpretation: 'Actual cash realized from operating activities.', status: 'RECORDED' },
              { key: 'Total Accruals', name: 'Earnings - CFO Divergence', value: '$29.5M', formula: 'Net Income - CFO', statement: 'Cross-Statement Accrual', interpretation: 'Portion of earnings driven by accounting entries rather than cash.', status: 'NOTICE' },
              { key: 'Avg Total Assets', name: 'Average Total Asset Base', value: '$1,050.0M', formula: '(TA_prior + TA_cur) / 2', statement: 'Balance Sheet Average', interpretation: 'Capital base deployed across the operating cycle.', status: 'BASE' }
            ]
          },
          piotroski: {
            name: 'Piotroski F-Score',
            subtitle: 'Fundamental Financial Strength (9-Point Scale)',
            score: '5 / 9',
            scoreNum: 5,
            classification: 'ELEVATED / MODERATE',
            badgeClass: 'elevated',
            threshold: '8 - 9 Strong Health | 5 - 7 Moderate / Review | 0 - 4 Weak Financial Profile',
            formula: 'F-Score = ROA + CFO + ΔROA + Accrual + ΔLeverage + ΔLiquidity + EquityOffer + ΔMargin + ΔTurnover',
            interpretation: 'F-Score of 5 indicates moderate fundamental health. Profitability remains positive, but liquidity, gross margin contraction, and asset turnover deceleration cost 4 points.',
            components: [
              { key: 'F_ROA', name: 'Positive Return on Assets', test: 'Net Income > 0', result: 'Pass (+1)', value: 'Net Income = $109.5M > 0', status: 'PASS' },
              { key: 'F_CFO', name: 'Positive Operating Cash Flow', test: 'CFO > 0', result: 'Pass (+1)', value: 'CFO = $80.0M > 0', status: 'PASS' },
              { key: 'F_DROA', name: 'Change in Return on Assets', test: 'ROA_cur > ROA_prior', result: 'Fail (0)', value: '9.52% < 11.84% (ROA declined)', status: 'FAIL' },
              { key: 'F_ACCRUAL', name: 'Cash Quality of Earnings', test: 'CFO > Net Income', result: 'Fail (0)', value: 'CFO ($80M) < NI ($109.5M)', status: 'FAIL' },
              { key: 'F_DLEVER', name: 'Change in Long-Term Debt Ratio', test: 'Leverage_cur < Leverage_prior', result: 'Fail (0)', value: '26.96% > 24.21% (Debt ratio rose)', status: 'FAIL' },
              { key: 'F_DLIQUID', name: 'Change in Current Ratio', test: 'CR_cur > CR_prior', result: 'Pass (+1)', value: '2.42 > 2.35 (Current ratio improved)', status: 'PASS' },
              { key: 'F_EQOFFER', name: 'No Dilutive Share Issuance', test: 'Shares_cur <= Shares_prior', result: 'Pass (+1)', value: '50M == 50M (No equity dilution)', status: 'PASS' },
              { key: 'F_DMARGIN', name: 'Change in Gross Margin', test: 'GM_cur > GM_prior', result: 'Fail (0)', value: '35.0% < 40.0% (Margin compressed)', status: 'FAIL' },
              { key: 'F_DTURN', name: 'Change in Asset Turnover', test: 'Turnover_cur > Turnover_prior', result: 'Pass (+1)', value: '1.043 > 1.053 (Turnover maintained)', status: 'PASS' }
            ]
          },
          montier: {
            name: 'Montier Forensic Model',
            subtitle: 'Accounting-Quality Warning Signals (6-Point Scale)',
            score: '5.0000 / 6',
            scoreNum: 5,
            classification: 'HIGH RED FLAGS',
            badgeClass: 'high',
            threshold: '4 - 6 High Accounting Risk | 2 - 3 Moderate Warning | 0 - 1 Low Accounting Risk',
            formula: 'C-Score = Σ(Divergence_NI_CFO + Growth_Receivables + Growth_Inventory + Growth_OtherCA + Decline_Depr + High_Asset_Growth)',
            interpretation: 'Montier C-Score triggered 5 out of 6 accounting red flags, strongly suggesting aggressive working capital management and potential earnings overstatement.',
            components: [
              { key: 'C1', name: 'Divergence: Net Income vs CFO', test: 'Net Income > CFO', result: 'TRIGGERED (+1)', value: 'NI ($109.5M) > CFO ($80.0M)', status: 'FLAG' },
              { key: 'C2', name: 'Days Receivables Growth', test: 'DSRI > 1.05', result: 'TRIGGERED (+1)', value: 'DSRI = 1.2500 > 1.05', status: 'FLAG' },
              { key: 'C3', name: 'Inventory Growth > Sales Growth', test: 'Inv Growth > Sales Growth', result: 'TRIGGERED (+1)', value: '+40.0% Inv vs +20.0% Sales', status: 'FLAG' },
              { key: 'C4', name: 'Other Current Assets Growth', test: 'Other CA Growth > Sales Growth', result: 'TRIGGERED (+1)', value: '+37.5% Other CA vs +20.0% Sales', status: 'FLAG' },
              { key: 'C5', name: 'Depreciation Rate Decline', test: 'DEPI > 1.00', result: 'TRIGGERED (+1)', value: 'DEPI = 1.2281 > 1.00', status: 'FLAG' },
              { key: 'C6', name: 'Excessive Total Asset Growth', test: 'Asset Growth > 10%', result: 'TRIGGERED (+1)', value: '+21.05% Total Asset Growth > 10%', status: 'FLAG' }
            ]
          }
        },
        connections: [
          {
            id: 'conn_rec_sales',
            title: 'Receivables ↔ Revenue',
            question: 'Are trade receivables growing faster than top-line revenue?',
            sources: 'Balance Sheet (Trade Receivables) ↔ Income Statement (Revenue)',
            fields: ['receivables', 'sales'],
            models: ['Beneish M-Score (DSRI)', 'Montier C-Score (C2)'],
            component: 'DSRI = (AR_cur / Sales_cur) / (AR_prior / Sales_prior) = 1.2500',
            finding: 'Trade Receivables grew by 50.0% while Revenue grew by only 20.0%. This significant divergence indicates potential channel stuffing, uncollected billings, or relaxed credit terms.'
          },
          {
            id: 'conn_ni_cfo',
            title: 'Net Profit ↔ Operating Cash Flow',
            question: 'How do reported earnings compare with cash generated by operations?',
            sources: 'Income Statement (Net Income) ↔ Cash Flow Statement (CFO)',
            fields: ['net_income', 'cfo'],
            models: ['Sloan Accrual Model', 'Piotroski F-Score (F_Accrual)', 'Montier C-Score (C1)', 'Beneish (TATA)'],
            component: 'Total Accruals = $29.5M | TATA = +0.02565',
            finding: 'Net Income was $109.5M, but Operating Cash Flow fell to $80.0M. When net income consistently outpaces cash generation, earnings quality degrades.'
          },
          {
            id: 'conn_sales_cogs',
            title: 'Revenue ↔ COGS / Gross Margin',
            question: 'Is gross profitability expanding or contracting under cost pressure?',
            sources: 'Income Statement (Revenue, COGS)',
            fields: ['sales', 'cogs', 'gross_profit'],
            models: ['Beneish M-Score (GMI)', 'Piotroski F-Score (F_DMargin)'],
            component: 'GMI = 1.1429 | Gross Margin FY25: 40.0% → FY26: 35.0%',
            finding: 'Gross Margin contracted from 40.0% to 35.0%. In forensic analysis, deteriorating margins create incentives to accelerate future sales or delay cost recognition.'
          },
          {
            id: 'conn_debt_assets',
            title: 'Debt & Liquidity ↔ Total Assets',
            question: 'Is leverage increasing as a proportion of the balance sheet capital base?',
            sources: 'Balance Sheet (Current Liabilities, Long-Term Debt, Total Assets)',
            fields: ['current_liabilities', 'long_term_debt', 'total_assets'],
            models: ['Altman Z\'\'-Score (X1, X4)', 'Beneish (LVGI)', 'Piotroski (F_DLever)'],
            component: 'LVGI = 1.0842 | Debt / Assets: 42.1% → 45.7%',
            finding: 'Total financial debt increased by $80.0M (+34.8%), raising leverage to 45.7% of total assets.'
          },
          {
            id: 'conn_depr_ppe',
            title: 'D&A ↔ Net PPE',
            question: 'Is depreciation expense slowing down relative to physical productive assets?',
            sources: 'Income Statement (Depreciation) ↔ Balance Sheet (Net PPE)',
            fields: ['depreciation', 'net_ppe'],
            models: ['Beneish M-Score (DEPI)', 'Montier C-Score (C5)'],
            component: 'DEPI = 1.2281 | Effective Depr Rate: 10.0% → 8.1%',
            finding: 'Depreciation expense dropped from $50M to $45M even though Net PPE grew from $450M to $510M. This suggests lengthened useful asset lives.'
          },
          {
            id: 'conn_profit_assets',
            title: 'EBIT / Net Profit ↔ Total Assets',
            question: 'Are total assets generating higher or lower operating returns?',
            sources: 'Income Statement (EBIT) ↔ Balance Sheet (Total Assets)',
            fields: ['ebit', 'net_income', 'total_assets'],
            models: ['Altman Z\'\'-Score (X3)', 'Piotroski F-Score (F_DROA)'],
            component: 'ROA: 11.84% → 9.52% | Asset Turnover: 1.053 → 1.043',
            finding: 'Asset base expanded by $200M (+21.1%) while EBIT remained flat ($171M vs $170M), diluting operational efficiency.'
          }
        ]
      },
      'dbs_group': {
        id: 'dbs_group',
        name: 'DBS Group Holdings Ltd',
        sector: 'Banking & Financial Institutions',
        sectorKey: 'banking',
        currency: 'SGD',
        units: 'S$ in Millions',
        periods: {
          prior: 'FY2023',
          current: 'FY2024'
        },
        metadata: {
          filingType: 'SGX Annual Report',
          auditor: 'PricewaterhouseCoopers LLP',
          opinion: 'Unqualified / Clean Opinion',
          filingDate: '2025-03-05',
          exchange: 'SGX: D05'
        },
        statements: {
          income: [
            { id: 'sales', label: 'Total Income / Revenue', prior: 20185.0, current: 22297.0, unit: 'S$M', category: 'Operating Income' },
            { id: 'nii', label: 'Net Interest Income (NII)', prior: 13647.0, current: 14424.0, unit: 'S$M', category: 'Operating Income' },
            { id: 'noninterest', label: 'Net Fee & Commission Income', prior: 6538.0, current: 7873.0, unit: 'S$M', category: 'Operating Income' },
            { id: 'opex', label: 'Total Operating Expenses', prior: 8061.0, current: 9018.0, unit: 'S$M', category: 'Operating Expenses' },
            { id: 'provisions', label: 'Allowances for Credit / ECL', prior: 590.0, current: 620.0, unit: 'S$M', category: 'Provisions' },
            { id: 'ebit', label: 'Profit Before Tax', prior: 11650.0, current: 12884.0, unit: 'S$M', category: 'Operating Profit' },
            { id: 'tax', label: 'Income Tax Expense', prior: 1364.0, current: 1594.0, unit: 'S$M', category: 'Taxes' },
            { id: 'net_income', label: 'Net Profit After Tax', prior: 10286.0, current: 11290.0, unit: 'S$M', category: 'Bottom Line' }
          ],
          balance: [
            { id: 'cash', label: 'Cash & Balances with Central Banks', prior: 54120.0, current: 59800.0, unit: 'S$M', category: 'Assets' },
            { id: 'gross_loans', label: 'Gross Loans & Advances to Customers', prior: 416200.0, current: 430594.0, unit: 'S$M', category: 'Assets' },
            { id: 'ecl_balance', label: 'Allowance for Expected Credit Losses', prior: 3120.0, current: 3210.0, unit: 'S$M', category: 'Assets' },
            { id: 'stage3', label: 'Stage 3 Non-Performing Loans (NPL)', prior: 4950.0, current: 4820.0, unit: 'S$M', category: 'Asset Quality' },
            { id: 'investments', label: 'Government & Investment Securities', prior: 174000.0, current: 182000.0, unit: 'S$M', category: 'Assets' },
            { id: 'total_assets', label: 'Total Assets', prior: 738801.0, current: 827219.0, unit: 'S$M', category: 'Total Assets' },
            { id: 'deposits', label: 'Customer Deposits', prior: 534950.0, current: 561730.0, unit: 'S$M', category: 'Liabilities' },
            { id: 'borrowings', label: 'Other Debt & Borrowings', prior: 142341.0, current: 196656.0, unit: 'S$M', category: 'Liabilities' },
            { id: 'total_liabilities', label: 'Total Liabilities', prior: 677291.0, current: 758386.0, unit: 'S$M', category: 'Total Liabilities' },
            { id: 'equity', label: 'Total Shareholders\' Funds', prior: 61510.0, current: 68786.0, unit: 'S$M', category: 'Equity' },
            { id: 'cet1', label: 'Common Equity Tier 1 (CET1) Ratio', prior: 14.6, current: 14.7, unit: '%', category: 'Capital Adequacy' }
          ],
          cashflow: [
            { id: 'cfo', label: 'Operating Cash Flow', prior: 14200.0, current: 15341.0, unit: 'S$M', category: 'Operating Cash Flow' },
            { id: 'investing_cash_flow', label: 'Net Cash Flow from Investments', prior: -3400.0, current: -4100.0, unit: 'S$M', category: 'Investing' },
            { id: 'financing_cash_flow', label: 'Dividends & Financing Flow', prior: -5100.0, current: -6200.0, unit: 'S$M', category: 'Financing' },
            { id: 'net_change_cash', label: 'Net Change in Cash Position', prior: 5700.0, current: 5041.0, unit: 'S$M', category: 'Summary' },
            { id: 'ending_cash', label: 'Ending Liquid Assets & Cash', prior: 54120.0, current: 59800.0, unit: 'S$M', category: 'Summary' }
          ]
        },
        models: {
          beneish: {
            name: 'Beneish M-Score',
            subtitle: 'Earnings-Manipulation Screening (Adapted for Financial Institutions)',
            score: -2.8540,
            classification: 'LOW RISK (SAFE)',
            badgeClass: 'safe',
            threshold: '< -1.78 indicates low probability of earnings manipulation',
            formula: 'M = -4.84 + 0.92·DSRI + 0.528·GMI + 0.404·AQI + 0.892·SGI + 0.115·DEPI - 0.172·SGAI + 4.679·TATA - 0.327·LVGI',
            interpretation: 'Score of -2.8540 is well below the manipulation threshold (-1.78). Asset quality and interest spreads reflect genuine commercial banking operations.',
            components: [
              { key: 'DSRI', name: 'Days Fee Receivables Index', value: 0.9840, formula: 'Fee Receivables / Fee Income Ratio', statement: 'Balance Sheet ↔ Income Statement', interpretation: 'Fee billing cycles remain consistent.', status: 'NORMAL' },
              { key: 'GMI', name: 'Gross Margin Index (NIM Proxy)', value: 1.0210, formula: 'Net Interest Margin Prior / NIM Cur', statement: 'Income Statement', interpretation: 'Net interest margins remained resilient at 2.14%.', status: 'NORMAL' },
              { key: 'AQI', name: 'Asset Quality Index (NPL / Loans)', value: 0.9420, formula: 'Stage 3 Loans / Gross Loans Ratio', statement: 'Balance Sheet', interpretation: 'NPL ratio improved from 1.19% to 1.12%.', status: 'HEALTHY' },
              { key: 'SGI', name: 'Sales Growth Index (Total Income)', value: 1.1046, formula: 'Total Income Cur / Total Income Prior', statement: 'Income Statement', interpretation: 'Total revenue grew steadily by 10.46%.', status: 'NORMAL' },
              { key: 'DEPI', name: 'Software & Technology Amortization', value: 1.0120, formula: 'Amortization Rate Consistency', statement: 'Income Statement', interpretation: 'Tech amortization rate aligned with investment.', status: 'NORMAL' },
              { key: 'SGAI', name: 'Cost-to-Income Index', value: 0.9620, formula: 'Cost-to-Income Cur / Cost-to-Income Prior', statement: 'Income Statement', interpretation: 'Cost-to-income ratio improved to 40.4%.', status: 'HEALTHY' },
              { key: 'TATA', name: 'Total Accruals to Total Assets', value: -0.00489, formula: '(Net Income - CFO) / Total Assets', statement: 'Cash Flow ↔ Balance Sheet', interpretation: 'Operating cash flow ($15.3B) comfortably exceeded Net Profit ($11.3B).', status: 'HEALTHY' },
              { key: 'LVGI', name: 'Leverage Index (Assets / Equity)', value: 1.0020, formula: 'Assets / Equity Cur vs Prior', statement: 'Balance Sheet', interpretation: 'Capital adequacy maintained with CET1 at 14.7%.', status: 'HEALTHY' }
            ]
          },
          altman: {
            name: 'Altman Z\'\'-Score',
            subtitle: 'Financial Strength & Solvency Screening',
            score: 4.1200,
            classification: 'SAFE ZONE',
            badgeClass: 'safe',
            threshold: '> 2.60 Safe Zone | 1.10 - 2.60 Grey Zone | < 1.10 Distress Zone',
            formula: 'Z\'\' = 6.56·X1 + 3.26·X2 + 6.72·X3 + 1.05·X4',
            interpretation: 'Score of 4.1200 indicates robust solvency backed by S$68.8B in common equity tier 1 capital and disciplined credit provisioning.',
            components: [
              { key: 'X1', name: 'Liquidity Coverage / Total Assets', value: 0.1520, formula: 'High Quality Liquid Assets / Total Assets', statement: 'Balance Sheet', interpretation: 'Ample liquid assets representing 15.2% of total balance sheet.', status: 'HEALTHY' },
              { key: 'X2', name: 'Retained Earnings / Total Assets', value: 0.0831, formula: 'Retained Earnings / Total Assets', statement: 'Balance Sheet', interpretation: 'Cumulative reinvested banking profits.', status: 'HEALTHY' },
              { key: 'X3', name: 'Pre-Tax Return on Assets', value: 0.0156, formula: 'Profit Before Tax / Total Assets', statement: 'Income Statement ↔ Balance Sheet', interpretation: 'Pre-tax ROA of 1.56% is superior for large commercial banks.', status: 'HEALTHY' },
              { key: 'X4', name: 'Equity / Total Liabilities', value: 0.0907, formula: 'Shareholders\' Funds / Total Liabilities', statement: 'Balance Sheet', interpretation: 'CET1 of 14.7% exceeds regulatory requirements.', status: 'HEALTHY' }
            ]
          },
          sloan: {
            name: 'Sloan Accrual Model',
            subtitle: 'Accrual Quality & Cash Realization',
            score: '-0.5173%',
            scoreNum: -0.005173,
            classification: 'HIGH CASH QUALITY (SAFE)',
            badgeClass: 'safe',
            threshold: '< 5% Low Accrual Risk | Operating Cash Flow exceeds Net Income',
            formula: 'Accrual Ratio = (Net Income - Operating Cash Flow) / Average Total Assets',
            interpretation: 'Negative accrual ratio of -0.52% indicates cash generation of S$15,341M substantially exceeded accounting net profit of S$11,290M.',
            components: [
              { key: 'Net Profit', name: 'Reported Net Profit', value: 'S$11,290M', formula: 'Consolidated Income Statement', statement: 'Income Statement', interpretation: 'Audited post-tax net profit.', status: 'RECORDED' },
              { key: 'CFO', name: 'Operating Cash Flow', value: 'S$15,341M', formula: 'Consolidated Cash Flow Statement', statement: 'Cash Flow Statement', interpretation: 'Net cash flows from banking operations.', status: 'RECORDED' },
              { key: 'Cash Surplus', name: 'CFO Excess Over Earnings', value: '+S$4,051M', formula: 'CFO - Net Income', statement: 'Cross-Statement Health', interpretation: 'Superior cash backing of accounting earnings.', status: 'STRONG' }
            ]
          },
          piotroski: {
            name: 'Piotroski F-Score',
            subtitle: 'Fundamental Strength (Banking Metric Adaptation)',
            score: '8 / 9',
            scoreNum: 8,
            classification: 'STRONG FINANCIAL HEALTH',
            badgeClass: 'safe',
            threshold: '8 - 9 Strong Health | 5 - 7 Moderate / Review | 0 - 4 Weak Financial Profile',
            formula: 'F-Score = 8 out of 9 tests passed',
            interpretation: 'Piotroski F-Score of 8/9 reflects exceptional capital strength, improving cost-to-income efficiency, and strong credit recovery performance.',
            components: [
              { key: 'F_ROA', name: 'Positive Return on Assets', test: 'ROA > 0', result: 'Pass (+1)', value: 'ROA = 1.36% > 0', status: 'PASS' },
              { key: 'F_CFO', name: 'Positive Operating Cash Flow', test: 'CFO > 0', result: 'Pass (+1)', value: 'CFO = S$15.34B > 0', status: 'PASS' },
              { key: 'F_DROA', name: 'Change in Return on Assets', test: 'ROA_cur >= ROA_prior', result: 'Pass (+1)', value: '1.36% vs 1.39% (Stable ROA)', status: 'PASS' },
              { key: 'F_ACCRUAL', name: 'CFO Exceeds Net Income', test: 'CFO > Net Income', result: 'Pass (+1)', value: 'S$15.34B > S$11.29B', status: 'PASS' },
              { key: 'F_CAPITAL', name: 'CET1 Ratio Expansion', test: 'CET1_cur >= CET1_prior', result: 'Pass (+1)', value: '14.7% >= 14.6%', status: 'PASS' },
              { key: 'F_NPL', name: 'NPL Asset Quality Improvement', test: 'NPL%_cur <= NPL%_prior', result: 'Pass (+1)', value: '1.12% <= 1.19%', status: 'PASS' },
              { key: 'F_EFF', name: 'Cost-to-Income Ratio Improvement', test: 'CIR_cur <= CIR_prior', result: 'Pass (+1)', value: '40.4% <= 39.9% (Maintained)', status: 'PASS' },
              { key: 'F_NIM', name: 'Net Interest Margin Expansion', test: 'NIM_cur >= NIM_prior', result: 'Pass (+1)', value: '2.14% vs 2.11%', status: 'PASS' },
              { key: 'F_LOAN_GROWTH', name: 'Excessive Unhedged Loan Growth', test: 'Loan Growth <= 15%', result: 'Pass (+1)', value: '+3.45% Loan Growth (Prudent)', status: 'PASS' }
            ]
          },
          montier: {
            name: 'Montier Forensic Model',
            subtitle: 'Accounting-Quality Warning Signals',
            score: '1.0000 / 6',
            scoreNum: 1,
            classification: 'LOW ACCOUNTING RISK',
            badgeClass: 'safe',
            threshold: '4 - 6 High Accounting Risk | 2 - 3 Moderate Warning | 0 - 1 Low Accounting Risk',
            formula: 'C-Score = Σ(Warning flags triggered)',
            interpretation: 'Only 1 minor flag triggered out of 6 tests. Governance and financial disclosures adhere strictly to IFRS 9 / MAS requirements.',
            components: [
              { key: 'C1', name: 'Earnings-Cash Divergence', test: 'Net Income > CFO', result: 'NOT TRIGGERED (0)', value: 'CFO exceeds Net Income by S$4.05B', status: 'CLEAN' },
              { key: 'C2', name: 'Fee Receivables Distortion', test: 'Fee Receivables > Fee Growth', result: 'NOT TRIGGERED (0)', value: 'Normal fee collection', status: 'CLEAN' },
              { key: 'C3', name: 'Underprovisioning of Credit Losses', test: 'ECL Allowance / NPL < 100%', result: 'NOT TRIGGERED (0)', value: 'ECL Coverage = 128%', status: 'CLEAN' },
              { key: 'C4', name: 'Off-Balance Sheet Expansion', test: 'Contingent Growth > 25%', result: 'NOT TRIGGERED (0)', value: 'Normal growth rate', status: 'CLEAN' },
              { key: 'C5', name: 'Tech Capitalization Acceleration', test: 'Software Cap > 20%', result: 'NOT TRIGGERED (0)', value: 'Conservative expense policy', status: 'CLEAN' },
              { key: 'C6', name: 'Rapid Unsecured Lending Growth', test: 'Unsecured > 20%', result: 'TRIGGERED (+1)', value: 'Retail credit card expansion in regional markets', status: 'FLAG' }
            ]
          }
        },
        connections: [
          {
            id: 'conn_nii_loans',
            title: 'Net Interest Income ↔ Gross Loans',
            question: 'Is interest income moving consistently with customer loan volumes and rates?',
            sources: 'Income Statement (NII) ↔ Balance Sheet (Gross Loans & Advances)',
            fields: ['nii', 'gross_loans'],
            models: ['Beneish Proxy (GMI)', 'Piotroski (F_NIM)'],
            component: 'NII = S$14,424M (+5.7%) | Gross Loans = S$430,594M (+3.5%)',
            finding: 'Interest income expansion was driven by disciplined asset repricing and rate optimization.'
          },
          {
            id: 'conn_ecl_npl',
            title: 'ECL Provisions ↔ Stage 3 NPLs',
            question: 'Are credit loss allowances adequately buffering non-performing exposures?',
            sources: 'Income Statement (Provisions) ↔ Balance Sheet (Stage 3 NPL & ECL Reserves)',
            fields: ['provisions', 'stage3', 'ecl_balance'],
            models: ['Altman Solvency', 'Montier (C3)'],
            component: 'ECL Reserves S$3,210M / Stage 3 NPL S$4,820M = 66.6% (128% with regulatory reserves)',
            finding: 'Total allowance coverage remains conservative and resilient against credit shocks.'
          }
        ]
      }
    },

    reconciliation: [
      {
        model: 'Beneish M-Score',
        fsreScore: '-1.7185 (HIGH RISK)',
        geminiScore: '-2.2400 (SAFE) [Initial Prompt] → -1.7185 (HIGH) [Gov Spec]',
        chatgptScore: '-1.7185 (HIGH RISK)',
        claudeScore: '-1.7185 (HIGH RISK)',
        status: 'PASS',
        statusClass: 'pass',
        why: 'The initial Gemini disparity was caused by an ambiguous prompt that omitted negative signs on SGAI and LVGI and used an unadjusted 5-variable model. When evaluated against the governed FSRE 8-variable specification with exact mathematical signs (-0.172·SGAI and -0.327·LVGI), all models produce the exact result of -1.7185.'
      },
      {
        model: 'Altman Z\'\'-Score',
        fsreScore: '4.0402 (SAFE ZONE)',
        geminiScore: '4.0402 (SAFE ZONE)',
        chatgptScore: '4.0402 (SAFE ZONE)',
        claudeScore: '4.0402 (SAFE ZONE)',
        status: 'PASS',
        statusClass: 'pass',
        why: '100% deterministic alignment across all four AI engines using the 4-variable Emerging Market / Non-Manufacturing Altman weighting (6.56·X1 + 3.26·X2 + 6.72·X3 + 1.05·X4).'
      },
      {
        model: 'Sloan Accrual Model',
        fsreScore: '2.6087% (LOW RISK)',
        geminiScore: '2.6087% (LOW RISK)',
        chatgptScore: '2.6087% (LOW RISK)',
        claudeScore: '2.6087% (LOW RISK)',
        status: 'PASS',
        statusClass: 'pass',
        why: 'Accrual ratio calculation matches exactly: ($109.5M Net Income - $80.0M CFO) / $1,050.0M Average Total Assets = 2.6087%.'
      },
      {
        model: 'Piotroski F-Score',
        fsreScore: '5 / 9 (MODERATE)',
        geminiScore: '5 / 9 (MODERATE)',
        chatgptScore: '5 / 9 (MODERATE)',
        claudeScore: '5 / 9 (MODERATE)',
        status: 'PASS',
        statusClass: 'pass',
        why: 'All 9 binary tests evaluated identically. Strict inequalities on ROA change and Gross Margin change resulted in 0 points, confirming deterministic parity.'
      },
      {
        model: 'Montier C-Score',
        fsreScore: '5.0000 / 6 (HIGH RISK)',
        geminiScore: '5.0000 / 6 (HIGH RISK)',
        chatgptScore: '5.0000 / 6 (HIGH RISK)',
        claudeScore: '5.0000 / 6 (HIGH RISK)',
        status: 'PASS',
        statusClass: 'pass',
        why: '5 out of 6 accounting warning signals triggered across all independent engines: Net Income > CFO, DSRI > 1.05, Inventory Growth > Sales Growth, Other CA Growth > Sales Growth, and DEPI > 1.0.'
      }
    ]
  };

  /* ==========================================================================
     2. APPLICATION STATE MANAGEMENT
     ========================================================================== */
  const COMPANY_TEMPLATES = JSON.parse(JSON.stringify(FSRE_DATA.companies));

  const state = {
    currentCompanyId: 'apex_mfg',
    analysisSourceType: 'demo', // 'demo' | 'live'
    activeStep: 'upload', // 'upload', 'processing', 'completed', 'dashboard'
    activeTab: 'overview', // 'overview', 'models', 'statements', 'charts', 'connections', 'reconciliation'
    activeStatementTab: 'income', // 'income', 'balance', 'cashflow'
    activeModelKey: 'beneish', // 'beneish', 'altman', 'sloan', 'piotroski', 'montier'
    searchQuery: '',
    viewMode: 'compact', // 'compact' vs 'detailed'
    showAllDetails: false,
    selectedFileName: '',
    processingProgress: 0,
    processingInterval: null,
    investigatedField: null,
    drawerTriggerEl: null,
    expandedModelPreviews: {},
    chartAnimStates: {} // canvasId -> rendered companyId
  };

  /* ==========================================================================
     3. DOM UTILITIES & HELPERS
     ========================================================================== */
  const $ = (id) => document.getElementById(id);
  const $$ = (selector) => document.querySelectorAll(selector);

  function formatNumber(val, decimals = 2) {
    if (val === null || val === undefined || isNaN(val)) return '—';
    return Number(val).toLocaleString(undefined, {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals
    });
  }

  function escapeHtml(str) {
    if (typeof str !== 'string') return String(str ?? '');
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function escapeRegExp(string) {
    return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  function highlightMatches(text, query) {
    if (!query || !text) return escapeHtml(text);
    const escapedText = escapeHtml(text);
    const escapedQuery = escapeRegExp(escapeHtml(query));
    try {
      const regex = new RegExp(`(${escapedQuery})`, 'gi');
      return escapedText.replace(regex, '<mark class="search-mark">$1</mark>');
    } catch (e) {
      return escapedText;
    }
  }

  function getLighterTint(hex, factor = 0.28) {
    if (!hex || hex[0] !== '#') return hex;
    const cleanHex = hex.replace('#', '');
    const num = parseInt(cleanHex, 16);
    let r = (num >> 16);
    let g = ((num >> 8) & 0x00FF);
    let b = (num & 0x0000FF);

    r = Math.min(255, Math.round(r + (255 - r) * factor));
    g = Math.min(255, Math.round(g + (255 - g) * factor));
    b = Math.min(255, Math.round(b + (255 - b) * factor));

    return `rgb(${r}, ${g}, ${b})`;
  }

  const MODEL_ICONS = {
    beneish: `<svg class="model-card-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>`,
    altman: `<svg class="model-card-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>`,
    sloan: `<svg class="model-card-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M16 16l3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1z"></path><path d="M2 16l3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1z"></path><path d="M7 21h10"></path><path d="M12 3v18"></path><path d="M3 7h18"></path></svg>`,
    piotroski: `<svg class="model-card-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 11l3 3L22 4"></path><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path></svg>`,
    montier: `<svg class="model-card-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>`
  };

  /* Map storing hit-test regions for each canvas */
  const canvasBarsMap = {};

  /* ==========================================================================
     4. RENDERERS: HEADER & NAVIGATION
     ========================================================================== */
  function renderHeader() {
    const company = FSRE_DATA.companies[state.currentCompanyId];
    const isLive = state.analysisSourceType === 'live';
    if (!company || (!isLive && ['apex_mfg', 'dbs_group'].includes(company.id))) {
      $('currentEntityBadge').innerHTML = '';
      return;
    }
    
    $('currentEntityBadge').innerHTML = `
      <div class="fsre-entity-pill">
        <span>Company:</span>
        <strong>${escapeHtml(company.name)}</strong>
        <span style="color: var(--text-light);">(${company.periods.prior} → ${company.periods.current})</span>
        <span class="source-mode-badge ${isLive ? 'live' : 'demo'}">
          ${isLive ? '● Uploaded Report' : ''}
        </span>
      </div>
    `;
  }

  function updateNavIndicator() {
    const indicator = $('fsreNavIndicator');
    const navLinks = $('fsreNavLinks');
    if (!indicator || !navLinks) return;

    const activeItem = navLinks.querySelector('.fsre-nav-item.active');
    if (!activeItem || navLinks.offsetParent === null) {
      indicator.style.opacity = '0';
      return;
    }

    const left = activeItem.offsetLeft;
    const width = activeItem.offsetWidth;
    indicator.style.width = `${width}px`;
    indicator.style.transform = `translateX(${left}px)`;
    indicator.style.opacity = '1';
  }

  function renderNav() {
    $$('.fsre-nav-item').forEach(item => {
      const tab = item.dataset.tab;
      const isActive = tab === state.activeTab;
      item.classList.toggle('active', isActive);
      item.setAttribute('aria-selected', isActive ? 'true' : 'false');
      item.setAttribute('tabindex', isActive ? '0' : '-1');
    });
    requestAnimationFrame(() => updateNavIndicator());
  }

  /* ==========================================================================
     5. RENDERERS: STEP 1 - UPLOAD SCREEN
     ========================================================================== */
  function renderUploadScreen() {
    const demoCardsContainer = $('demoCompanyCards');
    if (!demoCardsContainer) return;

    const reports = Object.values(FSRE_DATA.companies)
      .filter(company => !['apex_mfg', 'dbs_group'].includes(company.id))
      .sort((left, right) => left.name.localeCompare(right.name, undefined, { sensitivity: 'base' }));
    const groups = reports.reduce((result, company) => {
      const first = String(company.name || '').trim().charAt(0).toUpperCase();
      const letter = /^[A-Z0-9]$/.test(first) ? first : '#';
      (result[letter] ||= []).push(company);
      return result;
    }, {});
    demoCardsContainer.innerHTML = reports.length ? Object.entries(groups).map(([letter, companies]) => `
      <section class="report-letter-group" aria-labelledby="report-group-${letter}">
        <div class="report-letter-heading" id="report-group-${letter}">${letter}</div>
        <div class="report-letter-grid">
          ${companies.map(company => `
            <div class="demo-card ${company.id === state.currentCompanyId ? 'selected' : ''}" data-company-id="${escapeHtml(company.id)}" tabindex="0" role="radio" aria-checked="${company.id === state.currentCompanyId ? 'true' : 'false'}">
              <button type="button" class="report-delete-icon" data-delete-company-id="${escapeHtml(company.id)}" title="Delete this report" aria-label="Delete ${escapeHtml(company.name)}">⌫</button>
              <div class="demo-card-title">${escapeHtml(company.name)}</div>
              <div class="demo-card-sector">${escapeHtml(company.sector)} · ${escapeHtml(company.units)}</div>
              <div class="demo-card-desc">Filing: ${escapeHtml(company.metadata.filingType)} (${company.periods.prior} → ${company.periods.current}). Auditor: ${escapeHtml(company.metadata.auditor)}.</div>
            </div>
          `).join('')}
        </div>
      </section>
    `).join('') : '<div class="demo-card-desc">No uploaded annual reports are available.</div>';

    $$('.demo-card').forEach(card => {
      const selectCard = () => {
        state.currentCompanyId = card.dataset.companyId;
        state.analysisSourceType = liveContextById.has(card.dataset.companyId) ? 'live' : 'demo';
        saveUiSession();
        renderUploadScreen();
        renderHeader();
      };
      card.onclick = selectCard;
      card.onkeydown = (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          selectCard();
        }
      };
    });
    $$('.report-delete-icon').forEach(button => {
      button.onclick = event => {
        event.preventDefault(); event.stopPropagation();
        deleteUploadedReport(button.dataset.deleteCompanyId, button);
      };
    });
  }

  /* ========================================================================== 
     DATAIKU BACKEND INTEGRATION
     The production UI keeps its renderers, but all report identity, statement
     values and model results below come from backend.py rather than demo data.
     ========================================================================== */
  const liveContextById = new Map();
  const UI_SESSION_KEY = 'fsre.production.ui.session.v1';

  function saveUiSession() {
    if (!liveContextById.has(state.currentCompanyId)) return;
    sessionStorage.setItem(UI_SESSION_KEY, JSON.stringify({
      context_id: state.currentCompanyId,
      active_step: state.activeStep,
      active_tab: state.activeTab,
      statement_tab: state.activeStatementTab,
      saved_at: Date.now()
    }));
  }

  function readUiSession() {
    try { return JSON.parse(sessionStorage.getItem(UI_SESSION_KEY) || '{}'); }
    catch (_) { return {}; }
  }

  function showUiNotice(message, type = 'success') {
    let notice = $('fsreUiNotice');
    if (!notice) {
      notice = document.createElement('div');
      notice.id = 'fsreUiNotice';
      notice.className = 'fsre-ui-notice';
      notice.setAttribute('role', 'status');
      document.body.appendChild(notice);
    }
    notice.className = `fsre-ui-notice ${type}`;
    notice.textContent = message;
    notice.classList.add('visible');
    window.clearTimeout(showUiNotice.timer);
    showUiNotice.timer = window.setTimeout(() => notice.classList.remove('visible'), 5000);
  }

  function backendUrl(path) {
    return typeof window.getWebAppBackendUrl === 'function'
      ? window.getWebAppBackendUrl(path)
      : path;
  }

  async function backendJson(path, options) {
    const response = await fetch(backendUrl(path), Object.assign({
      credentials: 'same-origin',
      cache: 'no-store'
    }, options || {}));
    const contentType = response.headers.get('content-type') || '';
    const payload = contentType.includes('application/json')
      ? await response.json()
      : { error: (await response.text()).slice(0, 1200) };
    if (!response.ok) {
      const rawMessage = String(payload.error || '');
      const message = /^\s*<!doctype|^\s*<html/i.test(rawMessage)
        ? `Backend returned HTTP ${response.status} while processing ${path}. Restart the Dataiku webapp backend and review its backend log.`
        : (rawMessage || `Backend request failed (HTTP ${response.status}).`);
      const error = new Error(message);
      error.status = response.status;
      error.path = path;
      error.payload = payload;
      throw error;
    }
    return payload;
  }

  function contextId(context) {
    return `${context.assessment_run_id || ''}:${context.source_document_id || ''}`;
  }

  function contextName(context) {
    const candidates = [context.entity_name, context.company_name, context.report_name,
      context.file_name, context.source_file_name, context.source_document_id];
    return candidates.find(value => {
      const label = String(value || '').trim();
      return label && !/^unknown(?:\s+entity)?$/i.test(label);
    }) || 'Uploaded Report';
  }

  function contextToCompany(context) {
    const sectorText = String(context.sector_name || context.sector || context.sector_key || '').toLowerCase();
    const banking = /bank|financial institution|lender|credit institution/.test(sectorText);
    const base = JSON.parse(JSON.stringify(banking ? COMPANY_TEMPLATES.dbs_group : COMPANY_TEMPLATES.apex_mfg));
    const id = contextId(context);
    base.id = id;
    base.name = contextName(context).replace(/\.pdf$/i, '');
    base.sector = context.sector_name || context.sector || context.sector_key || 'Sector Pending';
    base.sectorKey = context.sector_key || 'manufacturing';
    base.units = context.reporting_units || context.units || 'Reporting Units Pending';
    base.currency = context.currency || '';
    base.periods.current = String(context.current_period || context.current_year || 'Current Period');
    base.periods.prior = String(context.prior_period || context.prior_year || 'Prior Period');
    base.metadata.filingType = context.filing_type || 'Annual Report';
    base.metadata.auditor = context.auditor || 'Not Reported';
    base.metadata.opinion = context.audit_opinion || 'Not Reported';
    base.metadata.filingDate = context.created_at || context.run_created_at || '';
    base.metadata.exchange = context.exchange || '';
    const allowed = banking ? {
      income: new Set(['sales', 'nii', 'noninterest', 'opex', 'provisions', 'ebit', 'net_income']),
      balance: new Set(['gross_loans', 'stage3', 'ecl_balance', 'investments', 'total_assets', 'deposits', 'borrowings', 'total_liabilities', 'equity', 'cet1']),
      cashflow: new Set(['cfo'])
    } : {
      income: new Set(['sales', 'cogs', 'sga', 'depreciation', 'ebit', 'interest_expense', 'net_income']),
      balance: new Set(['current_assets', 'receivables', 'inventory', 'net_ppe', 'total_assets', 'current_liabilities', 'long_term_debt', 'total_liabilities', 'retained_earnings', 'equity', 'shares']),
      cashflow: new Set(['cfo', 'investing_cash_flow', 'financing_cash_flow', 'net_change_cash', 'ending_cash'])
    };
    Object.keys(base.statements).forEach(statement => {
      base.statements[statement] = (base.statements[statement] || []).filter(row => allowed[statement]?.has(row.id));
    });
    Object.values(base.statements).flat().forEach(row => { row.current = null; row.prior = null; });
    Object.values(base.models).forEach(model => {
      model.score = '—'; model.scoreNum = null; model.classification = 'Pending Analysis';
      model.interpretation = 'Run Analysis to calculate this model for the selected annual report.';
      model.components = [];
    });
    return base;
  }

  function setStatementValues(company, inputs) {
    const current = inputs.current || {};
    const prior = inputs.prior || {};
    const aliases = {
      sales: ['sales', 'revenue', 'total_income'], cogs: ['cogs', 'cost_of_goods_sold'],
      sga: ['sga', 'sg_and_a_expense', 'operating_expenses'],
      depreciation: ['depreciation', 'depreciation_amortization'],
      ebit: ['ebit', 'operating_income_ebit'], interest_expense: ['interest_expense'],
      net_income: ['net_income', 'net_profit'], current_assets: ['current_assets', 'total_current_assets'],
      receivables: ['receivables', 'trade_receivables_net'], inventory: ['inventory'],
      net_ppe: ['net_ppe'], total_assets: ['total_assets'],
      current_liabilities: ['current_liabilities', 'total_current_liabilities'],
      long_term_debt: ['long_term_debt'], total_liabilities: ['total_liabilities'],
      retained_earnings: ['retained_earnings'], equity: ['equity', 'total_shareholders_equity'],
      shares: ['shares', 'shares_outstanding'], cfo: ['cfo', 'operating_cash_flow'],
      investing_cash_flow: ['investing_cash_flow'], financing_cash_flow: ['financing_cash_flow'],
      net_change_cash: ['net_change_cash'], ending_cash: ['ending_cash'],
      nii: ['net_interest_income'], noninterest: ['non_interest_income'],
      opex: ['operating_expenses'], provisions: ['provisions_impairment'],
      gross_loans: ['gross_loans_advances'], stage3: ['stage3_npa'],
      ecl_balance: ['ecl_balance'], investments: ['investments'],
      deposits: ['customer_deposits'], borrowings: ['borrowings'], cet1: ['cet1_ratio']
    };
    const value = (source, keys) => {
      for (const key of keys) if (source[key] !== undefined && source[key] !== null && source[key] !== '') return source[key];
      return null;
    };
    Object.values(company.statements).flat().forEach(row => {
      const keys = aliases[row.id] || [row.id];
      row.current = value(current, keys);
      row.prior = value(prior, keys);
      row.unit = company.units;
    });
  }

  function setModelValues(company, payload) {
    const derivation = payload.score_derivation || {};
    const rows = derivation.models || payload.scores || [];
    rows.forEach(row => {
      const rawKey = String(row.model_key || row.key || row.model_name || '').toLowerCase();
      const key = rawKey.includes('beneish') ? 'beneish' : rawKey.includes('altman') ? 'altman' :
        rawKey.includes('sloan') ? 'sloan' : rawKey.includes('piotroski') ? 'piotroski' :
        rawKey.includes('montier') ? 'montier' : '';
      if (!key || !company.models[key]) return;
      const model = company.models[key];
      const score = row.score_value ?? row.score ?? row.value ?? row.numeric_score;
      model.score = score === null || score === undefined ? '—' : score;
      model.scoreNum = Number(score);
      model.name = row.model_name || model.name;
      model.classification = String(row.risk_band || row.classification || row.status || 'Calculated').replaceAll('_', ' ');
      model.interpretation = row.interpretation || row.description || model.interpretation;
      model.formula = row.formula || model.formula;
      const components = row.components_json || row.calculation_components || row.components;
      if (components && !Array.isArray(components)) {
        model.components = Object.entries(components).map(([componentKey, componentValue]) => ({
          key: componentKey.toUpperCase(), name: componentKey.replaceAll('_', ' '),
          value: componentValue, formula: '', statement: 'Backend Calculation',
          interpretation: 'Calculated from the selected annual report.', status: 'RECORDED'
        }));
      } else if (Array.isArray(components)) model.components = components;
    });
  }

  async function loadLiveResult(context) {
    const query = new URLSearchParams({
      assessment_run_id: context.assessment_run_id,
      source_document_id: context.source_document_id,
      refresh_revision: String(Date.now())
    });
    const payload = await backendJson(`/api/forensic-scores?${query}`);
    const company = FSRE_DATA.companies[contextId(context)] || contextToCompany(context);
    const inputs = payload.reference_forensic_inputs || {};
    company.name = inputs.entity || company.name;
    company.sector = inputs.sector || company.sector;
    company.units = inputs.units || company.units;
    company.periods.current = String(inputs.period_normalization?.current_label || company.periods.current);
    company.periods.prior = String(inputs.period_normalization?.prior_label || company.periods.prior);
    setStatementValues(company, inputs);
    setModelValues(company, payload);
    FSRE_DATA.companies[company.id] = company;
    state.currentCompanyId = company.id;
    state.analysisSourceType = 'live';
    window.__FSRE_LIVE_SCORE_PAYLOAD__ = payload;
    return payload;
  }

  async function loadLiveResultWithRetry(context, attempts = 4) {
    let lastError;
    for (let attempt = 1; attempt <= attempts; attempt += 1) {
      try {
        return await loadLiveResult(context);
      } catch (error) {
        lastError = error;
        if (attempt >= attempts || ![500, 502, 503, 504].includes(Number(error.status))) throw error;
        showBackendProgress(92, `Waiting for refreshed backend data · attempt ${attempt + 1} of ${attempts}`);
        await new Promise(resolve => setTimeout(resolve, attempt * 1500));
      }
    }
    throw lastError;
  }

  async function loadReportContexts(selectLatest) {
    const response = await backendJson('/api/contexts');
    const contexts = Array.isArray(response) ? response : (response.contexts || response.items || []);
    liveContextById.clear();
    Object.keys(FSRE_DATA.companies).forEach(key => {
      if (!['apex_mfg', 'dbs_group'].includes(key)) delete FSRE_DATA.companies[key];
    });
    contexts.forEach(context => {
      if (!context.assessment_run_id || !context.source_document_id) return;
      const company = contextToCompany(context);
      liveContextById.set(company.id, context);
      FSRE_DATA.companies[company.id] = company;
    });
    if (selectLatest && contexts.length) state.currentCompanyId = contextId(contexts[0]);
    renderUploadScreen();
    renderHeader();
    return contexts;
  }

  async function deleteUploadedReport(companyId, button) {
    const context = liveContextById.get(companyId);
    if (!context) return;
    const reportName = contextName(context);
    if (!window.confirm(`Delete ${reportName} and its saved analysis records?`)) return;
    const original = button.textContent;
    try {
      button.disabled = true; button.textContent = '…';
      await backendJson(`/api/reports/${encodeURIComponent(context.source_document_id)}`, { method: 'DELETE' });
      if (state.currentCompanyId === companyId) {
        sessionStorage.removeItem(UI_SESSION_KEY);
        state.currentCompanyId = 'apex_mfg';
        state.analysisSourceType = 'demo';
        $('currentEntityBadge').innerHTML = '';
      }
      const contexts = await loadReportContexts(false);
      if (contexts.length && state.currentCompanyId === 'apex_mfg') {
        state.currentCompanyId = contextId(contexts[0]);
        state.analysisSourceType = 'live';
      }
      renderUploadScreen(); renderHeader();
    } catch (error) {
      window.alert(error.message || 'The report could not be deleted.');
      if (button.isConnected) { button.disabled = false; button.textContent = original; }
    }
  }

  function showBackendProgress(percent, message) {
    state.activeStep = 'processing';
    updateStepVisibility();
    $('processingPercentageText').textContent = `${percent}%`;
    $('processingProgressFill').style.width = `${percent}%`;
    $('processingProgressBarWrap').setAttribute('aria-valuenow', String(percent));
    $('processingStagesList').innerHTML = `<div class="processing-stage-item active"><span class="stage-icon">●</span><span>${escapeHtml(message)}</span></div>`;
  }

  async function runSelectedBackendAnalysis() {
    const context = liveContextById.get(state.currentCompanyId);
    if (!context) return startProcessing();
    try {
      showBackendProgress(20, 'Loading the selected annual report');
      const result = await backendJson('/api/run-analysis-validated', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ assessment_run_id: context.assessment_run_id, source_document_id: context.source_document_id })
      });
      window.__FSRE_VALIDATED_RUN_DEBUG__ = result;
      showBackendProgress(82, 'Loading validated financial inputs and forensic scores');
      await loadLiveResult(context);
      showBackendProgress(100, 'Analysis complete and saved');
      state.activeStep = 'dashboard';
      state.activeTab = 'statements';
      state.activeStatementTab = 'income';
      saveUiSession();
      updateStepVisibility();
      renderHeader(); renderExecutiveOverview(); renderStatements(); renderModelDetails(); renderConnections(); renderReconciliation();
    } catch (error) {
      state.activeStep = 'upload'; updateStepVisibility();
      window.alert(error.message || 'Run Analysis failed.');
    }
  }

  async function uploadAndRun(file) {
    try {
      if (!file || !/\.pdf$/i.test(file.name) || (file.type && file.type !== 'application/pdf')) {
        throw new Error('Only PDF annual reports are accepted.');
      }
      // Never leave the previous report visible while a new upload is being
      // registered and processed. Results are exposed only after a fresh
      // selected-document score/input response has been received.
      state.analysisSourceType = 'live';
      state.currentCompanyId = 'apex_mfg';
      window.__FSRE_LIVE_SCORE_PAYLOAD__ = null;
      window.__FSRE_VALIDATED_RUN_DEBUG__ = null;
      window.__FSRE_SINGLE_VALUE_DEBUG__ = null;
      showBackendProgress(5, `Uploading ${file.name}`);
      const form = new FormData(); form.append('files', file, file.name);
      const upload = await backendJson('/api/upload-financial-reports', { method: 'POST', body: form });
      let job = upload;
      for (let attempt = 0; upload.job_id && attempt < 180; attempt += 1) {
        await new Promise(resolve => setTimeout(resolve, 2000));
        job = await backendJson(`/api/analysis-jobs/${encodeURIComponent(upload.job_id)}`);
        const status = String(job.status || '').toUpperCase();
        const pct = Math.min(90, Math.max(10, Number(job.progress_percent || ((job.current_step || 0) / Math.max(job.total_steps || 1, 1) * 85))));
        showBackendProgress(Math.round(pct), job.message || job.stage_name || 'Processing annual report');
        if (['COMPLETED', 'SUCCESS', 'SUCCEEDED'].includes(status)) break;
        if (['FAILED', 'ERROR'].includes(status)) throw new Error(job.error_message || job.message || 'Document analysis failed.');
      }
      showBackendProgress(92, 'Refreshing financial statements for the uploaded report');
      const contexts = await loadReportContexts(true);
      if (!contexts.length) throw new Error('The pipeline completed but no report context was created.');
      const normalizedUploadName = String(file.name || '').trim().toLowerCase();
      const uploadedContext = contexts.find(context =>
        String(context.file_name || context.source_file_name || context.report_name || '')
          .trim().toLowerCase() === normalizedUploadName
      );
      const selectedContext = uploadedContext || liveContextById.get(state.currentCompanyId) || contexts[0];
      if (!selectedContext) throw new Error('The uploaded report context could not be selected.');
      state.currentCompanyId = contextId(selectedContext);
      await loadLiveResultWithRetry(selectedContext);
      renderHeader();
      renderStatements();
      renderModelDetails();
      renderConnections();
      renderReconciliation();
      showBackendProgress(100, 'Fresh financial statements are ready');
      state.activeStep = 'completed'; updateStepVisibility(); renderCompleteScreen();
      saveUiSession();
    } catch (error) {
      state.activeStep = 'upload'; updateStepVisibility();
      window.alert(error.message || 'Upload failed.');
    }
  }

  async function resolveSelectedMissingValues() {
    const context = liveContextById.get(state.currentCompanyId);
    if (!context) {
      window.alert('Select an uploaded annual report first.');
      return;
    }
    const button = $('resolveMissingBtn');
    try {
      if (button) { button.disabled = true; button.textContent = 'Resolving…'; }
      showBackendProgress(30, 'Resolving missing Income Statement, Balance Sheet and Cash Flow values');
      const result = await backendJson('/api/financial-fact-resolution/batch-preview', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          assessment_run_id: context.assessment_run_id,
          source_document_id: context.source_document_id,
          verify_source: false,
          llm_validate_all: false,
          maximum_targets: 60,
          target_concepts: [
            'revenue','cost_of_goods_sold','sg_and_a_expense','depreciation_amortization',
            'operating_income_ebit','interest_expense','net_profit','total_current_assets',
            'trade_receivables_net','inventory','net_ppe','total_assets',
            'total_current_liabilities','long_term_debt','total_liabilities','retained_earnings',
            'total_shareholders_equity','shares_outstanding','operating_cash_flow',
            'investing_cash_flow','financing_cash_flow','net_change_cash','ending_cash'
          ]
        })
      });
      window.__FSRE_MISSING_VALUE_DEBUG__ = result;
      await loadLiveResult(context);
      state.activeStep = 'dashboard'; state.activeTab = 'statements';
      saveUiSession();
      updateStepVisibility(); renderHeader(); renderExecutiveOverview(); renderStatements();
      renderModelDetails(); renderConnections(); renderReconciliation();
    } catch (error) {
      state.activeStep = 'upload'; updateStepVisibility();
      window.alert(error.message || 'Missing-value resolution failed.');
    } finally {
      if (button) { button.disabled = false; button.textContent = 'Resolve Missing Values'; }
    }
  }

  async function resolveSingleFinancialValue(fieldId, periodRole, button) {
    const context = liveContextById.get(state.currentCompanyId);
    if (!context) {
      window.alert('Select an uploaded annual report first.');
      return;
    }
    const conceptMap = {
      sales: 'revenue', cogs: 'cost_of_goods_sold', sga: 'sg_and_a_expense',
      depreciation: 'depreciation_amortization', ebit: 'operating_income_ebit',
      interest_expense: 'interest_expense', net_income: 'net_profit',
      current_assets: 'total_current_assets', receivables: 'trade_receivables_net',
      inventory: 'inventory', net_ppe: 'net_ppe', total_assets: 'total_assets',
      current_liabilities: 'total_current_liabilities', long_term_debt: 'long_term_debt',
      total_liabilities: 'total_liabilities', retained_earnings: 'retained_earnings',
      equity: 'total_shareholders_equity', shares: 'shares_outstanding',
      cfo: 'operating_cash_flow', investing_cash_flow: 'investing_cash_flow',
      financing_cash_flow: 'financing_cash_flow', net_change_cash: 'net_change_cash',
      ending_cash: 'ending_cash',
      nii: 'net_interest_income', noninterest: 'non_interest_income',
      opex: 'operating_expenses', provisions: 'provisions_impairment',
      gross_loans: 'gross_loans_advances', stage3: 'stage3_npa',
      ecl_balance: 'ecl_balance', investments: 'investments',
      deposits: 'customer_deposits', borrowings: 'borrowings', cet1: 'cet1_ratio'
    };
    const conceptKey = conceptMap[fieldId] || fieldId;
    const oldHtml = button ? button.innerHTML : '';
    try {
      if (button) { button.disabled = true; button.innerHTML = '<span>◌</span><span>Resolving</span>'; }
      const proposal = await backendJson('/api/financial-fact-resolution/propose', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          assessment_run_id: context.assessment_run_id,
          source_document_id: context.source_document_id,
          concept_key: conceptKey,
          period_role: periodRole,
          validation_mode: false
        })
      });
      window.__FSRE_SINGLE_VALUE_DEBUG__ = { request: { concept_key: conceptKey, period_role: periodRole }, response: proposal };
      if (!proposal.proposal_id) {
        throw new Error(proposal.error || proposal.explanation || 'AI did not return a saveable value.');
      }
      const approval = await backendJson('/api/financial-fact-resolution/approve', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ proposal_id: proposal.proposal_id, approved_by: 'FSRE single-value resolution' })
      });
      window.__FSRE_SINGLE_VALUE_DEBUG__.approval = approval;
      const approvedValue = approval.approved_value ?? proposal.proposed_value;
      const activeCompany = FSRE_DATA.companies[state.currentCompanyId];
      const activeRow = Object.values(activeCompany?.statements || {}).flat().find(row => row.id === fieldId);
      if (activeRow && approvedValue !== null && approvedValue !== undefined) {
        activeRow[periodRole] = Number(approvedValue);
        renderStatements();
      }
      await loadLiveResult(context);
      renderHeader(); renderStatements(); renderModelDetails();
      saveUiSession();
      showUiNotice(`${activeRow?.label || conceptKey} was resolved and saved.`);
    } catch (error) {
      showUiNotice(error.message || 'This value could not be resolved.', 'error');
      if (button && button.isConnected) { button.disabled = false; button.innerHTML = oldHtml; }
    }
  }

  function installBackendIntegration() {
    const logo = $('dataikuLogo');
    if (logo) {
      logo.src = backendUrl('/api/logo');
      logo.onerror = () => { logo.style.display = 'none'; };
    }
    const start = $('startAnalysisBtn');
    if (start) start.onclick = runSelectedBackendAnalysis;
    const resolve = $('resolveMissingBtn');
    if (resolve) resolve.onclick = resolveSelectedMissingValues;
    const viewRisk = $('viewRiskAnalysisBtn');
    if (viewRisk) viewRisk.onclick = async () => {
      const context = liveContextById.get(state.currentCompanyId);
      if (!context) { window.alert('Select an uploaded annual report first.'); return; }
      const original = viewRisk.textContent;
      try {
        viewRisk.disabled = true; viewRisk.textContent = 'Refreshing Report…';
        await loadLiveResultWithRetry(context);
        state.activeStep = 'dashboard'; state.activeTab = 'statements'; state.activeStatementTab = 'income';
        updateStepVisibility(); renderHeader(); renderExecutiveOverview(); renderStatements();
        renderModelDetails(); renderConnections(); renderReconciliation();
        saveUiSession();
        window.scrollTo({ top: 0, behavior: 'smooth' });
      } catch (error) {
        window.alert(error.message || 'The latest report data could not be loaded.');
      } finally {
        viewRisk.disabled = false; viewRisk.textContent = original;
      }
    };
    const input = $('fileInput');
    const dropzone = $('uploadDropzone');
    if (input) input.onchange = () => input.files?.[0] && uploadAndRun(input.files[0]);
    if (dropzone) dropzone.ondrop = event => {
      event.preventDefault(); dropzone.classList.remove('dragover');
      const file = event.dataTransfer.files?.[0]; if (file) uploadAndRun(file);
    };
    loadReportContexts(false).then(async contexts => {
      if (!contexts.length) {
        showUiNotice('No saved report registrations were returned by the backend.', 'error');
        return;
      }
      const saved = readUiSession();
      const selected = contexts.find(context => contextId(context) === saved.context_id);
      if (!selected) return;
      state.currentCompanyId = contextId(selected);
      state.analysisSourceType = 'live';
      state.activeTab = saved.active_tab || 'overview';
      state.activeStatementTab = saved.statement_tab || 'income';
      await loadLiveResult(selected);
      state.activeStep = ['dashboard', 'completed'].includes(saved.active_step)
        ? saved.active_step : 'upload';
      updateStepVisibility(); renderHeader(); renderUploadScreen();
      if (state.activeStep === 'completed') renderCompleteScreen();
      if (state.activeStep === 'dashboard') {
        renderNav(); renderExecutiveOverview(); renderStatements(); renderModelDetails();
        renderConnections(); renderReconciliation();
      }
    }).catch(error => {
      console.error('Unable to restore report session:', error);
      showUiNotice(error.message || 'Unable to load saved annual reports.', 'error');
    });
  }

  /* ==========================================================================
     6. STEP 2: DETERMINISTIC VARIABLE-SPEED PROCESSING SIMULATION
     ========================================================================== */
  const PROCESSING_STAGES = [
    { pct: 15, title: 'File received & document metadata parsed' },
    { pct: 35, title: 'Reading Balance Sheet, Income & Cash Flow statements' },
    { pct: 55, title: 'Extracting 42 verified financial line items' },
    { pct: 75, title: 'Mapping multi-statement cross-relationships' },
    { pct: 90, title: 'Computing 5 forensic models (Beneish, Altman, Sloan, Piotroski, Montier)' },
    { pct: 100, title: 'Analysis complete & ready for executive review' }
  ];

  function startProcessing() {
    state.activeStep = 'processing';
    state.processingProgress = 0;
    updateStepVisibility();

    const progressBar = $('processingProgressFill');
    const progressBarWrap = $('processingProgressBarWrap');
    const percentageText = $('processingPercentageText');
    const stagesList = $('processingStagesList');

    if (state.processingInterval) clearInterval(state.processingInterval);

    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const intervalTick = prefersReducedMotion ? 20 : 35;

    state.processingInterval = setInterval(() => {
      let increment = 1;
      const cur = state.processingProgress;

      if (cur < 20) {
        increment = 3;
      } else if (cur >= 20 && cur < 50) {
        increment = 2;
      } else if (cur >= 50 && cur < 80) {
        increment = 1;
      } else if (cur >= 80 && cur < 94) {
        increment = 2;
      } else {
        increment = 3;
      }

      state.processingProgress += increment;
      if (state.processingProgress > 100) state.processingProgress = 100;

      progressBar.style.width = `${state.processingProgress}%`;
      progressBarWrap.setAttribute('aria-valuenow', state.processingProgress);
      percentageText.textContent = `${state.processingProgress}%`;

      stagesList.innerHTML = PROCESSING_STAGES.map((st, idx) => {
        const isDone = state.processingProgress >= st.pct;
        const isActive = !isDone && (idx === 0 || state.processingProgress >= PROCESSING_STAGES[idx - 1].pct);
        return `
          <div class="processing-stage-item ${isDone ? 'completed' : ''} ${isActive ? 'active' : ''}">
            <span class="stage-icon" aria-hidden="true">${isDone ? '✓' : isActive ? '●' : '○'}</span>
            <span>${st.title}</span>
          </div>
        `;
      }).join('');

      if (state.processingProgress >= 100) {
        clearInterval(state.processingInterval);
        setTimeout(() => {
          state.activeStep = 'completed';
          updateStepVisibility();
          renderCompleteScreen();
        }, prefersReducedMotion ? 100 : 350);
      }
    }, intervalTick);
  }

  function renderCompleteScreen() {
    const company = FSRE_DATA.companies[state.currentCompanyId];
    $('completeCompanyTitle').textContent = `Forensic Analysis Complete: ${company.name}`;
    $('completeSubtitle').textContent = `Successfully extracted and reconciled all financial statement items for ${company.periods.prior} and ${company.periods.current}.`;
  }

  /* ==========================================================================
     7. RENDERERS: STEP 4 - EXECUTIVE DASHBOARD & MODELS
     ========================================================================== */
  function getModelCardFlags(key, m) {
    const flags = [];
    const components = m.components || [];

    if (key === 'beneish') {
      const flagged = components.filter(c => c.status === 'FLAG');
      flagged.forEach(c => {
        const valStr = typeof c.value === 'number' ? formatNumber(c.value, 2) : c.value;
        const text = c.interpretation ? `${c.key} (${valStr}) — ${c.interpretation}` : `${c.key} at ${valStr}`;
        flags.push({ severity: 'high', text });
      });
    } else if (key === 'altman') {
      const adverse = components.filter(c => c.status === 'DISTRESS' || c.status === 'FLAG' || c.status === 'WARNING');
      adverse.forEach(c => {
        const valStr = typeof c.value === 'number' ? formatNumber(c.value, 2) : c.value;
        const text = c.interpretation ? `${c.key} (${valStr}) — ${c.interpretation}` : `${c.name} (${valStr})`;
        flags.push({ severity: c.status === 'DISTRESS' ? 'high' : 'elevated', text });
      });
    } else if (key === 'sloan') {
      const notices = components.filter(c => c.status === 'FLAG' || c.status === 'NOTICE' || c.status === 'WARNING');
      notices.forEach(c => {
        const text = c.interpretation ? `${c.key} (${c.value}) — ${c.interpretation}` : `${c.key} (${c.value})`;
        flags.push({ severity: m.badgeClass === 'high' ? 'high' : 'elevated', text });
      });
    } else if (key === 'piotroski') {
      const failed = components.filter(c => c.status === 'FAIL' || (c.result && c.result.toLowerCase().startsWith('fail')));
      failed.forEach(c => {
        const text = c.value ? `${c.name} — ${c.value}` : `${c.name} (${c.test})`;
        flags.push({ severity: m.badgeClass === 'high' ? 'high' : 'elevated', text });
      });
    } else if (key === 'montier') {
      const triggered = components.filter(c => c.status === 'FLAG' || (c.result && !c.result.toUpperCase().includes('NOT TRIGGERED') && c.result.toUpperCase().includes('TRIGGERED')));
      triggered.forEach(c => {
        const text = c.value ? `${c.name} — ${c.value}` : `${c.name} (${c.test})`;
        flags.push({ severity: 'high', text });
      });
    }

    // Limit to 3 most significant flags
    const topFlags = flags.slice(0, 3);

    // No-flag state fallback if favorable/safe and 0 candidate flags
    if (topFlags.length === 0) {
      if (key === 'beneish') {
        topFlags.push({ severity: 'safe', text: `No manipulation-consistent signals detected (${m.classification})` });
      } else if (key === 'altman') {
        topFlags.push({ severity: 'safe', text: `All solvency and capital ratios in healthy range (${m.classification})` });
      } else if (key === 'sloan') {
        topFlags.push({ severity: 'safe', text: `Operating cash flow exceeds net income (${m.classification})` });
      } else if (key === 'piotroski') {
        topFlags.push({ severity: 'safe', text: `Passed fundamental strength tests (${m.classification})` });
      } else if (key === 'montier') {
        topFlags.push({ severity: 'safe', text: `No accounting warning signals triggered (${m.classification})` });
      } else {
        topFlags.push({ severity: 'safe', text: `All model metrics within normal bounds (${m.classification})` });
      }
    }

    return topFlags;
  }

  function renderExecutiveOverview() {
    const company = FSRE_DATA.companies[state.currentCompanyId];
    const models = company.models;
    const query = state.searchQuery.toLowerCase().trim();

    // Executive Meta Bar
    $('execEntityName').textContent = company.name;
    $('execSector').textContent = company.sector;
    $('execPeriods').textContent = `${company.periods.prior} → ${company.periods.current}`;
    $('execCurrency').textContent = `${company.currency} (${company.units})`;
    $('execAuditor').textContent = company.metadata.auditor;

    // 5 Model Highlight Cards with Inline Quick-Preview Affordance & Risk Accents
    const modelsContainer = $('executiveModelCards');
    modelsContainer.innerHTML = Object.entries(models).map(([key, m]) => {
      const flags = getModelCardFlags(key, m);
      const isMatch = query && (
        m.name.toLowerCase().includes(query) ||
        m.subtitle.toLowerCase().includes(query) ||
        (m.components && m.components.some(c => c.key.toLowerCase().includes(query) || c.name.toLowerCase().includes(query))) ||
        flags.some(f => f.text.toLowerCase().includes(query))
      );
      const isExpanded = !!state.expandedModelPreviews[key];
      const iconSvg = MODEL_ICONS[key] || '';

      const flagsHtml = `
        <div class="model-card-flags" aria-label="Model flags for ${escapeHtml(m.name)}">
          ${flags.map(f => `
            <div class="model-flag-item">
              <span class="model-flag-dot ${f.severity}" aria-hidden="true"></span>
              <span class="model-flag-text" title="${escapeHtml(f.text)}">${escapeHtml(f.text)}</span>
            </div>
          `).join('')}
        </div>
      `;

      return `
        <div class="model-card ${m.badgeClass} ${isMatch ? 'search-match' : ''}" data-model-key="${key}" tabindex="0" role="button" aria-label="${escapeHtml(m.name)} - Score ${typeof m.score === 'number' ? formatNumber(m.score, 4) : m.score} - ${m.classification}">
          <div class="model-card-top">
            <div>
              <div class="model-card-name-wrap">
                ${iconSvg}
                <div class="model-card-name">${escapeHtml(m.name)}</div>
              </div>
              <div class="model-card-purpose">${escapeHtml(m.subtitle)}</div>
            </div>
            <span class="risk-badge ${m.badgeClass}"><span class="risk-dot" aria-hidden="true"></span>${m.classification}</span>
          </div>
          <div class="model-card-score">${typeof m.score === 'number' ? formatNumber(m.score, 4) : m.score}</div>
          <div style="font-size: 11px; color: var(--text-muted); line-height: 1.4;">${escapeHtml(m.threshold)}</div>
          
          ${flagsHtml}

          <div class="model-card-footer">
            <button class="model-quick-preview-btn" data-preview-key="${key}" aria-label="Toggle component quick preview for ${escapeHtml(m.name)}">
              <span>${isExpanded ? 'Hide' : 'Quick Preview'}</span>
              <span>${isExpanded ? '▲' : '▼'}</span>
            </button>
            <span style="color: var(--brand-cyan); font-weight: 700;">Inspect Full Model →</span>
          </div>

          <div class="model-quick-preview-drawer ${isExpanded ? 'open' : ''}" id="previewDrawer-${key}">
            <div style="font-weight: 700; color: var(--bg-header); margin-bottom: 6px; font-size: 11px;">Components:</div>
            ${(m.components || []).slice(0, 4).map(c => `
              <div class="quick-preview-item">
                <span style="font-family: var(--font-mono); color: var(--brand-cyan); font-weight: 700;">${c.key}</span>
                <span style="font-family: var(--font-mono); font-weight: 600;">${typeof c.value === 'number' ? formatNumber(c.value, 4) : c.value}</span>
              </div>
            `).join('')}
            ${(m.components && m.components.length > 4) ? `<div style="text-align: right; color: var(--text-muted); margin-top: 4px; font-size: 10px;">+${m.components.length - 4} more in drilldown</div>` : ''}
          </div>
        </div>
      `;
    }).join('');

    // Wire main card navigation & quick preview toggle button
    $$('.model-card').forEach(card => {
      const key = card.dataset.modelKey;
      card.onclick = (e) => {
        // If clicked the quick preview button, do not navigate
        if (e.target.closest('.model-quick-preview-btn')) return;
        navigateToModel(key);
      };
      card.onkeydown = (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          if (e.target.closest('.model-quick-preview-btn')) return;
          e.preventDefault();
          navigateToModel(key);
        }
      };
    });

    $$('.model-quick-preview-btn').forEach(btn => {
      btn.onclick = (e) => {
        e.stopPropagation();
        const key = btn.dataset.previewKey;
        state.expandedModelPreviews[key] = !state.expandedModelPreviews[key];
        renderExecutiveOverview();
      };
    });

    // Forensic Model Profile Bars
    const profileContainer = $('modelProfileSummaryRows');
    profileContainer.innerHTML = [
      { name: 'Beneish M-Score', score: models.beneish.score, risk: models.beneish.classification, cls: models.beneish.badgeClass, width: models.beneish.badgeClass === 'high' ? '88%' : '22%' },
      { name: 'Altman Z\'\'-Score', score: models.altman.score, risk: models.altman.classification, cls: models.altman.badgeClass, width: models.altman.badgeClass === 'safe' ? '25%' : '75%' },
      { name: 'Sloan Accruals', score: models.sloan.score, risk: models.sloan.classification, cls: models.sloan.badgeClass, width: '28%' },
      { name: 'Piotroski F-Score', score: models.piotroski.score, risk: models.piotroski.classification, cls: models.piotroski.badgeClass, width: models.piotroski.badgeClass === 'elevated' ? '55%' : '88%' },
      { name: 'Montier Warning Signals', score: models.montier.score, risk: models.montier.classification, cls: models.montier.badgeClass, width: models.montier.badgeClass === 'high' ? '83%' : '17%' }
    ].map(item => `
      <div class="profile-bar-row ${item.cls}">
        <div class="profile-bar-identity">
          <div class="profile-bar-name">${escapeHtml(item.name)}</div>
          <div class="profile-bar-score">${escapeHtml(String(item.score ?? '—'))}</div>
        </div>
        <div class="profile-bar-meter">
          <div class="profile-bar-track" aria-label="${escapeHtml(item.name)} risk profile">
            <div class="profile-bar-fill" style="width: ${item.width}; background: ${item.cls === 'high' ? 'var(--risk-high-badge)' : item.cls === 'elevated' ? 'var(--risk-elevated-badge)' : 'var(--risk-low-badge)'};"></div>
          </div>
          <span class="profile-scale-label">Risk Profile</span>
        </div>
        <div class="profile-bar-verdict">
          <span class="risk-badge ${item.cls}">${item.risk}</span>
        </div>
      </div>
    `).join('');

    renderCharts();
  }

  function navigateToModel(modelKey) {
    state.activeTab = 'models';
    state.activeModelKey = modelKey;
    renderNav();
    updateStepVisibility();
    renderModelDetails();
    window.scrollTo({ top: $('section-models').offsetTop - 120, behavior: 'smooth' });
  }

  /* ==========================================================================
     8. RENDERERS: FINANCIAL STATEMENTS & SEARCH
     ========================================================================== */
  function renderStatements() {
    const company = FSRE_DATA.companies[state.currentCompanyId];
    const items = company.statements[state.activeStatementTab] || [];
    const query = state.searchQuery.toLowerCase().trim();

    const filtered = items.filter(it => 
      !query || 
      it.label.toLowerCase().includes(query) || 
      it.id.toLowerCase().includes(query) ||
      it.category.toLowerCase().includes(query)
    );

    const tableBody = $('statementTableBody');
    const showClassification = state.activeStatementTab !== 'cashflow';
    const classificationHeader = $('statementClassificationHeader');
    if (classificationHeader) classificationHeader.hidden = !showClassification;
    $('statementPeriodPriorHeader').textContent = `${company.periods.prior} (${company.units})`;
    $('statementPeriodCurHeader').textContent = `${company.periods.current} (${company.units})`;

    tableBody.classList.remove('table-fade-swap');
    void tableBody.offsetWidth;
    tableBody.classList.add('table-fade-swap');

    if (filtered.length === 0) {
      tableBody.innerHTML = `
        <tr>
          <td colspan="${showClassification ? 5 : 4}" style="text-align:center; padding: 32px; color: var(--text-muted);">
            No matching financial fields found for "${escapeHtml(query)}".
          </td>
        </tr>
      `;
      return;
    }

    tableBody.innerHTML = filtered.map(row => {
      const prior = row.prior;
      const current = row.current;
      const hasPrior = prior !== null && prior !== undefined && prior !== '';
      const hasCurrent = current !== null && current !== undefined && current !== '';
      const changeAbs = hasPrior && hasCurrent ? current - prior : null;
      const changePct = changeAbs !== null && prior !== 0 ? (changeAbs / Math.abs(prior)) * 100 : null;
      const changeClass = changeAbs > 0 ? 'text-green' : changeAbs < 0 ? 'text-red' : '';

      const valueCell = (value, role) => value === null || value === undefined || value === ''
        ? `<button type="button" class="ai-cell-resolve" data-ai-field="${row.id}" data-ai-role="${role}" title="Resolve this value with AI" aria-label="Resolve ${escapeHtml(row.label)} for the ${role} period with AI"><span aria-hidden="true">✦</span><span>Resolve</span></button>`
        : formatNumber(value, 2);

      const highlightedLabel = highlightMatches(row.label, query);
      const highlightedId = highlightMatches(row.id, query);
      const highlightedCategory = highlightMatches(row.category, query);

      return `
        <tr class="clickable-row" data-field-id="${row.id}" data-statement="${state.activeStatementTab}" tabindex="0" role="button" aria-label="Inspect ${escapeHtml(row.label)}">
          <td>
            <strong>${highlightedLabel}</strong>
            <div style="font-size: 11px; color: var(--text-muted); font-family: var(--font-mono);">${highlightedId}</div>
          </td>
          ${showClassification ? `<td><span class="badge-tag">${highlightedCategory}</span></td>` : ''}
          <td class="num">${valueCell(prior, 'prior')}</td>
          <td class="num" style="font-weight: 700;">${valueCell(current, 'current')}</td>
          <td class="num ${changeClass}">
            ${changeAbs === null ? '—' : `${changeAbs >= 0 ? '+' : ''}${formatNumber(changeAbs, 2)}`} 
            <small style="color: var(--text-muted);">(${changePct !== null ? (changePct >= 0 ? '+' : '') + formatNumber(changePct, 1) + '%' : '—'})</small>
          </td>
        </tr>
      `;
    }).join('');

    $$('#statementTableBody .clickable-row').forEach(tr => {
      const inspect = () => openFieldInvestigation(tr.dataset.fieldId, tr.dataset.statement);
      tr.onclick = inspect;
      tr.onkeydown = (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          inspect();
        }
      };
    });
    $$('#statementTableBody .ai-cell-resolve').forEach(button => {
      button.onclick = event => {
        event.preventDefault(); event.stopPropagation();
        resolveSingleFinancialValue(button.dataset.aiField, button.dataset.aiRole, button);
      };
    });
  }

  /* ==========================================================================
     9. RENDERERS: MODEL DRILLDOWNS & EXACT FORMULAS
     ========================================================================== */
  function renderModelDetails() {
    const company = FSRE_DATA.companies[state.currentCompanyId];
    const container = $('modelDrilldownContainer');
    const query = state.searchQuery.toLowerCase().trim();

    // Model Selector Tabs
    const tabsContainer = $('modelTabsContainer');
    tabsContainer.innerHTML = Object.entries(company.models).map(([key, m]) => {
      const isMatch = query && (
        m.name.toLowerCase().includes(query) ||
        (m.components && m.components.some(c => c.key.toLowerCase().includes(query) || c.name.toLowerCase().includes(query)))
      );
      return `
        <button class="statement-tab-btn ${key === state.activeModelKey ? 'active' : ''} ${isMatch ? 'search-match' : ''}" data-model-tab="${key}" role="tab" aria-selected="${key === state.activeModelKey ? 'true' : 'false'}">
          ${escapeHtml(m.name)}
        </button>
      `;
    }).join('');

    $$('[data-model-tab]').forEach(btn => {
      btn.onclick = () => {
        state.activeModelKey = btn.dataset.modelTab;
        renderModelDetails();
      };
    });

    const m = company.models[state.activeModelKey];
    if (!m) return;
    const compactMontier = state.activeModelKey === 'montier';

    container.innerHTML = `
      <div class="model-drilldown-card">
        <div class="model-drilldown-head">
          <div>
            <h3 style="font-size: 20px; font-weight: 800; color: var(--bg-header);">${escapeHtml(m.name)}</h3>
            <p style="font-size: 13px; color: var(--text-muted);">${escapeHtml(m.subtitle)}</p>
          </div>
          <div style="text-align: right;">
            <span class="risk-badge ${m.badgeClass}" style="font-size: 13px; padding: 6px 14px;">${m.classification}</span>
            <div style="font-size: 24px; font-weight: 900; font-family: var(--font-mono); margin-top: 4px;">
              ${typeof m.score === 'number' ? formatNumber(m.score, 4) : m.score}
            </div>
          </div>
        </div>

        <div class="detailed-only" style="font-size: 13px; color: var(--text-secondary); line-height: 1.6; margin-bottom: 16px;">
          <strong>Interpretation:</strong> ${escapeHtml(m.interpretation)}
        </div>

        <div class="detailed-only" style="margin: 16px 0;">
          <div style="font-size: 11px; text-transform: uppercase; font-weight: 700; color: var(--text-muted); letter-spacing: 0.5px; margin-bottom: 6px;">
            Exact Governed FSRE Formula &amp; Implementation:
          </div>
          <div class="model-formula-box">
            ${escapeHtml(m.formula)}
          </div>
        </div>

        <h4 style="font-size: 14px; font-weight: 700; color: var(--bg-header); margin-top: 24px; margin-bottom: 12px;">
          Component Decomposition &amp; Statement Lineage (Click row to inspect)
        </h4>

        <div class="table-responsive">
          <table class="components-table" aria-label="${escapeHtml(m.name)} Components">
            <thead>
              <tr>
                <th>Component</th>
                ${compactMontier ? '' : '<th>Formula / Condition</th>'}
                <th>Calculated Value</th>
                ${compactMontier ? '' : '<th>Status / Signal</th>'}
              </tr>
            </thead>
            <tbody>
              ${(m.components || []).map((c, cIdx) => {
                const isMatch = query && (
                  c.key.toLowerCase().includes(query) ||
                  c.name.toLowerCase().includes(query) ||
                  (c.formula && c.formula.toLowerCase().includes(query))
                );
                return `
                  <tr class="clickable-row component-row ${isMatch ? 'search-match' : ''}" data-model-key="${state.activeModelKey}" data-component-index="${cIdx}" tabindex="0" role="button" aria-label="Inspect component ${escapeHtml(c.name)}">
                    <td><strong style="color: var(--brand-cyan); font-family: var(--font-mono);">${highlightMatches(c.key, query)}</strong></td>
                    ${compactMontier ? '' : `<td style="font-family: var(--font-mono); font-size: 11px; color: var(--text-muted);">${highlightMatches(c.formula || c.test || '—', query)}</td>`}
                    <td style="font-family: var(--font-mono); font-weight: 700;">${typeof c.value === 'number' ? formatNumber(c.value, 4) : c.value}</td>
                    ${compactMontier ? '' : `<td>
                      <span class="risk-badge ${c.status === 'FLAG' || c.status === 'FAIL' ? 'high' : c.status === 'PASS' || c.status === 'HEALTHY' || c.status === 'CLEAN' ? 'safe' : 'info'}">
                        ${c.result || c.status}
                      </span>
                    </td>`}
                  </tr>
                `;
              }).join('')}
            </tbody>
          </table>
        </div>
      </div>
    `;

    // Make every component row clickable to open drawer drilldown
    $$('.component-row').forEach(row => {
      const openRow = () => {
        const idx = Number(row.dataset.componentIndex);
        const comp = m.components[idx];
        if (comp) openComponentInvestigation(m, comp);
      };
      row.onclick = openRow;
      row.onkeydown = (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          openRow();
        }
      };
    });
  }

  /* ==========================================================================
     10. RENDERERS: FINANCIAL STATEMENT CONNECTIONS
     ========================================================================== */
  function renderConnections() {
    const company = FSRE_DATA.companies[state.currentCompanyId];
    const container = $('statementConnectionsGrid');
    const query = state.searchQuery.toLowerCase().trim();

    container.innerHTML = company.connections.map(conn => {
      const isMatch = query && (
        conn.title.toLowerCase().includes(query) ||
        conn.question.toLowerCase().includes(query) ||
        conn.finding.toLowerCase().includes(query) ||
        conn.fields.some(f => f.toLowerCase().includes(query)) ||
        conn.models.some(m => m.toLowerCase().includes(query))
      );

      return `
        <div class="connection-card ${isMatch ? 'search-match' : ''}" data-conn-id="${conn.id}" tabindex="0" role="button" aria-label="Inspect relationship ${escapeHtml(conn.title)}">
          <div class="connection-title">
            <span>🔗</span>
            <span>${highlightMatches(conn.title, query)}</span>
          </div>
          <div class="connection-question">
            <strong>Question:</strong> ${highlightMatches(conn.question, query)}
          </div>
          <div style="font-size: 12px; color: var(--text-secondary); margin-bottom: 12px; line-height: 1.5;">
            ${highlightMatches(conn.finding, query)}
          </div>
          <div class="connection-meta-row">
            <span><strong>Models:</strong> ${escapeHtml(conn.models.join(', '))}</span>
            <span style="color: var(--brand-cyan); font-weight: 700;">Examine Lineage →</span>
          </div>
        </div>
      `;
    }).join('');

    $$('#statementConnectionsGrid .connection-card').forEach(card => {
      const openConn = () => {
        const connId = card.dataset.connId;
        const conn = company.connections.find(c => c.id === connId);
        if (conn) openConnectionModal(conn);
      };
      card.onclick = openConn;
      card.onkeydown = (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          openConn();
        }
      };
    });
  }

  /* ==========================================================================
     11. RENDERERS: AI RECONCILIATION MATRIX
     ========================================================================== */
  function renderReconciliation() {
    const container = $('reconciliationTableBody');
    const query = state.searchQuery.toLowerCase().trim();

    container.innerHTML = FSRE_DATA.reconciliation.map(rec => {
      const isMatch = query && (
        rec.model.toLowerCase().includes(query) ||
        rec.why.toLowerCase().includes(query) ||
        rec.fsreScore.toLowerCase().includes(query)
      );
      const badgeVariant = rec.statusClass === 'pass' ? 'safe' : 'elevated';

      return `
        <tr class="${isMatch ? 'search-match' : ''}">
          <td><strong style="color: var(--bg-header); font-size: 14px;">${highlightMatches(rec.model, query)}</strong></td>
          <td style="font-weight: 800; font-family: var(--font-mono); color: var(--brand-blue);">${escapeHtml(rec.fsreScore)}</td>
          <td style="font-family: var(--font-mono); font-size: 12px;">${escapeHtml(rec.geminiScore)}</td>
          <td style="font-family: var(--font-mono); font-size: 12px;">${escapeHtml(rec.chatgptScore)}</td>
          <td style="font-family: var(--font-mono); font-size: 12px;">${escapeHtml(rec.claudeScore)}</td>
          <td><span class="risk-badge ${badgeVariant}"><span class="risk-dot" aria-hidden="true"></span>${rec.status}</span></td>
        </tr>
        <tr style="background: var(--bg-surface-subtle);">
          <td colspan="6" style="padding: 10px 18px; font-size: 12px; color: var(--text-secondary); border-bottom: 2px solid var(--border-color);">
            <strong style="color: var(--brand-cyan);">Reconciliation Verification Note:</strong> ${highlightMatches(rec.why, query)}
          </td>
        </tr>
      `;
    }).join('');
  }

  /* ==========================================================================
     12. INTERACTIVE CHARTS WITH TOOLTIPS, ANIMATIONS & HIT-TESTING
     ========================================================================== */
  function renderCharts() {
    const company = FSRE_DATA.companies[state.currentCompanyId];
    
    // 1. Revenue vs Receivables
    drawBarComparisonChart('chartRevVsRec', {
      title: 'Revenue vs Trade Receivables',
      tooltipId: 'tooltipRevVsRec',
      srTableId: 'srTableRevVsRec',
      labels: [company.periods.prior, company.periods.current],
      series: [
        { label: 'Revenue ($M)', values: [company.statements.income.find(i=>i.id==='sales')?.prior||0, company.statements.income.find(i=>i.id==='sales')?.current||0], color: '#1D96AE', fieldId: 'sales', statement: 'income' },
        { label: 'Receivables ($M)', values: [company.statements.balance.find(i=>i.id==='receivables')?.prior||0, company.statements.balance.find(i=>i.id==='receivables')?.current||0], color: '#DC2626', fieldId: 'receivables', statement: 'balance' }
      ]
    });

    // 2. Net Income vs Operating Cash Flow
    drawBarComparisonChart('chartNiVsCfo', {
      title: 'Net Profit vs Operating Cash Flow (CFO)',
      tooltipId: 'tooltipNiVsCfo',
      srTableId: 'srTableNiVsCfo',
      labels: [company.periods.prior, company.periods.current],
      series: [
        { label: 'Net Profit ($M)', values: [company.statements.income.find(i=>i.id==='net_income')?.prior||0, company.statements.income.find(i=>i.id==='net_income')?.current||0], color: '#0E7490', fieldId: 'net_income', statement: 'income' },
        { label: 'Operating Cash Flow ($M)', values: [company.statements.cashflow.find(i=>i.id==='cfo')?.prior||0, company.statements.cashflow.find(i=>i.id==='cfo')?.current||0], color: '#16A34A', fieldId: 'cfo', statement: 'cashflow' }
      ]
    });

    // 3. Gross Margin Trend
    drawBarComparisonChart('chartMarginCogs', {
      title: 'Revenue vs Cost of Goods Sold (COGS)',
      tooltipId: 'tooltipMarginCogs',
      srTableId: 'srTableMarginCogs',
      labels: [company.periods.prior, company.periods.current],
      series: [
        { label: 'Revenue ($M)', values: [company.statements.income.find(i=>i.id==='sales')?.prior||0, company.statements.income.find(i=>i.id==='sales')?.current||0], color: '#1D96AE', fieldId: 'sales', statement: 'income' },
        { label: 'COGS ($M)', values: [company.statements.income.find(i=>i.id==='cogs')?.prior||0, company.statements.income.find(i=>i.id==='cogs')?.current||0], color: '#D97706', fieldId: 'cogs', statement: 'income' }
      ]
    });

    // 4. Asset Structure Comparison
    drawBarComparisonChart('chartAssetStructure', {
      title: 'Balance Sheet Composition',
      tooltipId: 'tooltipAssetStructure',
      srTableId: 'srTableAssetStructure',
      labels: [company.periods.prior, company.periods.current],
      series: [
        { label: 'Current Assets ($M)', values: [company.statements.balance.find(i=>i.id==='current_assets')?.prior||0, company.statements.balance.find(i=>i.id==='current_assets')?.current||0], color: '#2563EB', fieldId: 'current_assets', statement: 'balance' },
        { label: 'Net PPE ($M)', values: [company.statements.balance.find(i=>i.id==='net_ppe')?.prior||0, company.statements.balance.find(i=>i.id==='net_ppe')?.current||0], color: '#7C3AED', fieldId: 'net_ppe', statement: 'balance' },
        { label: 'Total Debt ($M)', values: [(company.statements.balance.find(i=>i.id==='current_liabilities')?.prior||0)+(company.statements.balance.find(i=>i.id==='long_term_debt')?.prior||0), (company.statements.balance.find(i=>i.id==='current_liabilities')?.current||0)+(company.statements.balance.find(i=>i.id==='long_term_debt')?.current||0)], color: '#DC2626', fieldId: 'total_liabilities', statement: 'balance' }
      ]
    });
  }

  function drawBarComparisonChart(canvasId, config) {
    const canvas = $(canvasId);
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const container = canvas.parentElement;
    const tooltip = config.tooltipId ? $(config.tooltipId) : null;
    const srTable = config.srTableId ? $(config.srTableId) : null;

    // High DPI Support
    const dpr = window.devicePixelRatio || 1;
    const displayWidth = container.clientWidth || 400;
    const displayHeight = container.clientHeight || 220;

    canvas.width = displayWidth * dpr;
    canvas.height = displayHeight * dpr;
    canvas.style.width = `${displayWidth}px`;
    canvas.style.height = `${displayHeight}px`;
    ctx.scale(dpr, dpr);

    // Populate accessible screen-reader fallback table
    if (srTable) {
      srTable.innerHTML = `
        <table>
          <caption>${escapeHtml(config.title)}</caption>
          <thead>
            <tr><th>Series</th>${config.labels.map(l => `<th>${escapeHtml(l)}</th>`).join('')}</tr>
          </thead>
          <tbody>
            ${config.series.map(s => `
              <tr>
                <td>${escapeHtml(s.label)}</td>
                ${s.values.map(v => `<td>${formatNumber(v, 2)}</td>`).join('')}
              </tr>
            `).join('')}
          </tbody>
        </table>
      `;
    }

    // Determine if we should animate (only on initial load or dataset switch)
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const shouldAnimate = !prefersReducedMotion && (state.chartAnimStates[canvasId] !== state.currentCompanyId);

    // Find max value
    let maxVal = 0;
    config.series.forEach(s => s.values.forEach(v => { if (v > maxVal) maxVal = v; }));
    maxVal = (maxVal * 1.15) || 100;

    const padLeft = 60;
    const padRight = 20;
    const padTop = 30;
    const padBottom = 40;
    const chartW = displayWidth - padLeft - padRight;
    const chartH = displayHeight - padTop - padBottom;

    function renderFrame(progress = 1.0, hoveredBar = null) {
      ctx.clearRect(0, 0, displayWidth, displayHeight);

      // Grid lines
      ctx.strokeStyle = '#E2E8F0';
      ctx.lineWidth = 1;
      ctx.fillStyle = '#64748B';
      ctx.font = '11px sans-serif';

      const gridLines = 4;
      for (let i = 0; i <= gridLines; i++) {
        const y = padTop + (chartH / gridLines) * i;
        const val = maxVal - (maxVal / gridLines) * i;
        ctx.beginPath();
        ctx.moveTo(padLeft, y);
        ctx.lineTo(displayWidth - padRight, y);
        ctx.stroke();
        ctx.fillText(Math.round(val), 10, y + 4);
      }

      // Compute bars
      const groupCount = config.labels.length;
      const seriesCount = config.series.length;
      const groupWidth = chartW / groupCount;
      const barWidth = Math.min(36, (groupWidth * 0.7) / seriesCount);

      const computedBars = [];

      config.labels.forEach((label, gIdx) => {
        const gX = padLeft + gIdx * groupWidth;
        const groupCenterX = gX + groupWidth / 2;

        config.series.forEach((s, sIdx) => {
          const val = s.values[gIdx];
          const targetBarH = (val / maxVal) * chartH;
          const currentBarH = Math.max(0, targetBarH * progress);
          const barX = groupCenterX - (seriesCount * barWidth) / 2 + sIdx * barWidth;
          const barY = padTop + chartH - currentBarH;

          const isHovered = hoveredBar && hoveredBar.seriesIdx === sIdx && hoveredBar.groupIdx === gIdx;
          const actualBarH = Math.max(currentBarH, 2);

          // Vertical linear gradient from lighter tint to full base color
          const barGrad = ctx.createLinearGradient(barX, barY, barX, barY + actualBarH);
          barGrad.addColorStop(0, getLighterTint(s.color, isHovered ? 0.35 : 0.25));
          barGrad.addColorStop(1, s.color);

          ctx.fillStyle = barGrad;

          // Soft shadow under bars
          if (isHovered) {
            ctx.shadowColor = 'rgba(0, 0, 0, 0.25)';
            ctx.shadowBlur = 8;
            ctx.shadowOffsetY = 2;
          } else {
            ctx.shadowColor = 'rgba(0, 0, 0, 0.08)';
            ctx.shadowBlur = 4;
            ctx.shadowOffsetY = 1;
          }

          ctx.beginPath();
          ctx.roundRect(barX, barY, barWidth - 4, currentBarH, [4, 4, 0, 0]);
          ctx.fill();

          // Reset shadow immediately
          ctx.shadowColor = 'transparent';
          ctx.shadowBlur = 0;
          ctx.shadowOffsetY = 0;

          // Numeric label on top of bar
          if (progress >= 0.8) {
            ctx.fillStyle = isHovered ? '#1D96AE' : '#0F172A';
            ctx.font = 'bold 10px monospace';
            ctx.textAlign = 'center';
            ctx.fillText(Math.round(val), barX + (barWidth - 4) / 2, barY - 5);
          }

          computedBars.push({
            x: barX,
            y: barY,
            w: barWidth - 4,
            h: currentBarH,
            groupLabel: label,
            seriesLabel: s.label,
            value: val,
            color: s.color,
            fieldId: s.fieldId,
            statement: s.statement,
            seriesIdx: sIdx,
            groupIdx: gIdx
          });
        });

        // Group Label
        ctx.fillStyle = '#334155';
        ctx.font = 'bold 12px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(label, groupCenterX, displayHeight - 12);
      });

      // Legend
      let legendX = padLeft;
      config.series.forEach(s => {
        ctx.fillStyle = s.color;
        ctx.fillRect(legendX, 10, 10, 10);
        ctx.fillStyle = '#334155';
        ctx.font = '11px sans-serif';
        ctx.textAlign = 'left';
        ctx.fillText(s.label, legendX + 14, 19);
        legendX += ctx.measureText(s.label).width + 30;
      });

      canvasBarsMap[canvasId] = computedBars;
    }

    if (shouldAnimate) {
      state.chartAnimStates[canvasId] = state.currentCompanyId;
      const startTime = performance.now();
      const duration = 500;

      function step(now) {
        const elapsed = now - startTime;
        const rawProgress = Math.min(1.0, elapsed / duration);
        // Ease-out cubic curve
        const eased = 1 - Math.pow(1 - rawProgress, 3);
        renderFrame(eased);
        if (rawProgress < 1.0) {
          requestAnimationFrame(step);
        }
      }
      requestAnimationFrame(step);
    } else {
      state.chartAnimStates[canvasId] = state.currentCompanyId;
      renderFrame(1.0);
    }

    // Attach Interactive Hit-Testing Listeners (Tooltips + Click/Tap Drilldown)
    canvas.onpointermove = (e) => {
      const rect = canvas.getBoundingClientRect();
      const mouseX = e.clientX - rect.left;
      const mouseY = e.clientY - rect.top;

      const bars = canvasBarsMap[canvasId] || [];
      const hit = bars.find(b => mouseX >= b.x && mouseX <= b.x + b.w && mouseY >= b.y && mouseY <= b.y + b.h);

      if (hit) {
        canvas.style.cursor = 'pointer';
        renderFrame(1.0, hit);
        if (tooltip) {
          tooltip.innerHTML = `
            <div class="chart-tooltip-title">${escapeHtml(hit.seriesLabel)} (${escapeHtml(hit.groupLabel)})</div>
            <div class="chart-tooltip-val">${formatNumber(hit.value, 2)}</div>
            <div class="chart-tooltip-hint">Click / Tap to inspect provenance</div>
          `;
          tooltip.style.left = `${hit.x + hit.w / 2}px`;
          tooltip.style.top = `${hit.y}px`;
          tooltip.classList.add('visible');
        }
      } else {
        canvas.style.cursor = 'default';
        renderFrame(1.0, null);
        if (tooltip) tooltip.classList.remove('visible');
      }
    };

    canvas.onpointerleave = () => {
      renderFrame(1.0, null);
      if (tooltip) tooltip.classList.remove('visible');
    };

    canvas.onclick = (e) => {
      const rect = canvas.getBoundingClientRect();
      const mouseX = e.clientX - rect.left;
      const mouseY = e.clientY - rect.top;

      const bars = canvasBarsMap[canvasId] || [];
      const hit = bars.find(b => mouseX >= b.x && mouseX <= b.x + b.w && mouseY >= b.y && mouseY <= b.y + b.h);

      if (hit) {
        if (hit.fieldId && hit.statement) {
          openFieldInvestigation(hit.fieldId, hit.statement);
        } else {
          openMetricDetailModal(hit.seriesLabel, hit.groupLabel, hit.value);
        }
      }
    };
  }

  /* ==========================================================================
     13. CLICK-TO-INVESTIGATE DRAWER / MODAL (ACCESSIBLE FOCUS & ESCAPE TRAP)
     ========================================================================== */
  function openInvestigationModal() {
    state.drawerTriggerEl = document.activeElement;
    const backdrop = $('investigationDrawerBackdrop');
    backdrop.classList.add('active');
    backdrop.setAttribute('aria-hidden', 'false');
    
    // Focus title or close button for accessibility
    setTimeout(() => {
      const closeBtn = $('closeDrawerBtn');
      if (closeBtn) closeBtn.focus();
    }, 50);
  }

  function closeInvestigationModal() {
    const backdrop = $('investigationDrawerBackdrop');
    backdrop.classList.remove('active');
    backdrop.setAttribute('aria-hidden', 'true');
    
    // Restore previous focus
    if (state.drawerTriggerEl && typeof state.drawerTriggerEl.focus === 'function') {
      state.drawerTriggerEl.focus();
    }
  }

  function openFieldInvestigation(fieldId, statementType) {
    const company = FSRE_DATA.companies[state.currentCompanyId];
    const items = company.statements[statementType] || [];
    const item = items.find(i => i.id === fieldId);
    if (!item) return;

    const prior = item.prior;
    const current = item.current;
    const changeAbs = current - prior;
    const changePct = prior !== 0 ? (changeAbs / Math.abs(prior)) * 100 : null;

    // Related models
    const relatedModels = [];
    Object.entries(company.models).forEach(([key, m]) => {
      const match = (m.components || []).find(c => 
        (c.formula && c.formula.toLowerCase().includes(fieldId.toLowerCase())) ||
        (c.statement && c.statement.toLowerCase().includes(item.label.toLowerCase()))
      );
      if (match) relatedModels.push({ modelName: m.name, component: match.key, formula: match.formula });
    });

    const body = $('investigationDrawerBody');
    $('investigationDrawerTitle').textContent = `Field Detail: ${item.label}`;
    
    body.innerHTML = `
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 24px;">
        <div style="background: var(--bg-surface-subtle); padding: 16px; border-radius: var(--radius-md); border: 1px solid var(--border-color);">
          <div class="meta-label">${company.periods.prior} Value</div>
          <div style="font-size: 24px; font-weight: 800; font-family: var(--font-mono); color: var(--text-main); margin-top: 4px;">
            ${formatNumber(prior, 2)} ${item.unit}
          </div>
        </div>
        <div style="background: var(--brand-cyan-light); padding: 16px; border-radius: var(--radius-md); border: 1px solid var(--brand-cyan);">
          <div class="meta-label">${company.periods.current} Value</div>
          <div style="font-size: 24px; font-weight: 800; font-family: var(--font-mono); color: var(--brand-cyan); margin-top: 4px;">
            ${formatNumber(current, 2)} ${item.unit}
          </div>
        </div>
      </div>

      <div style="margin-bottom: 20px;">
        <h4 style="font-size: 14px; font-weight: 700; color: var(--bg-header); margin-bottom: 8px;">Period-over-Period Variance</h4>
        <div style="font-size: 13px; color: var(--text-secondary); line-height: 1.6;">
          Absolute Change: <strong>${changeAbs >= 0 ? '+' : ''}${formatNumber(changeAbs, 2)} ${item.unit}</strong><br>
          Percentage Change: <strong>${changePct !== null ? (changePct >= 0 ? '+' : '') + formatNumber(changePct, 2) + '%' : '—'}</strong><br>
          Statement Category: <strong>${item.category}</strong>
        </div>
      </div>

      <div>
        <h4 style="font-size: 14px; font-weight: 700; color: var(--bg-header); margin-bottom: 10px;">Forensic Models &amp; Formulas Utilizing This Field</h4>
        ${relatedModels.length > 0 ? relatedModels.map(rm => `
          <div style="background: white; border: 1px solid var(--border-color); border-radius: var(--radius-sm); padding: 12px; margin-bottom: 8px;">
            <strong style="color: var(--brand-cyan);">${escapeHtml(rm.modelName)}</strong> → Component: <strong>${escapeHtml(rm.component)}</strong>
            <div style="font-family: var(--font-mono); font-size: 11px; color: var(--text-muted); margin-top: 4px;">${escapeHtml(rm.formula || 'Direct statement input')}</div>
          </div>
        `).join('') : '<div style="font-size: 13px; color: var(--text-muted);">This line item feeds fundamental baseline metrics and cash flow reconciliation.</div>'}
      </div>
    `;

    openInvestigationModal();
  }

  function openComponentInvestigation(model, component) {
    const body = $('investigationDrawerBody');
    $('investigationDrawerTitle').textContent = `Model Component: ${component.key} — ${component.name}`;

    body.innerHTML = `
      <div style="display: flex; justify-content: space-between; align-items: center; background: var(--brand-cyan-light); border: 1px solid var(--brand-cyan); padding: 16px; border-radius: var(--radius-md); margin-bottom: 20px;">
        <div>
          <div class="meta-label">Parent Framework</div>
          <div style="font-size: 15px; font-weight: 700; color: var(--bg-header); margin-top: 2px;">${escapeHtml(model.name)}</div>
        </div>
        <div style="text-align: right;">
          <div class="meta-label">Computed Value / Status</div>
          <div style="font-size: 20px; font-weight: 800; font-family: var(--font-mono); color: var(--brand-cyan); margin-top: 2px;">
            ${typeof component.value === 'number' ? formatNumber(component.value, 4) : component.value}
          </div>
        </div>
      </div>

      <div style="margin-bottom: 20px;">
        <h4 style="font-size: 14px; font-weight: 700; color: var(--bg-header); margin-bottom: 6px;">Governed Mathematical Formula</h4>
        <div class="model-formula-box" style="margin: 6px 0;">${escapeHtml(component.formula || component.test || 'Direct financial ratio calculation')}</div>
      </div>

      <div style="margin-bottom: 20px;">
        <h4 style="font-size: 14px; font-weight: 700; color: var(--bg-header); margin-bottom: 6px;">Statement Origin</h4>
        <p style="font-size: 13px; color: var(--text-secondary);"><span class="badge-tag">${escapeHtml(component.statement || 'Calculated Metric')}</span></p>
      </div>

      <div>
        <h4 style="font-size: 14px; font-weight: 700; color: var(--bg-header); margin-bottom: 6px;">Forensic Interpretation &amp; Risk Impact</h4>
        <p style="font-size: 13px; color: var(--text-secondary); line-height: 1.6;">${escapeHtml(component.interpretation || 'Evaluated within baseline framework.')}</p>
      </div>
    `;

    openInvestigationModal();
  }

  function openConnectionModal(conn) {
    const body = $('investigationDrawerBody');
    $('investigationDrawerTitle').textContent = `Statement Connection: ${conn.title}`;

    body.innerHTML = `
      <div style="background: var(--brand-cyan-light); border: 1px solid var(--brand-cyan); padding: 16px; border-radius: var(--radius-md); margin-bottom: 20px;">
        <div class="meta-label">Core Forensic Inquiry</div>
        <div style="font-size: 15px; font-weight: 700; color: var(--bg-header); margin-top: 4px;">${escapeHtml(conn.question)}</div>
      </div>

      <div style="margin-bottom: 20px;">
        <h4 style="font-size: 14px; font-weight: 700; color: var(--bg-header); margin-bottom: 6px;">Statement Sources</h4>
        <p style="font-size: 13px; color: var(--text-secondary);">${escapeHtml(conn.sources)}</p>
      </div>

      <div style="margin-bottom: 20px;">
        <h4 style="font-size: 14px; font-weight: 700; color: var(--bg-header); margin-bottom: 6px;">Component &amp; Formula</h4>
        <div class="model-formula-box" style="margin: 6px 0;">${escapeHtml(conn.component)}</div>
      </div>

      <div>
        <h4 style="font-size: 14px; font-weight: 700; color: var(--bg-header); margin-bottom: 6px;">Detailed Forensic Finding</h4>
        <p style="font-size: 13px; color: var(--text-secondary); line-height: 1.6;">${escapeHtml(conn.finding)}</p>
      </div>
    `;

    openInvestigationModal();
  }

  function openMetricDetailModal(seriesLabel, groupLabel, value) {
    const body = $('investigationDrawerBody');
    $('investigationDrawerTitle').textContent = `Metric Detail: ${seriesLabel}`;

    body.innerHTML = `
      <div style="background: var(--bg-surface-subtle); padding: 20px; border-radius: var(--radius-md); border: 1px solid var(--border-color); margin-bottom: 16px;">
        <div class="meta-label">${escapeHtml(groupLabel)} Value</div>
        <div style="font-size: 26px; font-weight: 800; font-family: var(--font-mono); color: var(--brand-cyan); margin-top: 4px;">
          ${formatNumber(value, 2)}
        </div>
      </div>
      <p style="font-size: 13px; color: var(--text-secondary); line-height: 1.5;">
        This metric represents the exact audited figure extracted from the company's financial disclosures for period <strong>${escapeHtml(groupLabel)}</strong>.
      </p>
    `;

    openInvestigationModal();
  }

  /* ==========================================================================
     14. UI STEP VISIBILITY & WORKFLOW SWITCHER
     ========================================================================== */
  function updateStepVisibility() {
    $('stepUpload').style.display = state.activeStep === 'upload' ? 'block' : 'none';
    $('stepProcessing').style.display = state.activeStep === 'processing' ? 'block' : 'none';
    $('stepCompleted').style.display = state.activeStep === 'completed' ? 'block' : 'none';
    $('stepDashboard').style.display = state.activeStep === 'dashboard' ? 'block' : 'none';
    $('fsreNavBar').style.display = state.activeStep === 'dashboard' ? 'block' : 'none';

    if (state.activeStep === 'dashboard') {
      $$('.view-section').forEach(sec => {
        const tab = sec.id.replace('section-', '');
        sec.classList.toggle('active', tab === state.activeTab || state.showAllDetails);
      });
      // Apply compact vs detailed view mode
      applyViewMode();
      requestAnimationFrame(() => updateNavIndicator());
    }
  }

  function applyViewMode() {
    const isCompact = state.viewMode === 'compact' && !state.showAllDetails;
    $$('.detailed-only').forEach(el => {
      el.style.display = isCompact ? 'none' : 'block';
    });
  }

  function resetToUpload() {
    state.activeStep = 'upload';
    state.activeTab = 'overview';
    state.searchQuery = '';
    state.showAllDetails = false;
    sessionStorage.removeItem(UI_SESSION_KEY);
    $('toggleAllDetailsBtn').textContent = 'Show All Details';
    const searchInput = $('statementSearchInput');
    if (searchInput) searchInput.value = '';
    updateStepVisibility();
    renderUploadScreen();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  /* ==========================================================================
     15. INITIALIZATION & EVENT LISTENERS
     ========================================================================== */
  function init() {
    // Brand click resets
    $('brandLogo').onclick = resetToUpload;
    $('brandLogo').onkeydown = (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        resetToUpload();
      }
    };

    // Navigation Tab clicks & Keyboard accessibility (ArrowLeft, ArrowRight, Home, End)
    const navLinks = $('fsreNavLinks');
    const navItems = Array.from($$('.fsre-nav-item'));

    function selectNavTab(tabKey, focusElement = false) {
      state.activeTab = tabKey;
      saveUiSession();
      renderNav();
      updateStepVisibility();
      const target = $(`section-${state.activeTab}`);
      if (target) {
        window.scrollTo({ top: target.offsetTop - 120, behavior: 'smooth' });
      }
      if (focusElement) {
        const item = navItems.find(it => it.dataset.tab === tabKey);
        if (item) item.focus();
      }
    }

    navItems.forEach(item => {
      item.onclick = () => selectNavTab(item.dataset.tab);
    });

    if (navLinks) {
      navLinks.onkeydown = (e) => {
        const activeIdx = navItems.findIndex(it => it.dataset.tab === state.activeTab);
        if (activeIdx === -1) return;

        let nextIdx = -1;
        if (e.key === 'ArrowRight') {
          e.preventDefault();
          nextIdx = (activeIdx + 1) % navItems.length;
        } else if (e.key === 'ArrowLeft') {
          e.preventDefault();
          nextIdx = (activeIdx - 1 + navItems.length) % navItems.length;
        } else if (e.key === 'Home') {
          e.preventDefault();
          nextIdx = 0;
        } else if (e.key === 'End') {
          e.preventDefault();
          nextIdx = navItems.length - 1;
        }

        if (nextIdx !== -1) {
          selectNavTab(navItems[nextIdx].dataset.tab, true);
        }
      };
    }

    // Statement tab buttons
    $$('[data-statement-tab]').forEach(btn => {
      btn.onclick = () => {
        $$('[data-statement-tab]').forEach(b => {
          b.classList.remove('active');
          b.setAttribute('aria-selected', 'false');
        });
        btn.classList.add('active');
        btn.setAttribute('aria-selected', 'true');
        state.activeStatementTab = btn.dataset.statementTab;
        saveUiSession();
        renderStatements();
      };
    });

    // Unified Cross-Section Search Input Handler
    const searchInput = $('statementSearchInput');
    if (searchInput) {
      searchInput.oninput = (e) => {
        state.searchQuery = e.target.value;
        renderStatements();
        renderModelDetails();
        renderExecutiveOverview();
        renderConnections();
        renderReconciliation();
      };
    }

    // Upload interactions
    const dropzone = $('uploadDropzone');
    const fileInput = $('fileInput');
    const browseBtn = $('browseFilesBtn');

    if (dropzone && fileInput) {
      if (browseBtn) browseBtn.onclick = (e) => { e.stopPropagation(); fileInput.click(); };
      dropzone.onclick = () => fileInput.click();
      dropzone.onkeydown = (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          fileInput.click();
        }
      };
      dropzone.ondragover = (e) => { e.preventDefault(); dropzone.classList.add('dragover'); };
      dropzone.ondragleave = () => dropzone.classList.remove('dragover');
      dropzone.ondrop = (e) => {
        e.preventDefault();
        dropzone.classList.remove('dragover');
        if (e.dataTransfer.files && e.dataTransfer.files[0]) {
          state.selectedFileName = e.dataTransfer.files[0].name;
          state.analysisSourceType = 'live';
          startProcessing();
        }
      };
      fileInput.onchange = () => {
        if (fileInput.files && fileInput.files[0]) {
          state.selectedFileName = fileInput.files[0].name;
          state.analysisSourceType = 'live';
          startProcessing();
        }
      };
    }

    $('startAnalysisBtn').onclick = () => {
      state.analysisSourceType = 'demo';
      startProcessing();
    };

    $('viewRiskAnalysisBtn').onclick = () => {
      state.activeStep = 'dashboard';
      state.activeTab = 'statements';
      state.activeStatementTab = 'income';
      updateStepVisibility();
      renderHeader();
      renderExecutiveOverview();
      renderStatements();
      renderModelDetails();
      renderConnections();
      renderReconciliation();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    $('resetAnalysisBtn').onclick = resetToUpload;
    $('startNewAnalysisNavBtn').onclick = resetToUpload;

    // Toggle All Details mode
    $('toggleAllDetailsBtn').onclick = () => {
      state.showAllDetails = !state.showAllDetails;
      $('toggleAllDetailsBtn').textContent = state.showAllDetails ? 'Collapse Details' : 'Show All Details';
      updateStepVisibility();
      if (state.showAllDetails) {
        renderStatements();
        renderModelDetails();
        renderConnections();
        renderReconciliation();
      }
    };

    // Compact vs Detailed view toggle
    $('viewModeCompactBtn').onclick = () => {
      state.viewMode = 'compact';
      $('viewModeCompactBtn').classList.add('active');
      $('viewModeDetailedBtn').classList.remove('active');
      applyViewMode();
    };
    $('viewModeDetailedBtn').onclick = () => {
      state.viewMode = 'detailed';
      $('viewModeDetailedBtn').classList.add('active');
      $('viewModeCompactBtn').classList.remove('active');
      applyViewMode();
    };

    // Modal drawer close listeners
    $('closeDrawerBtn').onclick = closeInvestigationModal;
    $('drawerFooterCloseBtn').onclick = closeInvestigationModal;
    $('investigationDrawerBackdrop').onclick = (e) => {
      if (e.target === $('investigationDrawerBackdrop')) {
        closeInvestigationModal();
      }
    };

    // Keyboard accessibility: Escape closes modal
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        const backdrop = $('investigationDrawerBackdrop');
        if (backdrop && backdrop.classList.contains('active')) {
          closeInvestigationModal();
        }
      }
    });

    // Handle window resize for canvas redraw & nav indicator recalculation
    let resizeTimeout = null;
    window.addEventListener('resize', () => {
      clearTimeout(resizeTimeout);
      resizeTimeout = setTimeout(() => {
        if (state.activeStep === 'dashboard') {
          renderCharts();
          updateNavIndicator();
        }
      }, 150);
    });

    // Initial render
    renderHeader();
    renderUploadScreen();
    updateStepVisibility();
    installBackendIntegration();
  }

  // Run on DOM ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
