from __future__ import annotations

import datetime as dt
import hashlib
import json
import os
import re
import urllib.request
from typing import Any, Dict, List, Optional, Tuple

import dataiku
import pandas as pd


INPUT_DATASET = os.getenv(
    "FRI_INCOME_INPUT_DATASET",
    "FRI_STANDARDIZED_STATEMENT_VALUES",
)
OUTPUT_DATASET = os.getenv(
    "FRI_INCOME_OUTPUT_DATASET",
    "FRI_INCOME_STATEMENT_INPUTS",
)
EXCEPTION_DATASET = os.getenv(
    "FRI_INCOME_EXCEPTION_DATASET",
    "FRI_INCOME_STATEMENT_INPUT_EXCEPTIONS",
)
ALIAS_DATASET = os.getenv(
    "FRI_FINANCIAL_ALIAS_DATASET",
    "FRI_APPROVED_FINANCIAL_CONCEPT_ALIASES",
)
VERSION = "fri-manufacturing-income-statement-resolver-2.1.0"

FIELDS = [
    ("revenue", "Net revenue / sales"),
    ("cost_of_goods_sold", "Cost of goods sold"),
    ("sg_and_a_expense", "SG&A expense"),
    ("depreciation_amortization", "Depreciation & amortisation"),
    ("operating_income_ebit", "Operating income (EBIT)"),
    ("interest_expense", "Interest expense"),
    ("net_profit", "Net income"),
]

ALIASES = {
    "revenue": [
        "revenue", "net revenue", "sales", "net sales", "turnover",
        "revenue from contracts with customers",
        "revenue from contract with customer",
    ],
    "cost_of_goods_sold": [
        "cost of goods sold", "cost of sales", "cost of revenue",
        "cost of inventories sold",
    ],
    "sg_and_a_expense": [
        "sg&a expense", "selling general and administrative expenses",
        "general and administrative expenses",
    ],
    "depreciation_amortization": [
        "depreciation and amortisation", "depreciation and amortization",
        "depreciation & amortisation", "depreciation & amortization",
    ],
    "operating_income_ebit": [
        "operating profit", "operating income", "profit from operations",
        "income from operations", "results from operating activities", "ebit",
    ],
    "interest_expense": [
        "interest expense", "interest expenses", "finance cost",
        "finance costs", "finance expense", "finance expenses",
        "interest cost", "net finance expense",
    ],
    "net_profit": [
        "net profit", "net income", "profit for the year",
        "profit for the financial year", "profit for the period",
        "profit for the year net of tax", "profit after tax",
        "profit after taxation", "loss for the year",
        "(loss)/profit for the year", "profit/(loss) for the year",
        "net (loss)/profit for the financial year",
        "loss for the financial year", "loss after tax",
        "loss for the year, attributable to owners of the company",
        "profit for the year, attributable to owners of the company",
    ],
}

VALUE_COLUMNS = [
    "statement_value_id", "tenant_id", "entity_id", "assessment_run_id",
    "source_document_id", "table_artifact_id", "source_table_id",
    "statement_type", "statement_title", "statement_section", "row_index",
    "row_order", "row_label", "concept_key", "source_row_label",
    "entity_scope", "period_label", "period_end", "column_index",
    "raw_value", "numeric_value", "value_status", "currency", "unit",
    "page_number", "extraction_confidence", "selection_method",
    "source_column_index", "normalization_status", "resolver_version",
    "resolved_at",
]

EXCEPTION_COLUMNS = [
    "tenant_id", "entity_id", "assessment_run_id", "source_document_id",
    "table_artifact_id", "concept_key", "display_label", "exception_code",
    "severity", "message", "recommended_action", "resolver_version",
    "created_at",
]


def text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    value = str(value).strip()
    return "" if value.lower() in {"", "nan", "none", "null"} else value


def number(value: Any) -> Optional[float]:
    raw = text(value)
    if not raw or raw.lower() in {"-", "—", "–", "n/a", "na"}:
        return None
    negative = raw.startswith("(") and raw.endswith(")")
    raw = raw.replace(",", "").replace("(", "").replace(")", "")
    try:
        result = float(raw)
        return -result if negative else result
    except ValueError:
        return None


def integer(value: Any, default: int = -1) -> int:
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return default


def year(value: Any) -> Optional[int]:
    values = re.findall(r"\b(?:19|20)\d{2}\b", text(value))
    return int(values[-1]) if values else None


def norm(value: Any) -> str:
    value = text(value).lower().replace("’", "'").replace("&", " and ")
    value = re.sub(r"\([^)]*\)", " ", value)
    value = re.sub(r"[^a-z0-9]+", " ", value)
    return re.sub(r"\s+", " ", value).strip()


def dataset(name: str) -> pd.DataFrame:
    try:
        return dataiku.Dataset(name).get_dataframe(infer_with_pandas=False)
    except TypeError:
        return dataiku.Dataset(name).get_dataframe()


def load_database_aliases(defaults: Dict[str, List[str]]) -> Dict[str, List[str]]:
    """Merge approved database synonyms with safe built-in defaults."""
    merged = {key: list(values) for key, values in defaults.items()}
    try:
        frame = dataset(ALIAS_DATASET)
    except Exception as error:
        print(
            f"Alias dataset {ALIAS_DATASET} unavailable; using built-ins: {error}",
            flush=True,
        )
        return merged

    required = {"concept_key", "alias_text"}
    if not required.issubset(frame.columns):
        print(
            f"Alias dataset {ALIAS_DATASET} lacks {sorted(required)}; using built-ins",
            flush=True,
        )
        return merged

    if "approval_status" in frame.columns:
        frame = frame[
            frame["approval_status"].fillna("").astype(str).str.upper().eq("APPROVED")
        ]
    if "active" in frame.columns:
        frame = frame[
            frame["active"].fillna(False).astype(str).str.lower().isin(
                {"true", "1", "yes", "y"}
            )
        ]
    if "statement_type" in frame.columns:
        frame = frame[
            frame["statement_type"].fillna("").astype(str).str.upper().isin(
                {"INCOME_STATEMENT", "PROFIT_AND_LOSS", "STATEMENT_OF_INCOME"}
            )
        ]
    sort_columns = [column for column in ("priority", "alias_text") if column in frame.columns]
    if sort_columns:
        frame = frame.sort_values(sort_columns, kind="stable")

    loaded = 0
    for row in frame.to_dict(orient="records"):
        concept = text(row.get("concept_key"))
        alias = text(row.get("alias_text"))
        if not concept or not alias:
            continue
        existing = {norm(value) for value in merged.setdefault(concept, [])}
        if norm(alias) not in existing:
            merged[concept].append(alias)
            loaded += 1

    print(f"Loaded {loaded} approved database aliases from {ALIAS_DATASET}", flush=True)
    return merged


ALIASES = load_database_aliases(ALIASES)


def is_income(row: Dict[str, Any]) -> bool:
    statement = norm(row.get("statement_type"))
    if statement in {
        "income statement", "profit and loss",
        "statement of income", "statement of comprehensive income",
    }:
        return True

    combined = norm(
        f"{text(row.get('statement_title'))} "
        f"{text(row.get('row_label'))}"
    )

    return any(
        item in combined
        for item in [
            "income statement", "profit and loss",
            "profit before tax", "net interest income",
        ]
    )


def table_id(row: Dict[str, Any]) -> str:
    return (
        text(row.get("table_artifact_id"))
        or text(row.get("source_table_id"))
        or text(row.get("statement_title"))
        or "UNKNOWN_TABLE"
    )


def table_score(rows: List[Dict[str, Any]]) -> int:
    title = norm(" ".join(
        text(row.get("statement_title"))
        for row in rows
    ))

    labels = {norm(row.get("row_label")) for row in rows}
    score = 0

    # Primary consolidated statements must outrank segment-note tables. Both
    # can contain labels such as Finance costs and Net profit, but segment
    # columns are not the Group current/prior periods required by the model.
    if any(phrase in title for phrase in (
        "consolidated statement of profit or loss",
        "consolidated statement of comprehensive income",
        "consolidated income statement",
    )):
        score += 600
    if "segment" in title or any("segment" in label for label in labels):
        score -= 1000

    if "consolidated" in title:
        score += 100
    if "the group" in title:
        score += 80
    if "supplementary financial statements" in title:
        score -= 100
    if "revenue" in labels or "sales" in labels:
        score += 30
    if "cost of sales" in labels or "cost of goods sold" in labels:
        score += 30
    if "profit for the year" in labels or "net profit" in labels:
        score += 30
    if any("profit loss before income tax" in label or "profit before tax" in label for label in labels):
        score += 100
    if any("income tax expense" in label for label in labels):
        score += 80
    if any(
        ("profit for the year" in label or "loss for the year" in label)
        and "attributable to owners" in label
        for label in labels
    ):
        score += 120

    return score


def select_table(rows: List[Dict[str, Any]]):
    grouped: Dict[str, List[Dict[str, Any]]] = {}

    for row in rows:
        grouped.setdefault(table_id(row), []).append(row)

    if not grouped:
        raise RuntimeError("No income-statement table found")

    return max(
        grouped.items(),
        key=lambda item: table_score(item[1]),
    )


def row_period(row: Dict[str, Any]) -> Optional[int]:
    """Find a reporting year across normalized and preserved header fields."""
    fields = (
        "period_label", "period_end", "column_period", "reporting_period",
        "column_header", "header_text", "header_path", "column_name",
    )
    for field in fields:
        value = row.get(field)
        if isinstance(value, (list, tuple)):
            value = " ".join(text(item) for item in value)
        elif isinstance(value, dict):
            value = " ".join(text(item) for item in value.values())
        found = year(value)
        if found is not None:
            return found
    return None


def group_columns(rows: List[Dict[str, Any]]) -> List[int]:
    """Return the two consolidated/group period columns.

    PDF table extraction commonly emits a note-number column before the
    financial years and may also append Company columns.  Selecting the first
    two numeric indexes therefore produces incorrect values.  We instead use
    period metadata, reject Company columns, and select one column per year.
    """
    anchors = {
        "revenue", "sales", "turnover", "cost of sales",
        "cost of goods sold", "administrative expenses",
        "operating profit", "operating income",
        "results from operating activities", "finance expense", "finance costs",
        "interest expense", "profit for the year", "net profit", "net income",
        "loss for the year attributable to owners of the company",
    }
    candidates: Dict[int, Dict[str, Any]] = {}

    for row in rows:
        try:
            column = int(float(row.get("column_index")))
        except (TypeError, ValueError):
            continue

        scope = norm(row.get("entity_scope") or row.get("column_scope")).upper()
        if scope in {"COMPANY", "STANDALONE", "PARENT"}:
            continue

        item = candidates.setdefault(
            column,
            {
                "periods": {},
                "anchor_count": 0,
                "row_count": 0,
            },
        )
        item["row_count"] += 1
        period = row_period(row)
        if period is not None:
            item["periods"][period] = item["periods"].get(period, 0) + 1
        label = norm(row.get("row_label") or row.get("source_row_label"))
        if any(label == anchor or anchor in label for anchor in anchors):
            item["anchor_count"] += 1

    by_period: Dict[int, List[Tuple[int, Dict[str, Any]]]] = {}
    for column, info in candidates.items():
        if info["periods"]:
            period = max(info["periods"], key=info["periods"].get)
            info["period"] = period
            by_period.setdefault(period, []).append((column, info))

    periods = sorted(by_period, reverse=True)
    selected: List[int] = []
    if periods:
        current_options = sorted(
            by_period[periods[0]],
            key=lambda item: (-item[1]["anchor_count"], item[0]),
        )
        if current_options:
            selected.append(current_options[0][0])

    # Consolidated statements normally place Group current/prior columns next
    # to one another, followed by Company current/prior columns. Bad PDF header
    # propagation can label the Company prior column as GROUP. Prefer the
    # nearest prior-period column to the selected current-period column.
    if len(periods) > 1 and selected:
        current_column = selected[0]
        prior_options = sorted(
            by_period[periods[1]],
            key=lambda item: (
                0 if item[0] > current_column else 1,
                abs(item[0] - current_column),
                -item[1]["anchor_count"],
            ),
        )
        if prior_options:
            selected.append(prior_options[0][0])

    if len(selected) < 2:
        # Some extractors preserve the values and coordinates but lose the year
        # header association. Financial value columns still contain the same
        # income-statement anchor rows, whereas the Note column does not. Choose
        # the strongest adjacent pair; ties go to the left-most pair because
        # Group columns precede Company columns in consolidated statements.
        viable = sorted(
            (
                (column, info)
                for column, info in candidates.items()
                if info["anchor_count"] >= 1
            ),
            key=lambda item: item[0],
        )
        if len(viable) < 2 and candidates:
            # Last structural fallback: value columns cover most statement
            # rows, while a Note column has sparse numeric cells.
            maximum_rows = max(info["row_count"] for info in candidates.values())
            viable = sorted(
                (
                    (column, info)
                    for column, info in candidates.items()
                    if info["row_count"] >= max(3, int(maximum_rows * 0.60))
                ),
                key=lambda item: item[0],
            )
        pairs = []
        for left_index, (left_column, left_info) in enumerate(viable):
            for right_column, right_info in viable[left_index + 1:]:
                distance = right_column - left_column
                if distance <= 0:
                    continue
                pairs.append((
                    -min(left_info["anchor_count"], right_info["anchor_count"]),
                    -(left_info["anchor_count"] + right_info["anchor_count"]),
                    -min(left_info["row_count"], right_info["row_count"]),
                    distance,
                    left_column,
                    right_column,
                ))

        if pairs:
            _, _, _, _, left_column, right_column = min(pairs)
            selected = [left_column, right_column]

    if len(selected) < 2:
        diagnostic = {
            column: {
                "anchors": info["anchor_count"],
                "rows": info["row_count"],
                "periods": info["periods"],
            }
            for column, info in sorted(candidates.items())
        }
        raise RuntimeError(
            "Unable to identify two consolidated income-statement period "
            f"columns; candidates={diagnostic}"
        )

    return selected[:2]


def direct_match(
    concept_key: str,
    rows: List[Dict[str, Any]],
    column: int,
) -> Optional[Dict[str, Any]]:
    ordered_aliases = [norm(x) for x in ALIASES.get(concept_key, [])]
    alias_rank = {alias: index for index, alias in enumerate(ordered_aliases)}
    matches = []

    for row in rows:
        try:
            row_column = int(float(row.get("column_index")))
        except (TypeError, ValueError):
            continue

        label = norm(row.get("row_label"))
        if row_column == column and label in alias_rank:
            matches.append((alias_rank[label], integer(row.get("row_index"), 10**9), row))

    if matches:
        _, _, row = min(matches, key=lambda item: (item[0], item[1]))
        return {
                **row,
                "value_status": "REPORTED",
                "selection_method": "PYTHON_ALIAS_EXACT",
                "source_row_label": text(row.get("row_label")),
            }

    return None


def derive(
    concept_key: str,
    rows: List[Dict[str, Any]],
    column: int,
) -> Optional[Dict[str, Any]]:
    component_aliases = {
        "sg_and_a_expense": {
            "administrative expenses", "distribution expenses",
            "marketing and distribution expense",
            "marketing and distribution expenses", "selling expenses",
        },
        "depreciation_amortization": {
            "depreciation of property plant and equipment",
            "depreciation of right of use assets",
            "amortisation of intangible assets",
            "amortization of intangible assets",
        },
    }
    wanted = component_aliases.get(concept_key)
    if wanted:
        components = []
        for row in rows:
            try:
                row_column = int(float(row.get("column_index")))
            except (TypeError, ValueError):
                continue
            if row_column == column and norm(row.get("row_label")) in wanted:
                if number(row.get("numeric_value")) is not None:
                    components.append(row)
        if components:
            value = sum(number(item.get("numeric_value")) for item in components)
            first = components[0]
            labels = " + ".join(text(item.get("row_label")) for item in components)
            return {
                **first,
                "numeric_value": value,
                "raw_value": f"Derived: {labels}",
                "source_row_label": labels,
                "value_status": "DERIVED",
                "selection_method": "DERIVED_COMPONENT_SUM",
            }
    if concept_key == "operating_income_ebit":
        before_tax = None
        finance_cost = None
        finance_income = None
        for row in rows:
            try:
                row_column = int(float(row.get("column_index")))
            except (TypeError, ValueError):
                continue
            if row_column != column or number(row.get("numeric_value")) is None:
                continue
            label = norm(row.get("row_label"))
            if (
                label.startswith(("profit before tax", "loss before tax", "profit before income tax",
                                  "loss before income tax", "profit loss before income tax",
                                  "loss profit before income tax"))
                and "discontinued" not in label
            ):
                before_tax = row
            elif label in {"finance cost", "finance costs", "finance expense", "finance expenses", "interest expense"}:
                finance_cost = row
            elif label in {"finance income", "interest income"}:
                finance_income = row
        if before_tax is not None and finance_cost is not None:
            result = number(before_tax.get("numeric_value")) + abs(number(finance_cost.get("numeric_value")))
            if finance_income is not None:
                result -= abs(number(finance_income.get("numeric_value")))
            return {
                **before_tax,
                "numeric_value": result,
                "raw_value": "Derived: profit/loss before tax + finance costs - finance income",
                "source_row_label": "Profit/loss before tax + finance costs - finance income",
                "value_status": "DERIVED",
                "selection_method": "GOVERNED_EBIT_RECONCILIATION",
            }
    # Do not manufacture any other value that is not present in the filing.
    return None


def resolve(
    concept_key: str,
    rows: List[Dict[str, Any]],
    column: int,
) -> Optional[Dict[str, Any]]:
    return (
        direct_match(concept_key, rows, column)
        or derive(concept_key, rows, column)
    )


def make_output(
    field_index: int,
    concept_key: str,
    label: str,
    source: Optional[Dict[str, Any]],
    period: Any,
    output_column: int,
    table: str,
    timestamp: str,
) -> Dict[str, Any]:
    valid = source is not None

    return {
        "statement_value_id": hashlib.sha256(
            f"{table}|{concept_key}|{period}".encode()
        ).hexdigest(),
        "tenant_id": text(source.get("tenant_id")) if valid else "",
        "entity_id": text(source.get("entity_id")) if valid else "",
        "assessment_run_id": (
            text(source.get("assessment_run_id")) if valid else ""
        ),
        "source_document_id": (
            text(source.get("source_document_id")) if valid else ""
        ),
        "table_artifact_id": table,
        "source_table_id": text(source.get("source_table_id")) if valid else "",
        "statement_type": "INCOME_STATEMENT",
        "statement_title": text(source.get("statement_title")) if valid else "",
        "statement_section": text(source.get("statement_section")) if valid else "",
        "row_index": field_index,
        "row_order": field_index,
        "row_label": label,
        "concept_key": concept_key,
        "source_row_label": (
            text(source.get("source_row_label"))
            or text(source.get("row_label"))
            if valid else ""
        ),
        "entity_scope": "GROUP",
        "period_label": period,
        "period_end": period,
        "column_index": output_column,
        "raw_value": (
            text(source.get("raw_value") or source.get("raw_text"))
            if valid else "Not reported in filing"
        ),
        "numeric_value": number(source.get("numeric_value")) if valid else None,
        "value_status": text(source.get("value_status")) if valid else "NOT_REPORTED",
        "currency": text(source.get("currency")) if valid else "",
        "unit": text(source.get("unit")) if valid else "",
        "page_number": source.get("page_number") if valid else None,
        "extraction_confidence": (
            number(source.get("extraction_confidence"))
            if valid else None
        ),
        "selection_method": (
            text(source.get("selection_method"))
            if valid else "NOT_REPORTED"
        ),
        "source_column_index": (
            source.get("column_index") if valid else -1
        ),
        "normalization_status": "INCOME_STATEMENT_RESOLVED",
        "resolver_version": VERSION,
        "resolved_at": timestamp,
    }


frame = dataset(INPUT_DATASET)

all_numeric_rows = [
    row
    for row in frame.to_dict(orient="records")
    if number(row.get("numeric_value")) is not None
]
rows = [row for row in all_numeric_rows if is_income(row)]

if not rows:
    raise RuntimeError("No income-statement rows found")

documents: Dict[Any, List[Dict[str, Any]]] = {}
all_document_rows: Dict[Any, List[Dict[str, Any]]] = {}

for row in all_numeric_rows:
    key = (
        text(row.get("tenant_id")), text(row.get("entity_id")),
        text(row.get("assessment_run_id")), text(row.get("source_document_id")),
    )
    all_document_rows.setdefault(key, []).append(row)

for row in rows:
    key = (
        text(row.get("tenant_id")),
        text(row.get("entity_id")),
        text(row.get("assessment_run_id")),
        text(row.get("source_document_id")),
    )
    documents.setdefault(key, []).append(row)

output = []
exceptions = []
timestamp = dt.datetime.now(dt.timezone.utc).isoformat()

for document_key, document_rows in documents.items():
    selected_table, table_rows = select_table(document_rows)
    columns = group_columns(table_rows)
    source_rows = [
        row for row in table_rows
        if int(float(row.get("column_index"))) in columns
    ]
    supporting_rows = [
        row for row in all_document_rows.get(document_key, document_rows)
        if norm(row.get("statement_type")) in {
            "cash_flow", "cash_flow_statement", "statement_of_cash_flows",
        }
    ]

    periods = sorted(
        {
            year(row.get("period_label") or row.get("period_end"))
            for row in source_rows
            if year(row.get("period_label") or row.get("period_end"))
        },
        reverse=True,
    )

    current_period = periods[0] if periods else "Current period"
    prior_period = periods[1] if len(periods) > 1 else "Prior period"

    for field_index, (concept_key, label) in enumerate(FIELDS):
        for output_column, period, source_column in [
            (1, current_period, columns[0]),
            (2, prior_period, columns[1]),
        ]:
            resolution_rows = (
                supporting_rows
                if concept_key == "depreciation_amortization"
                else source_rows
            )
            source = resolve(concept_key, resolution_rows, source_column)

            output.append(
                make_output(
                    field_index,
                    concept_key,
                    label,
                    source,
                    period,
                    output_column,
                    selected_table,
                    timestamp,
                )
            )

            if source is None:
                first = table_rows[0]
                exceptions.append({
                    "tenant_id": text(first.get("tenant_id")),
                    "entity_id": text(first.get("entity_id")),
                    "assessment_run_id": text(
                        first.get("assessment_run_id")
                    ),
                    "source_document_id": text(
                        first.get("source_document_id")
                    ),
                    "table_artifact_id": selected_table,
                    "concept_key": concept_key,
                    "display_label": label,
                    "exception_code": "FIELD_NOT_REPORTED",
                    "severity": "WARNING",
                    "message": f"{label} not found for {period}",
                    "recommended_action": (
                        "Review the income statement and notes"
                    ),
                    "resolver_version": VERSION,
                    "created_at": timestamp,
                })

dataiku.Dataset(OUTPUT_DATASET).write_with_schema(
    pd.DataFrame(output, columns=VALUE_COLUMNS)
)

dataiku.Dataset(EXCEPTION_DATASET).write_with_schema(
    pd.DataFrame(exceptions, columns=EXCEPTION_COLUMNS)
)

print(json.dumps({
    "resolver_version": VERSION,
    "document_count": len(documents),
    "output_rows": len(output),
    "exception_count": len(exceptions),
}, indent=2, default=str))
