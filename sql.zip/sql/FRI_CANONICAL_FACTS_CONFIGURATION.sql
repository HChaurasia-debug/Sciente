-- Canonical concept bootstrap. Run the governed synonym registry next.
BEGIN;
CREATE SCHEMA IF NOT EXISTS financial_risk_intelligence;
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS financial_risk_intelligence.financial_concepts (
    concept_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    concept_key text NOT NULL UNIQUE,
    statement_type text NOT NULL CHECK (statement_type IN ('INCOME_STATEMENT','BALANCE_SHEET','CASH_FLOW_STATEMENT')),
    canonical_label text NOT NULL,
    is_required boolean NOT NULL DEFAULT true,
    active boolean NOT NULL DEFAULT true,
    validation_definition jsonb NOT NULL DEFAULT '{}'::jsonb,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS financial_risk_intelligence.financial_derivation_rules (
    derivation_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    concept_key text NOT NULL REFERENCES financial_risk_intelligence.financial_concepts(concept_key),
    expression text NOT NULL,
    required_concepts text[] NOT NULL,
    priority integer NOT NULL DEFAULT 100,
    active boolean NOT NULL DEFAULT true,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    UNIQUE (concept_key,expression)
);

INSERT INTO financial_risk_intelligence.financial_concepts
    (concept_key,statement_type,canonical_label,is_required,active)
VALUES
    ('revenue','INCOME_STATEMENT','Revenue',true,true),
    ('total_income','INCOME_STATEMENT','Total income',false,true),
    ('cost_of_sales','INCOME_STATEMENT','Cost of sales',false,true),
    ('cost_of_goods_sold','INCOME_STATEMENT','Cost of goods sold',true,true),
    ('gross_profit','INCOME_STATEMENT','Gross profit',false,true),
    ('net_interest_income','INCOME_STATEMENT','Net interest income',false,true),
    ('non_interest_income','INCOME_STATEMENT','Non-interest income',false,true),
    ('other_income','INCOME_STATEMENT','Other income',false,true),
    ('operating_expenses','INCOME_STATEMENT','Operating expenses',false,true),
    ('administrative_expenses','INCOME_STATEMENT','Administrative expenses',false,true),
    ('sg_and_a_expense','INCOME_STATEMENT','SG&A expense',true,true),
    ('depreciation_amortization','INCOME_STATEMENT','Depreciation and amortisation',true,true),
    ('finance_costs','INCOME_STATEMENT','Finance costs',false,true),
    ('interest_expense','INCOME_STATEMENT','Interest expense',true,true),
    ('provisions_impairment','INCOME_STATEMENT','Provisions / impairment',false,true),
    ('operating_income_ebit','INCOME_STATEMENT','Operating income (EBIT)',true,true),
    ('profit_before_tax','INCOME_STATEMENT','Profit before tax',false,true),
    ('income_tax_expense','INCOME_STATEMENT','Income tax expense',false,true),
    ('net_profit','INCOME_STATEMENT','Net income',true,true),
    ('cash_and_cash_equivalents','BALANCE_SHEET','Cash and cash equivalents',false,true),
    ('total_current_assets','BALANCE_SHEET','Total current assets',true,true),
    ('total_non_current_assets','BALANCE_SHEET','Total non-current assets',false,true),
    ('trade_receivables_net','BALANCE_SHEET','Trade receivables (net)',true,true),
    ('inventory','BALANCE_SHEET','Inventory',true,true),
    ('net_ppe','BALANCE_SHEET','Net PP&E (fixed assets)',true,true),
    ('property_plant_equipment','BALANCE_SHEET','Property, plant and equipment',false,true),
    ('gross_loans_advances','BALANCE_SHEET','Gross loans and advances',false,true),
    ('stage3_npa','BALANCE_SHEET','Stage-3 / NPA loans',false,true),
    ('ecl_balance','BALANCE_SHEET','Loan-loss provision / ECL balance',false,true),
    ('investments','BALANCE_SHEET','Investments',false,true),
    ('total_assets','BALANCE_SHEET','Total assets',true,true),
    ('total_current_liabilities','BALANCE_SHEET','Total current liabilities',true,true),
    ('total_non_current_liabilities','BALANCE_SHEET','Total non-current liabilities',false,true),
    ('long_term_debt','BALANCE_SHEET','Long-term debt',true,true),
    ('borrowings','BALANCE_SHEET','Borrowings',false,true),
    ('customer_deposits','BALANCE_SHEET','Customer deposits',false,true),
    ('total_liabilities','BALANCE_SHEET','Total liabilities',true,true),
    ('retained_earnings','BALANCE_SHEET','Retained earnings',true,true),
    ('total_shareholders_equity','BALANCE_SHEET','Total shareholders'' equity',true,true),
    ('total_equity','BALANCE_SHEET','Total equity',false,true),
    ('shares_outstanding','BALANCE_SHEET','Shares outstanding',true,true),
    ('cet1_ratio','BALANCE_SHEET','CET-1 / capital ratio',false,true),
    ('cash_generated_from_operations','CASH_FLOW_STATEMENT','Cash generated from operations',false,true),
    ('operating_cash_flow','CASH_FLOW_STATEMENT','Cash flow from operations',true,true),
    ('investing_cash_flow','CASH_FLOW_STATEMENT','Investing cash flow',false,true),
    ('financing_cash_flow','CASH_FLOW_STATEMENT','Financing cash flow',false,true),
    ('net_change_cash','CASH_FLOW_STATEMENT','Net change in cash',false,true),
    ('beginning_cash','CASH_FLOW_STATEMENT','Cash and cash equivalents at beginning of period',false,true),
    ('ending_cash','CASH_FLOW_STATEMENT','Cash and cash equivalents at end of period',false,true)
ON CONFLICT (concept_key) DO UPDATE SET
    statement_type=EXCLUDED.statement_type,canonical_label=EXCLUDED.canonical_label,
    is_required=EXCLUDED.is_required,active=EXCLUDED.active,updated_at=now();

COMMIT;

SELECT statement_type,count(*) AS active_concept_count
FROM financial_risk_intelligence.financial_concepts
WHERE active=true GROUP BY statement_type ORDER BY statement_type;
