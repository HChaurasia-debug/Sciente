"""Build a configuration-driven required-field manifest from registered uploads.

Input: FRI_UPLOAD_REGISTRATION_RESULTS
Output: FRI_REQUIRED_FIELD_MANIFEST

Successful duplicate registrations are valid because they point to existing
assessment and source-document identifiers.
"""

from __future__ import annotations

import json
from typing import Any, Dict, List

import dataiku
import pandas as pd

from financial_risk_intelligence.database import tenant_connection


INPUT_DATASET = "FRI_UPLOAD_REGISTRATION_RESULTS"
OUTPUT_DATASET = "FRI_REQUIRED_FIELD_MANIFEST"

OUTPUT_COLUMNS = [
    "tenant_id", "entity_id", "assessment_run_id", "run_id",
    "source_document_id", "configuration_set_id", "configuration_key",
    "configuration_version", "configuration_item_id", "sequence_number",
    "concept_key", "statement_key", "period_key", "data_type",
    "is_required", "extraction_strategy", "model_key",
    "validation_definition", "configuration_definition",
]


def safe_string(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except (TypeError, ValueError):
        pass
    return str(value).strip()


def require_value(definition: Dict[str, Any], key: str, item_key: str) -> Any:
    value = definition.get(key)
    if value in (None, ""):
        raise ValueError(
            f"Configuration item '{item_key}' is missing required property '{key}'"
        )
    return value


def validate_input(input_df: pd.DataFrame) -> None:
    required = {
        "tenant_id", "entity_id", "assessment_run_id",
        "source_document_id", "registration_status",
    }
    missing = sorted(required - set(input_df.columns))
    if missing:
        raise ValueError(
            f"{INPUT_DATASET} is missing required columns: {', '.join(missing)}"
        )


def select_documents(input_df: pd.DataFrame) -> pd.DataFrame:
    selected = input_df[
        input_df["registration_status"]
        .fillna("")
        .astype(str)
        .str.strip()
        .str.upper()
        .eq("SUCCESS")
    ].copy()

    # Do not exclude duplicate_document=True. Those rows contain the IDs of
    # the already-registered document and are valid for manifest generation.
    for column in (
        "tenant_id", "entity_id", "assessment_run_id", "source_document_id"
    ):
        selected = selected[
            selected[column].fillna("").astype(str).str.strip().ne("")
        ]

    return selected.drop_duplicates(
        subset=["tenant_id", "assessment_run_id", "source_document_id"],
        keep="last",
    )


def load_configuration(cursor, tenant_id: str) -> Dict[str, Any]:
    cursor.execute(
        """
        SELECT configuration_set_id, configuration_key, version, definition
        FROM financial_risk_intelligence.configuration_sets
        WHERE tenant_id = %s
          AND LOWER(lifecycle_state) = 'active'
          AND (effective_from IS NULL OR effective_from <= CURRENT_TIMESTAMP)
          AND (effective_to IS NULL OR effective_to > CURRENT_TIMESTAMP)
        ORDER BY effective_from DESC NULLS LAST, created_at DESC
        """,
        (tenant_id,),
    )
    rows = cursor.fetchall()
    if not rows:
        raise LookupError(f"No active configuration set exists for tenant '{tenant_id}'")
    if len(rows) > 1:
        ids = [str(row["configuration_set_id"]) for row in rows]
        raise LookupError(
            f"Multiple active configuration sets exist for tenant '{tenant_id}': {ids}"
        )
    return rows[0]


def load_items(cursor, tenant_id: str, configuration_set_id: str, item_type: str):
    cursor.execute(
        """
        SELECT configuration_item_id, item_key, display_name,
               sequence_number, definition
        FROM financial_risk_intelligence.configuration_items
        WHERE tenant_id = %s
          AND configuration_set_id = %s
          AND item_type = %s
          AND LOWER(lifecycle_state) = 'active'
        ORDER BY sequence_number NULLS LAST, item_key
        """,
        (tenant_id, configuration_set_id, item_type),
    )
    rows = cursor.fetchall()
    if not rows:
        raise LookupError(
            f"No active configuration items exist for item_type '{item_type}'"
        )
    return rows


def get_periods(definition: Dict[str, Any], item_key: str) -> List[str]:
    periods = definition.get("period_keys")
    if periods is None:
        periods = [definition.get("period_key")]
    elif not isinstance(periods, list):
        raise ValueError(f"Configuration item '{item_key}' period_keys must be a list")

    result: List[str] = []
    for value in periods:
        period = safe_string(value)
        if period and period not in result:
            result.append(period)
    if not result:
        raise ValueError(
            f"Configuration item '{item_key}' has no period_key or period_keys"
        )
    return result


def build_document_manifest(document: pd.Series) -> List[Dict[str, Any]]:
    tenant_id = safe_string(document["tenant_id"])
    entity_id = safe_string(document["entity_id"])
    run_id = safe_string(document["assessment_run_id"])
    document_id = safe_string(document["source_document_id"])

    with tenant_connection(tenant_id) as cursor:
        context = load_configuration(cursor, tenant_id)
        set_definition = context["definition"] or {}
        if not isinstance(set_definition, dict):
            raise ValueError("Configuration-set definition must be a JSON object")

        item_type = safe_string(set_definition.get("required_field_item_type"))
        if not item_type:
            raise ValueError(
                f"Configuration set '{context['configuration_set_id']}' does not "
                "define required_field_item_type"
            )
        items = load_items(
            cursor, tenant_id, str(context["configuration_set_id"]), item_type
        )

    output: List[Dict[str, Any]] = []
    for item in items:
        item_key = safe_string(item["item_key"])
        definition = item["definition"] or {}
        if not isinstance(definition, dict):
            raise ValueError(f"Configuration item '{item_key}' must contain JSON")

        for period in get_periods(definition, item_key):
            output.append({
                "tenant_id": tenant_id,
                "entity_id": entity_id,
                "assessment_run_id": run_id,
                "run_id": run_id,
                "source_document_id": document_id,
                "configuration_set_id": str(context["configuration_set_id"]),
                "configuration_key": safe_string(context["configuration_key"]),
                "configuration_version": safe_string(context["version"]),
                "configuration_item_id": str(item["configuration_item_id"]),
                "sequence_number": item["sequence_number"],
                "concept_key": safe_string(
                    require_value(definition, "concept_key", item_key)
                ),
                "statement_key": safe_string(definition.get("statement_key")),
                "period_key": period,
                "data_type": safe_string(
                    require_value(definition, "data_type", item_key)
                ),
                "is_required": bool(definition.get("is_required", True)),
                "extraction_strategy": safe_string(
                    definition.get("extraction_strategy")
                ),
                "model_key": safe_string(definition.get("model_key")),
                "validation_definition": json.dumps(
                    definition.get("validation", {}), sort_keys=True
                ),
                "configuration_definition": json.dumps(definition, sort_keys=True),
            })
    return output


def main() -> None:
    input_df = dataiku.Dataset(INPUT_DATASET).get_dataframe()
    validate_input(input_df)
    documents = select_documents(input_df)

    diagnostic_columns = [
        column for column in (
            "registration_status", "duplicate_document", "tenant_id",
            "entity_id", "assessment_run_id", "source_document_id", "message"
        ) if column in input_df.columns
    ]
    print(f"Registration rows read: {len(input_df)}")
    print(f"Documents selected: {len(documents)}")
    if diagnostic_columns:
        print(input_df[diagnostic_columns].to_string(index=False))

    if documents.empty:
        raise RuntimeError(
            "No successful registered documents with populated tenant, entity, "
            "assessment-run and source-document identifiers are available"
        )

    rows: List[Dict[str, Any]] = []
    for _, document in documents.iterrows():
        rows.extend(build_document_manifest(document))

    result = pd.DataFrame(rows, columns=OUTPUT_COLUMNS)
    if not result.empty:
        result = result.drop_duplicates(
            subset=[
                "tenant_id", "assessment_run_id", "source_document_id",
                "configuration_item_id", "period_key",
            ],
            keep="last",
        ).sort_values(
            ["tenant_id", "assessment_run_id", "sequence_number", "period_key"],
            na_position="last",
        )

    dataiku.Dataset(OUTPUT_DATASET).write_with_schema(result)
    print(json.dumps({
        "registration_rows_read": len(input_df),
        "documents_selected": len(documents),
        "manifest_row_count": len(result),
    }, indent=2))

    if result.empty:
        raise RuntimeError("No required-field manifest rows were generated")


main()
