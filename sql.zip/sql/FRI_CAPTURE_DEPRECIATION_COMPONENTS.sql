-- Register auditable D&A components for canonical capture.
-- This migration adds configuration only; values come from standardized
-- statement/note rows for each company and filing.
BEGIN;

INSERT INTO financial_risk_intelligence.financial_concepts
 (concept_key,statement_type,canonical_label,is_required,active)
VALUES
 ('depreciation_ppe','CASH_FLOW_STATEMENT','Depreciation of PP&E',false,true),
 ('depreciation_rou','CASH_FLOW_STATEMENT','Depreciation of right-of-use assets',false,true),
 ('amortization_intangibles','CASH_FLOW_STATEMENT','Amortisation of intangible assets',false,true)
ON CONFLICT (concept_key) DO UPDATE SET
 statement_type=EXCLUDED.statement_type,
 canonical_label=EXCLUDED.canonical_label,
 active=true,
 updated_at=now();

INSERT INTO financial_risk_intelligence.financial_concept_aliases
 (concept_key,alias_text,normalized_alias_text,sector_key,priority,active,
  approval_status,approved_by,approved_at)
SELECT v.concept_key,v.alias_text,
       financial_risk_intelligence.normalize_financial_alias_text(v.alias_text),
       NULL,v.priority,true,'APPROVED','D_AND_A_CAPTURE',now()
FROM (VALUES
 ('depreciation_ppe','Depreciation',1),
 ('depreciation_ppe','Depreciation expense',2),
 ('depreciation_ppe','Depreciation of property, plant and equipment',3),
 ('depreciation_ppe','Depreciation of property plant and equipment',4),
 ('depreciation_ppe','Depreciation of PP&E',5),
 ('depreciation_rou','Depreciation of right-of-use assets',1),
 ('depreciation_rou','Depreciation of right of use assets',2),
 ('depreciation_rou','Depreciation of leased assets',3),
 ('amortization_intangibles','Amortisation of intangible assets',1),
 ('amortization_intangibles','Amortization of intangible assets',2),
 ('amortization_intangibles','Amortisation expense',3),
 ('amortization_intangibles','Amortization expense',4)
) v(concept_key,alias_text,priority)
ON CONFLICT DO NOTHING;

-- Component labels must not be selected as the aggregate D&A fact directly.
DELETE FROM financial_risk_intelligence.financial_concept_aliases
WHERE concept_key='depreciation_amortization'
  AND normalized_alias_text IN (
    financial_risk_intelligence.normalize_financial_alias_text('Depreciation'),
    financial_risk_intelligence.normalize_financial_alias_text('Depreciation expense'),
    financial_risk_intelligence.normalize_financial_alias_text('Depreciation of property, plant and equipment'),
    financial_risk_intelligence.normalize_financial_alias_text('Depreciation of property plant and equipment'),
    financial_risk_intelligence.normalize_financial_alias_text('Depreciation of PP&E'),
    financial_risk_intelligence.normalize_financial_alias_text('Depreciation of right-of-use assets'),
    financial_risk_intelligence.normalize_financial_alias_text('Depreciation of right of use assets'),
    financial_risk_intelligence.normalize_financial_alias_text('Depreciation of leased assets'),
    financial_risk_intelligence.normalize_financial_alias_text('Amortisation of intangible assets'),
    financial_risk_intelligence.normalize_financial_alias_text('Amortization of intangible assets')
  );

COMMIT;

-- Verification: the view used by recipe 04E must expose all components.
SELECT concept_key,canonical_label,statement_type,aliases
FROM financial_risk_intelligence.financial_concept_configuration
WHERE concept_key IN (
 'depreciation_ppe','depreciation_rou','amortization_intangibles'
)
ORDER BY concept_key;
