"""PostgreSQL-backed orchestration state for parallel FSRE assessments."""

from __future__ import annotations

import json
import os
from typing import Any, Iterable, Optional


def orchestration_run_id_from_flow(dataiku_module: Any) -> Optional[str]:
    """Resolve the run-specific output partition supplied to a Dataiku recipe."""
    candidates = [
        os.getenv("FSRE_ORCHESTRATION_RUN_ID"),
        os.getenv("DKU_CURRENT_PARTITION"),
    ]
    try:
        flow_variables = dataiku_module.get_flow_variables() or {}
        # For an output dimension named ``run_id``, DSS exposes the selected
        # partition as DKU_DST_run_id (and may also expose a dataset-qualified
        # DKU_DST_<dataset>_run_id variable).
        candidates.extend(
            value for key, value in flow_variables.items()
            if (
                str(key).upper().endswith("_PARTITION")
                or (
                    str(key).upper().startswith("DKU_DST_")
                    and str(key).upper().endswith("_RUN_ID")
                )
            )
        )
    except Exception:
        pass
    for value in candidates:
        text = str(value or "").strip()
        if text and text.upper() not in {"NP", "NONE", "NULL"}:
            return text
    return None


def runtime_context(cur: Any, orchestration_run_id: str) -> dict[str, Any]:
    row = load_runtime_state(cur, orchestration_run_id)
    if not row:
        raise ValueError(f"No database runtime state exists for orchestration_run_id={orchestration_run_id}")
    return row


def database_run_id_for_orchestration(cur: Any, orchestration_run_id: str) -> Optional[str]:
    row = runtime_context(cur, orchestration_run_id)
    value = row.get("database_run_id")
    return str(value) if value else None


def create_runtime_state(
    cur: Any,
    orchestration_run_id: str,
    company_name: str,
    report_paths: Iterable[str],
    rule_ids: Iterable[str],
    datasets: Iterable[str],
) -> dict[str, Any]:
    dataset_names = list(datasets)
    cur.execute(
        """
        INSERT INTO fsre_audit.assessment_runtime_state (
            orchestration_run_id, company_name, report_paths, rule_ids,
            status, total_count, context_json
        ) VALUES (%s, %s, %s::jsonb, %s::jsonb, 'queued', %s, %s::jsonb)
        ON CONFLICT (orchestration_run_id) DO UPDATE SET
            company_name = EXCLUDED.company_name,
            report_paths = EXCLUDED.report_paths,
            rule_ids = EXCLUDED.rule_ids,
            updated_at = now()
        RETURNING *
        """,
        (
            orchestration_run_id,
            company_name,
            json.dumps(list(report_paths)),
            json.dumps(list(rule_ids)),
            len(dataset_names),
            json.dumps({"source": "fsre_new_assessment_workbench"}),
        ),
    )
    state = dict(cur.fetchone())
    for order, dataset_name in enumerate(dataset_names, start=1):
        cur.execute(
            """
            INSERT INTO fsre_audit.assessment_stage_queue (
                orchestration_run_id, stage_name, stage_order, dataset_name, partition_id
            ) VALUES (%s, %s, %s, %s, %s)
            ON CONFLICT (orchestration_run_id, stage_name) DO NOTHING
            """,
            (orchestration_run_id, dataset_name, order, dataset_name, orchestration_run_id),
        )
    return state


def load_runtime_state(cur: Any, orchestration_run_id: str) -> Optional[dict[str, Any]]:
    cur.execute(
        "SELECT * FROM fsre_audit.assessment_runtime_state WHERE orchestration_run_id = %s",
        (orchestration_run_id,),
    )
    row = cur.fetchone()
    return dict(row) if row else None


def update_runtime_state(cur: Any, orchestration_run_id: str, **updates: Any) -> None:
    allowed = {
        "database_run_id", "status", "current_stage", "current_dataset",
        "completed_datasets", "completed_count", "total_count", "backend_job_ids",
        "result_warning", "error_message", "context_json", "started_at", "completed_at",
    }
    values = {key: value for key, value in updates.items() if key in allowed}
    if not values:
        return
    json_columns = {"completed_datasets", "backend_job_ids", "context_json"}
    assignments = []
    params = []
    for key, value in values.items():
        assignments.append(f"{key} = %s" + ("::jsonb" if key in json_columns else ""))
        params.append(json.dumps(value) if key in json_columns else value)
    params.append(orchestration_run_id)
    cur.execute(
        f"UPDATE fsre_audit.assessment_runtime_state SET {', '.join(assignments)}, updated_at = now() "
        "WHERE orchestration_run_id = %s",
        params,
    )


def claim_stage(cur: Any, orchestration_run_id: str, stage_name: str, worker_id: str) -> Optional[dict[str, Any]]:
    cur.execute(
        """
        UPDATE fsre_audit.assessment_stage_queue q
        SET status = 'claimed', claimed_by = %s, claimed_at = now(), updated_at = now()
        WHERE q.stage_request_id = (
            SELECT stage_request_id
            FROM fsre_audit.assessment_stage_queue
            WHERE orchestration_run_id = %s AND stage_name = %s AND status = 'pending'
            FOR UPDATE SKIP LOCKED
            LIMIT 1
        )
        RETURNING q.*
        """,
        (worker_id, orchestration_run_id, stage_name),
    )
    row = cur.fetchone()
    return dict(row) if row else None


def complete_stage(cur: Any, orchestration_run_id: str, stage_name: str, error: Optional[str] = None) -> None:
    status = "failed" if error else "completed"
    cur.execute(
        """
        UPDATE fsre_audit.assessment_stage_queue
        SET status = %s, error_message = %s, completed_at = now(), updated_at = now()
        WHERE orchestration_run_id = %s AND stage_name = %s
        """,
        (status, error, orchestration_run_id, stage_name),
    )
