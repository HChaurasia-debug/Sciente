"""Classify registered entities into governed sectors from annual-report text.

Inputs: FRI_UPLOAD_REGISTRATION_RESULTS, FRI_DOCUMENT_FRAGMENTS,
FRI_SECTOR_CLASSIFICATION_RULES (PostgreSQL view active_sector_classification_rules).
Outputs: FRI_ENTITY_SECTOR_CLASSIFICATION_EVIDENCE,
FRI_ENTITY_SECTOR_CLASSIFICATION_EXCEPTIONS.

High-confidence results are upserted into PostgreSQL entity_sector_assignments.
Manual/approved assignments are never overwritten.
"""
from __future__ import annotations

import datetime as dt
import json
import math
import re
from collections import defaultdict
from typing import Any, Dict, List

import dataiku
import pandas as pd
import psycopg2

from financial_risk_intelligence.database import DatabaseSettings

REGISTRATIONS = "FRI_UPLOAD_REGISTRATION_RESULTS"
FRAGMENTS = "FRI_DOCUMENT_FRAGMENTS"
RULES = "FRI_SECTOR_CLASSIFICATION_RULES"
EVIDENCE = "FRI_ENTITY_SECTOR_CLASSIFICATION_EVIDENCE"
EXCEPTIONS = "FRI_ENTITY_SECTOR_CLASSIFICATION_EXCEPTIONS"
VERSION = "sector-classifier-rules-and-format-1.1.0"
MIN_SCORE = 12.0
MIN_CONFIDENCE = 0.55
MIN_MARGIN = 0.15
DOMINANCE_TERMS = ("principal activity", "principal business", "primary business", "main business", "majority of revenue", "lion s share", "largest segment", "external customers", "total revenue")
PROTECTED_SOURCES = {"MANUAL", "APPROVED", "ENTITY_MASTER", "REGULATORY_CLASSIFICATION"}

# Report-format profiles are stricter than ordinary sector keywords.  Every
# required phrase and the configured number of optional phrases must occur in
# the document before a format-specific sector/template can be selected.
# This detects a reusable SGX/SFRS(I) statement layout, not a filename or an
# entity identifier.
REPORT_FORMAT_PROFILES = {
    "manufacturing_addvalue": {
        "sector_name": "Manufacturing - Addvalue report format",
        "base_sector": "manufacturing",
        "required": (
            "consolidated statement of profit or loss and other comprehensive income",
            "profit for the year representing total comprehensive income for the year net of tax",
            "statements of financial position",
            "consolidated statement of cash flows",
        ),
        "optional": (
            "provision for expected credit loss on trade receivables",
            "net cash generated from used in financing activities",
            "redeemable convertible bonds",
            "weighted average number of ordinary shares for the purpose of calculating basic and diluted earnings per share",
        ),
        "minimum_optional": 2,
    },
}
EVIDENCE_COLUMNS = ["tenant_id","entity_id","assessment_run_id","source_document_id","file_name","sector_key","sector_name",
                    "classification_status","classification_method","score","confidence","runner_up_sector_key","runner_up_score",
                    "score_margin","evidence_json","classifier_version","classified_at"]
EXCEPTION_COLUMNS = ["tenant_id","entity_id","assessment_run_id","source_document_id","file_name","exception_code","message",
                     "candidate_scores_json","classifier_version","created_at"]


def read(name: str) -> pd.DataFrame:
    try: frame=dataiku.Dataset(name).get_dataframe(infer_with_pandas=True)
    except (TypeError,ValueError): frame=dataiku.Dataset(name).get_dataframe()
    frame=frame.copy(); frame.columns=[str(column).strip().lower() for column in frame.columns]; return frame


def text(value: Any) -> str:
    if value is None: return ""
    try:
        if pd.isna(value): return ""
    except Exception: pass
    return str(value).strip()


def normalized(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+"," ",text(value).lower()).strip()


def number(value: Any, default: float=0.0) -> float:
    try:
        result=float(value); return result if math.isfinite(result) else default
    except (TypeError,ValueError): return default


def connection():
    settings=DatabaseSettings.from_runtime()
    return psycopg2.connect(host=settings.host,port=settings.port,dbname=settings.database,user=settings.user,
                            password=settings.password,application_name=settings.application_name,connect_timeout=30)


def score_document(fragment_rows: List[Dict[str,Any]], rules: List[Dict[str,Any]]):
    scores=defaultdict(float); evidence=defaultdict(list)
    for fragment in fragment_rows:
        content=normalized(fragment.get("content_text")); page=int(number(fragment.get("page_number"),0))
        if not content: continue
        dominant=any(term in content for term in DOMINANCE_TERMS)
        for rule in rules:
            phrase=normalized(rule.get("normalized_phrase") or rule.get("phrase"))
            if not phrase or phrase not in content: continue
            occurrences=min(content.count(phrase),3); base=number(rule.get("weight"),1.0)*occurrences
            evidence_type=text(rule.get("evidence_type")).upper()
            multiplier=1.0+(0.75 if dominant else 0)+(0.5 if evidence_type in {"PRINCIPAL_ACTIVITY","SEGMENT_REVENUE","REGULATORY_IDENTITY"} else 0)
            contribution=base*multiplier; sector=text(rule.get("sector_key")); scores[sector]+=contribution
            start=max(0,content.find(phrase)-100); end=min(len(content),content.find(phrase)+len(phrase)+160)
            evidence[sector].append({"page_number":page,"phrase":phrase,"evidence_type":evidence_type,
                                     "score_contribution":round(contribution,4),"excerpt":content[start:end]})
    ranked=sorted(scores.items(),key=lambda item:(-item[1],item[0])); return ranked,evidence


def detect_report_format(fragment_rows: List[Dict[str, Any]], base_sector: str):
    """Return a format-specific sector only for a complete audited signature."""
    content = " ".join(
        normalized(fragment.get("content_text"))
        for fragment in fragment_rows
        if text(fragment.get("content_text"))
    )
    if not content:
        return None
    for sector_key, profile in REPORT_FORMAT_PROFILES.items():
        if base_sector != profile["base_sector"]:
            continue
        required = [phrase for phrase in profile["required"] if phrase in content]
        optional = [phrase for phrase in profile["optional"] if phrase in content]
        if (
            len(required) == len(profile["required"])
            and len(optional) >= int(profile["minimum_optional"])
        ):
            return {
                "sector_key": sector_key,
                "sector_name": profile["sector_name"],
                "confidence": 0.99,
                "required_matches": required,
                "optional_matches": optional,
            }
    return None


def existing_assignment(cursor,entity_id: str):
    cursor.execute("""SELECT sector_key,source,confidence FROM financial_risk_intelligence.entity_sector_assignments
                      WHERE entity_id=%s AND active AND (valid_to IS NULL OR valid_to>=CURRENT_DATE)
                      ORDER BY valid_from DESC LIMIT 1""",(entity_id,)); return cursor.fetchone()


def upsert_assignment(cursor,entity_id: str,sector: str,confidence: float):
    cursor.execute("""UPDATE financial_risk_intelligence.entity_sector_assignments
                      SET valid_to=CURRENT_DATE-1,active=false
                      WHERE entity_id=%s AND active AND valid_from<CURRENT_DATE""",(entity_id,))
    cursor.execute("""INSERT INTO financial_risk_intelligence.entity_sector_assignments
      (entity_id,sector_key,valid_from,valid_to,source,confidence,active)
      VALUES(%s,%s,CURRENT_DATE,NULL,'ANNUAL_REPORT_RULE_CLASSIFIER',%s,true)
      ON CONFLICT(entity_id,valid_from) DO UPDATE SET sector_key=EXCLUDED.sector_key,valid_to=NULL,
      source=EXCLUDED.source,confidence=EXCLUDED.confidence,active=true""",(entity_id,sector,confidence))


def main():
    registrations,fragments,rules_frame=read(REGISTRATIONS),read(FRAGMENTS),read(RULES)
    required_registration={"tenant_id","entity_id","assessment_run_id","source_document_id","file_name"}
    required_fragments={"source_document_id","page_number","content_text"}; required_rules={"sector_key","phrase","weight"}
    missing=(required_registration-set(registrations.columns))|(required_fragments-set(fragments.columns))|(required_rules-set(rules_frame.columns))
    if missing: raise RuntimeError("Sector classifier input schema is missing: "+", ".join(sorted(missing)))
    rules=rules_frame.to_dict("records"); now=dt.datetime.now(dt.timezone.utc).isoformat(); evidence_rows=[]; exception_rows=[]
    sector_names={text(row.get("sector_key")):text(row.get("sector_name") or row.get("sector_key")) for row in rules}
    db=connection()
    try:
        with db.cursor() as cursor:
            for registration in registrations.to_dict("records"):
                if text(registration.get("registration_status")).upper() not in {"SUCCESS","REGISTERED"}: continue
                document_id=text(registration.get("source_document_id")); entity_id=text(registration.get("entity_id"))
                base={key:text(registration.get(key)) for key in ["tenant_id","entity_id","assessment_run_id","source_document_id","file_name"]}
                doc_fragments=fragments[fragments["source_document_id"].astype(str).eq(document_id)].to_dict("records")
                current=existing_assignment(cursor,entity_id)
                if current and text(current[1]).upper() in PROTECTED_SOURCES:
                    evidence_rows.append({**base,"sector_key":text(current[0]),"sector_name":sector_names.get(text(current[0]),text(current[0])),
                      "classification_status":"PRESERVED","classification_method":"EXISTING_GOVERNED_ASSIGNMENT","score":None,"confidence":number(current[2]),
                      "runner_up_sector_key":"","runner_up_score":None,"score_margin":None,"evidence_json":"[]","classifier_version":VERSION,"classified_at":now}); continue
                ranked,evidence=score_document(doc_fragments,rules)
                if not ranked:
                    exception_rows.append({**base,"exception_code":"NO_SECTOR_EVIDENCE","message":"No approved sector phrase was found in extracted annual-report text",
                                           "candidate_scores_json":"{}","classifier_version":VERSION,"created_at":now}); continue
                top_sector,top_score=ranked[0]; runner_sector,runner_score=ranked[1] if len(ranked)>1 else ("",0.0)
                total=sum(score for _,score in ranked); confidence=top_score/total if total else 0.0; margin=(top_score-runner_score)/top_score if top_score else 0.0
                candidates=dict(ranked)
                if top_score<MIN_SCORE or confidence<MIN_CONFIDENCE or margin<MIN_MARGIN:
                    exception_rows.append({**base,"exception_code":"AMBIGUOUS_SECTOR","message":f"Top candidate {top_sector} did not meet score/confidence/margin thresholds",
                                           "candidate_scores_json":json.dumps(candidates),"classifier_version":VERSION,"created_at":now}); continue
                base_sector = top_sector
                format_match = detect_report_format(doc_fragments, base_sector)
                classification_method = "DATABASE_RULES_WITH_DOMINANCE_BOOST"
                format_evidence = []
                if format_match:
                    top_sector = text(format_match["sector_key"])
                    confidence = number(format_match["confidence"], 0.99)
                    classification_method = "DATABASE_SECTOR_RULES_PLUS_REPORT_FORMAT_SIGNATURE"
                    format_evidence = [{
                        "evidence_type": "REPORT_FORMAT_SIGNATURE",
                        "required_matches": format_match["required_matches"],
                        "optional_matches": format_match["optional_matches"],
                        "template_route": "MANUFACTURING_ADDVALUE_AR",
                    }]
                    sector_names[top_sector] = text(format_match["sector_name"])
                unchanged=bool(current and text(current[0])==top_sector)
                if not unchanged:
                    upsert_assignment(cursor,entity_id,top_sector,confidence)
                evidence_rows.append({**base,"sector_key":top_sector,"sector_name":sector_names.get(top_sector,top_sector),"classification_status":"CONFIRMED" if unchanged else "ASSIGNED",
                  "classification_method":"EXISTING_ASSIGNMENT_CONFIRMED" if unchanged else classification_method,"score":top_score,"confidence":confidence,
                  "runner_up_sector_key":runner_sector,"runner_up_score":runner_score,"score_margin":margin,
                  "evidence_json":json.dumps(format_evidence + evidence.get(base_sector, [])[:20],ensure_ascii=False),"classifier_version":VERSION,"classified_at":now})
        db.commit()
    except Exception:
        db.rollback(); raise
    finally: db.close()
    dataiku.Dataset(EVIDENCE).write_with_schema(pd.DataFrame(evidence_rows,columns=EVIDENCE_COLUMNS))
    dataiku.Dataset(EXCEPTIONS).write_with_schema(pd.DataFrame(exception_rows,columns=EXCEPTION_COLUMNS))
    print(f"Sector classification completed: {len(evidence_rows)} classified/preserved, {len(exception_rows)} exception(s)")


main()
