from __future__ import annotations

from dataclasses import dataclass
from typing import Any
from uuid import UUID

from .database import DatabaseSettings, tenant_connection


def _uuid(value: str | None, field_name: str, optional: bool = False) -> str | None:
    if optional and not value:
        return None
    try:
        return str(UUID(str(value)))
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{field_name} must be a valid UUID") from exc


@dataclass(frozen=True)
class CreateRunRequest:
    tenant_id: str
    customer_id: str
    report_id: str
    configuration_set_id: str
    requested_by: str | None
    idempotency_key: str
    engine_release: str
    workflow_item_type: str
    run_initial_state: str
    job_initial_state: str
    request_payload: dict[str, Any]

    def validate(self) -> None:
        _uuid(self.tenant_id, "tenant_id")
        _uuid(self.customer_id, "customer_id")
        _uuid(self.report_id, "report_id")
        _uuid(self.configuration_set_id, "configuration_set_id")
        _uuid(self.requested_by, "requested_by", optional=True)
        for name in (
            "idempotency_key", "engine_release", "workflow_item_type",
            "run_initial_state", "job_initial_state",
        ):
            if not getattr(self, name).strip():
                raise ValueError(f"{name} is required")


def create_run(request: CreateRunRequest, settings: DatabaseSettings | None = None) -> dict[str, Any]:
    """Create one idempotent run and its configuration-driven workflow jobs."""
    request.validate()
    with tenant_connection(request.tenant_id, settings) as cursor:
        cursor.execute(
            """SELECT r.report_id
               FROM financial_risk_intelligence.reports r
               WHERE r.tenant_id=%s AND r.report_id=%s AND r.customer_id=%s""",
            (request.tenant_id, request.report_id, request.customer_id),
        )
        if cursor.fetchone() is None:
            raise LookupError("The report does not belong to the supplied tenant and customer")

        cursor.execute(
            """SELECT configuration_set_id
               FROM financial_risk_intelligence.configuration_sets
               WHERE tenant_id=%s AND configuration_set_id=%s""",
            (request.tenant_id, request.configuration_set_id),
        )
        if cursor.fetchone() is None:
            raise LookupError("Configuration set is not available to the supplied tenant")

        cursor.execute(
            """INSERT INTO financial_risk_intelligence.runs
               (tenant_id,customer_id,report_id,configuration_set_id,idempotency_key,
                lifecycle_state,engine_release,request_payload,requested_by)
               VALUES (%s,%s,%s,%s,%s,%s,%s,%s::jsonb,%s)
               ON CONFLICT (tenant_id,idempotency_key)
               DO UPDATE SET idempotency_key=EXCLUDED.idempotency_key
               RETURNING run_id,lifecycle_state,(xmax=0) AS created""",
            (
                request.tenant_id, request.customer_id, request.report_id,
                request.configuration_set_id, request.idempotency_key,
                request.run_initial_state, request.engine_release,
                __import__("json").dumps(request.request_payload), request.requested_by,
            ),
        )
        run = cursor.fetchone()

        cursor.execute(
            """SELECT item_key,sequence_number,definition
               FROM financial_risk_intelligence.configuration_items
               WHERE tenant_id=%s AND configuration_set_id=%s AND item_type=%s
               ORDER BY sequence_number,item_key""",
            (request.tenant_id, request.configuration_set_id, request.workflow_item_type),
        )
        stages = cursor.fetchall()
        if not stages:
            raise LookupError("No workflow stages exist for the selected configuration")

        for stage in stages:
            definition = stage["definition"] or {}
            if "attempt_limit" not in definition:
                raise ValueError(f"Workflow stage {stage['item_key']} has no attempt_limit")
            partition_key = str(definition.get("partition_key") or stage["item_key"])
            job_key = f"{request.idempotency_key}:{stage['item_key']}:{partition_key}"
            cursor.execute(
                """INSERT INTO financial_risk_intelligence.run_jobs
                   (tenant_id,run_id,stage_key,partition_key,idempotency_key,lifecycle_state,
                    sequence_number,attempt_limit,input_payload)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s::jsonb)
                   ON CONFLICT (tenant_id,idempotency_key) DO NOTHING""",
                (
                    request.tenant_id, run["run_id"], stage["item_key"], partition_key,
                    job_key, request.job_initial_state, stage["sequence_number"],
                    int(definition["attempt_limit"]),
                    __import__("json").dumps(definition.get("input_payload", {})),
                ),
            )

        return {
            "tenant_id": request.tenant_id,
            "run_id": str(run["run_id"]),
            "lifecycle_state": run["lifecycle_state"],
            "created": bool(run["created"]),
            "job_count": len(stages),
        }
