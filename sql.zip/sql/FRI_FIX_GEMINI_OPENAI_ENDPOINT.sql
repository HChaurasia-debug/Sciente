BEGIN;

UPDATE financial_risk_intelligence.runtime_settings
   SET setting_value = 'https://generativelanguage.googleapis.com/v1beta/openai',
       active = TRUE,
       updated_at = CURRENT_TIMESTAMP
 WHERE setting_key = 'fri_gemini_base_url';

INSERT INTO financial_risk_intelligence.runtime_settings
    (setting_key, setting_value, is_secret, active, updated_at)
VALUES
    ('fri_gemini_base_url',
     'https://generativelanguage.googleapis.com/v1beta/openai',
     FALSE, TRUE, CURRENT_TIMESTAMP)
ON CONFLICT (setting_key) DO NOTHING;

COMMIT;

SELECT setting_key, setting_value, active, updated_at
  FROM financial_risk_intelligence.runtime_settings
 WHERE setting_key IN ('fri_llm_provider', 'fri_gemini_base_url', 'fri_gemini_model');
