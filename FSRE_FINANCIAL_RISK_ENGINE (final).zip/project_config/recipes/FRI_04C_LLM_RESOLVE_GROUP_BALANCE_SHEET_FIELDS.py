"""FRI_04C_LLM_RESOLVE_GROUP_BALANCE_SHEET_FIELDS

Deterministic Balance Sheet mapping with constrained Groq assistance only for
share-note quantities. The LLM sees compact share candidates and chooses IDs;
Python copies and validates the actual document amounts.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import os
import re
import urllib.request
from typing import Any, Dict, List, Optional

import dataiku
import pandas as pd
import psycopg2

INPUT = "FRI_STANDARDIZED_STATEMENT_VALUES"
FRAGMENTS_INPUT = "FRI_DOCUMENT_TEXT_FRAGMENTS"
OUTPUT = "FRI_BALANCE_SHEET_INPUTS"
EXCEPTIONS = "FRI_BALANCE_SHEET_INPUT_EXCEPTIONS"
VERSION = "fri-groq-share-note-resolver-1.5.0"
FIELDS = [
    ("total_current_assets", "Total current assets"),
    ("trade_receivables_net", "Trade receivables (net)"),
    ("inventory", "Inventory"),
    ("net_ppe_fixed_assets", "Net PP&E (fixed assets)"),
    ("total_assets", "Total assets"),
    ("total_current_liabilities", "Total current liabilities"),
    ("long_term_debt", "Long-term debt"),
    ("total_liabilities", "Total liabilities"),
    ("retained_earnings", "Retained earnings"),
    ("total_shareholders_equity", "Total shareholders' equity"),
    ("shares_outstanding", "Shares outstanding"),
]
VALUE_COLUMNS = ["statement_value_id", "tenant_id", "entity_id", "assessment_run_id", "source_document_id", "table_artifact_id", "source_table_id", "statement_type", "statement_title", "statement_section", "row_index", "row_order", "row_label", "concept_key", "source_row_label", "note_reference", "entity_scope", "period_label", "period_end", "column_index", "raw_value", "numeric_value", "value_status", "currency", "unit", "is_total", "page_number", "extraction_confidence", "structure_score", "selection_method", "source_column_index", "normalization_status", "resolver_version", "resolved_at"]
EXCEPTION_COLUMNS = ["tenant_id", "entity_id", "assessment_run_id", "source_document_id", "table_artifact_id", "concept_key", "display_label", "exception_code", "severity", "message", "recommended_action", "resolver_version", "created_at"]


def text(value: Any) -> str:
    if value is None or str(value).strip().lower() in {"", "nan", "none", "null"}:
        return ""
    return str(value).strip()


def numeric(value: Any) -> Optional[float]:
    try:
        result = float(value)
        return None if pd.isna(result) else result
    except (TypeError, ValueError):
        return None


def year(value: Any) -> Optional[int]:
    found = re.findall(r"\b(?:19|20)\d{2}\b", text(value))
    return int(found[-1]) if found else None


def normalize_label(value: Any) -> str:
    value = text(value).lower().replace("’", "'").replace("&", " and ")
    value = re.sub(r"\([^)]*\)", " ", value)
    value = re.sub(r"[^a-z0-9]+", " ", value)
    return re.sub(r"\s+", " ", value).strip()


def table_key(row: Dict[str, Any]) -> str:
    return text(
        row.get("table_artifact_id")
        or row.get("source_table_id")
        or row.get("statement_title")
    ) or "UNKNOWN_TABLE"


def table_score(table_rows: List[Dict[str, Any]]) -> int:
    title = " ".join(
        text(row.get("statement_title"))
        for row in table_rows
    ).lower()

    labels = {
        normalize_label(row.get("row_label"))
        for row in table_rows
    }

    score = 0

    if "the group" in title:
        score += 100
    if "the company" in title:
        score += 35
    if "consolidated" in title:
        score += 35
    if "supplementary financial statements" in title:
        score -= 100
    if "the bank group" in title:
        score -= 50
    if "total assets" in labels:
        score += 30
    if "total liabilities" in labels:
        score += 30
    if "shareholders funds" in labels:
        score += 20

    return score


def select_consolidated_table(
    all_rows: List[Dict[str, Any]],
) -> tuple[str, List[Dict[str, Any]]]:
    grouped: Dict[str, List[Dict[str, Any]]] = {}

    for row in all_rows:
        grouped.setdefault(table_key(row), []).append(row)

    if not grouped:
        raise RuntimeError("No balance-sheet table groups were found")

    selected_key, selected_rows = max(
        grouped.items(),
        key=lambda item: table_score(item[1]),
    )

    print(
        f"Selected consolidated table={selected_key} "
        f"score={table_score(selected_rows)} "
        f"rows={len(selected_rows)}"
    )

    return selected_key, selected_rows


def infer_group_columns(
    table_rows: List[Dict[str, Any]],
) -> List[int]:
    total_rows = [
        row for row in table_rows
        if normalize_label(row.get("row_label")) == "total assets"
    ]

    columns = set()

    for row in total_rows:
        try:
            columns.add(int(float(row.get("column_index"))))
        except (TypeError, ValueError):
            continue

    if len(columns) < 2:
        for row in table_rows:
            try:
                columns.add(int(float(row.get("column_index"))))
            except (TypeError, ValueError):
                continue

    ordered = sorted(columns)

    if len(ordered) < 2:
        raise RuntimeError(
            "Unable to identify current and prior group columns"
        )

    selected = ordered[:2]

    print(f"Selected group columns={selected}")

    return selected


ALIASES = {
    "total_current_assets": ["total current assets", "current assets"],
    "trade_receivables_net": ["trade receivables", "accounts receivable", "receivables net", "trade and other receivables"],
    "inventory": ["inventory", "inventories"],
    "net_ppe_fixed_assets": ["property plant and equipment", "property and equipment", "net ppe", "fixed assets", "properties and other fixed assets"],
    "total_assets": ["total assets"],
    "total_current_liabilities": ["total current liabilities", "current liabilities"],
    "long_term_debt": ["long term debt", "long-term debt", "long term borrowings", "non current debt", "non-current debt", "other debt securities"],
    "total_liabilities": ["total liabilities"],
    "retained_earnings": ["retained earnings", "revenue reserves"],
    "total_shareholders_equity": ["total shareholders funds", "shareholders funds", "total shareholders equity", "total equity"],
    "shares_outstanding": ["shares outstanding", "ordinary shares outstanding", "shares in issue",
                           "issued ordinary shares", "number of ordinary shares", "issued shares at end"],
}


def python_candidate(concept_key: str, candidate_rows: List[Dict[str, Any]], requested_period: Any, requested_column: Optional[int] = None) -> Optional[Dict[str, Any]]:
    aliases = [normalize_label(alias) for alias in ALIASES.get(concept_key, [])]
    for row in candidate_rows:
        label = normalize_label(row.get("row_label"))
        candidate_year = year(row.get("period_label") or row.get("period_end"))
        try:
            candidate_column = int(float(row.get("column_index")))
        except (TypeError, ValueError):
            candidate_column = None
        column_ok = requested_column is None or candidate_column == requested_column
        period_ok = requested_column is not None or not isinstance(requested_period, int) or candidate_year == requested_period
        if column_ok and period_ok and any(label == alias or alias in label or label in alias for alias in aliases):
            return row
    return None

def ordered_field_candidates(
    concept_key: str,
    candidate_rows: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """
    Match the preferred source label first, then sort by source column.

    This prevents:
    - note references (column 1) being selected as values
    - Total equity replacing Shareholders' funds
    - company columns replacing group columns
    """
    aliases = [
        normalize_label(alias)
        for alias in ALIASES.get(concept_key, [])
    ]

    matches = []

    for row_order, row in enumerate(candidate_rows):
        label = normalize_label(row.get("row_label"))

        matched_rank = None

        for alias_rank, alias in enumerate(aliases):
            if label == alias:
                matched_rank = alias_rank
                break

        if matched_rank is None:
            for alias_rank, alias in enumerate(aliases):
                if alias in label or label in alias:
                    matched_rank = 100 + alias_rank
                    break

        if matched_rank is None:
            continue

        try:
            column_index = int(float(row.get("column_index")))
        except (TypeError, ValueError):
            column_index = 10**9

        matches.append(
            (matched_rank, column_index, row_order, row)
        )

    matches.sort(key=lambda item: item[:3])

    return [item[3] for item in matches]
def derived_long_term_debt(
    candidate_rows: List[Dict[str, Any]],
    requested_column: int,
) -> Optional[Dict[str, Any]]:
    """
    Derive Long-term debt from the two source rows used by App.jsx:
    Other debt securities + Subordinated term debts.
    """
    found = {}

    for row in candidate_rows:
        try:
            column = int(float(row.get("column_index")))
        except (TypeError, ValueError):
            continue

        if column != requested_column:
            continue

        label = normalize_label(row.get("row_label"))

        if label in {
            "other debt securities",
            "subordinated term debts",
        }:
            value = numeric(row.get("numeric_value"))
            if value is not None:
                found[label] = row

    debt = found.get("other debt securities")
    subordinated = found.get("subordinated term debts")

    if debt is None or subordinated is None:
        return None

    debt_value = numeric(debt.get("numeric_value"))
    subordinated_value = numeric(subordinated.get("numeric_value"))
    total = debt_value + subordinated_value

    return {
        **debt,
        "numeric_value": total,
        "raw_value": f"{debt_value:g} + {subordinated_value:g} = {total:g}",
        "row_label": "Long-term debt",
        "source_row_label": (
            "Other debt securities + Subordinated term debts"
        ),
        "value_status": "DERIVED",
        "selection_method": "DERIVED_SUM",
    }

def read_dataset(name: str) -> pd.DataFrame:
    try:
        return dataiku.Dataset(name).get_dataframe(infer_with_pandas=False)
    except TypeError:
        return dataiku.Dataset(name).get_dataframe()


def read_optional_dataset(name: str) -> pd.DataFrame:
    try:
        return read_dataset(name)
    except Exception as exc:
        print(f"Optional dataset {name} unavailable: {type(exc).__name__}: {exc}")
        return pd.DataFrame()


def runtime_settings() -> Dict[str, str]:
    """Load runtime configuration from PostgreSQL, with migration fallback."""
    variables = dataiku.get_custom_variables()
    settings: Dict[str, str] = {}
    connection = None
    try:
        connection = psycopg2.connect(
            host=variables.get("fsre_pg_host") or variables.get("fri_pg_host") or os.getenv("FSRE_PG_HOST"),
            port=int(variables.get("fsre_pg_port") or variables.get("fri_pg_port") or os.getenv("FSRE_PG_PORT", "5432")),
            dbname=variables.get("fsre_pg_database") or variables.get("fri_pg_database") or os.getenv("FSRE_PG_DATABASE"),
            user=variables.get("fsre_pg_user") or variables.get("fri_pg_user") or os.getenv("FSRE_PG_USER"),
            password=variables.get("fsre_pg_password") or variables.get("fri_pg_password") or os.getenv("FSRE_PG_PASSWORD"),
        )
        with connection.cursor() as cursor:
            cursor.execute(
                """SELECT setting_key, setting_value
                   FROM financial_risk_intelligence.runtime_settings
                   WHERE active = TRUE"""
            )
            settings.update({str(key): str(value) for key, value in cursor.fetchall()})
    except Exception as exc:
        print(f"Runtime settings database unavailable; using Dataiku variables: {type(exc).__name__}: {exc}")
    finally:
        if connection is not None:
            connection.close()

    for key in ("fri_groq_api_key", "fri_groq_base_url", "fri_groq_model", "fri_groq_timeout_seconds"):
        if not settings.get(key) and variables.get(key):
            settings[key] = str(variables[key])
    return settings


def groq_config() -> Dict[str, Any]:
    variables = runtime_settings()
    return {
        "url": text(variables.get("fri_groq_base_url")) or "https://api.groq.com/openai/v1",
        "model": text(variables.get("fri_groq_model")) or "openai/gpt-oss-20b",
        "api_key": text(variables.get("fri_groq_api_key")),
        "timeout": int(float(variables.get("fri_groq_timeout_seconds", 120))),
    }


def call_share_llm(config: Dict[str, Any], candidates: List[Dict[str, Any]]) -> Dict[str, Any]:
    if not config["api_key"]:
        raise RuntimeError("fri_groq_api_key is not configured")
    prompt = {
        "instruction": "Select the current and prior period NUMBER OF ISSUED/OUTSTANDING ORDINARY SHARES. Return candidate IDs only. Never return a monetary share-capital balance and never use weighted-average EPS shares.",
        "requested_field": {"concept_key": "shares_outstanding", "display_label": "Shares outstanding"},
        "period_rule": "Use the two latest reported periods; latest is CURRENT and second latest is PRIOR.",
        "candidates": candidates,
        "response_schema": {"mappings": [{"concept_key": "shares_outstanding", "current_candidate_id": None, "prior_candidate_id": None, "confidence": 0.0}]},
    }
    body = json.dumps({"model": config["model"], "stream": False, "temperature": 0,
                       "messages": [{"role": "system", "content": "Conservative financial-document mapper. JSON only."},
                                    {"role": "user", "content": json.dumps(prompt, ensure_ascii=False)}]}).encode("utf-8")
    request = urllib.request.Request(config["url"].rstrip("/") + "/chat/completions", data=body,
                                     headers={"Content-Type": "application/json", "Authorization": "Bearer " + config["api_key"]}, method="POST")
    with urllib.request.urlopen(request, timeout=config["timeout"]) as response:
        envelope = json.loads(response.read().decode("utf-8"))
    content = text((((envelope.get("choices") or [{}])[0].get("message") or {}).get("content")))
    fenced = re.search(r"```(?:json)?\s*(\{.*\})\s*```", content, re.DOTALL | re.IGNORECASE)
    result = json.loads(fenced.group(1) if fenced else content)
    result["model"] = config["model"]
    return result


df = read_dataset(INPUT)
document_fragments = read_optional_dataset(FRAGMENTS_INPUT)

all_rows = [
    row
    for row in df.to_dict(orient="records")
    if text(row.get("statement_type")).upper() == "BALANCE_SHEET"
    and numeric(row.get("numeric_value")) is not None
]

if not all_rows:
    raise RuntimeError(
        "No numeric Balance Sheet values found in FRI_STANDARDIZED_STATEMENT_VALUES"
    )

document_groups = {}

for row in all_rows:
    document_key = (
        text(row.get("tenant_id")),
        text(row.get("entity_id")),
        text(row.get("assessment_run_id")),
        text(row.get("source_document_id")),
    )
    document_groups.setdefault(document_key, []).append(row)

all_output = []
all_exceptions = []

for document_key, rows in document_groups.items():
    table_id, eligible = select_consolidated_table(rows)
    group_columns = infer_group_columns(eligible)

    header_years = sorted(
        {
            int(value)
            for value in re.findall(
                r"\b(?:19|20)\d{2}\b",
                text(eligible[0].get("statement_title")),
            )
        },
        reverse=True,
    )
    periods = sorted(
        {
            year(row.get("period_label") or row.get("period_end"))
            for row in eligible
            if year(row.get("period_label") or row.get("period_end")) is not None
        },
        reverse=True,
    )

    periods = header_years[:2] if len(header_years) >= 2 else periods

    current_period = periods[0] if periods else "Current period"
    prior_period = periods[1] if len(periods) > 1 else "Prior period"

    current_column = group_columns[0]
    prior_column = group_columns[1]

    # Only these columns contain Group financial values.
    # Column 1 is the Note column and must never be treated as an amount.
    group_rows = []

    for row in eligible:
        try:
            source_column = int(float(row.get("column_index")))
        except (TypeError, ValueError):
            continue

        if source_column in group_columns:
            group_rows.append(row)

    if not group_rows:
        raise RuntimeError(
            "No group financial rows were found after excluding note/company columns"
        )
    candidates = []
    candidate_by_id = {}
    share_candidates = []
    document_rows = [row for row in df.to_dict(orient="records")
                     if (text(row.get("tenant_id")), text(row.get("entity_id")),
                         text(row.get("assessment_run_id")), text(row.get("source_document_id"))) == document_key
                     and numeric(row.get("numeric_value")) is not None]
    for row in document_rows:
        search_text = " ".join(text(row.get(key)) for key in
                               ("row_label", "source_row_label", "statement_title", "statement_section")).lower()
        is_share_note = "share" in search_text and any(token in search_text for token in
            ("number of", "shares in issue", "issued ordinary", "issued shares", "outstanding",
             "ordinary shares at end", "treasury shares count", "treasury shares"))
        excluded = any(token in search_text for token in
                       ("weighted average", "earnings per share", "loss per share", "share-based payment"))
        value = numeric(row.get("numeric_value"))
        if is_share_note and not excluded and value is not None and abs(value) >= 1000:
            share_candidates.append(row)
    # The authoritative outstanding-share disclosure may be narrative rather
    # than a standardized table row. Capture the exact current/prior figures
    # from the share/treasury note and expose them as candidate IDs only.
    if not document_fragments.empty:
        document_id = document_key[3]
        for fragment in document_fragments.to_dict(orient="records"):
            if text(fragment.get("source_document_id")) != document_id:
                continue
            content = text(fragment.get("content_text"))
            if "excluding treasury shares" not in content.lower():
                continue
            match = re.search(
                r"excluding treasury shares\)?\s+comprised\s+([\d,]+)\s+ordinary shares\s*\(\s*(20\d{2})\s*:\s*([\d,]+)\s+ordinary shares",
                content, re.IGNORECASE,
            )
            if not match:
                continue
            current_years = [value for value in re.findall(r"financial year(?:s)? ended[^\n]{0,80}?(20\d{2})", content, re.IGNORECASE)]
            current_year = int(current_years[0]) if current_years else int(match.group(2)) + 1
            for period, raw_value in ((current_year, match.group(1)), (int(match.group(2)), match.group(3))):
                synthetic = dict(eligible[0])
                synthetic.update({"row_label": "Issued ordinary shares excluding treasury shares",
                                  "source_row_label": "Issued and paid up share capital excluding treasury shares",
                                  "statement_title": "Treasury shares note", "statement_section": "Share capital",
                                  "period_label": str(period), "period_end": str(period),
                                  "numeric_value": float(raw_value.replace(",", "")),
                                  "raw_value": raw_value, "page_number": fragment.get("page_number"),
                                  "selection_method": "DOCUMENT_FRAGMENT_EXACT_DISCLOSURE"})
                share_candidates.append(synthetic)
            break
    llm_rows = share_candidates[:40]
    for index, row in enumerate(llm_rows):
        candidate_id = f"c{index}"
        candidate = {"candidate_id": candidate_id, "row_label": text(row.get("row_label")),
                     "source_context": text(row.get("statement_title") or row.get("statement_section")),
                     "period": year(row.get("period_label") or row.get("period_end")),
                     "numeric_value": numeric(row.get("numeric_value")),
                     "raw_value": text(row.get("raw_value") or row.get("raw_text")),
                     "page_number": row.get("page_number"), "column_index": row.get("column_index")}
        candidates.append(candidate)
        candidate_by_id[candidate_id] = row

    config = groq_config()
    now = dt.datetime.now(dt.timezone.utc).isoformat()
    exceptions = []
    try:
        answer = call_share_llm(config, candidates) if candidates else {"mappings": [], "model": config["model"]}
        mappings = {text(item.get("concept_key")): item for item in answer.get("mappings", []) if isinstance(item, dict)}
        model_name = text(answer.get("model"))
    except Exception as exc:
        mappings = {}
        model_name = ""
        exceptions.append({"tenant_id": text(eligible[0].get("tenant_id")), "entity_id": text(eligible[0].get("entity_id")), "assessment_run_id": text(eligible[0].get("assessment_run_id")), "source_document_id": text(eligible[0].get("source_document_id")), "table_artifact_id": table_id, "concept_key": "shares_outstanding", "display_label": "Shares outstanding", "exception_code": "GROQ_SHARE_MAPPING_UNAVAILABLE", "severity": "WARNING", "message": f"{type(exc).__name__}: {exc}", "recommended_action": "Check Groq configuration or review the share-capital note candidates.", "resolver_version": VERSION, "created_at": now})

    output = []

    for field_index, (concept_key, display_label) in enumerate(FIELDS):
        mapping = mappings.get(concept_key, {})

        for output_column_index, period_name, requested_period, requested_source_column in [
            (1, "CURRENT", current_period, current_column),
            (2, "PRIOR", prior_period, prior_column),
        ]:
            candidate_id = ""
            derived_flag = False

            if concept_key == "long_term_debt":
                source = derived_long_term_debt(
                    group_rows,
                    requested_source_column,
                )
                valid = source is not None
                derived_flag = valid
            else:
                candidate_id = text(
                    mapping.get(
                        "current_candidate_id"
                        if period_name == "CURRENT"
                        else "prior_candidate_id"
                    )
                )

                source = candidate_by_id.get(candidate_id)

                valid = (
                    source is not None
                    and (
                        year(
                            source.get("period_label")
                            or source.get("period_end")
                        )
                        == requested_period
                        or requested_period
                        in {"Current period", "Prior period"}
                    )
                )

                # Preserve the Groq-selected document-fragment candidate for
                # shares. A generic balance-sheet row can be a monetary share
                # capital amount and must not override the verified quantity.
                ordered = ([] if concept_key == "shares_outstanding" else
                           ordered_field_candidates(concept_key, group_rows))

                preferred_index = (
                    0
                    if period_name == "CURRENT"
                    else 1
                )

                preferred = (
                    ordered[preferred_index]
                    if len(ordered) > preferred_index
                    else None
                )

                if preferred is not None and (
                    source is None
                    or source.get("column_index")
                    != preferred.get("column_index")
                ):
                    source = preferred
                    valid = True
                    candidate_id = ""

                if not valid:
                    fallback = python_candidate(
                        concept_key,
                        group_rows,
                        requested_period,
                        requested_source_column,
                    )

                    if fallback is not None:
                        source = fallback
                        valid = True
                    else:
                        source = eligible[0]

            if not valid:
                exceptions.append({
                    "tenant_id": text(source.get("tenant_id")),
                    "entity_id": text(source.get("entity_id")),
                    "assessment_run_id": text(
                        source.get("assessment_run_id")
                    ),
                    "source_document_id": text(
                        source.get("source_document_id")
                    ),
                    "table_artifact_id": table_id,
                    "concept_key": concept_key,
                    "display_label": display_label,
                    "exception_code": "FIELD_NOT_CONFIRMED",
                    "severity": "WARNING",
                    "message": (
                        f"No source candidate was confirmed for "
                        f"{display_label} ({period_name})."
                    ),
                    "recommended_action": (
                        "Review the source Balance Sheet."
                    ),
                    "resolver_version": VERSION,
                    "created_at": now,
                })

            output.append({
                "statement_value_id": hashlib.sha256(
                    f"{table_id}|{concept_key}|{period_name}".encode()
                ).hexdigest(),
                "tenant_id": text(source.get("tenant_id")),
                "entity_id": text(source.get("entity_id")),
                "assessment_run_id": text(
                    source.get("assessment_run_id")
                ),
                "source_document_id": text(
                    source.get("source_document_id")
                ),
                "table_artifact_id": table_id,
                "source_table_id": text(
                    source.get("source_table_id")
                ),
                "statement_type": "BALANCE_SHEET",
                "statement_title": text(
                    source.get("statement_title")
                ),
                "statement_section": text(
                    source.get("statement_section")
                ),
                "row_index": field_index,
                "row_order": field_index,
                "row_label": display_label,
                "concept_key": concept_key,
                "source_row_label": (
                    text(source.get("source_row_label"))
                    or text(source.get("row_label"))
                    if valid
                    else ""
                ),
                "note_reference": (
                    text(source.get("note_reference"))
                    if valid
                    else ""
                ),
                "entity_scope": "GROUP",
                "period_label": requested_period,
                "period_end": requested_period,
                "column_index": output_column_index,
                "raw_value": (
                    text(source.get("raw_value") or source.get("raw_text"))
                    if valid
                    else "Not reported in filing"
                ),
                "numeric_value": (
                    numeric(source.get("numeric_value"))
                    if valid
                    else None
                ),
                "value_status": (
                    "DERIVED"
                    if derived_flag
                    else (
                        "REPORTED"
                        if valid
                        else "NOT_REPORTED"
                    )
                ),
                "currency": text(source.get("currency")),
                "unit": text(source.get("unit")),
                "is_total": display_label.lower().startswith("total"),
                "page_number": source.get("page_number"),
                "extraction_confidence": numeric(
                    source.get("extraction_confidence")
                ),
                "structure_score": numeric(
                    source.get("structure_score")
                ),
                "selection_method": (
                    "DERIVED_SUM"
                    if derived_flag
                    else (
                        "OLLAMA_CANDIDATE_VALIDATED"
                        if candidate_id and valid
                        else (
                            "PYTHON_ALIAS_FALLBACK"
                            if valid
                            else "NOT_REPORTED"
                        )
                    )
                ),
                "source_column_index": (
                    source.get("column_index")
                    if valid
                    else -1
                ),
                "normalization_status": (
                    "BALANCE_SHEET_RESOLVED"
                ),
                "resolver_version": VERSION,
                "resolved_at": now,
            })
    all_output.extend(output)
    all_exceptions.extend(exceptions)

dataiku.Dataset(OUTPUT).write_with_schema(
    pd.DataFrame(all_output, columns=VALUE_COLUMNS)
)

dataiku.Dataset(EXCEPTIONS).write_with_schema(
    pd.DataFrame(all_exceptions, columns=EXCEPTION_COLUMNS)
)

print(
    json.dumps(
        {
            "resolver_version": VERSION,
            "document_count": len(document_groups),
            "output_rows": len(all_output),
            "exception_count": len(all_exceptions),
        },
        indent=2,
        default=str,
    )
)


