"""FRI_03B_EXTRACT_TABLE_LAYOUTS

Fast coordinate-based financial-table extraction.

Inputs:
    FRI_UPLOAD_REGISTRATION_RESULTS
    FRI_DOCUMENT_FRAGMENTS

Managed-folder configuration:
    fri_source_document_folder_id

Outputs:
    FRI_EXTRACTED_TABLES
    FRI_EXTRACTED_TABLE_CELLS

Required package:
    PyMuPDF
"""

from __future__ import annotations

import hashlib
import json
import math
import os
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Sequence, Tuple

import dataiku
import fitz
import pandas as pd


INPUT_REGISTRATIONS = "FRI_UPLOAD_REGISTRATION_RESULTS"
INPUT_FRAGMENTS = "FRI_DOCUMENT_FRAGMENTS"

OUTPUT_TABLES = "FRI_EXTRACTED_TABLES"
OUTPUT_CELLS = "FRI_EXTRACTED_TABLE_CELLS"
STATEMENT_ALIAS_DATASET = os.getenv(
    "FRI_STATEMENT_ALIAS_DATASET",
    "FRI_APPROVED_FINANCIAL_STATEMENT_ALIASES",
)

EXTRACTOR_VERSION = "fri-pymupdf-layout-2.3.0"


TABLE_COLUMNS = [
    "tenant_id",
    "entity_id",
    "assessment_run_id",
    "source_document_id",
    "document_checksum",
    "table_artifact_id",
    "table_id",
    "page_number",
    "table_number",
    "table_title",
    "statement_type",
    "table_bbox_json",
    "page_width",
    "page_height",
    "reporting_date",
    "presentation_currency",
    "presentation_unit",
    "row_count",
    "column_count",
    "non_empty_cell_count",
    "numeric_cell_count",
    "numeric_cell_ratio",
    "period_labels_json",
    "entity_scopes_json",
    "grid_json",
    "header_tree_json",
    "merged_cells_json",
    "extraction_method",
    "model_name",
    "extractor_version",
    "extraction_confidence",
    "extraction_status",
    "extracted_at",
]

CELL_COLUMNS = [
    "tenant_id",
    "entity_id",
    "assessment_run_id",
    "source_document_id",
    "document_checksum",
    "table_artifact_id",
    "table_id",
    "page_number",
    "table_number",
    "row_index",
    "column_index",
    "row_span",
    "column_span",
    "cell_role",
    "row_label",
    "header_path",
    "column_scope",
    "period_label",
    "note_reference",
    "raw_text",
    "normalized_text",
    "numeric_value",
    "currency",
    "unit",
    "cell_bbox_json",
    "extraction_confidence",
    "extraction_method",
    "extractor_version",
]


STATEMENT_PATTERNS = {
    "BALANCE_SHEET": [
        r"\bbalance\s+sheets?\b",
        r"\bstatements?\s+of\s+financial\s+(?:position|condition)\b",
    ],
    "INCOME_STATEMENT": [
        r"\bincome\s+statements?\b",
        r"\bprofit\s+and\s+loss\b",
        r"\bstatements?\s+of\s+(?:comprehensive\s+)?income\b",
        r"\bstatements?\s+of\s+profit\s+(?:or|and)\s+loss(?:\s+and\s+other\s+comprehensive\s+income)?\b",
        r"\bstatements?\s+of\s+operations\b",
    ],
    "CASH_FLOW_STATEMENT": [
        r"\bcash\s+flow\s+statements?\b",
        r"\bstatements?\s+of\s+cash\s+flows?\b",
    ],
    "CHANGES_IN_EQUITY": [
        r"\bchanges?\s+in\s+equity\b",
    ],
    "NOTES_TABLE": [
        r"\bnotes?\s+to\s+the\s+financial\s+statements?\b",
    ],
}


def load_database_statement_patterns() -> None:
    """Extend baseline detection with approved DB-managed title aliases."""
    try:
        try:
            frame = dataiku.Dataset(STATEMENT_ALIAS_DATASET).get_dataframe(
                infer_with_pandas=False
            )
        except TypeError:
            frame = dataiku.Dataset(STATEMENT_ALIAS_DATASET).get_dataframe()
        loaded = 0
        for row in frame.to_dict(orient="records"):
            statement_type = str(row.get("statement_type") or "").strip().upper()
            alias = str(row.get("alias_text") or row.get("normalized_alias_text") or "").strip()
            if statement_type not in STATEMENT_PATTERNS or not alias:
                continue
            escaped = re.escape(alias.lower()).replace(r"\ ", r"\s+")
            pattern = r"\b" + escaped + r"\b"
            if pattern not in STATEMENT_PATTERNS[statement_type]:
                STATEMENT_PATTERNS[statement_type].insert(0, pattern)
                loaded += 1
        print(f"Loaded {loaded} approved statement patterns from {STATEMENT_ALIAS_DATASET}", flush=True)
    except Exception as error:
        print(f"Statement alias dataset unavailable; using baseline patterns: {error}", flush=True)


load_database_statement_patterns()

YEAR_PATTERN = re.compile(r"\b(?:19|20)\d{2}\b")

NUMBER_PATTERN = re.compile(
    r"^\s*[\(\-+]?\s*"
    r"(?:[$€£₹]\s*)?"
    r"(?:\d{1,3}(?:,\d{3})+|\d+)"
    r"(?:\.\d+)?"
    r"%?\s*\)?\s*$"
)

DASH_VALUES = {"-", "–", "—", "−", "--", "––"}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def missing(value: Any) -> bool:
    if value is None:
        return True

    try:
        if pd.isna(value):
            return True
    except (TypeError, ValueError):
        pass

    return str(value).strip().lower() in {
        "",
        "nan",
        "none",
        "null",
        "nat",
    }


def text_value(value: Any, default: str = "") -> str:
    if missing(value):
        return default
    return str(value).strip()


def int_value(value: Any, default: int) -> int:
    if missing(value):
        return default

    try:
        return int(float(value))
    except (TypeError, ValueError):
        return default


def float_value(value: Any, default: float) -> float:
    if missing(value):
        return default

    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def first_value(
    row: Dict[str, Any],
    names: Sequence[str],
    default: Any = None,
) -> Any:
    for name in names:
        if name in row and not missing(row.get(name)):
            return row.get(name)
    return default


def bool_value(value: Any) -> bool:
    if isinstance(value, bool):
        return value

    return text_value(value).lower() in {
        "true",
        "1",
        "yes",
        "y",
    }


def stable_id(parts: Sequence[Any]) -> str:
    material = "|".join(text_value(part) for part in parts)
    return hashlib.sha256(material.encode("utf-8")).hexdigest()[:32]


def normalize_space(value: str) -> str:
    return re.sub(r"\s+", " ", value or "").strip()


def parse_numeric(value: str) -> Optional[float]:
    candidate = normalize_space(value)

    if candidate in DASH_VALUES:
        return None

    if not NUMBER_PATTERN.match(candidate):
        return None

    negative = candidate.startswith("(") and candidate.endswith(")")

    candidate = candidate.strip("()")
    candidate = candidate.replace(",", "")
    candidate = candidate.replace("−", "-")
    candidate = re.sub(r"[$€£₹%]", "", candidate)
    candidate = candidate.strip()

    try:
        number = float(candidate)
        return -number if negative else number
    except ValueError:
        return None


def is_numeric_token(value: str) -> bool:
    candidate = normalize_space(value)
    return candidate in DASH_VALUES or parse_numeric(candidate) is not None


def load_configuration() -> Dict[str, Any]:
    variables = dataiku.get_custom_variables()

    folder_id = variables.get("fri_source_document_folder_id")
    if missing(folder_id):
        raise RuntimeError(
            "Missing Dataiku project variable: "
            "fri_source_document_folder_id"
        )

    return {
        "folder_id": str(folder_id),
        "workers": max(
            1,
            min(
                8,
                int_value(
                    variables.get("fri_table_extraction_workers"),
                    4,
                ),
            ),
        ),
        "min_numeric_tokens": max(
            2,
            int_value(
                variables.get("fri_table_min_numeric_tokens"),
                8,
            ),
        ),
        "min_numeric_rows": max(
            2,
            int_value(
                variables.get("fri_table_min_numeric_rows"),
                3,
            ),
        ),
        "row_gap": max(
            10.0,
            float_value(
                variables.get("fri_table_row_gap_points"),
                32.0,
            ),
        ),
        "column_tolerance": max(
            8.0,
            float_value(
                variables.get("fri_table_column_tolerance_points"),
                24.0,
            ),
        ),
        "context_lines": max(
            1,
            int_value(
                variables.get("fri_table_context_lines"),
                4,
            ),
        ),
        "max_columns": max(
            4,
            int_value(
                variables.get("fri_table_max_columns"),
                20,
            ),
        ),
    }


def classify_statement(text: str) -> str:
    lowered = text.lower()

    for statement_type, patterns in STATEMENT_PATTERNS.items():
        for pattern in patterns:
            if re.search(pattern, lowered, re.IGNORECASE):
                return statement_type

    # PDF table detection can separate a heading from the table body. Recover
    # primary statements from multiple independent row anchors rather than
    # leaving a complete financial table UNCLASSIFIED. Requiring several
    # anchors prevents an isolated note-table label from becoming a primary
    # statement.
    structural_patterns = {
        "CASH_FLOW_STATEMENT": [
            r"\b(?:cash flows? from|net cash (?:generated|used|provided))\s+operating activities\b",
            r"\boperating activities\b",
            r"\binvesting activities\b",
            r"\bfinancing activities\b",
            r"\bcash and cash equivalents at (?:beginning|end)\b",
        ],
        "INCOME_STATEMENT": [
            r"\brevenue\b",
            r"\bcost of sales\b|\bcost of goods sold\b",
            r"\bgross profit\b",
            r"\b(?:profit|loss) before (?:income )?tax\b",
            r"\b(?:profit|loss) for the (?:year|period)\b",
            r"\bfinance costs?\b",
        ],
        "BALANCE_SHEET": [
            r"\btotal current assets\b",
            r"\btotal assets\b",
            r"\btotal current liabilities\b",
            r"\btotal liabilities\b",
            r"\btotal equity\b|\bshareholders['’]? equity\b",
        ],
    }
    scores = {
        statement_type: sum(bool(re.search(pattern, lowered, re.IGNORECASE)) for pattern in patterns)
        for statement_type, patterns in structural_patterns.items()
    }
    ranked = sorted(scores.items(), key=lambda item: item[1], reverse=True)
    if ranked and ranked[0][1] >= 3 and (len(ranked) == 1 or ranked[0][1] > ranked[1][1]):
        return ranked[0][0]

    return "UNCLASSIFIED"


def group_words_into_lines(
    words: List[Tuple[Any, ...]],
    tolerance: float = 3.0,
) -> List[Dict[str, Any]]:
    prepared = []

    for word in words:
        if len(word) < 5:
            continue

        x0, y0, x1, y1, token = word[:5]
        token = normalize_space(str(token))

        if not token:
            continue

        prepared.append({
            "x0": float(x0),
            "y0": float(y0),
            "x1": float(x1),
            "y1": float(y1),
            "text": token,
            "yc": (float(y0) + float(y1)) / 2.0,
        })

    prepared.sort(key=lambda item: (item["yc"], item["x0"]))

    lines: List[Dict[str, Any]] = []

    for word in prepared:
        selected = None

        for line in reversed(lines[-4:]):
            if abs(line["yc"] - word["yc"]) <= tolerance:
                selected = line
                break

        if selected is None:
            selected = {
                "yc": word["yc"],
                "words": [],
            }
            lines.append(selected)

        selected["words"].append(word)

        count = len(selected["words"])
        selected["yc"] = (
            ((selected["yc"] * (count - 1)) + word["yc"]) / count
        )

    for line in lines:
        line["words"].sort(key=lambda item: item["x0"])
        line["text"] = normalize_space(
            " ".join(word["text"] for word in line["words"])
        )
        line["y0"] = min(word["y0"] for word in line["words"])
        line["y1"] = max(word["y1"] for word in line["words"])
        line["x0"] = min(word["x0"] for word in line["words"])
        line["x1"] = max(word["x1"] for word in line["words"])
        line["numeric_count"] = sum(
            1 for word in line["words"]
            if is_numeric_token(word["text"])
        )
        line["year_count"] = len(YEAR_PATTERN.findall(line["text"]))

    lines.sort(key=lambda line: line["y0"])
    return lines


def page_is_candidate(
    lines: List[Dict[str, Any]],
    minimum_numeric_tokens: int,
    minimum_numeric_rows: int,
) -> bool:
    """
    Detect a table-like page from its physical layout.

    Statement titles are not used as a mandatory extraction gate because
    financial reports use different terminology across industries,
    countries and accounting standards.
    """

    numeric_tokens = sum(
        line["numeric_count"]
        for line in lines
    )

    numeric_rows = sum(
        1
        for line in lines
        if line["numeric_count"] >= 2
    )

    aligned_numeric_rows = sum(
        1
        for line in lines
        if (
            line["numeric_count"] >= 2
            and len(line["words"]) >= 3
        )
    )

    return (
        numeric_tokens >= minimum_numeric_tokens
        and numeric_rows >= minimum_numeric_rows
        and aligned_numeric_rows >= minimum_numeric_rows
    )


def detect_regions(
    lines: List[Dict[str, Any]],
    row_gap: float,
    minimum_numeric_rows: int,
    context_lines: int,
) -> List[List[Dict[str, Any]]]:
    table_line_indexes = [
        index
        for index, line in enumerate(lines)
        if line["numeric_count"] >= 2 or line["year_count"] >= 2
    ]

    if not table_line_indexes:
        return []

    groups: List[List[int]] = []
    current_group = [table_line_indexes[0]]

    for current_index in table_line_indexes[1:]:
        previous_index = current_group[-1]

        previous_line = lines[previous_index]
        current_line = lines[current_index]

        vertical_gap = current_line["y0"] - previous_line["y1"]

        if vertical_gap <= row_gap:
            current_group.append(current_index)
        else:
            groups.append(current_group)
            current_group = [current_index]

    groups.append(current_group)

    regions = []

    for group in groups:
        numeric_rows = sum(
            1 for index in group
            if lines[index]["numeric_count"] >= 2
        )

        if numeric_rows < minimum_numeric_rows:
            continue

        start = max(0, group[0] - context_lines)
        end = min(len(lines), group[-1] + 2)

        region = lines[start:end]

        if region:
            regions.append(region)

    return regions


def merge_primary_statement_fragments(
    regions: List[List[Dict[str, Any]]],
    row_gap: float,
) -> List[List[Dict[str, Any]]]:
    """Join nearby pieces of one primary statement without joining schedules.

    Coordinate extraction can split a balance sheet at ``Total non-current
    assets`` or at a section heading because that line has no two-number
    pattern.  The resulting lower fragment passes validation but loses every
    current-asset line.  Only adjoining fragments (within four normal row
    gaps) are joined; remotely separated note schedules remain independent.
    """
    if len(regions) < 2:
        return regions
    maximum_gap = max(row_gap * 4.0, 110.0)
    merged: List[List[Dict[str, Any]]] = [list(regions[0])]
    for region in regions[1:]:
        previous = merged[-1]
        gap = min(line["y0"] for line in region) - max(line["y1"] for line in previous)
        if gap <= maximum_gap:
            seen = {(line["y0"], line["y1"], line["text"]) for line in previous}
            previous.extend(
                line for line in region
                if (line["y0"], line["y1"], line["text"]) not in seen
            )
            previous.sort(key=lambda line: line["y0"])
        else:
            merged.append(list(region))
    return merged


def build_column_anchors(
    region: List[Dict[str, Any]],
    tolerance: float,
    max_columns: int,
) -> List[float]:
    candidates = []

    for line in region:
        for word in line["words"]:
            if is_numeric_token(word["text"]):
                candidates.append(word["x0"])

    candidates.sort()

    clusters: List[List[float]] = []

    for x_position in candidates:
        selected_cluster = None

        for cluster in clusters:
            cluster_center = sum(cluster) / len(cluster)

            if abs(cluster_center - x_position) <= tolerance:
                selected_cluster = cluster
                break

        if selected_cluster is None:
            clusters.append([x_position])
        else:
            selected_cluster.append(x_position)

    minimum_frequency = max(
        2,
        int(math.ceil(len(region) * 0.08)),
    )

    retained = [
        cluster
        for cluster in clusters
        if len(cluster) >= minimum_frequency
    ]

    retained.sort(
        key=lambda cluster: (
            -(len(cluster)),
            sum(cluster) / len(cluster),
        )
    )

    retained = retained[: max_columns - 1]

    anchors = sorted(
        sum(cluster) / len(cluster)
        for cluster in retained
    )

    return anchors


def assign_word_to_column(
    word: Dict[str, Any],
    anchors: List[float],
    tolerance: float,
) -> int:
    if not anchors:
        return 0

    distances = [
        abs(word["x0"] - anchor)
        for anchor in anchors
    ]

    nearest_index = min(
        range(len(distances)),
        key=lambda index: distances[index],
    )

    nearest_distance = distances[nearest_index]

    if (
        is_numeric_token(word["text"])
        or YEAR_PATTERN.fullmatch(word["text"])
        or nearest_distance <= tolerance
    ):
        if nearest_distance <= tolerance * 1.8:
            return nearest_index + 1

    first_anchor = anchors[0]

    if word["x1"] < first_anchor - tolerance:
        return 0

    return nearest_index + 1


def union_bbox(words: List[Dict[str, Any]]) -> Dict[str, float]:
    return {
        "x0": round(min(word["x0"] for word in words), 3),
        "y0": round(min(word["y0"] for word in words), 3),
        "x1": round(max(word["x1"] for word in words), 3),
        "y1": round(max(word["y1"] for word in words), 3),
    }


def extract_region(
    registration: Dict[str, Any],
    page_number: int,
    page_width: float,
    page_height: float,
    region_number: int,
    region: List[Dict[str, Any]],
    configuration: Dict[str, Any],
) -> Tuple[Optional[Dict[str, Any]], List[Dict[str, Any]]]:
    anchors = build_column_anchors(
        region,
        configuration["column_tolerance"],
        configuration["max_columns"],
    )

    if len(anchors) < 2:
        return None, []

    tenant_id = text_value(
        first_value(registration, ["tenant_id"])
    )
    entity_id = text_value(
        first_value(registration, ["entity_id"])
    )
    assessment_run_id = text_value(
        first_value(
            registration,
            ["assessment_run_id", "run_id"],
        )
    )
    source_document_id = text_value(
        first_value(
            registration,
            ["source_document_id", "document_id"],
        )
    )
    checksum = text_value(
        first_value(
            registration,
            ["document_checksum", "checksum"],
        )
    )

    table_id = stable_id([
        tenant_id,
        assessment_run_id,
        source_document_id,
        checksum,
        page_number,
        region_number,
        EXTRACTOR_VERSION,
    ])

    table_cells = []
    grid_rows: List[List[Optional[str]]] = []

    period_by_column: Dict[int, str] = {}
    scope_by_column: Dict[int, str] = {}

    first_data_row = None

    for row_index, line in enumerate(region):
        cell_words: Dict[int, List[Dict[str, Any]]] = {}

        for word in line["words"]:
            column_index = assign_word_to_column(
                word,
                anchors,
                configuration["column_tolerance"],
            )
            cell_words.setdefault(column_index, []).append(word)

        numeric_values_in_row = 0

        for column_words in cell_words.values():
            combined = normalize_space(
                " ".join(
                    word["text"]
                    for word in sorted(
                        column_words,
                        key=lambda item: item["x0"],
                    )
                )
            )

            if is_numeric_token(combined):
                numeric_values_in_row += 1

        if first_data_row is None and numeric_values_in_row >= 2:
            non_year_numbers = 0

            for column_words in cell_words.values():
                combined = normalize_space(
                    " ".join(
                        word["text"]
                        for word in column_words
                    )
                )

                if (
                    is_numeric_token(combined)
                    and not YEAR_PATTERN.fullmatch(combined)
                ):
                    non_year_numbers += 1

            if non_year_numbers >= 2:
                first_data_row = row_index

        column_count = len(anchors) + 1
        grid_row: List[Optional[str]] = [
            None for _ in range(column_count)
        ]

        row_label = ""

        if 0 in cell_words:
            row_label = normalize_space(
                " ".join(
                    word["text"]
                    for word in sorted(
                        cell_words[0],
                        key=lambda item: item["x0"],
                    )
                )
            )

        for column_index, words_in_cell in sorted(
            cell_words.items()
        ):
            raw_text = normalize_space(
                " ".join(
                    word["text"]
                    for word in sorted(
                        words_in_cell,
                        key=lambda item: item["x0"],
                    )
                )
            )

            if not raw_text:
                continue

            grid_row[column_index] = raw_text

            years = YEAR_PATTERN.findall(raw_text)

            # Column periods are header metadata.  Do not let a year printed
            # later in the body (for example a financing reconciliation row)
            # overwrite the 2025 header of the prior-period column.
            if (
                years
                and column_index > 0
                and (first_data_row is None or row_index < first_data_row)
            ):
                period_by_column[column_index] = years[-1]

            lowered = raw_text.lower()

            if (
                column_index > 0
                and (first_data_row is None or row_index < first_data_row)
            ):
                if "group" in lowered or "consolidated" in lowered:
                    scope_by_column[column_index] = "GROUP"
                elif "company" in lowered or "standalone" in lowered:
                    scope_by_column[column_index] = "COMPANY"

            if first_data_row is None or row_index < first_data_row:
                cell_role = "HEADER"
            elif column_index == 0:
                cell_role = "ROW_HEADER"
            else:
                cell_role = "DATA"

            numeric_value = parse_numeric(raw_text)

            table_cells.append({
                "tenant_id": tenant_id,
                "entity_id": entity_id,
                "assessment_run_id": assessment_run_id,
                "source_document_id": source_document_id,
                "document_checksum": checksum,
                "table_artifact_id": table_id,
                "table_id": table_id,
                "page_number": page_number,
                "table_number": region_number,
                "row_index": row_index,
                "column_index": column_index,
                "row_span": 1,
                "column_span": 1,
                "cell_role": cell_role,
                "row_label": row_label if row_index >= (
                    first_data_row or 0
                ) else "",
                "header_path": "",
                "column_scope": "",
                "period_label": "",
                "note_reference": "",
                "raw_text": raw_text,
                "normalized_text": raw_text,
                "numeric_value": numeric_value,
                "currency": "",
                "unit": "",
                "cell_bbox_json": json.dumps(
                    union_bbox(words_in_cell),
                    sort_keys=True,
                ),
                "extraction_confidence": 0.85,
                "extraction_method": "PYMUPDF_COORDINATE_CLUSTERING",
                "extractor_version": EXTRACTOR_VERSION,
            })

        grid_rows.append(grid_row)

    if first_data_row is None:
        return None, []

    for cell in table_cells:
        column_index = cell["column_index"]

        if column_index > 0:
            period = period_by_column.get(column_index, "")
            scope = scope_by_column.get(column_index, "")

            cell["period_label"] = period
            cell["column_scope"] = scope

            header_parts = [
                value
                for value in [scope, period]
                if value
            ]

            cell["header_path"] = " / ".join(header_parts)

    non_empty_count = len(table_cells)

    numeric_count = sum(
        1
        for cell in table_cells
        if cell["numeric_value"] is not None
    )

    numeric_ratio = (
        numeric_count / non_empty_count
        if non_empty_count else 0.0
    )

    region_text = " ".join(
        line["text"] for line in region
    )

    statement_type = classify_statement(region_text)

    # Repair two recurring, visually valid annual-report layouts after the
    # physical cells have been identified:
    #   * a long caption wraps immediately above its numeric row; and
    #   * balance-sheet section totals contain amounts but no repeated label.
    # The rules use only row adjacency and statement structure.  They are not
    # tied to an issuer or filename and therefore leave ordinary labelled rows
    # unchanged.
    cells_by_row: Dict[int, List[Dict[str, Any]]] = {}
    for cell in table_cells:
        cells_by_row.setdefault(cell["row_index"], []).append(cell)

    continuation_pattern = re.compile(
        r"^(?:net of tax|after (?:income )?tax|attributable to|"
        r"representing total|for the (?:financial )?year)\b",
        re.IGNORECASE,
    )
    for row_index in range(1, len(region)):
        current_cells = cells_by_row.get(row_index, [])
        previous_cells = cells_by_row.get(row_index - 1, [])
        current_label = next(
            (cell["row_label"] for cell in current_cells if cell["column_index"] == 0),
            "",
        )
        previous_label = next(
            (cell["raw_text"] for cell in previous_cells if cell["column_index"] == 0),
            "",
        )
        current_has_values = sum(
            cell["numeric_value"] is not None and cell["column_index"] > 0
            for cell in current_cells
        ) >= 2
        previous_has_values = any(
            cell["numeric_value"] is not None and cell["column_index"] > 0
            for cell in previous_cells
        )
        if (
            current_has_values
            and not previous_has_values
            and previous_label
            and current_label
            and continuation_pattern.search(current_label)
        ):
            repaired_label = normalize_space(previous_label + " " + current_label)
            for cell in current_cells:
                cell["row_label"] = repaired_label

    if statement_type == "BALANCE_SHEET":
        section_pattern = re.compile(
            r"^(current assets|non[- ]current assets|current liabilities|"
            r"non[- ]current liabilities)$",
            re.IGNORECASE,
        )
        active_section = ""
        section_data_rows = 0
        for row_index in range(len(region)):
            row_cells = cells_by_row.get(row_index, [])
            label = next(
                (cell["row_label"] for cell in row_cells if cell["column_index"] == 0),
                "",
            )
            value_count = sum(
                cell["numeric_value"] is not None and cell["column_index"] > 0
                for cell in row_cells
            )
            section_match = section_pattern.fullmatch(normalize_space(label))
            if section_match and value_count == 0:
                active_section = re.sub(r"[- ]+", " ", section_match.group(1)).lower()
                section_data_rows = 0
                continue
            if active_section and label and value_count:
                section_data_rows += 1
                continue
            if active_section and not label and value_count >= 2 and section_data_rows:
                repaired_label = "Total " + active_section
                for cell in row_cells:
                    cell["row_label"] = repaired_label
                active_section = ""
                section_data_rows = 0

    title_lines = []

    for line_index, line in enumerate(region):
        if line_index >= first_data_row:
            break

        if line["text"]:
            title_lines.append(line["text"])

    table_title = normalize_space(
        " ".join(title_lines[-4:])
    )

    bbox = {
        "x0": round(
            min(line["x0"] for line in region),
            3,
        ),
        "y0": round(
            min(line["y0"] for line in region),
            3,
        ),
        "x1": round(
            max(line["x1"] for line in region),
            3,
        ),
        "y1": round(
            max(line["y1"] for line in region),
            3,
        ),
    }

    periods = sorted(set(period_by_column.values()))
    scopes = sorted(set(scope_by_column.values()))

    header_tree = {
        str(column_index): {
            "scope": scope_by_column.get(column_index),
            "period": period_by_column.get(column_index),
        }
        for column_index in range(1, len(anchors) + 1)
    }

    confidence = 0.55

    if statement_type != "UNCLASSIFIED":
        confidence += 0.15

    if periods:
        confidence += 0.10

    if numeric_ratio >= 0.20:
        confidence += 0.10

    if scopes:
        confidence += 0.05

    confidence = min(confidence, 0.95)

    table_row = {
        "tenant_id": tenant_id,
        "entity_id": entity_id,
        "assessment_run_id": assessment_run_id,
        "source_document_id": source_document_id,
        "document_checksum": checksum,
        "table_artifact_id": table_id,
        "table_id": table_id,
        "page_number": page_number,
        "table_number": region_number,
        "table_title": table_title,
        "statement_type": statement_type,
        "table_bbox_json": json.dumps(
            bbox,
            sort_keys=True,
        ),
        "page_width": page_width,
        "page_height": page_height,
        "reporting_date": "",
        "presentation_currency": "",
        "presentation_unit": "",
        "row_count": len(grid_rows),
        "column_count": len(anchors) + 1,
        "non_empty_cell_count": non_empty_count,
        "numeric_cell_count": numeric_count,
        "numeric_cell_ratio": round(
            numeric_ratio,
            6,
        ),
        "period_labels_json": json.dumps(periods),
        "entity_scopes_json": json.dumps(scopes),
        "grid_json": json.dumps(
            grid_rows,
            ensure_ascii=False,
        ),
        "header_tree_json": json.dumps(
            header_tree,
            ensure_ascii=False,
            sort_keys=True,
        ),
        "merged_cells_json": "[]",
        "extraction_method": "PYMUPDF_COORDINATE_CLUSTERING",
        "model_name": "",
        "extractor_version": EXTRACTOR_VERSION,
        "extraction_confidence": confidence,
        "extraction_status": "EXTRACTED",
        "extracted_at": utc_now(),
    }

    for cell in table_cells:
        cell["extraction_confidence"] = confidence

    return table_row, table_cells


def extract_page(
    pdf_bytes: bytes,
    registration: Dict[str, Any],
    page_index: int,
    configuration: Dict[str, Any],
) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    document = fitz.open(
        stream=pdf_bytes,
        filetype="pdf",
    )

    try:
        page = document.load_page(page_index)

        words = page.get_text(
            "words",
            sort=True,
        )

        lines = group_words_into_lines(words)

        # Classify the complete page before it is split into table regions.
        # Annual-report headings are frequently placed outside the detected
        # numeric region, while the footer mentions the notes. Page-level
        # evidence therefore supplies the primary-statement type to fragments.
        page_text = " ".join(line.get("text", "") for line in lines)
        page_statement_type = classify_statement(page_text)

        if not page_is_candidate(
            lines,
            configuration["min_numeric_tokens"],
            configuration["min_numeric_rows"],
        ):
            return [], []

        regions = detect_regions(
            lines,
            configuration["row_gap"],
            configuration["min_numeric_rows"],
            configuration["context_lines"],
        )
        if page_statement_type in {
            "BALANCE_SHEET", "INCOME_STATEMENT", "CASH_FLOW_STATEMENT"
        }:
            regions = merge_primary_statement_fragments(
                regions, configuration["row_gap"]
            )

        table_rows = []
        cell_rows = []

        page_number = page_index + 1

        for region_number, region in enumerate(
            regions,
            start=1,
        ):
            table_row, extracted_cells = extract_region(
                registration=registration,
                page_number=page_number,
                page_width=float(page.rect.width),
                page_height=float(page.rect.height),
                region_number=region_number,
                region=region,
                configuration=configuration,
            )

            if table_row is None:
                continue

            if (
                page_statement_type in {
                    "BALANCE_SHEET", "INCOME_STATEMENT", "CASH_FLOW_STATEMENT"
                }
                and table_row.get("statement_type") in {"UNCLASSIFIED", "NOTES_TABLE", ""}
            ):
                table_row["statement_type"] = page_statement_type

            table_rows.append(table_row)
            cell_rows.extend(extracted_cells)

        return table_rows, cell_rows

    finally:
        document.close()


def select_valid_registrations(
    dataframe: pd.DataFrame,
) -> List[Dict[str, Any]]:
    """
    Select usable registrations.

    ALREADY_REGISTERED and duplicate_document=True are valid when the existing
    tenant, entity, assessment-run and source-document identifiers are present.
    """

    if dataframe.empty:
        raise RuntimeError(
            "FRI_UPLOAD_REGISTRATION_RESULTS contains no rows."
        )

    failure_statuses = {
        "FAILED",
        "FAILURE",
        "ERROR",
        "REJECTED",
        "INVALID",
        "CANCELLED",
    }

    selected_by_document: Dict[str, Dict[str, Any]] = {}
    rejected_rows = []

    for row_number, row in enumerate(
        dataframe.to_dict(orient="records")
    ):
        tenant_id = text_value(
            first_value(row, ["tenant_id"])
        )
        entity_id = text_value(
            first_value(row, ["entity_id"])
        )
        assessment_run_id = text_value(
            first_value(
                row,
                ["assessment_run_id", "run_id"],
            )
        )
        source_document_id = text_value(
            first_value(
                row,
                ["source_document_id", "document_id"],
            )
        )
        registered_path = text_value(
            first_value(row, ["registered_path"])
        )
        source_path = text_value(
            first_value(row, ["source_path"])
        )

        registration_status = text_value(
            first_value(row, ["registration_status"])
        ).upper()

        processing_status = text_value(
            first_value(row, ["processing_status"])
        ).upper()

        required_identifiers = {
            "tenant_id": tenant_id,
            "entity_id": entity_id,
            "assessment_run_id": assessment_run_id,
            "source_document_id": source_document_id,
        }

        missing_identifiers = [
            name
            for name, value in required_identifiers.items()
            if not value
        ]

        explicitly_failed = (
            registration_status in failure_statuses
            or processing_status in failure_statuses
        )

        if explicitly_failed:
            rejected_rows.append({
                "row_number": row_number,
                "file_name": text_value(
                    first_value(row, ["file_name"])
                ),
                "reason": "EXPLICIT_FAILURE",
                "registration_status": registration_status,
                "processing_status": processing_status,
            })
            continue

        if missing_identifiers:
            rejected_rows.append({
                "row_number": row_number,
                "file_name": text_value(
                    first_value(row, ["file_name"])
                ),
                "reason": "MISSING_IDENTIFIERS",
                "missing_identifiers": missing_identifiers,
            })
            continue

        if not registered_path and not source_path:
            rejected_rows.append({
                "row_number": row_number,
                "file_name": text_value(
                    first_value(row, ["file_name"])
                ),
                "reason": "MISSING_DOCUMENT_PATH",
            })
            continue

        # duplicate_document=True is intentionally not rejected.
        # The existing source_document_id is reused.
        selected_by_document[source_document_id] = row

    selected = list(selected_by_document.values())

    print(json.dumps({
        "registration_input_count": len(dataframe),
        "selected_document_count": len(selected),
        "rejected_document_count": len(rejected_rows),
        "selected_documents": [
            {
                "file_name": text_value(
                    first_value(row, ["file_name"])
                ),
                "source_document_id": text_value(
                    first_value(
                        row,
                        ["source_document_id", "document_id"],
                    )
                ),
                "registration_status": text_value(
                    first_value(row, ["registration_status"])
                ),
                "processing_status": text_value(
                    first_value(row, ["processing_status"])
                ),
                "duplicate_document": bool_value(
                    first_value(
                        row,
                        ["duplicate_document"],
                        False,
                    )
                ),
            }
            for row in selected
        ],
        "rejected_documents": rejected_rows,
    }, indent=2, default=str))

    return selected


def load_document_from_folder(
    source_folder,
    registration: Dict[str, Any],
) -> Tuple[str, bytes]:
    """Load an existing registration; duplicate uploads remain processable."""

    candidate_paths: List[str] = []
    for column_name in (
        "registered_path",
        "source_path",
        "folder_path",
    ):
        candidate = text_value(
            first_value(registration, [column_name])
        )
        if candidate and candidate not in candidate_paths:
            candidate_paths.append(candidate)

    if not candidate_paths:
        raise RuntimeError(
            "The registration contains no registered_path, source_path "
            "or folder_path."
        )

    attempts = []
    for candidate in candidate_paths:
        normalized_path = "/" + candidate.lstrip("/")
        try:
            with source_folder.get_download_stream(
                normalized_path
            ) as stream:
                document_bytes = stream.read()

            if not document_bytes:
                attempts.append({
                    "path": normalized_path,
                    "error": "EMPTY_FILE",
                })
                continue

            return normalized_path, document_bytes
        except Exception as error:
            attempts.append({
                "path": normalized_path,
                "error": f"{type(error).__name__}: {error}",
            })

    raise RuntimeError(
        "Unable to read the registered document from the configured "
        "managed folder. attempts="
        + json.dumps(attempts, default=str)
    )

configuration = load_configuration()

registrations_df = dataiku.Dataset(
    INPUT_REGISTRATIONS
).get_dataframe()

# Declared and read for Flow lineage. Candidate detection itself uses native PDF
# word coordinates because fragment text does not preserve cell positions.
fragments_df = dataiku.Dataset(
    INPUT_FRAGMENTS
).get_dataframe()

registrations = select_valid_registrations(registrations_df)

if not registrations:
    diagnostic_columns = [
        column
        for column in [
            "file_name",
            "source_path",
            "registered_path",
            "registration_status",
            "processing_status",
            "duplicate_document",
            "tenant_id",
            "entity_id",
            "assessment_run_id",
            "run_id",
            "source_document_id",
            "document_id",
            "message",
        ]
        if column in registrations_df.columns
    ]

    diagnostics = (
        registrations_df[diagnostic_columns]
        .fillna("")
        .head(20)
        .to_dict(orient="records")
    )

    raise RuntimeError(
        "No processable registered documents were found. "
        "Input rows="
        + str(len(registrations_df))
        + "; available columns="
        + json.dumps(list(registrations_df.columns))
        + "; details="
        + json.dumps(diagnostics, default=str)
    )

source_folder = dataiku.Folder(
    configuration["folder_id"]
)

all_table_rows: List[Dict[str, Any]] = []
all_cell_rows: List[Dict[str, Any]] = []
document_summaries = []
errors = []

for registration in registrations:
    source_document_id = text_value(
        first_value(
            registration,
            ["source_document_id", "document_id"],
        )
    )

    try:
        document_path, pdf_bytes = load_document_from_folder(
            source_folder,
            registration,
        )

        document = fitz.open(
            stream=pdf_bytes,
            filetype="pdf",
        )

        page_count = document.page_count
        document.close()

        document_table_rows = []
        document_cell_rows = []

        worker_count = min(
            configuration["workers"],
            page_count,
        )

        with ThreadPoolExecutor(
            max_workers=worker_count
        ) as executor:
            futures = {
                executor.submit(
                    extract_page,
                    pdf_bytes,
                    registration,
                    page_index,
                    configuration,
                ): page_index
                for page_index in range(page_count)
            }

            for future in as_completed(futures):
                page_index = futures[future]

                try:
                    page_tables, page_cells = future.result()
                    document_table_rows.extend(page_tables)
                    document_cell_rows.extend(page_cells)

                except Exception as page_error:
                    errors.append({
                        "source_document_id": source_document_id,
                        "page_number": page_index + 1,
                        "message": (
                            f"{type(page_error).__name__}: "
                            f"{page_error}"
                        ),
                    })

        document_table_rows.sort(
            key=lambda row: (
                row["page_number"],
                row["table_number"],
            )
        )

        document_cell_rows.sort(
            key=lambda row: (
                row["page_number"],
                row["table_number"],
                row["row_index"],
                row["column_index"],
            )
        )

        all_table_rows.extend(document_table_rows)
        all_cell_rows.extend(document_cell_rows)

        document_summaries.append({
            "source_document_id": source_document_id,
            "document_path": document_path,
            "page_count": page_count,
            "table_count": len(document_table_rows),
            "non_empty_cell_count": len(document_cell_rows),
        })

    except Exception as document_error:
        errors.append({
            "source_document_id": source_document_id,
            "page_number": None,
            "message": (
                f"{type(document_error).__name__}: "
                f"{document_error}"
            ),
        })


if not all_table_rows:
    raise RuntimeError(
        "No tables were extracted. Check the source managed-folder ID, "
        "document paths, PDF text availability and extraction settings. "
        f"Errors: {json.dumps(errors[:10], default=str)}"
    )


tables_output = pd.DataFrame(
    all_table_rows,
    columns=TABLE_COLUMNS,
)

cells_output = pd.DataFrame(
    all_cell_rows,
    columns=CELL_COLUMNS,
)

dataiku.Dataset(
    OUTPUT_TABLES
).write_with_schema(tables_output)

dataiku.Dataset(
    OUTPUT_CELLS
).write_with_schema(cells_output)

print(json.dumps({
    "extractor_version": EXTRACTOR_VERSION,
    "registered_document_count": len(registrations),
    "fragment_row_count": len(fragments_df),
    "table_count": len(tables_output),
    "non_empty_cell_count": len(cells_output),
    "error_count": len(errors),
    "documents": document_summaries,
    "errors": errors[:20],
}, indent=2, default=str))
