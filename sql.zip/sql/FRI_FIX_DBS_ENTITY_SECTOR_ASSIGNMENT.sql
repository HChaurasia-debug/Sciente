-- DBS is a regulated banking entity. Restore its governed banking profile so
-- the financial-institution template and BANK aliases are used instead of the
-- manufacturing fallback. The entity UUID is taken from the DBS FY2025 run.

BEGIN;

WITH updated AS (
    UPDATE financial_risk_intelligence.entity_sector_assignments
       SET sector_key = 'banking',
           valid_to = NULL,
           source = 'MANUAL',
           confidence = 1.000000,
           active = true
     WHERE entity_id = '206afb8d-f70e-4930-84fe-b262aeecd7a7'
       AND active = true
       AND (valid_to IS NULL OR valid_to >= CURRENT_DATE)
    RETURNING entity_id
)
INSERT INTO financial_risk_intelligence.entity_sector_assignments
    (entity_id, sector_key, valid_from, valid_to, source, confidence, active)
SELECT
    '206afb8d-f70e-4930-84fe-b262aeecd7a7',
    'banking',
    CURRENT_DATE,
    NULL,
    'MANUAL',
    1.000000,
    true
WHERE NOT EXISTS (SELECT 1 FROM updated)
ON CONFLICT (entity_id, valid_from) DO UPDATE
SET sector_key = EXCLUDED.sector_key,
    valid_to = NULL,
    source = 'MANUAL',
    confidence = 1.000000,
    active = true;

COMMIT;

-- Expected: one active MANUAL banking assignment.
SELECT entity_id, sector_key, valid_from, valid_to, source, confidence, active
FROM financial_risk_intelligence.entity_sector_assignments
WHERE entity_id = '206afb8d-f70e-4930-84fe-b262aeecd7a7'
ORDER BY valid_from DESC;
