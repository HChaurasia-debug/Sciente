"""Lossless JSON representation for extracted financial tables."""
from __future__ import annotations

import hashlib
import json
import math
from collections import Counter, defaultdict
from datetime import date, datetime
from decimal import Decimal
from typing import Any, Dict, Iterable, List, Tuple


SCHEMA_VERSION = "fsre.financial-table.v1"


def _missing(value: Any) -> bool:
    if value is None:
        return True
    try:
        return bool(math.isnan(value))
    except (TypeError, ValueError):
        return False


def _json_value(value: Any) -> Any:
    if _missing(value):
        return None
    if isinstance(value, Decimal):
        return str(value)
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if hasattr(value, "item"):
        try:
            return _json_value(value.item())
        except (TypeError, ValueError):
            pass
    return value


def _text(value: Any) -> str:
    value = _json_value(value)
    return "" if value is None else str(value).strip()


def _integer(value: Any, default: int = -1) -> int:
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return default


def _canonical_cell(cell: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "cell_id": _text(cell.get("cell_id")),
        "row_index": _integer(cell.get("row_index")),
        "column_index": _integer(cell.get("column_index")),
        "row_span": max(1, _integer(cell.get("row_span"), 1)),
        "column_span": max(1, _integer(cell.get("column_span"), 1)),
        "role": _text(cell.get("cell_role")).upper() or "DATA",
        "raw_text": _text(cell.get("raw_text")),
        "normalized_text": _text(cell.get("normalized_text")),
        "numeric_value": _json_value(cell.get("numeric_value")),
        "row_label": _text(cell.get("row_label")),
        "header_path": _text(cell.get("header_path")),
        "note_reference": _text(cell.get("note_reference")),
        "period_label": _text(cell.get("period_label")),
        "entity_scope": _text(
            cell.get("entity_scope") or cell.get("column_scope")
        ).upper(),
        "currency": _text(cell.get("currency")),
        "unit": _text(cell.get("unit")),
        "bbox": _parse_json(cell.get("cell_bbox_json"), {}),
        "confidence": _json_value(cell.get("extraction_confidence")),
    }


def _parse_json(value: Any, default: Any) -> Any:
    if isinstance(value, (dict, list)):
        return value
    raw = _text(value)
    if not raw:
        return default
    try:
        return json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        return default


def build_table_document(
    artifact: Dict[str, Any], cells: Iterable[Dict[str, Any]]
) -> Tuple[Dict[str, Any], List[Dict[str, str]]]:
    """Build a deterministic lossless document and return validation issues."""
    canonical = sorted(
        (_canonical_cell(cell) for cell in cells),
        key=lambda cell: (cell["row_index"], cell["column_index"]),
    )
    issues: List[Dict[str, str]] = []
    coordinates = [(c["row_index"], c["column_index"]) for c in canonical]
    for coordinate, count in Counter(coordinates).items():
        if count > 1:
            issues.append({
                "code": "DUPLICATE_CELL_COORDINATE",
                "severity": "ERROR",
                "message": f"Coordinate {coordinate} occurs {count} times",
            })
    if any(row < 0 or column < 0 for row, column in coordinates):
        issues.append({
            "code": "INVALID_CELL_COORDINATE", "severity": "ERROR",
            "message": "One or more cells have a negative/missing coordinate",
        })

    column_context: Dict[int, set] = defaultdict(set)
    for cell in canonical:
        if cell["numeric_value"] is not None:
            column_context[cell["column_index"]].add(
                (cell["period_label"], cell["entity_scope"])
            )
    for column, contexts in sorted(column_context.items()):
        populated = {(p, s) for p, s in contexts if p or s}
        if len(populated) > 1:
            issues.append({
                "code": "AMBIGUOUS_COLUMN_CONTEXT", "severity": "ERROR",
                "message": f"Column {column} has multiple period/scope contexts: {sorted(populated)}",
            })

    rows: Dict[int, List[Dict[str, Any]]] = defaultdict(list)
    for cell in canonical:
        rows[cell["row_index"]].append(cell)

    document = {
        "schema_version": SCHEMA_VERSION,
        "identity": {
            "tenant_id": _text(artifact.get("tenant_id")),
            "entity_id": _text(artifact.get("entity_id")),
            "assessment_run_id": _text(artifact.get("assessment_run_id")),
            "source_document_id": _text(artifact.get("source_document_id")),
            "table_artifact_id": _text(
                artifact.get("table_artifact_id") or artifact.get("source_table_id")
            ),
            "source_table_id": _text(artifact.get("source_table_id")),
        },
        "source": {
            "page_number": _json_value(artifact.get("page_number")),
            "page_image_path": _text(artifact.get("page_image_path")),
            "table_bbox": _parse_json(artifact.get("table_bbox_json"), {}),
            "extraction_method": _text(artifact.get("extraction_method")),
            "model_name": _text(artifact.get("model_name")),
        },
        "table": {
            "title": _text(artifact.get("table_title")),
            "statement_type": _text(artifact.get("statement_type")).upper(),
            "currency": _text(artifact.get("presentation_currency")),
            "unit": _text(artifact.get("presentation_unit")),
            "row_count": _integer(artifact.get("row_count"), len(rows)),
            "column_count": _integer(artifact.get("column_count"), 0),
            "header_tree": _parse_json(artifact.get("header_tree_json"), {}),
            "merged_cells": _parse_json(artifact.get("merged_cells_json"), []),
            "rows": [
                {"row_index": index, "cells": rows[index]}
                for index in sorted(rows)
            ],
            "cells": canonical,
        },
        "validation": {
            "status": "INVALID" if any(i["severity"] == "ERROR" for i in issues) else "VALID",
            "issues": issues,
        },
    }
    fingerprint_input = json.dumps(document, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    document["integrity"] = {
        "algorithm": "sha256",
        "fingerprint": hashlib.sha256(fingerprint_input.encode("utf-8")).hexdigest(),
        "cell_count": len(canonical),
    }
    return document, issues


def dumps(document: Dict[str, Any]) -> str:
    return json.dumps(document, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
