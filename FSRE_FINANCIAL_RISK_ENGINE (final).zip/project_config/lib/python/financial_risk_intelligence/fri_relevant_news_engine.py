"""
Financial News Q&A Engine (v3) -- broad corpus + local finance sentiment
==========================================================================
Fixes the core problem with v2: Marketaux's free tier returns very few
articles per query, so there often isn't enough data to find genuinely
negative (or positive) news -- v2 was padding results with the "least
positive" articles, which is misleading.

v3 instead:
  1. Pulls a broader pool of articles from Marketaux using pagination and
      expanded sector queries for the requested company/sector.
  2. Scores each article's sentiment LOCALLY using a finance-specific
     keyword lexicon (no dependency on a third-party sentiment API's
     free-tier generosity).
  3. STRICTLY filters to only genuinely negative (or positive) articles.
     If fewer than requested exist, it says so honestly -- it never
     mislabels a positive article as "negative" just to fill a slot.

Usage
-----
    export MARKETAUX_API_KEY="your_key_here"
    python financial_news_engine_v3.py

    python financial_news_engine_v3.py --question \
        "top 5 negative news on Infosys"

    from financial_news_engine_v3 import answer_question
    print(answer_question("top 5 negative news on Infosys"))
"""

import os
import re
import sys
import time
import argparse
import hashlib
import requests


MARKETAUX_BASE_URL = "https://api.marketaux.com/v1/news/all"
NEWSDATA_BASE_URL = "https://newsdata.io/api/1/latest"
DEFAULT_API_KEY = ""


STOPWORDS = {
    "give", "me", "the", "on", "about", "for", "please", "show", "provide",
    "an", "a", "any", "news", "financial", "finance", "update", "updates",
    "recent", "latest", "today", "this", "week", "month", "company",
    "companies", "stock", "stocks", "share", "shares",
    "what", "whats", "is", "are", "happening", "with", "and", "of", "in",
    "to", "can", "you", "get", "find", "tell", "how", "i", "am", "need",
    "invest", "investing", "investor", "so", "that", "has", "have", "impact",
    "impacting", "impacts", "topics", "topic", "group", "top", "items",
    "list", "affecting", "affects", "affect",
}

NEGATIVE_SIGNALS = {"negative", "bad", "risk", "risks", "concern", "concerns",
                     "decline", "declining", "downside", "bearish", "trouble",
                     "troubles", "worst", "worrying", "loss", "losses", "drop"}
POSITIVE_SIGNALS = {"positive", "good", "bullish", "gains", "gain", "growth",
                     "best", "upside", "opportunity", "opportunities"}

TOP_N_RE = re.compile(r"\btop\s+(\d+)\b", re.IGNORECASE)

QUERY_EXPANSIONS = {
    "ev": "electric vehicle",
    "evs": "electric vehicles",
    "ai": "artificial intelligence",
}

# --------------------------------------------------------------------------
# Finance-specific sentiment lexicon (local scoring -- no API dependency)
# --------------------------------------------------------------------------
NEG_WORDS = {
    "fraud", "scam", "lawsuit", "sue", "sued", "suing", "probe", "investigation",
    "investigated", "decline", "declines", "declined", "plunge", "plunges",
    "plunged", "crash", "crashes", "crashed", "loss", "losses", "downgrade",
    "downgraded", "layoff", "layoffs", "resign", "resigns", "resignation",
    "scandal", "penalty", "penalties", "fine", "fined", "strike", "strikes",
    "recall", "recalled", "delay", "delayed", "delays", "cut", "cuts",
    "cutting", "slump", "slumps", "drop", "drops", "fell", "falls", "falling",
    "weak", "weakness", "concern", "concerns", "risk", "risks", "warning",
    "warns", "warned", "bankruptcy", "insolvency", "default", "debt",
    "restructuring", "controversy", "backlash", "boycott", "hack", "hacked",
    "breach", "cyberattack", "outage", "disruption", "miss", "misses",
    "missed", "shortfall", "underperform", "underperforms", "slowdown",
    "slashed", "slashes", "raid", "raided", "arrest", "arrested", "ban",
    "banned", "fired", "sacked", "protest", "protests", "strikes", "exit",
    "exits", "quits", "quit", "collapse", "collapsed", "tumbles", "tumbled",
    "plummet", "plummets", "plummeted", "probe", "scrutiny", "penalize",
}

POS_WORDS = {
    "growth", "grows", "grew", "profit", "profits", "profitable", "gain",
    "gains", "surge", "surges", "surged", "rally", "rallies", "rallied",
    "beat", "beats", "upgrade", "upgraded", "expansion", "expand", "expands",
    "partnership", "deal", "wins", "win", "won", "award", "awarded",
    "record", "strong", "robust", "boost", "boosts", "boosted", "positive",
    "optimistic", "breakthrough", "launch", "launches", "launched",
    "innovation", "milestone", "outperform", "outperforms", "rebound",
    "rebounds", "recovery", "recovers", "jump", "jumps", "jumped", "soar",
    "soars", "soared", "raise", "raised", "raises", "acquire", "acquires",
    "acquisition", "merger", "expand", "profitability",
}

IMPACT_SIGNALS = {
    "cash flow": {
        "loss", "losses", "debt", "default", "bankruptcy", "insolvency",
        "layoff", "layoffs", "fine", "fined", "penalty", "penalties",
        "delay", "delayed", "delays", "shortfall", "miss", "missed",
    },
    "business": {
        "lawsuit", "probe", "investigation", "scandal", "recall", "strike",
        "strikes", "breach", "cyberattack", "outage", "disruption", "ban",
        "banned", "boycott", "backlash", "slowdown", "expansion", "launch",
        "partnership", "acquisition", "merger",
    },
    "financial": {
        "decline", "declined", "plunge", "plunged", "downgrade", "downgraded",
        "slump", "drop", "fell", "weak", "warning", "underperform", "debt",
        "default", "profit", "profits", "growth", "gain", "gains", "upgrade",
        "upgraded", "strong", "record", "outperform",
    },
}


# --------------------------------------------------------------------------
# Step 1: interpret the question
# --------------------------------------------------------------------------
def interpret_question(question: str) -> dict:
    lower = question.lower()

    direction = None
    if any(w in lower for w in NEGATIVE_SIGNALS):
        direction = "negative"
    elif any(w in lower for w in POSITIVE_SIGNALS):
        direction = "positive"

    m = TOP_N_RE.search(lower)
    top_n = int(m.group(1)) if m else (5 if direction else 8)

    cleaned = re.sub(r"[^a-zA-Z0-9\s]", " ", lower)
    words = cleaned.split()
    keep = [w for w in words
            if w not in STOPWORDS
            and w not in NEGATIVE_SIGNALS
            and w not in POSITIVE_SIGNALS
            and not w.isdigit()]
    seen = set()
    deduped = []
    for w in keep:
        if w not in seen:
            seen.add(w)
            deduped.append(w)
    subject = " ".join(deduped).strip() or question.strip()

    return {"subject": subject, "direction": direction, "top_n": top_n}


# --------------------------------------------------------------------------
# Step 2: fetch a broad pool of articles from Marketaux (paginated)
# --------------------------------------------------------------------------
def fetch_marketaux_pool(subject: str, api_key: str, max_pages: int = 5,
                         language: str = "en") -> list:
    """Pull several Marketaux result pages to build a sentiment-scoring pool."""
    articles = []

    for page in range(1, max_pages + 1):
        params = {
            "api_token": api_key,
            "search": subject,
            "language": language,
            "limit": 100,
            "page": page,
            "sort": "published_desc",
        }

        print(
            f"[relevant-news-engine] Marketaux request search={subject!r} "
            f"page={page}/{max_pages} language={language!r} limit=100",
            flush=True,
        )
        resp = requests.get(MARKETAUX_BASE_URL, params=params, timeout=20)
        if not resp.ok:
            try:
                provider_error = resp.json().get("error") or resp.json().get("message")
            except (ValueError, AttributeError):
                provider_error = resp.text[:300]
            raise RuntimeError(
                f"Marketaux HTTP {resp.status_code}: {provider_error or resp.reason}"
            )
        data = resp.json()

        if "error" in data:
            raise RuntimeError(f"Marketaux error: {data['error']}")

        batch = data.get("data", []) or []
        print(
            f"[relevant-news-engine] Marketaux response status={resp.status_code} "
            f"page={page} article_count={len(batch)}",
            flush=True,
        )
        articles.extend(batch)

        if not batch or len(batch) < 100:
            break
        time.sleep(0.3)

    return articles


def fetch_query_pool(subject: str, api_key: str, max_pages: int = 5,
                     language: str = "en") -> list:
    """Fetch the original subject plus a useful expanded search variant."""
    queries = [subject]
    expanded = " ".join(QUERY_EXPANSIONS.get(word, word) for word in subject.split())
    if expanded != subject:
        queries.append(expanded)

    articles = []
    seen_urls = set()
    for query in queries:
        for article in fetch_marketaux_pool(query, api_key, max_pages=max_pages,
                                            language=language):
            identity = article.get("url") or article.get("uuid") or article.get("title")
            if identity and identity in seen_urls:
                continue
            if identity:
                seen_urls.add(identity)
            articles.append(article)
    return articles


def fetch_newsdata_pool(subject: str, api_key: str, max_pages: int = 3,
                        language: str = "en") -> list:
    """Fetch NewsData.io pages and normalize them to the Marketaux-shaped contract."""
    articles = []
    next_page = None
    for page_number in range(1, max_pages + 1):
        params = {"apikey": api_key, "q": subject, "language": language}
        if next_page:
            params["page"] = next_page
        print(
            f"[relevant-news-engine] NewsData request q={subject!r} "
            f"page={page_number}/{max_pages} language={language!r}", flush=True,
        )
        response = requests.get(NEWSDATA_BASE_URL, params=params, timeout=20)
        try:
            payload = response.json()
        except ValueError:
            payload = {}
        if not response.ok or str(payload.get("status", "success")).lower() == "error":
            message = payload.get("results") or payload.get("message") or response.text[:300]
            raise RuntimeError(f"NewsData HTTP {response.status_code}: {message}")
        batch = payload.get("results") or []
        print(
            f"[relevant-news-engine] NewsData response status={response.status_code} "
            f"page={page_number} article_count={len(batch)}", flush=True,
        )
        for item in batch:
            source = item.get("source_name") or item.get("source_id") or ""
            articles.append({
                "uuid": item.get("article_id") or item.get("link"),
                "title": item.get("title") or "",
                "description": item.get("description") or item.get("content") or "",
                "published_at": item.get("pubDate") or item.get("pubDateTZ") or "",
                "url": item.get("link") or item.get("source_url") or "",
                "source": source,
            })
        next_page = payload.get("nextPage")
        if not batch or not next_page:
            break
        time.sleep(0.3)
    return articles


def fetch_newsdata_query_pool(subject: str, api_key: str, max_pages: int = 3,
                              language: str = "en") -> tuple:
    """Try controlled legal-name variants and deduplicate provider results."""
    normalized = re.sub(r"[_\s]+", " ", subject).strip()
    stripped = re.sub(
        r"\s+(limited|ltd\.?|corporation|corp\.?|plc|pte\.?\s+ltd\.?|llc|inc\.?)$",
        "", normalized, flags=re.IGNORECASE,
    ).strip()
    queries = [normalized]
    # Very short abbreviations create unrelated market noise, so only broaden
    # when the remaining company name is sufficiently distinctive.
    if stripped.lower() != normalized.lower() and len(stripped) >= 4:
        queries.append(stripped)
    articles, seen = [], set()
    for query in queries:
        for article in fetch_newsdata_pool(query, api_key, max_pages=max_pages,
                                           language=language):
            identity = article.get("url") or article.get("uuid") or article.get("title")
            if identity and identity in seen:
                continue
            if identity:
                seen.add(identity)
            articles.append(article)
    return articles, queries


# --------------------------------------------------------------------------
# Step 3: local finance-sentiment scoring
# --------------------------------------------------------------------------
def score_article(article: dict) -> int:
    """Score = (positive keyword hits) - (negative keyword hits) across
    title + description. Negative number => negative article."""
    text = f"{article.get('title', '')} {article.get('description', '')}".lower()
    words = re.findall(r"[a-z]+", text)
    neg = sum(1 for w in words if w in NEG_WORDS)
    pos = sum(1 for w in words if w in POS_WORDS)
    return pos - neg


def analyze_impacts(article: dict) -> dict:
    """Describe potential impacts using only words found in title/summary."""
    text = f"{article.get('title', '')} {article.get('description', '')}".lower()
    words = set(re.findall(r"[a-z]+", text))
    score = score_article(article)
    impacts = {}

    for category, signals in IMPACT_SIGNALS.items():
        matches = sorted(signals.intersection(words))
        if not matches:
            continue

        evidence = ", ".join(matches[:3])
        if score < 0:
            impacts[category] = (
                f"Potential negative {category} pressure suggested by {evidence}."
            )
        elif score > 0:
            impacts[category] = (
                f"Potential positive {category} effect suggested by {evidence}."
            )
        else:
            impacts[category] = (
                f"Potential {category} relevance suggested by {evidence}; direction is unclear."
            )

    return impacts


def rank_articles(articles: list, direction: str, top_n: int) -> tuple:
    """Returns (results, total_pool_size). Strictly filters to genuinely
    negative/positive articles -- never pads with off-direction articles."""
    scored = [(score_article(a), a) for a in articles]

    if direction == "negative":
        strict = [(s, a) for s, a in scored if s < 0]
        strict.sort(key=lambda x: x[0])            # most negative first
        return strict[:top_n], len(articles)
    elif direction == "positive":
        strict = [(s, a) for s, a in scored if s > 0]
        strict.sort(key=lambda x: x[0], reverse=True)
        return strict[:top_n], len(articles)
    else:
        scored.sort(key=lambda x: x[1].get("pubDate", ""), reverse=True)
        return scored[:top_n], len(articles)


def article_identity(article: dict) -> str:
    """Return a stable, provider-independent identity for database upserts."""
    identity = (article.get("url") or article.get("uuid") or
                f"{article.get('title', '')}|{article.get('published_at', article.get('pubDate', ''))}")
    return hashlib.sha256(str(identity).strip().lower().encode("utf-8")).hexdigest()


def structured_results(question: str, api_key: str = None,
                       max_pages: int = 1, provider: str = "marketaux") -> dict:
    """Return UI/database-ready news without generating display Markdown.

    Only articles matching the requested sentiment direction are returned.
    Consumers can safely upsert ``article_key`` and keep older rows when the
    provider returns no fresh articles.
    """
    api_key = api_key or os.environ.get("MARKETAUX_API_KEY") or DEFAULT_API_KEY
    if not api_key:
        raise ValueError("MARKETAUX_API_KEY is not configured")
    parsed = interpret_question(question)
    selected_provider = str(provider or "marketaux").strip().lower()
    query_attempts = [parsed["subject"]]
    if selected_provider == "newsdata":
        pool, query_attempts = fetch_newsdata_query_pool(
            parsed["subject"], api_key, max_pages=max_pages,
        )
    elif selected_provider == "marketaux":
        pool = fetch_query_pool(parsed["subject"], api_key, max_pages=max_pages)
    else:
        raise ValueError("provider must be 'newsdata' or 'marketaux'")
    ranked, pool_size = rank_articles(pool, parsed["direction"], parsed["top_n"])
    articles = []
    for score, article in ranked:
        source = article.get("source") or ""
        if isinstance(source, dict):
            source = source.get("name") or source.get("domain") or ""
        articles.append({
            "article_key": article_identity(article),
            "provider_id": str(article.get("uuid") or ""),
            "headline": str(article.get("title") or "Untitled article").strip(),
            "summary": str(article.get("description") or "").strip(),
            "published_at": str(article.get("published_at") or article.get("pubDate") or ""),
            "url": str(article.get("url") or "").strip(),
            "source_name": str(source).strip(),
            "sentiment_score": score,
            "risk_impact": "high" if score <= -3 else "medium" if score < 0 else "low",
            "impacts": analyze_impacts(article),
        })
    return {"query": parsed, "query_attempts": query_attempts,
            "pool_size": pool_size, "articles": articles,
            "provider": selected_provider}


def generate_relevant_news(company_name: str, api_key: str = None,
                           top_n: int = 5, max_pages: int = 3,
                           direction: str = "negative",
                           provider: str = "marketaux") -> dict:
    """Production entry point used by the FSRE assessment pipeline.

    The company name must already be resolved from the governed annual-report
    context. This function creates the exact Marketaux question, executes the
    existing local financial-sentiment pipeline, and returns structured rows
    suitable for PostgreSQL persistence and UI rendering.
    """
    company = re.sub(r"[_\s]+", " ", str(company_name or "")).strip()
    if not company:
        raise ValueError("company_name is required")
    requested = max(1, min(20, int(top_n)))
    pages = max(1, min(5, int(max_pages)))
    sentiment = str(direction or "negative").strip().lower()
    if sentiment not in {"negative", "positive"}:
        raise ValueError("direction must be 'negative' or 'positive'")
    question = f"top {requested} {sentiment} news on {company}"
    print(
        f"[relevant-news-engine] company={company!r} generated_question={question!r} "
        f"max_pages={pages}",
        flush=True,
    )
    result = structured_results(
        question, api_key=api_key, max_pages=pages, provider=provider,
    )
    result.update({
        "company": company,
        "market_query": question,
        "requested_count": requested,
        "max_pages": pages,
        "direction": sentiment,
        "provider": str(provider).lower(),
    })
    print(
        f"[relevant-news-engine] pool_size={result.get('pool_size', 0)} "
        f"matching_count={len(result.get('articles') or [])} direction={sentiment}",
        flush=True,
    )
    return result


# --------------------------------------------------------------------------
# Step 4: format
# --------------------------------------------------------------------------
def format_results(results: list, pool_size: int, subject: str, direction: str,
                    requested_n: int) -> str:
    if not results:
        qualifier = f" {direction}" if direction else ""
        return (f"No genuinely{qualifier} news articles were found for "
                f"'{subject}' in a pool of {pool_size} recent articles. "
                f"Try a broader subject, or note that current coverage for "
                f"this company/sector may simply be neutral-to-positive "
                f"right now.")

    label = {"negative": "Negative-impact news", "positive": "Positive-impact news",
              None: "News"}[direction]
    lines = [f"### {label} for: {subject}\n"]

    if direction and len(results) < requested_n:
        lines.append(
            f"_Found only {len(results)} genuinely {direction} article(s) "
            f"out of {pool_size} searched -- showing all of them rather "
            f"than padding with unrelated-sentiment articles._\n"
        )

    for i, (score, art) in enumerate(results, start=1):
        title = art.get("title", "(no title)")
        desc = (art.get("description") or "").strip()
        published_date = art.get("published_at", art.get("pubDate", "Unknown date"))
        if len(desc) > 220:
            desc = desc[:220].rstrip() + "..."

        impacts = analyze_impacts(art)
        lines.append(f"### Article {i}")
        lines.append("")
        lines.append("**Article Title**")
        lines.append(title)
        lines.append("")
        lines.append("**Summary details**")
        if desc:
            lines.append(desc)
        else:
            lines.append("No summary available.")
        lines.append("")
        lines.append("**Published date**")
        lines.append(str(published_date))
        if impacts:
            lines.append("")
            lines.append("**Impact analysis**")
            lines.append("")
        impact_labels = {
            "cash flow": "Cash-flow impact",
            "business": "Business impact",
            "financial": "Financial impact",
        }
        for category, impact in impacts.items():
            lines.append(f"**{impact_labels[category]}**")
            lines.append(impact)
            lines.append("")
        lines.append("")

    return "\n".join(lines)


# --------------------------------------------------------------------------
# Orchestration
# --------------------------------------------------------------------------
def answer_question(question: str, api_key: str = None, max_pages: int = 5) -> str:
    api_key = api_key or os.environ.get("MARKETAUX_API_KEY") or DEFAULT_API_KEY
    if not api_key:
        raise ValueError(
            "No API key provided. Set MARKETAUX_API_KEY env var or pass api_key=."
        )

    parsed = interpret_question(question)
    print(f"[info] Interpreted question as: {parsed}", flush=True)

    try:
        pool = fetch_query_pool(parsed["subject"], api_key, max_pages=max_pages)
    except (requests.HTTPError, RuntimeError) as e:
        return f"Request to Marketaux failed: {e}"

    print(f"[info] Fetched a pool of {len(pool)} articles to score.", flush=True)

    results, pool_size = rank_articles(pool, parsed["direction"], parsed["top_n"])
    return format_results(results, pool_size, parsed["subject"], parsed["direction"],
                           parsed["top_n"])


# --------------------------------------------------------------------------
# CLI
# --------------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(description="Ask sentiment-aware financial news questions")
    parser.add_argument("--question", type=str)
    parser.add_argument("--api-key", type=str, default=None)
    parser.add_argument("--max-pages", type=int, default=5,
                         help="How many Marketaux result pages to pull")
    # Dataiku can execute project-library source inside its webapp process and
    # supply DSS-specific command arguments. Never terminate or start the
    # interactive CLI when such arguments are present.
    args, unknown = parser.parse_known_args()
    if unknown:
        return

    api_key = args.api_key or os.environ.get("MARKETAUX_API_KEY") or DEFAULT_API_KEY
    if not api_key:
        sys.exit("No API key found. Set MARKETAUX_API_KEY env var or pass --api-key.")

    if args.question:
        print(answer_question(args.question, api_key=api_key, max_pages=args.max_pages))
        return

    print("Financial News Q&A (local sentiment) -- type a question (or 'exit')")
    while True:
        try:
            question = input("\n> ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if not question or question.lower() in ("exit", "quit"):
            break
        print("\n" + answer_question(question, api_key=api_key, max_pages=args.max_pages))


# Do not invoke ``main`` automatically. Dataiku may execute project-library
# source in the webapp interpreter where ``__name__`` can be ``__main__``;
# calling argparse there would parse DSS backend arguments and raise
# SystemExit. For command-line diagnostics call ``main()`` explicitly from a
# small wrapper script instead.
