"""Placeholder for FRI_18_PUBLISH_EVIDENCE."""
raise NotImplementedError("Install the implementation for FRI_18_PUBLISH_EVIDENCE")
