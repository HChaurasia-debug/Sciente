"""Dataiku Scenario Python step: upload-to-manifest orchestration.

Run order:
1. Rebuild upload registration.
2. Validate generated tenant/entity/run/document identifiers.
3. Rebuild page fragments.
4. Rebuild the required-field manifest.

This prevents downstream recipes from reading stale failed outputs.
"""

from __future__ import annotations

import json
from typing import Dict, List

import dataiku
import pandas as pd
from dataiku.scenario import Scenario


REGISTRATION_DATASET = "FRI_UPLOAD_REGISTRATION_RESULTS"
FRAGMENTS_DATASET = "FRI_DOCUMENT_FRAGMENTS"
MANIFEST_DATASET = "FRI_REQUIRED_FIELD_MANIFEST"

PIPELINE_OUTPUTS = [
    "FRI_UPLOAD_REGISTRATION_RESULTS",
    "FRI_DOCUMENT_FRAGMENTS",
    "FRI_ENTITY_SECTOR_CLASSIFICATION_EVIDENCE",
    "FRI_REQUIRED_FIELD_MANIFEST",
    "FRI_EXTRACTED_TABLES",
    "FRI_VALIDATED_TABLE_ARTIFACTS",
    "FRI_FINANCIAL_TABLE_JSON",
    "FRI_STANDARDIZED_STATEMENT_VALUES",
    "FRI_BALANCE_SHEET_INPUTS",
    "FRI_INCOME_STATEMENT_INPUTS",
    "FRI_RESOLVED_FINANCIAL_FACTS",
    "FRI_SECTOR_TEMPLATE_VALUES",
    "FRI_SECTOR_FORENSIC_SCORES",
]

REQUIRED_REGISTRATION_IDS = [
    "tenant_id",
    "entity_id",
    "assessment_run_id",
    "source_document_id",
]


def safe_non_empty(series: pd.Series) -> pd.Series:
    return series.fillna("").astype(str).str.strip().ne("")


def validate_registration() -> pd.DataFrame:
    frame = dataiku.Dataset(REGISTRATION_DATASET).get_dataframe()
    required_columns = {
        "registration_status",
        "message",
        *REQUIRED_REGISTRATION_IDS,
    }
    missing = sorted(required_columns - set(frame.columns))
    if missing:
        raise RuntimeError(
            f"{REGISTRATION_DATASET} is missing columns: {', '.join(missing)}"
        )

    valid = (
        frame["registration_status"]
        .fillna("")
        .astype(str)
        .str.strip()
        .str.upper()
        .eq("SUCCESS")
    )
    for column in REQUIRED_REGISTRATION_IDS:
        valid = valid & safe_non_empty(frame[column])

    valid_frame = frame[valid].copy()
    if valid_frame.empty:
        failures: List[Dict[str, str]] = []
        for _, row in frame.iterrows():
            failures.append({
                "source_path": str(row.get("source_path", "")),
                "registration_status": str(row.get("registration_status", "")),
                "message": str(row.get("message", "")),
            })
        raise RuntimeError(
            "Upload registration produced no valid documents. Details: "
            + json.dumps(failures, ensure_ascii=False)
        )
    return valid_frame


def validate_fragments(valid_registration: pd.DataFrame) -> pd.DataFrame:
    frame = dataiku.Dataset(FRAGMENTS_DATASET).get_dataframe()
    required = {"source_document_id", "extraction_status"}
    missing = sorted(required - set(frame.columns))
    if missing:
        raise RuntimeError(
            f"{FRAGMENTS_DATASET} is missing columns: {', '.join(missing)}"
        )

    expected_ids = set(
        valid_registration["source_document_id"].dropna().astype(str)
    )
    extracted_ids = set(frame["source_document_id"].dropna().astype(str))
    missing_ids = sorted(expected_ids - extracted_ids)
    if missing_ids:
        raise RuntimeError(
            "Page extraction did not produce fragments for source documents: "
            + ", ".join(missing_ids)
        )
    return frame


def validate_manifest(valid_registration: pd.DataFrame) -> pd.DataFrame:
    frame = dataiku.Dataset(MANIFEST_DATASET).get_dataframe()
    required = {
        "source_document_id",
        "assessment_run_id",
        "configuration_set_id",
        "concept_key",
        "period_key",
    }
    missing = sorted(required - set(frame.columns))
    if missing:
        raise RuntimeError(
            f"{MANIFEST_DATASET} is missing columns: {', '.join(missing)}"
        )
    if frame.empty:
        raise RuntimeError("Required-field manifest is empty")

    expected_ids = set(
        valid_registration["source_document_id"].dropna().astype(str)
    )
    manifest_ids = set(frame["source_document_id"].dropna().astype(str))
    missing_ids = sorted(expected_ids - manifest_ids)
    if missing_ids:
        raise RuntimeError(
            "Manifest was not generated for source documents: "
            + ", ".join(missing_ids)
        )
    return frame


def main() -> None:
    scenario = Scenario()

    # Rebuild once, sequentially. Downstream stages never see stale output.
    scenario.build_dataset(REGISTRATION_DATASET, build_mode="NON_RECURSIVE_FORCED_BUILD")
    valid_registration = validate_registration()

    scenario.build_dataset(
        FRAGMENTS_DATASET,
        build_mode="NON_RECURSIVE_FORCED_BUILD",
    )
    fragments = validate_fragments(valid_registration)

    scenario.build_dataset(
        "FRI_ENTITY_SECTOR_CLASSIFICATION_EVIDENCE",
        build_mode="NON_RECURSIVE_FORCED_BUILD",
    )

    scenario.build_dataset(
        MANIFEST_DATASET,
        build_mode="NON_RECURSIVE_FORCED_BUILD",
    )
    manifest = validate_manifest(valid_registration)

    for dataset_name in PIPELINE_OUTPUTS[4:]:
        scenario.build_dataset(dataset_name, build_mode="NON_RECURSIVE_FORCED_BUILD")

    print(json.dumps({
        "status": "SUCCESS",
        "valid_registered_documents": len(valid_registration),
        "document_fragments": len(fragments),
        "manifest_rows": len(manifest),
        "pipeline_outputs": PIPELINE_OUTPUTS,
    }, indent=2))


main()
