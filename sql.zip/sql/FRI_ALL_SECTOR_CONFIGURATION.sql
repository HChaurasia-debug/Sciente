-- All-sector financial templates and forensic-scoring applicability.
-- Run after FRI_MANUFACTURING_DERIVATION_CONFIGURATION.sql.
BEGIN;

CREATE TABLE IF NOT EXISTS financial_risk_intelligence.sector_profiles (
  sector_key text PRIMARY KEY,
  sector_name text NOT NULL,
  parent_sector_key text REFERENCES financial_risk_intelligence.sector_profiles(sector_key),
  template_key text NOT NULL REFERENCES financial_risk_intelligence.financial_templates(template_key),
  profile_type text NOT NULL CHECK (profile_type IN ('COMMERCIAL','BANK','NBFC_INSURANCE')),
  description text NOT NULL DEFAULT '',
  active boolean NOT NULL DEFAULT true,
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS financial_risk_intelligence.entity_sector_assignments (
  entity_id text NOT NULL,
  sector_key text NOT NULL REFERENCES financial_risk_intelligence.sector_profiles(sector_key),
  valid_from date NOT NULL DEFAULT DATE '1900-01-01',
  valid_to date,
  source text NOT NULL DEFAULT 'MANUAL',
  confidence numeric(5,4) NOT NULL DEFAULT 1,
  active boolean NOT NULL DEFAULT true,
  PRIMARY KEY(entity_id,valid_from)
);

CREATE TABLE IF NOT EXISTS financial_risk_intelligence.sector_field_overrides (
  sector_key text NOT NULL REFERENCES financial_risk_intelligence.sector_profiles(sector_key),
  concept_key text NOT NULL REFERENCES financial_risk_intelligence.financial_concepts(concept_key),
  applicability_status text NOT NULL CHECK (applicability_status IN ('REQUIRED','OPTIONAL','NOT_APPLICABLE')),
  display_label text,
  display_order integer,
  reason text NOT NULL DEFAULT '',
  active boolean NOT NULL DEFAULT true,
  PRIMARY KEY(sector_key,concept_key)
);

CREATE TABLE IF NOT EXISTS financial_risk_intelligence.forensic_models (
  model_key text PRIMARY KEY,
  model_name text NOT NULL,
  model_version text NOT NULL,
  active boolean NOT NULL DEFAULT true
);

CREATE TABLE IF NOT EXISTS financial_risk_intelligence.forensic_input_bindings (
  concept_key text PRIMARY KEY REFERENCES financial_risk_intelligence.financial_concepts(concept_key),
  input_key text NOT NULL,
  active boolean NOT NULL DEFAULT true
);

CREATE TABLE IF NOT EXISTS financial_risk_intelligence.forensic_model_inputs (
  model_key text NOT NULL REFERENCES financial_risk_intelligence.forensic_models(model_key),
  concept_key text NOT NULL REFERENCES financial_risk_intelligence.financial_concepts(concept_key),
  period_requirement text NOT NULL CHECK (period_requirement IN ('CURRENT','CURRENT_AND_PRIOR')),
  required boolean NOT NULL DEFAULT true,
  input_order integer NOT NULL,
  PRIMARY KEY(model_key,concept_key)
);

CREATE TABLE IF NOT EXISTS financial_risk_intelligence.sector_model_configuration (
  sector_key text NOT NULL REFERENCES financial_risk_intelligence.sector_profiles(sector_key),
  model_key text NOT NULL REFERENCES financial_risk_intelligence.forensic_models(model_key),
  enabled boolean NOT NULL,
  weight numeric(10,4) NOT NULL DEFAULT 1,
  parameters jsonb NOT NULL DEFAULT '{}'::jsonb,
  disabled_reason text NOT NULL DEFAULT '',
  configuration_version text NOT NULL DEFAULT '2026.1',
  active boolean NOT NULL DEFAULT true,
  PRIMARY KEY(sector_key,model_key)
);

INSERT INTO financial_risk_intelligence.financial_templates(template_key,template_name,sector_key,active)
VALUES ('FINANCIAL_INSTITUTION_GENERIC','Financial inputs - Banking and financial institutions','BANK',true)
ON CONFLICT(template_key) DO UPDATE SET template_name=EXCLUDED.template_name,sector_key=EXCLUDED.sector_key,active=true,updated_at=now();

INSERT INTO financial_risk_intelligence.financial_template_fields
 (template_key,field_key,concept_key,display_label,statement_type,display_order,required,active)
VALUES
 ('FINANCIAL_INSTITUTION_GENERIC','total_income','total_income','Total income','INCOME_STATEMENT',10,true,true),
 ('FINANCIAL_INSTITUTION_GENERIC','net_interest_income','net_interest_income','Net interest income','INCOME_STATEMENT',20,true,true),
 ('FINANCIAL_INSTITUTION_GENERIC','non_interest_income','non_interest_income','Non-interest income','INCOME_STATEMENT',30,true,true),
 ('FINANCIAL_INSTITUTION_GENERIC','operating_expenses','operating_expenses','Operating expenses','INCOME_STATEMENT',40,true,true),
 ('FINANCIAL_INSTITUTION_GENERIC','provisions_impairment','provisions_impairment','Provisions / impairment (ECL charge)','INCOME_STATEMENT',50,true,true),
 ('FINANCIAL_INSTITUTION_GENERIC','profit_before_tax','profit_before_tax','Profit before tax','INCOME_STATEMENT',60,true,true),
 ('FINANCIAL_INSTITUTION_GENERIC','net_profit','net_profit','Net profit','INCOME_STATEMENT',70,true,true),
 ('FINANCIAL_INSTITUTION_GENERIC','gross_loans_advances','gross_loans_advances','Gross loans & advances','BALANCE_SHEET',110,true,true),
 ('FINANCIAL_INSTITUTION_GENERIC','stage3_npa','stage3_npa','Stage-3 / NPA loans','BALANCE_SHEET',120,true,true),
 ('FINANCIAL_INSTITUTION_GENERIC','ecl_balance','ecl_balance','Loan-loss provision / ECL balance','BALANCE_SHEET',130,true,true),
 ('FINANCIAL_INSTITUTION_GENERIC','investments','investments','Investments','BALANCE_SHEET',140,true,true),
 ('FINANCIAL_INSTITUTION_GENERIC','total_assets','total_assets','Total assets','BALANCE_SHEET',150,true,true),
 ('FINANCIAL_INSTITUTION_GENERIC','customer_deposits','customer_deposits','Customer deposits','BALANCE_SHEET',160,true,true),
 ('FINANCIAL_INSTITUTION_GENERIC','borrowings','borrowings','Borrowings','BALANCE_SHEET',170,true,true),
 ('FINANCIAL_INSTITUTION_GENERIC','total_liabilities','total_liabilities','Total liabilities','BALANCE_SHEET',180,true,true),
 ('FINANCIAL_INSTITUTION_GENERIC','total_shareholders_equity','total_shareholders_equity','Shareholders'' equity','BALANCE_SHEET',190,true,true),
 ('FINANCIAL_INSTITUTION_GENERIC','cet1_ratio','cet1_ratio','CET-1 / capital ratio (%)','BALANCE_SHEET',200,true,true),
 ('FINANCIAL_INSTITUTION_GENERIC','operating_cash_flow','operating_cash_flow','Operating cash flow','CASH_FLOW_STATEMENT',310,false,true)
ON CONFLICT(template_key,field_key) DO UPDATE SET concept_key=EXCLUDED.concept_key,display_label=EXCLUDED.display_label,
 statement_type=EXCLUDED.statement_type,display_order=EXCLUDED.display_order,required=EXCLUDED.required,active=true,updated_at=now();

INSERT INTO financial_risk_intelligence.sector_profiles
 (sector_key,sector_name,parent_sector_key,template_key,profile_type,description,active)
VALUES
 ('commercial_base','Commercial base',NULL,'MANUFACTURING_INDUSTRIALS_GENERIC','COMMERCIAL','Shared non-financial-company profile',true),
 ('manufacturing','Manufacturing & Industrials','commercial_base','MANUFACTURING_INDUSTRIALS_GENERIC','COMMERCIAL','Full forensic model calibration profile',true),
 ('trading','Trading & Commodities','commercial_base','MANUFACTURING_INDUSTRIALS_GENERIC','COMMERCIAL','Trading and commodity entities',true),
 ('technology','Technology & Software','commercial_base','MANUFACTURING_INDUSTRIALS_GENERIC','COMMERCIAL','Inventory generally not applicable',true),
 ('realestate','Real Estate & Infrastructure','commercial_base','MANUFACTURING_INDUSTRIALS_GENERIC','COMMERCIAL','Long-cycle and leveraged projects',true),
 ('energy','Energy, Mining & Utilities','commercial_base','MANUFACTURING_INDUSTRIALS_GENERIC','COMMERCIAL','Capital-intensive and impairment-sensitive',true),
 ('consumer','Consumer, Retail & Services','commercial_base','MANUFACTURING_INDUSTRIALS_GENERIC','COMMERCIAL','Inventory and cash-conversion sensitive',true),
 ('pharma','Pharmaceuticals & Healthcare','commercial_base','MANUFACTURING_INDUSTRIALS_GENERIC','COMMERCIAL','R&D and inventory-obsolescence sensitive',true),
 ('financial_institution_base','Financial institution base',NULL,'FINANCIAL_INSTITUTION_GENERIC','BANK','Shared regulated-financial-institution profile',true),
 ('banking','Banking & Financial Institutions','financial_institution_base','FINANCIAL_INSTITUTION_GENERIC','BANK','Bank-specific asset quality and capital metrics',true),
 ('nbfc','NBFC & Insurance','financial_institution_base','FINANCIAL_INSTITUTION_GENERIC','NBFC_INSURANCE','Interim shared profile pending separate insurance ontology',true)
ON CONFLICT(sector_key) DO UPDATE SET sector_name=EXCLUDED.sector_name,parent_sector_key=EXCLUDED.parent_sector_key,
 template_key=EXCLUDED.template_key,profile_type=EXCLUDED.profile_type,description=EXCLUDED.description,active=true,updated_at=now();

INSERT INTO financial_risk_intelligence.sector_field_overrides
 (sector_key,concept_key,applicability_status,reason)
VALUES ('technology','inventory','NOT_APPLICABLE','Inventory-dependent signals are disabled unless the entity reports material inventory')
ON CONFLICT(sector_key,concept_key) DO UPDATE SET applicability_status=EXCLUDED.applicability_status,reason=EXCLUDED.reason,active=true;

INSERT INTO financial_risk_intelligence.forensic_models(model_key,model_name,model_version)
VALUES ('beneish','Beneish M-Score','1999-8-variable'),('montier','Montier C-Score','6-flag'),
 ('altman','Altman Z double-prime','private-non-manufacturer'),('piotroski','Piotroski F-Score','9-signal'),
 ('sloan','Sloan Accruals Ratio','balance-sheet-accrual'),('bank_metrics','Bank asset-quality and capital metrics','2026.1')
ON CONFLICT(model_key) DO UPDATE SET model_name=EXCLUDED.model_name,model_version=EXCLUDED.model_version,active=true;

INSERT INTO financial_risk_intelligence.forensic_input_bindings(concept_key,input_key)
VALUES ('revenue','sales'),('cost_of_goods_sold','cogs'),('sg_and_a_expense','sga'),('depreciation_amortization','depreciation'),
 ('operating_income_ebit','ebit'),('interest_expense','interestExpense'),('net_profit','netIncome'),
 ('total_current_assets','currentAssets'),('trade_receivables_net','receivables'),('inventory','inventory'),('net_ppe','netPPE'),
 ('total_assets','totalAssets'),('total_current_liabilities','currentLiabilities'),('long_term_debt','longTermDebt'),
 ('total_liabilities','totalLiabilities'),('retained_earnings','retainedEarnings'),('total_shareholders_equity','equity'),
 ('shares_outstanding','shares'),('operating_cash_flow','cfo'),('total_income','sales'),('net_interest_income','nii'),
 ('non_interest_income','noninterest'),('operating_expenses','opex'),('provisions_impairment','provisions'),('profit_before_tax','ebit'),
 ('gross_loans_advances','grossLoans'),('stage3_npa','stage3'),('ecl_balance','eclBalance'),('investments','investments'),
 ('customer_deposits','deposits'),('borrowings','borrowings'),('cet1_ratio','cet1')
ON CONFLICT(concept_key) DO UPDATE SET input_key=EXCLUDED.input_key,active=true;

INSERT INTO financial_risk_intelligence.forensic_model_inputs(model_key,concept_key,period_requirement,required,input_order)
VALUES
 ('beneish','revenue','CURRENT_AND_PRIOR',true,1),('beneish','trade_receivables_net','CURRENT_AND_PRIOR',true,2),('beneish','cost_of_goods_sold','CURRENT_AND_PRIOR',true,3),
 ('beneish','total_current_assets','CURRENT_AND_PRIOR',true,4),('beneish','net_ppe','CURRENT_AND_PRIOR',true,5),('beneish','total_assets','CURRENT_AND_PRIOR',true,6),
 ('beneish','depreciation_amortization','CURRENT_AND_PRIOR',true,7),('beneish','sg_and_a_expense','CURRENT_AND_PRIOR',true,8),('beneish','total_current_liabilities','CURRENT_AND_PRIOR',true,9),
 ('beneish','long_term_debt','CURRENT_AND_PRIOR',true,10),('beneish','net_profit','CURRENT_AND_PRIOR',true,11),('beneish','operating_cash_flow','CURRENT',true,12),
 ('altman','total_current_assets','CURRENT',true,1),('altman','total_current_liabilities','CURRENT',true,2),('altman','total_assets','CURRENT',true,3),
 ('altman','retained_earnings','CURRENT',true,4),('altman','operating_income_ebit','CURRENT',true,5),('altman','total_shareholders_equity','CURRENT',true,6),('altman','total_liabilities','CURRENT',true,7),
 ('montier','revenue','CURRENT_AND_PRIOR',true,1),('montier','trade_receivables_net','CURRENT_AND_PRIOR',true,2),('montier','inventory','CURRENT_AND_PRIOR',false,3),
 ('montier','cost_of_goods_sold','CURRENT_AND_PRIOR',false,4),('montier','total_current_assets','CURRENT_AND_PRIOR',true,5),('montier','depreciation_amortization','CURRENT_AND_PRIOR',true,6),
 ('montier','net_ppe','CURRENT_AND_PRIOR',true,7),('montier','total_assets','CURRENT_AND_PRIOR',true,8),('montier','net_profit','CURRENT',true,9),('montier','operating_cash_flow','CURRENT',true,10),
 ('piotroski','net_profit','CURRENT_AND_PRIOR',true,1),('piotroski','total_assets','CURRENT_AND_PRIOR',true,2),('piotroski','operating_cash_flow','CURRENT',true,3),
 ('piotroski','long_term_debt','CURRENT_AND_PRIOR',true,4),('piotroski','total_current_assets','CURRENT_AND_PRIOR',true,5),('piotroski','total_current_liabilities','CURRENT_AND_PRIOR',true,6),
 ('piotroski','shares_outstanding','CURRENT_AND_PRIOR',true,7),('piotroski','revenue','CURRENT_AND_PRIOR',true,8),('piotroski','cost_of_goods_sold','CURRENT_AND_PRIOR',true,9),
 ('sloan','net_profit','CURRENT',true,1),('sloan','operating_cash_flow','CURRENT',true,2),('sloan','total_assets','CURRENT_AND_PRIOR',true,3),
 ('bank_metrics','net_interest_income','CURRENT_AND_PRIOR',true,1),('bank_metrics','gross_loans_advances','CURRENT_AND_PRIOR',true,2),
 ('bank_metrics','stage3_npa','CURRENT_AND_PRIOR',true,3),('bank_metrics','ecl_balance','CURRENT',true,4),('bank_metrics','total_assets','CURRENT_AND_PRIOR',true,5),('bank_metrics','cet1_ratio','CURRENT_AND_PRIOR',true,6)
ON CONFLICT(model_key,concept_key) DO UPDATE SET period_requirement=EXCLUDED.period_requirement,required=EXCLUDED.required,input_order=EXCLUDED.input_order;

INSERT INTO financial_risk_intelligence.sector_model_configuration
 (sector_key,model_key,enabled,weight,parameters,disabled_reason)
SELECT s.sector_key,m.model_key,
 CASE WHEN s.profile_type='COMMERCIAL' THEN m.model_key<>'bank_metrics' ELSE m.model_key='bank_metrics' END,
 1,
 CASE s.sector_key
  WHEN 'trading' THEN '{"inventory_growth_tolerance":1.2,"dso_tolerance":1.25}'::jsonb
  WHEN 'technology' THEN '{"inventory_signal_enabled":false,"dso_tolerance":1.15}'::jsonb
  WHEN 'realestate' THEN '{"interest_coverage_floor":1.5,"leverage_tolerance":1.25,"dso_tolerance":1.35,"piotroski_weight":0}'::jsonb
  WHEN 'energy' THEN '{"interest_coverage_floor":1.5,"leverage_tolerance":1.2}'::jsonb
  WHEN 'consumer' THEN '{"inventory_growth_tolerance":1.1,"dso_tolerance":1.15}'::jsonb
  WHEN 'pharma' THEN '{"inventory_growth_tolerance":1.1}'::jsonb
  ELSE '{}'::jsonb END,
 CASE WHEN s.profile_type<>'COMMERCIAL' AND m.model_key<>'bank_metrics' THEN 'Non-financial-company model is not approved for this profile'
      WHEN s.profile_type='COMMERCIAL' AND m.model_key='bank_metrics' THEN 'Bank-only model' ELSE '' END
FROM financial_risk_intelligence.sector_profiles s CROSS JOIN financial_risk_intelligence.forensic_models m
WHERE s.parent_sector_key IS NOT NULL
ON CONFLICT(sector_key,model_key) DO UPDATE SET enabled=EXCLUDED.enabled,weight=EXCLUDED.weight,parameters=EXCLUDED.parameters,
 disabled_reason=EXCLUDED.disabled_reason,configuration_version='2026.1',active=true;

-- Every active template field receives a direct rule. Approved formula rules
-- already seeded for the commercial template remain higher-priority fallbacks.
INSERT INTO financial_risk_intelligence.financial_template_rules
 (rule_key,template_key,target_concept_key,operator,priority,output_sign,active,approval_status)
SELECT upper(substr(md5(f.template_key||':'||f.concept_key),1,20)),f.template_key,f.concept_key,'DIRECT',10,
 CASE WHEN f.concept_key IN ('net_profit','profit_before_tax','operating_income_ebit','operating_cash_flow','retained_earnings','total_shareholders_equity') THEN 'AS_REPORTED' ELSE 'ABSOLUTE' END,
 true,'APPROVED'
FROM financial_risk_intelligence.financial_template_fields f
WHERE f.active
ON CONFLICT(template_key,target_concept_key,priority) DO NOTHING;

CREATE OR REPLACE VIEW financial_risk_intelligence.sector_template_configuration AS
SELECT s.sector_key,s.sector_name,s.profile_type,s.template_key,f.field_key,f.concept_key,b.input_key,
 COALESCE(o.display_label,f.display_label) display_label,f.statement_type,
 COALESCE(o.display_order,f.display_order) display_order,
 COALESCE(o.applicability_status,CASE WHEN f.required THEN 'REQUIRED' ELSE 'OPTIONAL' END) applicability_status,
 COALESCE(o.reason,'') applicability_reason
FROM financial_risk_intelligence.sector_profiles s
JOIN financial_risk_intelligence.financial_template_fields f ON f.template_key=s.template_key AND f.active
LEFT JOIN financial_risk_intelligence.sector_field_overrides o ON o.sector_key=s.sector_key AND o.concept_key=f.concept_key AND o.active
LEFT JOIN financial_risk_intelligence.forensic_input_bindings b ON b.concept_key=f.concept_key AND b.active
WHERE s.active AND s.parent_sector_key IS NOT NULL;

CREATE OR REPLACE VIEW financial_risk_intelligence.sector_derivation_configuration AS
SELECT s.sector_key,r.rule_key,r.template_key,r.target_concept_key,r.operator,r.priority,r.output_sign,
 c.component_concept_key,c.coefficient,c.component_sign,c.component_order
FROM financial_risk_intelligence.sector_profiles s
JOIN financial_risk_intelligence.financial_template_rules r ON r.template_key=s.template_key AND r.active AND r.approval_status='APPROVED'
LEFT JOIN financial_risk_intelligence.financial_rule_components c USING(rule_key)
WHERE s.active AND s.parent_sector_key IS NOT NULL;

CREATE OR REPLACE VIEW financial_risk_intelligence.sector_scoring_configuration AS
SELECT s.sector_key,s.sector_name,s.template_key,m.model_key,m.model_name,m.model_version,
 c.enabled,c.weight,c.parameters,c.disabled_reason,c.configuration_version,
 i.concept_key input_concept_key,i.period_requirement,i.required input_required,i.input_order
FROM financial_risk_intelligence.sector_profiles s
JOIN financial_risk_intelligence.sector_model_configuration c ON c.sector_key=s.sector_key AND c.active
JOIN financial_risk_intelligence.forensic_models m ON m.model_key=c.model_key AND m.active
LEFT JOIN financial_risk_intelligence.forensic_model_inputs i ON i.model_key=m.model_key
WHERE s.active AND s.parent_sector_key IS NOT NULL;

COMMIT;
