-- Manufacturing & Industrials generic financial template configuration.
-- Run after FRI_FINANCIAL_SYNONYM_REGISTRY.sql.
-- Database-only mapping: no recipe code changes are required.

BEGIN;

CREATE TABLE IF NOT EXISTS financial_risk_intelligence.financial_templates (
    template_key text PRIMARY KEY,
    template_name text NOT NULL,
    sector_key text NOT NULL,
    active boolean NOT NULL DEFAULT true,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS financial_risk_intelligence.financial_template_fields (
    template_key text NOT NULL REFERENCES financial_risk_intelligence.financial_templates(template_key),
    field_key text NOT NULL,
    concept_key text NOT NULL REFERENCES financial_risk_intelligence.financial_concepts(concept_key),
    display_label text NOT NULL,
    statement_type text NOT NULL CHECK (statement_type IN
        ('INCOME_STATEMENT','BALANCE_SHEET','CASH_FLOW_STATEMENT')),
    display_order integer NOT NULL,
    required boolean NOT NULL DEFAULT true,
    active boolean NOT NULL DEFAULT true,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (template_key,field_key),
    UNIQUE (template_key,concept_key)
);

INSERT INTO financial_risk_intelligence.financial_templates
    (template_key,template_name,sector_key,active)
VALUES ('MANUFACTURING_INDUSTRIALS_GENERIC','Financial inputs - Manufacturing & Industrials','COMMERCIAL',true)
ON CONFLICT (template_key) DO UPDATE SET
    template_name=EXCLUDED.template_name,sector_key=EXCLUDED.sector_key,
    active=true,updated_at=now();

INSERT INTO financial_risk_intelligence.financial_template_fields
    (template_key,field_key,concept_key,display_label,statement_type,display_order,required,active)
VALUES
    ('MANUFACTURING_INDUSTRIALS_GENERIC','net_revenue_sales','revenue','Net revenue / sales','INCOME_STATEMENT',10,true,true),
    ('MANUFACTURING_INDUSTRIALS_GENERIC','cost_of_goods_sold','cost_of_goods_sold','Cost of goods sold','INCOME_STATEMENT',20,true,true),
    ('MANUFACTURING_INDUSTRIALS_GENERIC','sg_and_a_expense','sg_and_a_expense','SG&A expense','INCOME_STATEMENT',30,true,true),
    ('MANUFACTURING_INDUSTRIALS_GENERIC','depreciation_amortisation','depreciation_amortization','Depreciation & amortisation','INCOME_STATEMENT',40,true,true),
    ('MANUFACTURING_INDUSTRIALS_GENERIC','operating_income_ebit','operating_income_ebit','Operating income (EBIT)','INCOME_STATEMENT',50,true,true),
    ('MANUFACTURING_INDUSTRIALS_GENERIC','interest_expense','interest_expense','Interest expense','INCOME_STATEMENT',60,true,true),
    ('MANUFACTURING_INDUSTRIALS_GENERIC','net_income','net_profit','Net income','INCOME_STATEMENT',70,true,true),
    ('MANUFACTURING_INDUSTRIALS_GENERIC','total_current_assets','total_current_assets','Total current assets','BALANCE_SHEET',110,true,true),
    ('MANUFACTURING_INDUSTRIALS_GENERIC','trade_receivables_net','trade_receivables_net','Trade receivables (net)','BALANCE_SHEET',120,true,true),
    ('MANUFACTURING_INDUSTRIALS_GENERIC','inventory','inventory','Inventory','BALANCE_SHEET',130,true,true),
    ('MANUFACTURING_INDUSTRIALS_GENERIC','net_ppe','net_ppe','Net PP&E (fixed assets)','BALANCE_SHEET',140,true,true),
    ('MANUFACTURING_INDUSTRIALS_GENERIC','total_assets','total_assets','Total assets','BALANCE_SHEET',150,true,true),
    ('MANUFACTURING_INDUSTRIALS_GENERIC','total_current_liabilities','total_current_liabilities','Total current liabilities','BALANCE_SHEET',160,true,true),
    ('MANUFACTURING_INDUSTRIALS_GENERIC','long_term_debt','long_term_debt','Long-term debt','BALANCE_SHEET',170,true,true),
    ('MANUFACTURING_INDUSTRIALS_GENERIC','total_liabilities','total_liabilities','Total liabilities','BALANCE_SHEET',180,true,true),
    ('MANUFACTURING_INDUSTRIALS_GENERIC','retained_earnings','retained_earnings','Retained earnings','BALANCE_SHEET',190,true,true),
    ('MANUFACTURING_INDUSTRIALS_GENERIC','total_shareholders_equity','total_shareholders_equity','Total shareholders'' equity','BALANCE_SHEET',200,true,true),
    ('MANUFACTURING_INDUSTRIALS_GENERIC','shares_outstanding','shares_outstanding','Shares outstanding','BALANCE_SHEET',210,true,true),
    ('MANUFACTURING_INDUSTRIALS_GENERIC','cash_flow_from_operations','operating_cash_flow','Cash flow from operations','CASH_FLOW_STATEMENT',310,true,true)
ON CONFLICT (template_key,field_key) DO UPDATE SET
    concept_key=EXCLUDED.concept_key,display_label=EXCLUDED.display_label,
    statement_type=EXCLUDED.statement_type,display_order=EXCLUDED.display_order,
    required=EXCLUDED.required,active=true,updated_at=now();

-- Curated from the PDFs in /data. DISTINCT ON + the governed unique index means
-- repeated labels across reports are stored once, not once per document.
INSERT INTO financial_risk_intelligence.financial_concept_aliases
    (concept_key,alias_text,normalized_alias_text,sector_key,priority,
     active,approval_status,approved_by,approved_at,match_confidence)
SELECT DISTINCT ON (concept_key,normalized_alias_text,COALESCE(sector_key,''))
       concept_key,alias_text,normalized_alias_text,sector_key,priority,
       true,'APPROVED','PDF_CORPUS_2026',now(),confidence
FROM (
    SELECT v.concept_key,v.alias_text,
           financial_risk_intelligence.normalize_financial_alias_text(v.alias_text) AS normalized_alias_text,
           'COMMERCIAL'::text AS sector_key,v.priority,v.confidence
    FROM (VALUES
      ('revenue','Revenue',1,99.00),('revenue','Net revenue',2,99.00),
      ('revenue','Sales',5,98.00),('revenue','Net sales',6,98.00),('revenue','Turnover',10,98.00),
      ('revenue','Revenue from contracts with customers',12,98.00),('revenue','Revenue from contract with customer',13,98.00),
      ('cost_of_goods_sold','Cost of goods sold',1,99.00),('cost_of_goods_sold','Cost of sales',2,99.00),
      ('cost_of_goods_sold','Cost of revenue',5,98.00),('cost_of_goods_sold','Cost of inventories sold',10,96.00),
      ('sg_and_a_expense','SG&A expense',1,99.00),('sg_and_a_expense','Selling, general and administrative expenses',2,99.00),
      ('sg_and_a_expense','General and administrative expenses',5,97.00),('sg_and_a_expense','Administrative expenses',10,95.00),
      ('sg_and_a_expense','Selling expenses',11,95.00),
      ('depreciation_amortization','Depreciation and amortisation',1,99.00),
      ('depreciation_amortization','Depreciation and amortization',2,99.00),
      ('depreciation_amortization','Depreciation & amortisation',3,99.00),
      ('operating_income_ebit','Operating profit',1,99.00),('operating_income_ebit','Operating income',2,99.00),
      ('operating_income_ebit','Profit from operations',5,98.00),('operating_income_ebit','Income from operations',6,98.00),
      ('operating_income_ebit','EBIT',10,99.00),
      ('interest_expense','Interest expense',1,99.00),('interest_expense','Interest expenses',2,99.00),
      ('interest_expense','Finance costs',5,98.00),('interest_expense','Finance cost',6,98.00),
      ('interest_expense','Finance expense',7,98.00),('interest_expense','Finance expenses',8,98.00),
      ('interest_expense','Interest cost',10,96.00),
      ('net_profit','Net income',1,99.00),('net_profit','Net profit',2,99.00),
      ('net_profit','Profit for the year',5,99.00),('net_profit','Profit for the financial year',6,99.00),
      ('net_profit','Loss for the year',7,99.00),('net_profit','Loss for the financial year',8,99.00),
      ('net_profit','Profit after tax',10,98.00),('net_profit','Loss after tax',11,98.00),
      ('net_profit','Profit after taxation',12,98.00),('net_profit','Loss after taxation',13,98.00),
      ('total_current_assets','Total current assets',1,99.00),
      ('trade_receivables_net','Trade receivables',1,99.00),('trade_receivables_net','Trade receivables, net',2,99.00),
      ('trade_receivables_net','Trade receivable',3,98.00),('trade_receivables_net','Accounts receivable',5,98.00),
      ('trade_receivables_net','Accounts receivable, net',6,98.00),
      ('inventory','Inventory',1,99.00),('inventory','Inventories',2,99.00),('inventory','Inventories, net',3,98.00),
      ('net_ppe','Property, plant and equipment',1,99.00),('net_ppe','Property, plant and equipment, net',2,99.00),
      ('net_ppe','Fixed assets',5,96.00),('net_ppe','Net fixed assets',6,98.00),
      ('total_assets','Total assets',1,99.00),
      ('total_current_liabilities','Total current liabilities',1,99.00),
      ('long_term_debt','Long-term debt',1,99.00),('long_term_debt','Long term debt',2,99.00),
      ('long_term_debt','Long-term loans',5,97.00),('long_term_debt','Non-current borrowings',6,97.00),
      ('long_term_debt','Borrowings - non-current',7,97.00),
      ('total_liabilities','Total liabilities',1,99.00),
      ('retained_earnings','Retained earnings',1,99.00),('retained_earnings','Retained profits',2,99.00),
      ('retained_earnings','Accumulated profits',5,98.00),('retained_earnings','Accumulated losses',6,98.00),
      ('total_shareholders_equity','Total shareholders'' equity',1,99.00),
      ('total_shareholders_equity','Shareholders'' equity',2,99.00),
      ('total_shareholders_equity','Shareholders'' funds',3,98.00),
      ('total_shareholders_equity','Equity attributable to owners of the Company',5,97.00),
      ('total_shareholders_equity','Equity attributable to owners',6,96.00),
      ('shares_outstanding','Shares outstanding',1,99.00),('shares_outstanding','Number of shares outstanding',2,99.00),
      ('shares_outstanding','Issued shares',5,97.00),('shares_outstanding','Shares in issue',6,97.00),
      ('operating_cash_flow','Cash flow from operating activities',1,99.00),
      ('operating_cash_flow','Cash flows from operating activities',2,99.00),
      ('operating_cash_flow','Net cash from operating activities',3,99.00),
      ('operating_cash_flow','Net cash generated from operating activities',4,99.00),
      ('operating_cash_flow','Net cash used in operating activities',5,99.00),
      ('operating_cash_flow','Net cash flows generated from operating activities',6,99.00),
      ('operating_cash_flow','Net cash flows used in operating activities',7,99.00)
    ) AS v(concept_key,alias_text,priority,confidence)
) seed
ORDER BY concept_key,normalized_alias_text,COALESCE(sector_key,''),priority
ON CONFLICT DO NOTHING;

INSERT INTO financial_risk_intelligence.financial_statement_aliases
    (statement_type,alias_text,normalized_alias_text,sector_key,priority,
     active,approval_status,approved_by,approved_at)
SELECT DISTINCT ON (statement_type,normalized_alias_text,COALESCE(sector_key,''))
       statement_type,alias_text,normalized_alias_text,sector_key,priority,
       true,'APPROVED','PDF_CORPUS_2026',now()
FROM (
    SELECT v.statement_type,v.alias_text,
           financial_risk_intelligence.normalize_financial_alias_text(v.alias_text) normalized_alias_text,
           'COMMERCIAL'::text sector_key,v.priority
    FROM (VALUES
      ('BALANCE_SHEET','Balance sheet',1),('BALANCE_SHEET','Balance sheets',2),
      ('BALANCE_SHEET','Statement of financial position',3),('BALANCE_SHEET','Statements of financial position',4),
      ('BALANCE_SHEET','Consolidated statement of financial position',5),
      ('BALANCE_SHEET','Consolidated statements of financial position',6),
      ('INCOME_STATEMENT','Income statement',1),('INCOME_STATEMENT','Income statements',2),
      ('INCOME_STATEMENT','Statement of income',3),('INCOME_STATEMENT','Consolidated statement of income',4),
      ('INCOME_STATEMENT','Statement of profit or loss',5),('INCOME_STATEMENT','Statements of profit or loss',6),
      ('INCOME_STATEMENT','Consolidated statement of profit or loss',7),
      ('INCOME_STATEMENT','Statement of comprehensive income',8),
      ('INCOME_STATEMENT','Statements of comprehensive income',9),
      ('INCOME_STATEMENT','Consolidated statement of comprehensive income',10),
      ('INCOME_STATEMENT','Consolidated statements of comprehensive income',11),
      ('INCOME_STATEMENT','Statement of profit or loss and other comprehensive income',12),
      ('INCOME_STATEMENT','Statements of profit or loss and other comprehensive income',13),
      ('INCOME_STATEMENT','Consolidated statement of profit or loss and other comprehensive income',14),
      ('INCOME_STATEMENT','Consolidated statements of profit or loss and other comprehensive income',15),
      ('CASH_FLOW_STATEMENT','Cash flow statement',1),('CASH_FLOW_STATEMENT','Statement of cash flow',2),
      ('CASH_FLOW_STATEMENT','Statement of cash flows',3),('CASH_FLOW_STATEMENT','Statements of cash flows',4),
      ('CASH_FLOW_STATEMENT','Consolidated statement of cash flow',5),
      ('CASH_FLOW_STATEMENT','Consolidated statement of cash flows',6),
      ('CASH_FLOW_STATEMENT','Consolidated statements of cash flows',7)
    ) AS v(statement_type,alias_text,priority)
) seed
ORDER BY statement_type,normalized_alias_text,COALESCE(sector_key,''),priority
ON CONFLICT DO NOTHING;

-- Runtime configuration consumed by a generic extractor/template renderer.
-- Alias_rank=1 is the deterministic winner if legacy data contains duplicates.
CREATE OR REPLACE VIEW financial_risk_intelligence.manufacturing_generic_template_mapping AS
SELECT template_key,field_key,display_label,statement_type,display_order,required,
       concept_key,alias_text,normalized_alias_text,priority,match_confidence
FROM (
    SELECT f.template_key,f.field_key,f.display_label,f.statement_type,
           f.display_order,f.required,f.concept_key,a.alias_text,
           a.normalized_alias_text,a.priority,a.match_confidence,
           row_number() OVER (
             PARTITION BY f.template_key,f.field_key,a.normalized_alias_text
             ORDER BY a.priority,a.updated_at DESC,a.alias_id
           ) AS alias_rank
    FROM financial_risk_intelligence.financial_template_fields f
    JOIN financial_risk_intelligence.financial_concept_aliases a
      ON a.concept_key=f.concept_key
     AND a.active=true AND a.approval_status='APPROVED'
     AND (a.sector_key IS NULL OR a.sector_key='COMMERCIAL')
    WHERE f.template_key='MANUFACTURING_INDUSTRIALS_GENERIC' AND f.active=true
) ranked
WHERE alias_rank=1;

COMMIT;

-- Expected: 19 template fields; no duplicate normalized alias per field.
SELECT count(*) AS template_field_count
FROM financial_risk_intelligence.financial_template_fields
WHERE template_key='MANUFACTURING_INDUSTRIALS_GENERIC' AND active=true;

SELECT template_key,field_key,normalized_alias_text,count(*) AS duplicate_count
FROM financial_risk_intelligence.manufacturing_generic_template_mapping
GROUP BY template_key,field_key,normalized_alias_text
HAVING count(*) > 1;
