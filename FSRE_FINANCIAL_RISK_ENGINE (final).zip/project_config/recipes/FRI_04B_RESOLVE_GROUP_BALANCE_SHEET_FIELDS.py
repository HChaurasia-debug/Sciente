"""FRI_04B_RESOLVE_GROUP_BALANCE_SHEET_FIELDS

Input:  FRI_STANDARDIZED_STATEMENT_VALUES
Outputs: FRI_BALANCE_SHEET_INPUTS, FRI_BALANCE_SHEET_INPUT_EXCEPTIONS

This phase intentionally resolves one Balance Sheet only. It prefers Group
scope; when the source has only one Balance Sheet and no Group/Company label,
that statement is treated as the Group fallback. Amounts are never calculated
or invented: every output value is copied from an extracted source cell.
"""

from __future__ import annotations

import collections
import datetime as dt
import json
import re
from typing import Any, Dict, List, Optional, Tuple

import dataiku
import pandas as pd


INPUT_DATASET = "FRI_STANDARDIZED_STATEMENT_VALUES"
OUTPUT_DATASET = "FRI_BALANCE_SHEET_INPUTS"
EXCEPTION_DATASET = "FRI_BALANCE_SHEET_INPUT_EXCEPTIONS"
VERSION = "fri-group-balance-sheet-fields-1.2.0"

TARGET_FIELDS = [
    ("total_current_assets", "Total current assets", ["total current assets", "current assets"]),
    ("trade_receivables_net", "Trade receivables (net)", ["trade receivables", "accounts receivable", "receivables net", "trade and other receivables"]),
    ("inventory", "Inventory", ["inventory", "inventories"]),
    ("net_ppe", "Net PP&E (fixed assets)", ["property plant and equipment", "plant and equipment", "property and equipment", "right of use assets", "net ppe", "fixed assets", "properties and other fixed assets"]),
    ("total_assets", "Total assets", ["total assets"]),
    ("total_current_liabilities", "Total current liabilities", ["total current liabilities", "current liabilities"]),
    ("long_term_debt", "Long-term debt", ["long term debt", "long-term debt", "non current debt", "non-current debt", "long term borrowings", "non-current borrowings", "non-current loans and borrowings", "non-current lease liabilities", "loans and borrowings", "lease liabilities", "other debt securities"]),
    ("total_liabilities", "Total liabilities", ["total liabilities"]),
    ("retained_earnings", "Retained earnings", ["retained earnings", "retained profits", "accumulated profits", "accumulated losses", "revenue reserves"]),
    ("total_shareholders_equity", "Total shareholders' equity", ["total shareholders equity", "total shareholders' funds", "shareholders funds", "total equity", "equity attributable to owners of the company", "equity attributable to owners"]),
    ("shares_outstanding", "Shares outstanding", ["shares outstanding", "number of shares outstanding", "ordinary shares outstanding", "net number of issued shares", "number of issued shares excluding treasury shares", "issued shares", "shares in issue"]),
]

VALUE_COLUMNS = [
    "statement_value_id", "tenant_id", "entity_id", "assessment_run_id", "source_document_id",
    "table_artifact_id", "source_table_id", "statement_type", "statement_title", "statement_section",
    "row_index", "row_order", "row_label", "concept_key", "source_row_label", "note_reference",
    "entity_scope", "period_label", "period_end", "column_index", "raw_value", "numeric_value", "value_status",
    "currency", "unit", "is_total", "page_number", "extraction_confidence", "structure_score",
    "selection_method", "source_column_index", "normalization_status", "resolver_version", "resolved_at",
]
EXCEPTION_COLUMNS = [
    "tenant_id", "entity_id", "assessment_run_id", "source_document_id", "table_artifact_id",
    "concept_key", "display_label", "exception_code", "severity", "message", "recommended_action",
    "resolver_version", "created_at",
]


def missing(value: Any) -> bool:
    if value is None:
        return True
    try:
        result = pd.isna(value)
        if isinstance(result, bool) and result:
            return True
    except (TypeError, ValueError):
        pass
    return str(value).strip().lower() in {"", "nan", "none", "null", "nat"}


def text(value: Any) -> str:
    return "" if missing(value) else str(value).strip()


def number(value: Any) -> Optional[float]:
    if missing(value):
        return None
    try:
        result = float(value)
        return None if pd.isna(result) else result
    except (TypeError, ValueError):
        return None


def integer(value: Any, default: int = -1) -> int:
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return default


def read_dataset(name: str) -> pd.DataFrame:
    try:
        return dataiku.Dataset(name).get_dataframe(infer_with_pandas=False)
    except TypeError:
        return dataiku.Dataset(name).get_dataframe()


def normalize_label(value: Any) -> str:
    value = re.sub(r"[^a-z0-9]+", " ", text(value).lower())
    return re.sub(r"\s+", " ", value).strip()


def field_match(label: str) -> Optional[Tuple[str, str]]:
    normalized = normalize_label(label)
    exact = []
    for concept_key, display_label, aliases in TARGET_FIELDS:
        for alias in aliases:
            alias_normalized = normalize_label(alias)
            if normalized == alias_normalized:
                return concept_key, display_label
            if alias_normalized in normalized or normalized in alias_normalized:
                exact.append((len(alias_normalized), concept_key, display_label))
    if not exact:
        return None
    _, concept_key, display_label = sorted(exact, reverse=True)[0]
    return concept_key, display_label


def year(value: Any) -> Optional[int]:
    match = re.findall(r"\b(?:19|20)\d{2}\b", text(value))
    return int(match[-1]) if match else None


def scope(value: Any) -> str:
    value = text(value).upper()
    return value if value not in {"", "UNKNOWN", "UNSPECIFIED", "NONE", "REPORTED"} else "REPORTED"


def total_label(label: str) -> bool:
    return bool(re.search(r"^total\b|^net assets$|shareholders?.? funds|total equity|retained earnings", label.lower()))


values = read_dataset(INPUT_DATASET)
if values.empty:
    raise RuntimeError("FRI_STANDARDIZED_STATEMENT_VALUES is empty. Run FRI_04A first.")

records = []
for row in values.to_dict(orient="records"):
    if text(row.get("statement_type")).upper() != "BALANCE_SHEET":
        continue
    if number(row.get("numeric_value")) is None:
        continue
    match = field_match(text(row.get("row_label")))
    if not match:
        continue
    copied = dict(row)
    copied["_concept_key"], copied["_display_label"] = match
    copied["_scope"] = scope(row.get("entity_scope"))
    copied["_period_year"] = year(row.get("period_label") or row.get("period_end"))
    copied["_table_key"] = text(row.get("table_artifact_id") or row.get("source_table_id"))
    records.append(copied)

exceptions: List[Dict[str, Any]] = []
if not records:
    raise RuntimeError("No requested Balance Sheet fields were found in FRI_STANDARDIZED_STATEMENT_VALUES.")

group_records = [row for row in records if row["_scope"] == "GROUP"]
if group_records:
    eligible = group_records
    scope_method = "GROUP_SCOPE"
else:
    non_company = [row for row in records if row["_scope"] != "COMPANY"]
    eligible = non_company
    scope_method = "SINGLE_STATEMENT_GROUP_FALLBACK"

if not eligible:
    raise RuntimeError("No Group-level or single-statement Balance Sheet values were found.")

table_scores: Dict[str, set] = collections.defaultdict(set)
for row in eligible:
    table_scores[row["_table_key"]].add(row["_concept_key"])
selected_table = sorted(
    table_scores,
    key=lambda key: (len(table_scores[key]), key),
    reverse=True,
)[0]
selected = [row for row in eligible if row["_table_key"] == selected_table]

periods = sorted({row["_period_year"] for row in selected if row["_period_year"] is not None}, reverse=True)
if len(periods) < 2:
    column_order = sorted({integer(row.get("column_index")) for row in selected if integer(row.get("column_index")) >= 0}, reverse=True)
    current_period = periods[0] if periods else "Current period"
    prior_period = periods[1] if len(periods) > 1 else "Prior period"
else:
    current_period, prior_period = periods[0], periods[1]

def period_bucket(row: Dict[str, Any]) -> str:
    if row["_period_year"] == current_period:
        return "CURRENT"
    if row["_period_year"] == prior_period:
        return "PRIOR"
    if row["_period_year"] is None and len(periods) < 2:
        index = integer(row.get("column_index"))
        if index == max(column_order, default=-1):
            return "CURRENT"
        if len(column_order) > 1 and index == column_order[1]:
            return "PRIOR"
    return "OTHER"


selected_by_field: Dict[str, Dict[str, Dict[str, Any]]] = collections.defaultdict(dict)
for row in selected:
    bucket = period_bucket(row)
    if bucket in {"CURRENT", "PRIOR"}:
        existing = selected_by_field[row["_concept_key"]].get(bucket)
        confidence = number(row.get("extraction_confidence")) or 0.0
        if existing is None or confidence > (number(existing.get("extraction_confidence")) or 0.0):
            selected_by_field[row["_concept_key"]][bucket] = row

now = dt.datetime.now(dt.timezone.utc).isoformat()
output_rows: List[Dict[str, Any]] = []
for field_index, (concept_key, display_label, _) in enumerate(TARGET_FIELDS):
    source_by_period = selected_by_field.get(concept_key, {})
    first = selected[0]
    if not source_by_period:
        exceptions.append({
            "tenant_id": text(first.get("tenant_id")), "entity_id": text(first.get("entity_id")),
            "assessment_run_id": text(first.get("assessment_run_id")), "source_document_id": text(first.get("source_document_id")),
            "table_artifact_id": selected_table, "concept_key": concept_key, "display_label": display_label,
            "exception_code": "REQUESTED_FIELD_NOT_FOUND", "severity": "WARNING",
            "message": f"No source value was found for {display_label}.",
            "recommended_action": "Review the source Balance Sheet or add an approved source alias.",
            "resolver_version": VERSION, "created_at": now,
        })
    for column_index, bucket in [(1, "CURRENT"), (2, "PRIOR")]:
        source = source_by_period.get(bucket) or first
        has_value = source_by_period.get(bucket) is not None
        output_rows.append({
            "statement_value_id": text(source.get("statement_value_id")) if has_value else "",
            "tenant_id": text(source.get("tenant_id")), "entity_id": text(source.get("entity_id")),
            "assessment_run_id": text(source.get("assessment_run_id")), "source_document_id": text(source.get("source_document_id")),
            "table_artifact_id": selected_table, "source_table_id": text(source.get("source_table_id")),
            "statement_type": "BALANCE_SHEET", "statement_title": text(source.get("statement_title")),
            "statement_section": text(source.get("statement_section")), "row_index": field_index,
            "row_order": field_index, "row_label": display_label, "concept_key": concept_key,
            "source_row_label": text(source.get("row_label")) if has_value else "", "note_reference": text(source.get("note_reference")) if has_value else "",
            "entity_scope": "GROUP", "period_label": source.get("period_label") if has_value else (current_period if bucket == "CURRENT" else prior_period),
            "period_end": source.get("period_end") if has_value else (current_period if bucket == "CURRENT" else prior_period), "column_index": column_index,
            "raw_value": text(source.get("raw_value") or source.get("raw_text")) if has_value else "Not reported in filing", "numeric_value": number(source.get("numeric_value")) if has_value else None, "value_status": "REPORTED" if has_value else "NOT_REPORTED",
            "currency": text(source.get("currency")), "unit": text(source.get("unit")), "is_total": total_label(display_label),
            "page_number": integer(source.get("page_number"), 0), "extraction_confidence": number(source.get("extraction_confidence")) if has_value else 0.0,
            "structure_score": number(source.get("structure_score")), "selection_method": scope_method if has_value else scope_method + "_MISSING",
            "source_column_index": integer(source.get("column_index")) if has_value else -1, "normalization_status": "BALANCE_SHEET_RESOLVED",
            "resolver_version": VERSION, "resolved_at": now,
        })
output_df = pd.DataFrame(output_rows, columns=VALUE_COLUMNS)
exception_df = pd.DataFrame(exceptions, columns=EXCEPTION_COLUMNS)
dataiku.Dataset(OUTPUT_DATASET).write_with_schema(output_df)
dataiku.Dataset(EXCEPTION_DATASET).write_with_schema(exception_df)
print(json.dumps({
    "resolver_version": VERSION,
    "selected_table_artifact_id": selected_table,
    "scope_method": scope_method,
    "current_period": current_period,
    "prior_period": prior_period,
    "output_rows": len(output_df),
    "requested_fields": len(TARGET_FIELDS),
    "missing_fields": len(exception_df),
}, indent=2, default=str))
