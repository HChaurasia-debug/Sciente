from __future__ import annotations

import hashlib
import json
import mimetypes
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional


@dataclass(frozen=True)
class DocumentIngestionRequest:
    document_path: str
    selected_entity_id: str
    source_document_id: str
    document_type: str
    connector_id: str
    requested_by: str
    document_name: Optional[str] = None
    original_file_name: Optional[str] = None
    storage_uri: Optional[str] = None
    reporting_period_label: Optional[str] = None
    document_date: Optional[str] = None
    run_id: Optional[str] = None
    connector_version: Optional[str] = None

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "DocumentIngestionRequest":
        allowed_fields = set(cls.__dataclass_fields__)
        filtered_payload = {
            key: value
            for key, value in payload.items()
            if key in allowed_fields
        }
        return cls(**filtered_payload)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def estimate_token_count(text: str) -> int:
    return max(1, int(len(text.split()) * 1.3)) if text.strip() else 0


def chunk_text(text: str, max_chars: int = 4000, overlap_chars: int = 300) -> list[str]:
    clean = "\n".join(line.rstrip() for line in text.splitlines()).strip()
    if not clean:
        return []

    chunks: list[str] = []
    start = 0
    while start < len(clean):
        end = min(start + max_chars, len(clean))
        chunk = clean[start:end].strip()
        if chunk:
            chunks.append(chunk)
        if end >= len(clean):
            break
        start = max(0, end - overlap_chars)
    return chunks


def extract_pages(path: Path) -> list[dict[str, Any]]:
    suffix = path.suffix.lower()
    if suffix == ".pdf":
        return _extract_pdf_pages(path)
    if suffix in {".txt", ".text"}:
        text = path.read_text(encoding="utf-8", errors="replace")
        return [{"page_number": 1, "text": text, "extractor": "plain_text_v1"}]
    raise ValueError(f"Unsupported document type for ingestion: {path.suffix}")


def _extract_pdf_pages(path: Path) -> list[dict[str, Any]]:
    try:
        import pdfplumber

        pages: list[dict[str, Any]] = []
        with pdfplumber.open(str(path)) as pdf:
            for index, page in enumerate(pdf.pages, start=1):
                pages.append(
                    {
                        "page_number": index,
                        "text": page.extract_text() or "",
                        "extractor": "pdfplumber_0_11",
                    }
                )
        return pages
    except Exception:
        from pypdf import PdfReader

        reader = PdfReader(str(path))
        return [
            {
                "page_number": index,
                "text": page.extract_text() or "",
                "extractor": "pypdf_fallback",
            }
            for index, page in enumerate(reader.pages, start=1)
        ]


def get_latest_run_id(cur: Any, requested_by: str) -> str:
    cur.execute(
        """
        SELECT run_id
        FROM fsre_audit.execution_runs
        WHERE requested_by = %s
        ORDER BY started_at DESC
        LIMIT 1
        """,
        (requested_by,),
    )
    row = cur.fetchone()
    if not row:
        raise ValueError(
            "No existing execution run found. Run 01_create_assessment_run first "
            "or create a document_ingestion runtime request with run_id."
        )
    return str(row["run_id"])


def ingest_document(cur: Any, request: DocumentIngestionRequest) -> dict[str, Any]:
    path = Path(request.document_path).expanduser()
    if not path.exists():
        raise FileNotFoundError(f"Document path does not exist: {path}")
    if not path.is_file():
        raise ValueError(f"Document path is not a file: {path}")

    run_id = request.run_id or get_latest_run_id(cur, request.requested_by)
    file_size = path.stat().st_size
    checksum = sha256_file(path)
    mime_type = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
    file_name = request.original_file_name or path.name
    storage_uri = request.storage_uri or str(path)
    document_name = request.document_name or path.stem

    cur.execute(
        """
        INSERT INTO fsre_ingestion.connector_runs (
            run_id,
            connector_id,
            connector_version,
            mode,
            status,
            connector_config
        )
        VALUES (%s, %s, %s, 'on_demand', 'running', %s::jsonb)
        RETURNING connector_run_id
        """,
        (
            run_id,
            request.connector_id,
            request.connector_version,
            json.dumps(
                {
                    "document_path": str(path),
                    "storage_uri": storage_uri,
                    "file_name": file_name,
                    "document_type": request.document_type,
                }
            ),
        ),
    )
    connector_run_id = cur.fetchone()["connector_run_id"]

    cur.execute(
        """
        INSERT INTO fsre_ingestion.raw_documents (
            run_id,
            connector_run_id,
            connector_id,
            entity_id,
            source_document_id,
            document_type,
            document_name,
            file_name,
            storage_uri,
            mime_type,
            file_size_bytes,
            checksum_sha256,
            reporting_period_label,
            document_date,
            metadata_json
        )
        VALUES (
            %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,
            NULLIF(%s, '')::date,
            %s::jsonb
        )
        RETURNING raw_document_id
        """,
        (
            run_id,
            connector_run_id,
            request.connector_id,
            request.selected_entity_id,
            request.source_document_id,
            request.document_type,
            document_name,
            file_name,
            storage_uri,
            mime_type,
            file_size,
            checksum,
            request.reporting_period_label,
            request.document_date or "",
            json.dumps({"ingestion_method": "dataiku_python_recipe"}),
        ),
    )
    raw_document_id = cur.fetchone()["raw_document_id"]

    pages = extract_pages(path)
    chunk_count = 0
    page_count = len(pages)

    for page in pages:
        page_number = page["page_number"]
        extractor = page["extractor"]
        for chunk in chunk_text(page["text"]):
            chunk_count += 1
            cur.execute(
                """
                INSERT INTO fsre_ingestion.document_text_chunks (
                    raw_document_id,
                    run_id,
                    page_number,
                    chunk_index,
                    section_label,
                    text_content,
                    token_count,
                    extractor_version,
                    metadata_json
                )
                VALUES (%s, %s, %s, %s, NULL, %s, %s, %s, %s::jsonb)
                """,
                (
                    raw_document_id,
                    run_id,
                    page_number,
                    chunk_count,
                    chunk,
                    estimate_token_count(chunk),
                    extractor,
                    json.dumps({"chunking": {"max_chars": 4000, "overlap_chars": 300}}),
                ),
            )

    status = "completed" if chunk_count > 0 else "completed"
    warning_count = 0 if chunk_count > 0 else 1

    cur.execute(
        """
        UPDATE fsre_ingestion.connector_runs
        SET status = %s,
            completed_at = now(),
            records_fetched = 1,
            records_written = %s
        WHERE connector_run_id = %s
        """,
        (status, chunk_count, connector_run_id),
    )

    if chunk_count == 0:
        cur.execute(
            """
            INSERT INTO fsre_audit.data_quality_log (
                run_id,
                entity_id,
                raw_document_id,
                severity,
                check_code,
                check_result,
                message,
                details_json
            )
            VALUES (%s, %s, %s, 'WARN', 'DOCUMENT_TEXT_EMPTY', 'warn', %s, %s::jsonb)
            """,
            (
                run_id,
                request.selected_entity_id,
                raw_document_id,
                "Document was registered but no text chunks were extracted.",
                json.dumps(
                    {
                        "document_path": str(path),
                        "storage_uri": storage_uri,
                        "file_name": file_name,
                        "page_count": page_count,
                    }
                ),
            ),
        )

    cur.execute(
        """
        INSERT INTO fsre_audit.run_events (
            run_id,
            event_stage,
            event_type,
            severity,
            message,
            event_json
        )
        VALUES (%s, 'document_ingestion', 'document_ingested', %s, %s, %s::jsonb)
        """,
        (
            run_id,
            "WARN" if warning_count else "INFO",
            f"Document ingested with {chunk_count} text chunks.",
            json.dumps(
                {
                    "raw_document_id": str(raw_document_id),
                    "source_document_id": request.source_document_id,
                    "file_name": file_name,
                    "storage_uri": storage_uri,
                    "page_count": page_count,
                    "chunk_count": chunk_count,
                    "checksum_sha256": checksum,
                }
            ),
        ),
    )

    cur.execute(
        """
        UPDATE fsre_audit.execution_runs
        SET input_count = GREATEST(input_count, 1),
            warning_count = warning_count + %s
        WHERE run_id = %s
        """,
        (warning_count, run_id),
    )

    return {
        "run_id": run_id,
        "connector_run_id": connector_run_id,
        "raw_document_id": raw_document_id,
        "entity_id": request.selected_entity_id,
        "source_document_id": request.source_document_id,
        "document_name": document_name,
        "file_name": file_name,
        "storage_uri": storage_uri,
        "file_size_bytes": file_size,
        "checksum_sha256": checksum,
        "page_count": page_count,
        "chunk_count": chunk_count,
        "status": status,
    }
