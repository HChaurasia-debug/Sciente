"""Placeholder for FRI_13_RUN_STRUCTURAL_ANOMALIES."""
raise NotImplementedError("Install the implementation for FRI_13_RUN_STRUCTURAL_ANOMALIES")
