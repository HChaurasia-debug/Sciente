BEGIN;

CREATE SCHEMA IF NOT EXISTS financial_risk_intelligence;

CREATE TABLE IF NOT EXISTS financial_risk_intelligence.runtime_settings (
    setting_key TEXT PRIMARY KEY,
    setting_value TEXT NOT NULL,
    is_secret BOOLEAN NOT NULL DEFAULT FALSE,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

DELETE FROM financial_risk_intelligence.runtime_settings
 WHERE setting_key IN (
    'fri_groq_api_key', 'fri_groq_base_url', 'fri_groq_model',
    'fri_groq_timeout_seconds', 'fri_bedrock_api_key',
    'fri_bedrock_region', 'fri_bedrock_model', 'fri_bedrock_timeout_seconds'
 );

INSERT INTO financial_risk_intelligence.runtime_settings
    (setting_key, setting_value, is_secret, active, updated_at)
VALUES
    ('fri_llm_provider', 'gemini', FALSE, TRUE, CURRENT_TIMESTAMP),
    ('fri_gemini_base_url', 'https://generativelanguage.googleapis.com/v1beta/openai', FALSE, TRUE, CURRENT_TIMESTAMP),
    ('fri_gemini_model', 'gemini-3.5-flash', FALSE, TRUE, CURRENT_TIMESTAMP),
    ('fri_gemini_timeout_seconds', '120', FALSE, TRUE, CURRENT_TIMESTAMP),
    ('fri_llm_financial_resolution_enabled', 'true', FALSE, TRUE, CURRENT_TIMESTAMP),
    ('fri_gemini_api_key', '<YOUR_NEW_GEMINI_API_KEY>', TRUE, TRUE, CURRENT_TIMESTAMP)
ON CONFLICT (setting_key) DO UPDATE SET
    setting_value = EXCLUDED.setting_value,
    is_secret = EXCLUDED.is_secret,
    active = EXCLUDED.active,
    updated_at = CURRENT_TIMESTAMP;

COMMIT;

SELECT setting_key,
       CASE WHEN is_secret THEN '[SECRET PRESENT]' ELSE setting_value END AS effective_value,
       is_secret, active, updated_at
  FROM financial_risk_intelligence.runtime_settings
 WHERE setting_key = 'fri_llm_provider' OR setting_key LIKE 'fri_gemini_%'
 ORDER BY setting_key;
