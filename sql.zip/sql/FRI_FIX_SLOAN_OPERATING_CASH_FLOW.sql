-- Sloan prerequisite: persist operating cash flow from the cash reconciliation.
-- Formula: operating = net change in cash - investing cash flow - financing cash flow.
-- This is used only after the higher-priority direct and generated-cash rules fail.
BEGIN;

INSERT INTO financial_risk_intelligence.financial_template_rules
 (rule_key,template_key,target_concept_key,operator,priority,output_sign,active,approval_status)
VALUES
 ('CFO_FROM_NET_CHANGE','MANUFACTURING_INDUSTRIALS_GENERIC','operating_cash_flow',
  'LINEAR_COMBINATION',30,'AS_REPORTED',true,'APPROVED')
ON CONFLICT(rule_key) DO UPDATE SET
  template_key=EXCLUDED.template_key,
  target_concept_key=EXCLUDED.target_concept_key,
  operator=EXCLUDED.operator,
  priority=EXCLUDED.priority,
  output_sign=EXCLUDED.output_sign,
  active=true,
  approval_status='APPROVED',
  updated_at=now();

INSERT INTO financial_risk_intelligence.financial_rule_components
 (rule_key,component_concept_key,coefficient,component_sign,component_order)
VALUES
 ('CFO_FROM_NET_CHANGE','net_change_cash',1,'AS_REPORTED',1),
 ('CFO_FROM_NET_CHANGE','investing_cash_flow',-1,'AS_REPORTED',2),
 ('CFO_FROM_NET_CHANGE','financing_cash_flow',-1,'AS_REPORTED',3)
ON CONFLICT(rule_key,component_concept_key) DO UPDATE SET
  coefficient=EXCLUDED.coefficient,
  component_sign=EXCLUDED.component_sign,
  component_order=EXCLUDED.component_order;

COMMIT;

-- Verification: this view must return three rows for CFO_FROM_NET_CHANGE.
SELECT rule_key,target_concept_key,operator,priority,output_sign,
       component_concept_key,coefficient,component_sign,component_order
FROM financial_risk_intelligence.manufacturing_derivation_configuration
WHERE rule_key='CFO_FROM_NET_CHANGE'
ORDER BY component_order;
