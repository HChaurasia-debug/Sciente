-- AMOS Group Limited is a commercial / industrial entity, not a bank.
-- This manual governed assignment is intentionally protected from the
-- automatic annual-report sector classifier.

BEGIN;

WITH updated AS (
    UPDATE financial_risk_intelligence.entity_sector_assignments
       SET sector_key = 'manufacturing',
           valid_to = NULL,
           source = 'MANUAL',
           confidence = 1.000000,
           active = true
     WHERE entity_id = '14e736aa-25b3-42f8-ba0f-4016984330a4'
       AND active = true
       AND (valid_to IS NULL OR valid_to >= CURRENT_DATE)
    RETURNING entity_id
)
INSERT INTO financial_risk_intelligence.entity_sector_assignments
    (entity_id, sector_key, valid_from, valid_to, source, confidence, active)
SELECT
    '14e736aa-25b3-42f8-ba0f-4016984330a4',
    'manufacturing',
    CURRENT_DATE,
    NULL,
    'MANUAL',
    1.000000,
    true
WHERE NOT EXISTS (SELECT 1 FROM updated)
ON CONFLICT (entity_id, valid_from) DO UPDATE
SET sector_key = EXCLUDED.sector_key,
    valid_to = NULL,
    source = 'MANUAL',
    confidence = 1.000000,
    active = true;

COMMIT;

-- Expected: one active MANUAL manufacturing assignment.
SELECT entity_id, sector_key, valid_from, valid_to, source, confidence, active
FROM financial_risk_intelligence.entity_sector_assignments
WHERE entity_id = '14e736aa-25b3-42f8-ba0f-4016984330a4'
ORDER BY valid_from DESC;
