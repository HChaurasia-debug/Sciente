"""Placeholder for FRI_17_RANK_FLAGS."""
raise NotImplementedError("Install the implementation for FRI_17_RANK_FLAGS")
