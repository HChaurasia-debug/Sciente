"""Resolve every sector template with one database-configured recipe.

Inputs: FRI_RESOLVED_FINANCIAL_FACTS, FRI_ENTITY_SECTOR_ASSIGNMENTS,
FRI_SECTOR_TEMPLATE_CONFIGURATION, FRI_SECTOR_DERIVATION_CONFIGURATION.
Outputs: FRI_SECTOR_TEMPLATE_VALUES, FRI_SECTOR_TEMPLATE_EXCEPTIONS.
"""
from __future__ import annotations

import datetime as dt
import json
import math
from typing import Any, Dict, List, Optional, Tuple

import dataiku
import pandas as pd

FACTS = "FRI_RESOLVED_FINANCIAL_FACTS"
ASSIGNMENTS = "FRI_ENTITY_SECTOR_ASSIGNMENTS"
FIELDS = "FRI_SECTOR_TEMPLATE_CONFIGURATION"
RULES = "FRI_SECTOR_DERIVATION_CONFIGURATION"
VALUES = "FRI_SECTOR_TEMPLATE_VALUES"
EXCEPTIONS = "FRI_SECTOR_TEMPLATE_EXCEPTIONS"
VERSION = "sector-template-db-rules-2.2.0"
IDENTITY = ["tenant_id", "entity_id", "assessment_run_id", "source_document_id", "scope", "currency", "unit"]
# Scope, currency and unit describe a fact; they must not split one filing
# into multiple sector-template runs.  Doing so allowed the webapp to merge
# available values while Recipe 05 saw several incomplete fragments.
FILING_IDENTITY = ["tenant_id", "entity_id", "assessment_run_id", "source_document_id"]
VALUE_COLUMNS = [*IDENTITY, "sector_key", "sector_name", "profile_type", "template_key", "statement_type",
                 "field_key", "concept_key", "field_label", "display_order", "applicability_status",
                 "current_period", "prior_period", "current_value", "prior_value", "confidence",
                 "resolution_method", "current_rule_key", "prior_rule_key", "current_lineage_json",
                 "prior_lineage_json", "resolver_version", "resolved_at"]
EXCEPTION_COLUMNS = [*IDENTITY, "sector_key", "template_key", "statement_type", "field_key", "concept_key",
                     "field_label", "exception_code", "message", "resolver_version", "created_at"]


def dataset(name: str) -> pd.DataFrame:
    try:
        # PostgreSQL configuration views can expose nullable integer columns
        # (for example component_order on DIRECT rules). Pandas inference keeps
        # these as nullable values; Dataiku's strict integer reader rejects NA.
        frame = dataiku.Dataset(name).get_dataframe(infer_with_pandas=True)
    except (TypeError, ValueError):
        frame = dataiku.Dataset(name).get_dataframe()
    frame = frame.copy()
    frame.columns = [str(column).strip().lower() for column in frame.columns]
    return frame


def text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    result = str(value).strip()
    return "" if result.lower() in {"", "nan", "none", "null"} else result


def number(value: Any) -> Optional[float]:
    if value is None:
        return None
    try:
        result = float(value)
        return result if math.isfinite(result) else None
    except (TypeError, ValueError):
        raw = text(value).replace(",", "")
        negative = raw.startswith("(") and raw.endswith(")")
        try:
            result = float(raw.strip("()"))
            return -result if negative else result
        except ValueError:
            return None


def best_facts(rows: List[Dict[str, Any]], column: str) -> Dict[str, Dict[str, Any]]:
    chosen: Dict[str, Dict[str, Any]] = {}
    # A filing may emit both consolidated Group and Company facts.  Resolve
    # each concept from Group/Consolidated facts whenever at least one exists.
    grouped_scope = {}
    for item in rows:
        key = text(item.get("concept_key"))
        scope = text(item.get("scope") or item.get("entity_scope") or item.get("column_scope")).upper()
        if key and ("GROUP" in scope or "CONSOLIDATED" in scope):
            grouped_scope[key] = True
    for row in rows:
        concept, value = text(row.get("concept_key")), number(row.get(column))
        if not concept or value is None:
            continue
        # Legacy period pivots are diagnostics only. They may contain note
        # rows or repeated placeholders and must never feed the governed
        # sector template when a source-backed fact is available.
        if text(row.get("resolution_method")).upper() == "LEGACY_PERIOD_PIVOT":
            continue
        scope = text(row.get("scope") or row.get("entity_scope") or row.get("column_scope")).upper()
        if grouped_scope.get(concept) and not ("GROUP" in scope or "CONSOLIDATED" in scope):
            continue
        score = number(row.get("confidence")) or 0.0
        method = text(row.get("resolution_method")).upper()
        # Prefer source-backed/direct facts over legacy pivots and synthetic
        # configuration rows when confidence is otherwise equal.
        method_bonus = {
            "DIRECT": 100,
            "PYTHON_DATABASE_CONFIGURATION": 80,
            "DERIVED": 60,
            "CANONICAL_SOURCE_FALLBACK_ACCOUNTING_SIGN_REPAIR": 50,
            "LEGACY_PERIOD_PIVOT": -100,
        }.get(method, 0)
        candidate = {"value": value, "confidence": score, "rank": score * 1000 + method_bonus,
                     "source": text(row.get("evidence") or row.get("canonical_label"))}
        if concept not in chosen or candidate["rank"] > chosen[concept].get("rank", -1):
            chosen[concept] = candidate
    return chosen


def parse_rules(frame: pd.DataFrame, sector: str) -> Dict[str, List[Dict[str, Any]]]:
    selected = frame[frame["sector_key"].astype(str).eq(sector)]
    grouped: Dict[str, Dict[str, Dict[str, Any]]] = {}
    for row in selected.to_dict(orient="records"):
        target, key = text(row.get("target_concept_key")), text(row.get("rule_key"))
        rule = grouped.setdefault(target, {}).setdefault(key, {
            "key": key, "operator": text(row.get("operator")).upper(), "priority": int(number(row.get("priority")) or 0),
            "output_sign": text(row.get("output_sign") or "AS_REPORTED").upper(), "components": [],
        })
        component = text(row.get("component_concept_key"))
        if component:
            rule["components"].append({"concept": component, "coefficient": number(row.get("coefficient")) or 0.0,
                                       "sign": text(row.get("component_sign") or "AS_REPORTED").upper(),
                                       "order": int(number(row.get("component_order")) or 0)})
    output = {}
    for target, rules in grouped.items():
        output[target] = sorted(rules.values(), key=lambda item: (item["priority"], item["key"]))
        for rule in output[target]:
            rule["components"].sort(key=lambda item: item["order"])
    return output


def apply_rule(target: str, rule: Dict[str, Any], available: Dict[str, Dict[str, Any]]) -> Optional[Tuple[float, float, List[Dict[str, Any]]]]:
    components = rule["components"]
    if rule["operator"] == "DIRECT":
        components = [{"concept": target, "coefficient": 1.0, "sign": "AS_REPORTED", "order": 1}]
    if rule["operator"] not in {"DIRECT", "LINEAR_COMBINATION"} or not components:
        return None
    if any(item["concept"] not in available for item in components):
        return None
    total, scores, lineage = 0.0, [], []
    for item in components:
        fact = available[item["concept"]]
        normalized = abs(fact["value"]) if item["sign"] == "ABSOLUTE" else fact["value"]
        total += normalized * item["coefficient"]
        scores.append(fact["confidence"])
        lineage.append({"concept_key": item["concept"], "reported_value": fact["value"], "normalized_value": normalized,
                        "coefficient": item["coefficient"], "component_sign": item["sign"], "source": fact.get("source", "")})
    if rule["output_sign"] == "ABSOLUTE":
        total = abs(total)
    return total, min(scores), lineage


def resolve(fields: List[Dict[str, Any]], rules: Dict[str, List[Dict[str, Any]]], facts: Dict[str, Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    available, resolved = dict(facts), {}
    pending = {text(field["concept_key"]) for field in fields if text(field.get("applicability_status")).upper() != "NOT_APPLICABLE"}
    for _ in range(len(pending) + 1):
        changed = False
        for target in list(pending):
            for rule in rules.get(target, []):
                outcome = apply_rule(target, rule, available)
                if outcome is None:
                    continue
                value, score, lineage = outcome
                resolved[target] = {"value": value, "confidence": score, "rule": rule["key"],
                                    "method": "DIRECT" if rule["operator"] == "DIRECT" else "DERIVED", "lineage": lineage}
                available[target] = {"value": value, "confidence": score, "source": rule["key"]}
                pending.remove(target)
                changed = True
                break
        if not changed:
            break
    return resolved


def derive_depreciation_amortization(
    facts: Dict[str, Dict[str, Any]],
) -> Optional[Dict[str, Any]]:
    """Build governed D&A from canonical disclosed components.

    PP&E depreciation is preferred because annual reports commonly include
    right-of-use depreciation inside that total. Separate ROU and intangible
    components are summed only when no PP&E aggregate is available.
    """
    ppe = facts.get("depreciation_ppe")
    if ppe is not None:
        value = abs(number(ppe.get("value")) or 0.0)
        if value:
            return {
                "value": value,
                "confidence": number(ppe.get("confidence")) or 0.0,
                "rule": "CANONICAL_DA_PPE_FALLBACK",
                "method": "DERIVED",
                "lineage": [{
                    "concept_key": "depreciation_ppe",
                    "reported_value": ppe.get("value"),
                    "normalized_value": value,
                    "coefficient": 1.0,
                    "component_sign": "ABSOLUTE",
                    "source": ppe.get("source", ""),
                }],
            }
    component_keys = ["depreciation_rou", "amortization_intangibles"]
    components = [(key, facts[key]) for key in component_keys if key in facts]
    if not components:
        return None
    lineage = []
    values = []
    confidence = []
    for key, fact in components:
        reported = number(fact.get("value"))
        if reported is None:
            continue
        normalized = abs(reported)
        values.append(normalized)
        confidence.append(number(fact.get("confidence")) or 0.0)
        lineage.append({
            "concept_key": key,
            "reported_value": reported,
            "normalized_value": normalized,
            "coefficient": 1.0,
            "component_sign": "ABSOLUTE",
            "source": fact.get("source", ""),
        })
    if not values:
        return None
    return {
        "value": sum(values),
        "confidence": min(confidence),
        "rule": "CANONICAL_DA_COMPONENT_FALLBACK",
        "method": "DERIVED",
        "lineage": lineage,
    }


def assignment_index(frame: pd.DataFrame) -> Dict[str, str]:
    if frame.empty:
        return {}
    active = frame if "active" not in frame.columns else frame[frame["active"].astype(str).str.lower().isin(["true", "1", "yes"])]
    active = active.sort_values("valid_from" if "valid_from" in active.columns else "entity_id").drop_duplicates("entity_id", keep="last")
    return {text(row["entity_id"]): text(row["sector_key"]) for row in active.to_dict(orient="records")}


def preferred_coordinate(group: pd.DataFrame, column: str) -> str:
    """Return filing metadata from the Group/consolidated facts when present."""
    if column not in group.columns:
        return ""
    preferred = group
    if "scope" in group.columns:
        group_rows = group[group["scope"].astype(str).str.upper().str.contains("GROUP|CONSOLIDATED", na=False)]
        if not group_rows.empty:
            preferred = group_rows
    values = [text(value) for value in preferred[column].tolist()]
    values = [value for value in values if value]
    return values[0] if values else ""


def main() -> None:
    facts, assignments, field_config, rule_config = dataset(FACTS), dataset(ASSIGNMENTS), dataset(FIELDS), dataset(RULES)
    required = set(IDENTITY + ["concept_key", "current_period", "prior_period", "current_value", "prior_value"])
    missing = required.difference(facts.columns)
    if missing:
        raise RuntimeError("Canonical facts are missing: " + ", ".join(sorted(missing)))
    sectors = assignment_index(assignments)
    now, output, errors = dt.datetime.now(dt.timezone.utc).isoformat(), [], []
    group_columns = FILING_IDENTITY
    for identity, group in facts.groupby(group_columns, dropna=False, sort=False):
        coordinates = dict(zip(group_columns, identity if isinstance(identity, tuple) else (identity,)))
        coordinates.update({
            "scope": preferred_coordinate(group, "scope"),
            "currency": preferred_coordinate(group, "currency"),
            "unit": preferred_coordinate(group, "unit"),
        })
        sector = next((text(row.get("sector_key")) for row in group.to_dict(orient="records") if text(row.get("sector_key"))), "")
        sector = sector or sectors.get(text(coordinates.get("entity_id")), "")
        if not sector:
            errors.append({**coordinates, "sector_key": "", "template_key": "", "statement_type": "", "field_key": "", "concept_key": "",
                           "field_label": "", "exception_code": "SECTOR_UNASSIGNED", "message": "No active sector assignment exists for the entity",
                           "resolver_version": VERSION, "created_at": now})
            continue
        selected = field_config[field_config["sector_key"].astype(str).eq(sector)].sort_values(["display_order", "field_key"])
        if selected.empty:
            errors.append({**coordinates, "sector_key": sector, "template_key": "", "statement_type": "", "field_key": "", "concept_key": "",
                           "field_label": "", "exception_code": "SECTOR_CONFIGURATION_MISSING", "message": "No active template configuration exists",
                           "resolver_version": VERSION, "created_at": now})
            continue
        fields = selected.drop_duplicates("concept_key").to_dict(orient="records")
        rules, rows = parse_rules(rule_config, sector), group.to_dict(orient="records")
        current_facts = best_facts(rows, "current_value")
        prior_facts = best_facts(rows, "prior_value")
        current, prior = resolve(fields, rules, current_facts), resolve(fields, rules, prior_facts)
        if "depreciation_amortization" not in current:
            derived = derive_depreciation_amortization(current_facts)
            if derived:
                current["depreciation_amortization"] = derived
        if "depreciation_amortization" not in prior:
            derived = derive_depreciation_amortization(prior_facts)
            if derived:
                prior["depreciation_amortization"] = derived
        current_period = next((text(row.get("current_period")) for row in rows if text(row.get("current_period"))), "")
        prior_period = next((text(row.get("prior_period")) for row in rows if text(row.get("prior_period"))), "")
        for field in fields:
            concept, status = text(field["concept_key"]), text(field.get("applicability_status")).upper()
            base = {**coordinates, "sector_key": sector, "sector_name": text(field.get("sector_name")), "profile_type": text(field.get("profile_type")),
                    "template_key": text(field["template_key"]), "statement_type": text(field["statement_type"]), "field_key": text(field["field_key"]),
                    "concept_key": concept, "field_label": text(field["display_label"]), "display_order": int(number(field["display_order"]) or 0),
                    "applicability_status": status, "current_period": current_period, "prior_period": prior_period}
            if status == "NOT_APPLICABLE":
                output.append({**base, "current_value": None, "prior_value": None, "confidence": 1.0, "resolution_method": "NOT_APPLICABLE",
                               "current_rule_key": "", "prior_rule_key": "", "current_lineage_json": "[]", "prior_lineage_json": "[]",
                               "resolver_version": VERSION, "resolved_at": now})
                continue
            cur, prev = current.get(concept), prior.get(concept)
            if cur is None or prev is None:
                # Keep every configured field in the output, even when the
                # source cannot yet resolve it. The webapp must show a clear
                # Not reported/MISSING row rather than silently omitting
                # long-term debt, shares outstanding, or any other field.
                output.append({**base, "current_value": None, "prior_value": None,
                               "confidence": 0.0, "resolution_method": "MISSING",
                               "current_rule_key": "", "prior_rule_key": "",
                               "current_lineage_json": "[]", "prior_lineage_json": "[]",
                               "resolver_version": VERSION, "resolved_at": now})
                if status == "REQUIRED":
                    errors.append({**{key: base.get(key, "") for key in IDENTITY}, "sector_key": sector, "template_key": base["template_key"],
                                   "statement_type": base["statement_type"], "field_key": base["field_key"], "concept_key": concept,
                                   "field_label": base["field_label"], "exception_code": "REQUIRED_DERIVATION_UNAVAILABLE",
                                   "message": "An approved same-coordinate current/prior derivation is incomplete", "resolver_version": VERSION, "created_at": now})
                continue
            output.append({**base, "current_value": cur["value"], "prior_value": prev["value"], "confidence": min(cur["confidence"], prev["confidence"]),
                           "resolution_method": cur["method"] if cur["method"] == prev["method"] else "MIXED",
                           "current_rule_key": cur["rule"], "prior_rule_key": prev["rule"],
                           "current_lineage_json": json.dumps(cur["lineage"], ensure_ascii=False), "prior_lineage_json": json.dumps(prev["lineage"], ensure_ascii=False),
                           "resolver_version": VERSION, "resolved_at": now})
    exception_frame = pd.DataFrame(errors, columns=EXCEPTION_COLUMNS)
    dataiku.Dataset(EXCEPTIONS).write_with_schema(exception_frame)
    # Data-quality exceptions do not fail the complete multi-entity build.
    # Publish only values supported by approved same-coordinate facts/rules;
    # affected templates remain incomplete and are blocked by the webapp,
    # while valid entities continue to scoring.
    dataiku.Dataset(VALUES).write_with_schema(pd.DataFrame(output, columns=VALUE_COLUMNS))
    if not exception_frame.empty:
        counts = exception_frame["exception_code"].value_counts().to_dict()
        print(f"Sector template completed with {len(exception_frame)} exception(s): {counts}")


main()
