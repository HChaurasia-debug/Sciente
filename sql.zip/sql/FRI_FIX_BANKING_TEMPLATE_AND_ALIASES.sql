-- Idempotent banking-template repair.
-- Restores all 18 FINANCIAL_INSTITUTION_GENERIC fields, direct rules and
-- BANK-scoped aliases without changing any commercial/manufacturing template.

BEGIN;

INSERT INTO financial_risk_intelligence.financial_templates
    (template_key, template_name, sector_key, active)
VALUES
    ('FINANCIAL_INSTITUTION_GENERIC',
     'Financial inputs - Banking and financial institutions', 'BANK', true)
ON CONFLICT (template_key) DO UPDATE
SET template_name = EXCLUDED.template_name,
    sector_key = EXCLUDED.sector_key,
    active = true,
    updated_at = now();

INSERT INTO financial_risk_intelligence.financial_template_fields
    (template_key, field_key, concept_key, display_label, statement_type,
     display_order, required, active)
VALUES
 ('FINANCIAL_INSTITUTION_GENERIC','total_income','total_income','Total income','INCOME_STATEMENT',10,true,true),
 ('FINANCIAL_INSTITUTION_GENERIC','net_interest_income','net_interest_income','Net interest income','INCOME_STATEMENT',20,true,true),
 ('FINANCIAL_INSTITUTION_GENERIC','non_interest_income','non_interest_income','Non-interest income','INCOME_STATEMENT',30,true,true),
 ('FINANCIAL_INSTITUTION_GENERIC','operating_expenses','operating_expenses','Operating expenses','INCOME_STATEMENT',40,true,true),
 ('FINANCIAL_INSTITUTION_GENERIC','provisions_impairment','provisions_impairment','Provisions / impairment (ECL charge)','INCOME_STATEMENT',50,true,true),
 ('FINANCIAL_INSTITUTION_GENERIC','profit_before_tax','profit_before_tax','Profit before tax','INCOME_STATEMENT',60,true,true),
 ('FINANCIAL_INSTITUTION_GENERIC','net_profit','net_profit','Net profit','INCOME_STATEMENT',70,true,true),
 ('FINANCIAL_INSTITUTION_GENERIC','gross_loans_advances','gross_loans_advances','Gross loans & advances','BALANCE_SHEET',110,true,true),
 ('FINANCIAL_INSTITUTION_GENERIC','stage3_npa','stage3_npa','Stage-3 / NPA loans','BALANCE_SHEET',120,true,true),
 ('FINANCIAL_INSTITUTION_GENERIC','ecl_balance','ecl_balance','Loan-loss provision / ECL balance','BALANCE_SHEET',130,true,true),
 ('FINANCIAL_INSTITUTION_GENERIC','investments','investments','Investments','BALANCE_SHEET',140,true,true),
 ('FINANCIAL_INSTITUTION_GENERIC','total_assets','total_assets','Total assets','BALANCE_SHEET',150,true,true),
 ('FINANCIAL_INSTITUTION_GENERIC','customer_deposits','customer_deposits','Customer deposits','BALANCE_SHEET',160,true,true),
 ('FINANCIAL_INSTITUTION_GENERIC','borrowings','borrowings','Borrowings','BALANCE_SHEET',170,true,true),
 ('FINANCIAL_INSTITUTION_GENERIC','total_liabilities','total_liabilities','Total liabilities','BALANCE_SHEET',180,true,true),
 ('FINANCIAL_INSTITUTION_GENERIC','total_shareholders_equity','total_shareholders_equity','Shareholders'' equity','BALANCE_SHEET',190,true,true),
 ('FINANCIAL_INSTITUTION_GENERIC','cet1_ratio','cet1_ratio','CET-1 / capital ratio (%)','BALANCE_SHEET',200,true,true),
 ('FINANCIAL_INSTITUTION_GENERIC','operating_cash_flow','operating_cash_flow','Operating cash flow','CASH_FLOW_STATEMENT',310,false,true)
ON CONFLICT (template_key, field_key) DO UPDATE
SET concept_key = EXCLUDED.concept_key,
    display_label = EXCLUDED.display_label,
    statement_type = EXCLUDED.statement_type,
    display_order = EXCLUDED.display_order,
    required = EXCLUDED.required,
    active = true,
    updated_at = now();

UPDATE financial_risk_intelligence.sector_profiles
SET template_key = 'FINANCIAL_INSTITUTION_GENERIC',
    profile_type = CASE WHEN sector_key = 'banking' THEN 'BANK' ELSE profile_type END,
    active = true,
    updated_at = now()
WHERE sector_key IN ('banking', 'financial_institution_base');

-- Banking uses the bank-specific model only. Commercial manipulation and
-- solvency models depend on concepts that banks do not report (COGS,
-- inventory, working capital, EBIT), so they are explicitly not applicable.
INSERT INTO financial_risk_intelligence.sector_model_configuration
    (sector_key, model_key, enabled, weight, parameters, disabled_reason,
     configuration_version, active)
SELECT
    'banking', model.model_key,
    model.model_key = 'bank_metrics',
    1,
    '{}'::jsonb,
    CASE WHEN model.model_key = 'bank_metrics' THEN ''
         ELSE 'Commercial-company model is not applicable to regulated banks' END,
    '2026.2', true
FROM financial_risk_intelligence.forensic_models model
ON CONFLICT (sector_key, model_key) DO UPDATE
SET enabled = EXCLUDED.enabled,
    weight = EXCLUDED.weight,
    parameters = EXCLUDED.parameters,
    disabled_reason = EXCLUDED.disabled_reason,
    configuration_version = EXCLUDED.configuration_version,
    active = true;

-- Make every banking field directly consumable from its canonical fact.
INSERT INTO financial_risk_intelligence.financial_template_rules
    (rule_key, template_key, target_concept_key, operator, priority,
     output_sign, active, approval_status)
SELECT
    upper(substr(md5(f.template_key || ':' || f.concept_key), 1, 20)),
    f.template_key, f.concept_key, 'DIRECT', 10,
    CASE WHEN f.concept_key IN
        ('net_profit','profit_before_tax','operating_cash_flow',
         'provisions_impairment','total_shareholders_equity')
      THEN 'AS_REPORTED' ELSE 'ABSOLUTE' END,
    true, 'APPROVED'
FROM financial_risk_intelligence.financial_template_fields f
WHERE f.template_key = 'FINANCIAL_INSTITUTION_GENERIC' AND f.active
ON CONFLICT (template_key, target_concept_key, priority) DO UPDATE
SET operator = 'DIRECT',
    output_sign = EXCLUDED.output_sign,
    active = true,
    approval_status = 'APPROVED',
    updated_at = now();

-- Safe accounting fallback: non-interest income = total income - net interest
-- income. The DIRECT rule remains higher priority whenever it is disclosed.
DELETE FROM financial_risk_intelligence.financial_template_rules
WHERE template_key = 'FINANCIAL_INSTITUTION_GENERIC'
  AND target_concept_key = 'non_interest_income'
  AND priority = 20
  AND rule_key <> 'BANK_NON_INTEREST_INCOME_DERIVED';

INSERT INTO financial_risk_intelligence.financial_template_rules
    (rule_key, template_key, target_concept_key, operator, priority,
     output_sign, active, approval_status)
VALUES
    ('BANK_NON_INTEREST_INCOME_DERIVED', 'FINANCIAL_INSTITUTION_GENERIC',
     'non_interest_income', 'LINEAR_COMBINATION', 20,
     'AS_REPORTED', true, 'APPROVED')
ON CONFLICT (rule_key) DO UPDATE
SET operator = EXCLUDED.operator,
    priority = EXCLUDED.priority,
    output_sign = EXCLUDED.output_sign,
    active = true,
    approval_status = 'APPROVED',
    updated_at = now();

INSERT INTO financial_risk_intelligence.financial_rule_components
    (rule_key, component_concept_key, coefficient, component_sign, component_order)
VALUES
    ('BANK_NON_INTEREST_INCOME_DERIVED','total_income',1,'AS_REPORTED',1),
    ('BANK_NON_INTEREST_INCOME_DERIVED','net_interest_income',-1,'AS_REPORTED',2)
ON CONFLICT (rule_key, component_concept_key) DO UPDATE
SET coefficient = EXCLUDED.coefficient,
    component_sign = EXCLUDED.component_sign,
    component_order = EXCLUDED.component_order;

-- BANK-only aliases, including captions commonly split by PDF line wrapping.
-- Fee/commission income is a component, not the total non-interest income.
-- Remove the older direct mapping so the governed total-minus-NII rule runs.
UPDATE financial_risk_intelligence.financial_concept_aliases
SET active = false,
    approval_status = 'REJECTED',
    updated_at = now()
WHERE concept_key = 'non_interest_income'
  AND COALESCE(sector_key, '') = 'BANK'
  AND normalized_alias_text IN (
      financial_risk_intelligence.normalize_financial_alias_text('Net fee and'),
      financial_risk_intelligence.normalize_financial_alias_text('Net fee and commission income'),
      financial_risk_intelligence.normalize_financial_alias_text('Fee and commission income'),
      financial_risk_intelligence.normalize_financial_alias_text('Fees and commissions')
  );

WITH seed(concept_key, alias_text, priority) AS (
    VALUES
      ('total_income','Total income',1),
      ('net_interest_income','Net interest income',1),
      ('non_interest_income','Non-interest income',1),
      ('operating_expenses','Operating expenses',1),
      ('operating_expenses','Total operating expenses',5),
      ('provisions_impairment','Allowances for credit and other losses',1),
      ('provisions_impairment','Credit impairment losses',5),
      ('provisions_impairment','Expected credit losses',10),
      ('profit_before_tax','Profit before tax',1),
      ('profit_before_tax','Profit before taxation',2),
      ('profit_before_tax','Profit before',15),
      ('net_profit','Net profit',1),
      ('gross_loans_advances','Loans and advances to customers',1),
      ('gross_loans_advances','Gross loans and advances',5),
      ('stage3_npa','Stage 3 loans',1),
      ('stage3_npa','Non-performing loans',5),
      ('stage3_npa','Non-performing assets',10),
      ('stage3_npa','Non-Performing Loans (impaired)',11),
      ('stage3_npa','NPL',15),
      ('ecl_balance','Loss allowance',1),
      ('ecl_balance','Expected credit loss allowance',5),
      ('ecl_balance','ECL balance',10),
      ('ecl_balance','Total ECL',1),
      ('investments','Investment securities',1),
      ('customer_deposits','Deposits and balances from customers',1),
      ('customer_deposits','Customer deposits',5),
      ('borrowings','Borrowings',1),
      ('borrowings','Due to banks',5),
      ('cet1_ratio','Common Equity Tier 1 capital adequacy ratio',1),
      ('cet1_ratio','Common Equity Tier 1 (CET-1)',1),
      ('cet1_ratio','Common Equity Tier 1',2),
      ('cet1_ratio','CET1 ratio',3),
      ('cet1_ratio','CET-1 ratio',4),
      ('operating_cash_flow','Net cash from operating activities',1)
), normalized AS (
    SELECT concept_key, alias_text,
           financial_risk_intelligence.normalize_financial_alias_text(alias_text) normalized_alias_text,
           priority
    FROM seed
)
INSERT INTO financial_risk_intelligence.financial_concept_aliases
    (concept_key, alias_text, normalized_alias_text, sector_key, priority,
     active, approval_status, approved_by, approved_at)
SELECT concept_key, alias_text, normalized_alias_text, 'BANK', priority,
       true, 'APPROVED', 'BANK_TEMPLATE_REPAIR', now()
FROM normalized
ON CONFLICT DO NOTHING;

-- Reactivate/update aliases that already existed but were disabled or stale.
WITH seed(concept_key, alias_text, priority) AS (
    VALUES
      ('provisions_impairment','Allowances for credit and other losses',1),
      ('profit_before_tax','Profit before',15),
      ('stage3_npa','Non-performing loans',5),
      ('stage3_npa','Non-Performing Loans (impaired)',11),
      ('ecl_balance','Loss allowance',1),
      ('ecl_balance','Total ECL',1),
      ('cet1_ratio','Common Equity Tier 1 capital adequacy ratio',1),
      ('cet1_ratio','Common Equity Tier 1 (CET-1)',1)
)
UPDATE financial_risk_intelligence.financial_concept_aliases target
SET alias_text = seed.alias_text,
    priority = seed.priority,
    active = true,
    approval_status = 'APPROVED',
    approved_by = 'BANK_TEMPLATE_REPAIR',
    approved_at = now(),
    updated_at = now()
FROM seed
WHERE target.concept_key = seed.concept_key
  AND target.normalized_alias_text =
      financial_risk_intelligence.normalize_financial_alias_text(seed.alias_text)
  AND COALESCE(target.sector_key, '') = 'BANK';

COMMIT;

-- Verification: expect 18 active fields and at least 18 active DIRECT rules.
SELECT count(*) AS active_banking_template_fields
FROM financial_risk_intelligence.financial_template_fields
WHERE template_key = 'FINANCIAL_INSTITUTION_GENERIC' AND active;

SELECT operator, count(*) AS active_rule_count
FROM financial_risk_intelligence.financial_template_rules
WHERE template_key = 'FINANCIAL_INSTITUTION_GENERIC'
  AND active AND approval_status = 'APPROVED'
GROUP BY operator ORDER BY operator;

SELECT concept_key, alias_text, priority
FROM financial_risk_intelligence.approved_financial_concept_aliases
WHERE sector_key = 'BANK'
ORDER BY concept_key, priority, alias_text;
