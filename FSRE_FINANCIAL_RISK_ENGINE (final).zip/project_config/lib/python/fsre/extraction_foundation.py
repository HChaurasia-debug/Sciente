from __future__ import annotations

import json
import re
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any, Optional


PERIOD_SUFFIXES = {
    ".current": "current",
    ".prior": "prior",
    ".next_period": "next_period",
    ".historical": "historical",
}

NARRATIVE_PREFIXES = (
    "notes.",
    "related_party",
    "ownership",
    "governance",
    "auditor",
    "events.",
    "sgx_announcements",
)

FINANCIAL_PREFIX = "financials."
NARRATIVE_EVIDENCE_RESOLVER_VERSION = "narrative_evidence_pattern_v3d_prior_document_lookup"
STATEMENT_PAGE_COMPATIBILITY = {
    "income_statement": {"income_statement", "notes"},
    "balance_sheet": {"balance_sheet", "notes"},
    "cash_flow": {"cash_flow", "notes"},
    "derived": {"income_statement", "balance_sheet", "cash_flow", "notes"},
}

GENERIC_FINANCIAL_SYNONYMS: tuple[dict[str, Any], ...] = (
    {"field_path": "financials.revenue", "synonym_text": "total revenue", "match_type": "contains", "confidence": "0.9000", "statement_type": "income_statement", "data_type": "number"},
    {"field_path": "financials.revenue", "synonym_text": "total revenues", "match_type": "contains", "confidence": "0.9000", "statement_type": "income_statement", "data_type": "number"},
    {"field_path": "financials.revenue", "synonym_text": "operating revenue", "match_type": "contains", "confidence": "0.9000", "statement_type": "income_statement", "data_type": "number"},
    {"field_path": "financials.revenue", "synonym_text": "sales", "match_type": "exact", "confidence": "0.8600", "statement_type": "income_statement", "data_type": "number"},
    {"field_path": "financials.accounts_receivable", "synonym_text": "trade receivables", "match_type": "contains", "confidence": "0.9200", "statement_type": "balance_sheet", "data_type": "number"},
    {"field_path": "financials.accounts_receivable", "synonym_text": "accounts receivable", "match_type": "contains", "confidence": "0.9200", "statement_type": "balance_sheet", "data_type": "number"},
    {"field_path": "financials.accounts_receivable", "synonym_text": "receivables from customers", "match_type": "contains", "confidence": "0.9000", "statement_type": "balance_sheet", "data_type": "number"},
    {"field_path": "financials.cash_and_equivalents", "synonym_text": "cash and cash equivalents", "match_type": "contains", "confidence": "0.9200", "statement_type": "balance_sheet", "data_type": "number"},
    {"field_path": "financials.inventory", "synonym_text": "inventories", "match_type": "exact", "confidence": "0.9000", "statement_type": "balance_sheet", "data_type": "number"},
    {"field_path": "financials.inventory", "synonym_text": "inventory", "match_type": "exact", "confidence": "0.9000", "statement_type": "balance_sheet", "data_type": "number"},
    {"field_path": "financials.current_assets", "synonym_text": "total current assets", "match_type": "contains", "confidence": "0.9300", "statement_type": "balance_sheet", "data_type": "number"},
    {"field_path": "financials.current_liabilities", "synonym_text": "total current liabilities", "match_type": "contains", "confidence": "0.9300", "statement_type": "balance_sheet", "data_type": "number"},
    {"field_path": "financials.total_assets", "synonym_text": "total assets", "match_type": "contains", "confidence": "0.9400", "statement_type": "balance_sheet", "data_type": "number"},
    {"field_path": "financials.total_liabilities", "synonym_text": "total liabilities", "match_type": "contains", "confidence": "0.9000", "statement_type": "balance_sheet", "data_type": "number"},
    {"field_path": "financials.total_equity", "synonym_text": "total shareholders equity", "match_type": "contains", "confidence": "0.9200", "statement_type": "balance_sheet", "data_type": "number"},
    {"field_path": "financials.total_equity", "synonym_text": "total shareholders' equity", "match_type": "contains", "confidence": "0.9200", "statement_type": "balance_sheet", "data_type": "number"},
    {"field_path": "financials.total_equity", "synonym_text": "total equity", "match_type": "contains", "confidence": "0.9000", "statement_type": "balance_sheet", "data_type": "number"},
    {"field_path": "financials.total_liabilities", "synonym_text": "total liabilities and shareholders equity", "match_type": "contains", "confidence": "0.4000", "statement_type": "balance_sheet", "data_type": "number"},
    {"field_path": "financials.net_profit", "synonym_text": "net income", "match_type": "exact", "confidence": "0.9300", "statement_type": "income_statement", "data_type": "number"},
    {"field_path": "financials.net_profit", "synonym_text": "net profit", "match_type": "contains", "confidence": "0.9200", "statement_type": "income_statement", "data_type": "number"},
    {"field_path": "financials.net_profit", "synonym_text": "profit for the year", "match_type": "contains", "confidence": "0.9200", "statement_type": "income_statement", "data_type": "number"},
    {"field_path": "financials.operating_profit", "synonym_text": "operating income", "match_type": "exact", "confidence": "0.9000", "statement_type": "income_statement", "data_type": "number"},
    {"field_path": "financials.operating_profit", "synonym_text": "operating profit", "match_type": "exact", "confidence": "0.9000", "statement_type": "income_statement", "data_type": "number"},
    {"field_path": "financials.operating_profit", "synonym_text": "profit from operations", "match_type": "contains", "confidence": "0.9100", "statement_type": "income_statement", "data_type": "number"},
    {"field_path": "financials.operating_profit", "synonym_text": "loss from operations", "match_type": "contains", "confidence": "0.9100", "statement_type": "income_statement", "data_type": "number"},
    {"field_path": "financials.ebit", "synonym_text": "income before interest", "match_type": "contains", "confidence": "0.8800", "statement_type": "income_statement", "data_type": "number"},
    {"field_path": "financials.ebit", "synonym_text": "earnings before interest and tax", "match_type": "contains", "confidence": "0.9300", "statement_type": "income_statement", "data_type": "number"},
    {"field_path": "financials.ebit", "synonym_text": "earnings before interest and taxes", "match_type": "contains", "confidence": "0.9300", "statement_type": "income_statement", "data_type": "number"},
    {"field_path": "financials.profit_before_tax", "synonym_text": "profit before tax", "match_type": "contains", "confidence": "0.9200", "statement_type": "income_statement", "data_type": "number"},
    {"field_path": "financials.profit_before_tax", "synonym_text": "loss before tax", "match_type": "contains", "confidence": "0.9200", "statement_type": "income_statement", "data_type": "number"},
    {"field_path": "financials.retained_earnings", "synonym_text": "retained earnings", "match_type": "exact", "confidence": "0.9100", "statement_type": "balance_sheet", "data_type": "number"},
    {"field_path": "financials.accumulated_losses", "synonym_text": "accumulated losses", "match_type": "contains", "confidence": "0.9200", "statement_type": "balance_sheet", "data_type": "number"},
    {"field_path": "financials.accumulated_losses", "synonym_text": "accumulated deficit", "match_type": "contains", "confidence": "0.9200", "statement_type": "balance_sheet", "data_type": "number"},
    {"field_path": "financials.operating_cash_flow", "synonym_text": "net cash provided by operating activities", "match_type": "contains", "confidence": "0.9300", "statement_type": "cash_flow", "data_type": "number"},
    {"field_path": "financials.operating_cash_flow", "synonym_text": "net cash from operating activities", "match_type": "contains", "confidence": "0.9300", "statement_type": "cash_flow", "data_type": "number"},
    {"field_path": "financials.investing_cash_flow", "synonym_text": "net cash used in investing activities", "match_type": "contains", "confidence": "0.9000", "statement_type": "cash_flow", "data_type": "number"},
    {"field_path": "financials.financing_cash_flow", "synonym_text": "net cash provided by financing activities", "match_type": "contains", "confidence": "0.9000", "statement_type": "cash_flow", "data_type": "number"},
)

GENERIC_NEGATIVE_PATTERNS: tuple[dict[str, Any], ...] = (
    {"field_path": "financials.cash_and_equivalents", "negative_pattern_text": "beginning of year", "match_type": "contains", "priority": 900, "reason": "Opening cash-flow rows are not balance-sheet cash."},
    {"field_path": "financials.cash_and_equivalents", "negative_pattern_text": "end of year", "match_type": "contains", "priority": 901, "reason": "Closing cash-flow rows are not balance-sheet cash when balance-sheet cash is required."},
    {"field_path": "financials.cash_and_equivalents", "negative_pattern_text": "increase decrease in cash", "match_type": "contains", "priority": 902, "reason": "Cash movement rows are not cash balance rows."},
    {"field_path": "financials.total_liabilities", "negative_pattern_text": "total liabilities and shareholders equity", "match_type": "contains", "priority": 900, "reason": "Balance-sheet footing is not total liabilities."},
    {"field_path": "financials.total_liabilities", "negative_pattern_text": "total liabilities and shareholders' equity", "match_type": "contains", "priority": 901, "reason": "Balance-sheet footing is not total liabilities."},
    {"field_path": "financials.total_liabilities", "negative_pattern_text": "total liabilities and equity", "match_type": "contains", "priority": 901, "reason": "Balance-sheet footing is not total liabilities."},
)


@dataclass(frozen=True)
class RunDocumentContext:
    run_id: str
    raw_document_id: str
    entity_id: Optional[str]
    profile_id: str
    profile_version: str
    environment: Optional[str]
    connector_id: str
    connector_version: Optional[str]
    reporting_period_label: Optional[str]
    file_name: Optional[str]
    storage_uri: Optional[str]
    source_run_id: Optional[str] = None


@dataclass(frozen=True)
class TableExtractionContext:
    header_by_col: dict[int, str]
    column_scope_by_col: dict[int, str]
    note_columns: set[int]
    currency: Optional[str]
    unit: Optional[str]
    unit_multiplier: Decimal


@dataclass(frozen=True)
class ExtractedTable:
    extractor_version: str
    confidence_score: Decimal
    raw_table: list[list[str]]
    extraction_json: dict[str, Any]


def _fetchone(cur: Any, sql: str, params: tuple[Any, ...]) -> Optional[dict[str, Any]]:
    cur.execute(sql, params)
    row = cur.fetchone()
    return dict(row) if row else None


def _fetchall(cur: Any, sql: str, params: tuple[Any, ...]) -> list[dict[str, Any]]:
    cur.execute(sql, params)
    return [dict(row) for row in cur.fetchall()]


def json_dumps(value: Any) -> str:
    return json.dumps(value, sort_keys=True, default=str)


def normalize_whitespace(value: Optional[str]) -> str:
    return re.sub(r"\s+", " ", value or "").strip()


def normalize_label(value: Optional[str]) -> str:
    text = normalize_whitespace(value).lower()
    text = text.replace("\u2019", "'").replace("\u2013", "-").replace("\u2014", "-")
    return re.sub(r"[^a-z0-9%()/'&. -]+", " ", text).strip()


def normalize_numeric(value: Any) -> Optional[Decimal]:
    if value in (None, ""):
        return None
    if isinstance(value, (int, float, Decimal)):
        try:
            return Decimal(str(value))
        except InvalidOperation:
            return None

    text = normalize_whitespace(str(value))
    if not text or text.lower() in {"n/a", "na", "nil", "none", "null"}:
        return None
    if text in {"-", "\u2013", "\u2014"}:
        return Decimal("0")

    multiplier = Decimal("1")
    lower = text.lower()
    if "million" in lower or re.search(r"\bm\b", lower):
        multiplier = Decimal("1000000")
    elif "thousand" in lower or re.search(r"\bk\b", lower):
        multiplier = Decimal("1000")

    cleaned = re.sub(r"(?i)(sgd|usd|s\\$|us\\$|\\$|rm|million|thousand|\\bm\\b|\\bk\\b)", "", text)
    cleaned = cleaned.replace(",", "").replace(" ", "")
    negative = False
    match = re.fullmatch(r"\((.+)\)", cleaned)
    if match:
        negative = True
        cleaned = match.group(1)
    cleaned = re.sub(r"[^0-9.\-]", "", cleaned)
    if cleaned in {"", ".", "-", "-."}:
        return None
    try:
        number = Decimal(cleaned)
    except InvalidOperation:
        return None
    if negative and number > 0:
        number = -number
    return number * multiplier


def normalize_millions(value: Any) -> Optional[Decimal]:
    number = normalize_numeric(value)
    if number is None:
        return None
    return number * Decimal("1000000")


def apply_numeric_scale(number: Optional[Decimal], scale: Any) -> Optional[Decimal]:
    if number is None:
        return None
    if scale in (None, ""):
        return number
    try:
        return number * Decimal(str(scale))
    except InvalidOperation:
        return number


def normalize_period_label(value: Optional[str]) -> Optional[str]:
    text = normalize_whitespace(value)
    if not text:
        return None

    fy_match = re.search(r"(?i)\bFY\s*((?:19|20)[0-9]{2})\b", text)
    if fy_match:
        return f"FY{fy_match.group(1)}"

    year_match = re.search(r"\b((?:19|20)[0-9]{2})\b", text)
    if year_match:
        return f"FY{year_match.group(1)}"

    return None


def prior_period_label(current_period_label: Optional[str]) -> Optional[str]:
    current = normalize_period_label(current_period_label)
    if not current:
        return None
    match = re.fullmatch(r"FY([12][0-9]{3})", current)
    if not match:
        return None
    return f"FY{int(match.group(1)) - 1}"


def next_period_label(current_period_label: Optional[str]) -> Optional[str]:
    current = normalize_period_label(current_period_label)
    if not current:
        return None
    match = re.fullmatch(r"FY([12][0-9]{3})", current)
    if not match:
        return None
    return f"FY{int(match.group(1)) + 1}"


def split_required_field_path(required_path: str) -> tuple[str, str]:
    for suffix, period_role in PERIOD_SUFFIXES.items():
        if required_path.endswith(suffix):
            return required_path[: -len(suffix)], period_role
    return required_path, "unspecified"


def get_run_context(cur: Any, run_id: str, raw_document_id: Optional[str] = None) -> RunDocumentContext:
    if raw_document_id:
        row = _fetchone(
            cur,
            """
            SELECT
                rd.*,
                er.profile_id AS run_profile_id,
                er.profile_version AS run_profile_version,
                er.environment AS run_environment,
                cr.connector_version AS run_connector_version
            FROM fsre_ingestion.raw_documents rd
            JOIN fsre_audit.execution_runs er
              ON er.run_id = rd.run_id
            LEFT JOIN fsre_ingestion.connector_runs cr
              ON cr.connector_run_id = rd.connector_run_id
            WHERE rd.run_id = %s
              AND rd.raw_document_id = %s
            """,
            (run_id, raw_document_id),
        )
    else:
        row = _fetchone(
            cur,
            """
            SELECT
                rd.*,
                er.profile_id AS run_profile_id,
                er.profile_version AS run_profile_version,
                er.environment AS run_environment,
                cr.connector_version AS run_connector_version
            FROM fsre_ingestion.raw_documents rd
            JOIN fsre_audit.execution_runs er
              ON er.run_id = rd.run_id
            LEFT JOIN fsre_ingestion.connector_runs cr
              ON cr.connector_run_id = rd.connector_run_id
            WHERE rd.run_id = %s
            ORDER BY rd.created_at DESC
            LIMIT 1
            """,
            (run_id,),
        )
    if not row:
        raise ValueError(f"No raw document found for run_id={run_id}")
    return RunDocumentContext(
        run_id=str(row["run_id"]),
        raw_document_id=str(row["raw_document_id"]),
        entity_id=row.get("entity_id"),
        profile_id=str(row["run_profile_id"]),
        profile_version=str(row["run_profile_version"]),
        environment=row.get("run_environment"),
        connector_id=str(row["connector_id"]),
        connector_version=row.get("run_connector_version"),
        reporting_period_label=row.get("reporting_period_label"),
        file_name=row.get("file_name"),
        storage_uri=row.get("storage_uri"),
    )


def load_run(cur: Any, run_id: str) -> dict[str, Any]:
    row = _fetchone(
        cur,
        """
        SELECT *
        FROM fsre_audit.execution_runs
        WHERE run_id = %s
        """,
        (run_id,),
    )
    if not row:
        raise ValueError(f"No execution run found for run_id={run_id}")
    return row


def build_required_field_manifest(cur: Any, run_id: str) -> dict[str, Any]:
    run = load_run(cur, run_id)
    run_config = run.get("run_config") or {}
    if isinstance(run_config, str):
        run_config = json.loads(run_config)

    ui_request = run_config.get("ui_request", {})
    rule_selection_mode = str(
        run_config.get("rule_selection_mode")
        or ui_request.get("rule_selection_mode")
        or "active_profile"
    )
    selected_rule_ids = set()
    if rule_selection_mode == "selected_only":
        selected_rule_ids = set(
            ui_request.get("selected_rule_ids")
            or [row.get("rule_id") for row in run_config.get("resolved_rules", [])]
        )

    params: list[Any] = [run["profile_pk"]]
    selected_filter = ""
    if selected_rule_ids:
        selected_filter = "AND rr.rule_id = ANY(%s)"
        params.append(list(selected_rule_ids))

    rules = _fetchall(
        cur,
        f"""
        SELECT
            rr.rule_id,
            rr.rule_version,
            rr.rule_name,
            rr.required_fields_json,
            rr.required_connectors_json,
            rr.threshold_config_json,
            par.execution_order
        FROM fsre_config.profile_active_rules par
        JOIN fsre_rules.rule_registry rr
          ON rr.rule_id = par.rule_id
         AND rr.rule_version = par.rule_version
        WHERE par.profile_pk = %s
          AND rr.status = 'active'
          AND COALESCE((par.rule_config_json ->> 'enabled')::boolean, TRUE) = TRUE
          {selected_filter}
        ORDER BY par.execution_order NULLS LAST, rr.rule_id
        """,
        tuple(params),
    )

    cur.execute(
        "DELETE FROM fsre_rules.run_required_field_manifest WHERE run_id = %s",
        (run_id,),
    )

    inserted = 0
    for rule in rules:
        required_fields = rule.get("required_fields_json") or []
        if isinstance(required_fields, str):
            required_fields = json.loads(required_fields)
        for required_path in required_fields:
            canonical_path, period_role = split_required_field_path(str(required_path))
            cur.execute(
                """
                INSERT INTO fsre_rules.run_required_field_manifest (
                    run_id,
                    profile_id,
                    profile_version,
                    rule_id,
                    rule_version,
                    rule_name,
                    execution_order,
                    required_field_path,
                    canonical_field_path,
                    period_role,
                    required_connector_json,
                    threshold_config_json,
                    source_json
                )
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s::jsonb, %s::jsonb, %s::jsonb)
                """,
                (
                    run_id,
                    run["profile_id"],
                    run["profile_version"],
                    rule["rule_id"],
                    rule["rule_version"],
                    rule["rule_name"],
                    rule["execution_order"],
                    str(required_path),
                    canonical_path,
                    period_role,
                    json_dumps(rule.get("required_connectors_json") or []),
                    json_dumps(rule.get("threshold_config_json") or {}),
                    json_dumps({
                        "source": "fsre_rules.rule_registry.required_fields_json",
                        "rule_source": "fsre_config.profile_active_rules",
                        "rule_selection_mode": rule_selection_mode,
                    }),
                ),
            )
            inserted += 1

    log_event(
        cur,
        run_id,
        "field_manifest",
        "required_field_manifest_built",
        "INFO",
        f"Built required field manifest with {inserted} rows.",
        {"manifest_field_count": inserted, "rule_count": len(rules)},
    )
    return {"run_id": run_id, "rule_count": len(rules), "manifest_field_count": inserted}


def classify_page(text: str) -> tuple[str, Decimal, dict[str, Any]]:
    normalized = normalize_label(text)
    audited_marker_score = score_keywords(
        normalized,
        [
            "notes to the financial statements",
            "consolidated income statement",
            "statements of financial position",
            "consolidated statement of cash flows",
        ],
    )
    summary_scores = {
        "financial_summary": score_keywords(
            normalized,
            [
                "financial highlights",
                "five-year financial summary",
                "group five-year financial summary",
            ],
        ),
        "management_discussion": score_keywords(
            normalized,
            [
                "management discussion and analysis",
                "business segment",
                "views from management",
            ],
        ),
    }
    summary_page_type, summary_score = max(summary_scores.items(), key=lambda item: item[1])
    if summary_score > 0 and audited_marker_score == 0:
        confidence = min(Decimal("0.9500"), Decimal("0.6500") + Decimal(summary_score) * Decimal("0.1000"))
        return summary_page_type, confidence, {
            "scores": summary_scores,
            "audited_marker_score": audited_marker_score,
        }

    scores = {
        "cash_flow": score_keywords(
            normalized,
            ["statement of cash flows", "cash flows from operating", "operating activities"],
        ),
        "balance_sheet": score_keywords(
            normalized,
            ["statement of financial position", "balance sheet", "total assets", "total liabilities"],
        ),
        "income_statement": score_keywords(
            normalized,
            ["profit or loss", "income statement", "revenue", "gross profit", "profit for the year"],
        ),
        "related_party": score_keywords(normalized, ["related party", "related parties"]),
        "auditor": score_keywords(normalized, ["independent auditor", "auditor's report", "audit opinion"]),
        "governance": score_keywords(normalized, ["board of directors", "corporate governance"]),
        "ownership": score_keywords(normalized, ["shareholdings", "substantial shareholders"]),
        "notes": score_keywords(normalized, ["notes to the financial statements", "accounting policies"]),
    }
    page_type, score = max(scores.items(), key=lambda item: item[1])
    if score == 0:
        return "other", Decimal("0.3000"), {"scores": scores, "audited_marker_score": audited_marker_score}
    confidence = min(Decimal("0.9500"), Decimal("0.5500") + Decimal(score) * Decimal("0.1000"))
    return page_type, confidence, {"scores": scores, "audited_marker_score": audited_marker_score}


def score_keywords(text: str, keywords: list[str]) -> int:
    return sum(1 for keyword in keywords if keyword in text)


def build_page_inventory(cur: Any, run_id: str, raw_document_id: Optional[str] = None) -> dict[str, Any]:
    context = get_run_context(cur, run_id, raw_document_id)
    pages = _fetchall(
        cur,
        """
        SELECT
            page_number,
            string_agg(text_content, E'\n\n' ORDER BY chunk_index) AS page_text
        FROM fsre_ingestion.document_text_chunks
        WHERE run_id = %s
          AND raw_document_id = %s
        GROUP BY page_number
        ORDER BY page_number
        """,
        (run_id, context.raw_document_id),
    )
    if not pages:
        raise ValueError(f"No text chunks found for raw_document_id={context.raw_document_id}")

    inserted = 0
    for page in pages:
        page_text = page["page_text"] or ""
        page_type, confidence, details = classify_page(page_text[:12000])
        evidence_text = normalize_whitespace(page_text[:1000])
        cur.execute(
            """
            INSERT INTO fsre_ingestion.document_page_inventory (
                run_id,
                raw_document_id,
                page_number,
                page_type,
                classifier_version,
                confidence_score,
                evidence_text,
                classification_json
            )
            VALUES (%s, %s, %s, %s, 'keyword_page_classifier_v1', %s, %s, %s::jsonb)
            ON CONFLICT (raw_document_id, page_number, classifier_version) DO UPDATE SET
                page_type = EXCLUDED.page_type,
                confidence_score = EXCLUDED.confidence_score,
                evidence_text = EXCLUDED.evidence_text,
                classification_json = EXCLUDED.classification_json
            """,
            (
                run_id,
                context.raw_document_id,
                page["page_number"],
                page_type,
                confidence,
                evidence_text,
                json_dumps(details),
            ),
        )
        inserted += 1

    log_event(
        cur,
        run_id,
        "page_inventory",
        "document_pages_classified",
        "INFO",
        f"Classified {inserted} document pages.",
        {"raw_document_id": context.raw_document_id, "page_count": inserted},
    )
    return {"run_id": run_id, "raw_document_id": context.raw_document_id, "page_count": inserted}


def extract_financial_tables(
    cur: Any,
    run_id: str,
    document_path: str,
    raw_document_id: Optional[str] = None,
    extraction_config: Optional[dict[str, Any]] = None,
) -> dict[str, Any]:
    context = get_run_context(cur, run_id, raw_document_id)
    extraction_config = extraction_config or {}
    path = Path(document_path)
    if not path.exists():
        raise FileNotFoundError(f"Document path does not exist for table extraction: {path}")

    try:
        import pdfplumber
    except ImportError as exc:
        raise RuntimeError("pdfplumber is required for deterministic table extraction.") from exc

    cur.execute(
        "DELETE FROM fsre_ingestion.document_tables WHERE raw_document_id = %s",
        (context.raw_document_id,),
    )

    page_types = {
        row["page_number"]: row["page_type"]
        for row in _fetchall(
            cur,
            """
            SELECT page_number, page_type
            FROM fsre_ingestion.document_page_inventory
            WHERE raw_document_id = %s
            """,
            (context.raw_document_id,),
        )
    }

    allowed_page_types = set(extraction_config.get("allowed_page_types") or [])
    layout_text_fallback_enabled = bool(extraction_config.get("layout_text_fallback_enabled", True))

    table_count = 0
    cell_count = 0
    with pdfplumber.open(str(path)) as pdf:
        for page_number, page in enumerate(pdf.pages, start=1):
            page_type = page_types.get(page_number)
            if allowed_page_types and page_types and page_type not in allowed_page_types:
                continue

            extracted_tables: list[ExtractedTable] = []
            for table in page.extract_tables() or []:
                raw_table = [
                    [normalize_whitespace(cell) for cell in row]
                    for row in table
                    if any(normalize_whitespace(cell) for cell in row)
                ]
                if raw_table:
                    extracted_tables.append(
                        ExtractedTable(
                            extractor_version="pdfplumber_grid_table_extractor_v1",
                            confidence_score=Decimal("0.8500"),
                            raw_table=raw_table,
                            extraction_json={"source": "pdfplumber_extract_tables"},
                        )
                    )

            if layout_text_fallback_enabled:
                extracted_tables.extend(
                    extract_layout_statement_tables(
                        page,
                        current_period=normalize_period_label(context.reporting_period_label),
                        prior_period=prior_period_label(context.reporting_period_label),
                        extraction_config=extraction_config,
                    )
                )

            for table_index, extracted_table in enumerate(extracted_tables, start=1):
                clean_table = extracted_table.raw_table
                if not clean_table:
                    continue
                row_count = len(clean_table)
                column_count = max(len(row) for row in clean_table)
                cur.execute(
                    """
                    INSERT INTO fsre_ingestion.document_tables (
                        run_id,
                        raw_document_id,
                        page_number,
                        table_index,
                        extractor_version,
                        page_type,
                        row_count,
                        column_count,
                        confidence_score,
                        table_json
                    )
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s::jsonb)
                    RETURNING document_table_id
                    """,
                    (
                        run_id,
                        context.raw_document_id,
                        page_number,
                        table_index,
                        extracted_table.extractor_version,
                        page_type,
                        row_count,
                        column_count,
                        extracted_table.confidence_score,
                        json_dumps(
                            {
                                "raw_table": clean_table,
                                "extractor_version": extracted_table.extractor_version,
                                **extracted_table.extraction_json,
                            }
                        ),
                    ),
                )
                document_table_id = cur.fetchone()["document_table_id"]
                table_count += 1
                for row_index, row in enumerate(clean_table, start=1):
                    for column_index in range(1, column_count + 1):
                        raw_text = row[column_index - 1] if column_index <= len(row) else ""
                        cur.execute(
                            """
                            INSERT INTO fsre_ingestion.document_table_cells (
                                document_table_id,
                                run_id,
                                raw_document_id,
                                page_number,
                                table_index,
                                row_index,
                                column_index,
                                raw_text,
                                normalized_text,
                                cell_json
                            )
                            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, '{}'::jsonb)
                            """,
                            (
                                document_table_id,
                                run_id,
                                context.raw_document_id,
                                page_number,
                                table_index,
                                row_index,
                                column_index,
                                raw_text,
                                normalize_label(raw_text),
                            ),
                        )
                        cell_count += 1

    log_event(
        cur,
        run_id,
        "table_extraction",
        "financial_tables_extracted",
        "INFO" if table_count else "WARN",
        f"Extracted {table_count} tables and {cell_count} cells.",
        {"raw_document_id": context.raw_document_id, "table_count": table_count, "cell_count": cell_count},
    )
    return {
        "run_id": run_id,
        "raw_document_id": context.raw_document_id,
        "table_count": table_count,
        "cell_count": cell_count,
    }


def extract_layout_statement_tables(
    page: Any,
    current_period: Optional[str],
    prior_period: Optional[str],
    extraction_config: dict[str, Any],
) -> list[ExtractedTable]:
    words = page.extract_words(x_tolerance=1, y_tolerance=3, keep_blank_chars=False) or []
    if not words:
        return []

    lines = group_pdf_words_by_line(words, y_tolerance=Decimal(str(extraction_config.get("layout_y_tolerance", "3"))))
    period_columns = infer_layout_period_columns(lines, current_period, prior_period)
    min_period_columns = int(extraction_config.get("min_layout_period_columns", 2))
    if len(period_columns) < min_period_columns:
        return []

    column_count = 2 + len(period_columns)
    table_rows: list[list[str]] = []
    table_rows.append(["", "Notes", *[label for _, label in period_columns]])

    value_row_count = 0
    for line in lines:
        row = layout_line_to_table_row(line, period_columns, column_count)
        if not row:
            continue
        table_rows.append(row)

    table_rows = repair_wrapped_layout_rows(table_rows)
    for row in table_rows[1:]:
        if any(normalize_numeric(row[column_index]) is not None for column_index in range(2, len(row))):
            value_row_count += 1

    min_value_rows = int(extraction_config.get("min_layout_value_rows", 3))
    if value_row_count < min_value_rows:
        return []

    return [
        ExtractedTable(
            extractor_version="pdfplumber_layout_text_table_extractor_v1",
            confidence_score=Decimal(str(extraction_config.get("layout_table_confidence", "0.9000"))),
            raw_table=table_rows,
            extraction_json={
                "source": "pdfplumber_extract_words",
                "period_columns": [
                    {"x0": str(x0), "period_label": label}
                    for x0, label in period_columns
                ],
                "value_row_count": value_row_count,
            },
        )
    ]


def repair_wrapped_layout_rows(rows: list[list[str]]) -> list[list[str]]:
    if not rows:
        return rows
    repaired: list[list[str]] = [rows[0]]
    for row in rows[1:]:
        if (
            len(repaired) > 1
            and is_label_only_layout_row(repaired[-1])
            and is_value_layout_row(row)
            and is_wrapped_label_continuation(repaired[-1][0], row[0])
        ):
            previous = repaired.pop()
            merged = list(row)
            merged[0] = normalize_whitespace(f"{previous[0]} {row[0]}")
            if len(merged) > 1:
                merged[1] = normalize_whitespace(f"{previous[1]} {row[1]}")
            repaired.append(merged)
            continue
        repaired.append(row)
    return repaired


def is_label_only_layout_row(row: list[str]) -> bool:
    return bool(row and row[0]) and not any(
        normalize_numeric(value) is not None for value in row[2:]
    )


def is_value_layout_row(row: list[str]) -> bool:
    return any(normalize_numeric(value) is not None for value in row[2:])


def is_wrapped_label_continuation(previous_label: str, current_label: str) -> bool:
    previous = normalize_whitespace(previous_label)
    current = normalize_whitespace(current_label)
    if not previous or not current:
        return False
    normalized_previous = normalize_label(previous)
    normalized_current = normalize_label(current)
    if normalized_previous in {
        "current assets",
        "current liabilities",
        "assets",
        "liabilities and shareholders equity",
        "shareholders equity",
        "cash flows from operating activities",
        "cash flows from investing activities",
        "cash flows from financing activities",
    }:
        return False
    if normalized_current.startswith(("total ", "net ", "cash ", "revenue", "cost ")):
        return False
    if previous.count("(") > previous.count(")"):
        return True
    if re.search(r"\b(of|for|from|net of|allowance for|doubtful|respectively|and)$", normalized_previous):
        return True
    if re.search(r"^(accounts?|allowance|respectively|shares?|value|activities|assets?|liabilities)\b", normalized_current):
        return True
    return current[:1].islower()


def group_pdf_words_by_line(words: list[dict[str, Any]], y_tolerance: Decimal) -> list[list[dict[str, Any]]]:
    lines: list[list[dict[str, Any]]] = []
    for word in sorted(words, key=lambda item: (Decimal(str(item["top"])), Decimal(str(item["x0"])))):
        top = Decimal(str(word["top"]))
        if not lines:
            lines.append([word])
            continue
        previous_top = Decimal(str(lines[-1][0]["top"]))
        if abs(top - previous_top) <= y_tolerance:
            lines[-1].append(word)
        else:
            lines.append([word])
    return [sorted(line, key=lambda item: Decimal(str(item["x0"]))) for line in lines]


def infer_layout_period_columns(
    lines: list[list[dict[str, Any]]],
    current_period: Optional[str],
    prior_period: Optional[str],
) -> list[tuple[Decimal, str]]:
    expected_periods = {period for period in (current_period, prior_period) if period}
    candidates: list[tuple[Decimal, str]] = []
    for line in lines[:20]:
        for word in line:
            period = normalize_period_label(word.get("text"))
            if not period or (expected_periods and period not in expected_periods):
                continue
            x0 = Decimal(str(word["x0"]))
            if x0 < Decimal("250"):
                continue
            candidates.append((x0, period))

    clustered: list[tuple[Decimal, str]] = []
    for x0, period in sorted(candidates, key=lambda item: item[0]):
        if clustered and abs(x0 - clustered[-1][0]) <= Decimal("18"):
            continue
        clustered.append((x0, period))
    return clustered


def layout_line_to_table_row(
    line: list[dict[str, Any]],
    period_columns: list[tuple[Decimal, str]],
    column_count: int,
) -> Optional[list[str]]:
    row = [""] * column_count
    label_words: list[str] = []
    note_words: list[str] = []
    data_words_by_col: dict[int, list[str]] = {}
    first_value_x = min(x0 for x0, _ in period_columns)

    for word in line:
        text = normalize_whitespace(word.get("text"))
        if not text:
            continue
        x0 = Decimal(str(word["x0"]))
        value = normalize_numeric(text)
        assigned_data_col = nearest_period_column_index(x0, period_columns)
        if value is not None and assigned_data_col is not None:
            data_words_by_col.setdefault(assigned_data_col, []).append(text)
            continue
        if value is not None and Decimal("230") <= x0 < first_value_x - Decimal("15"):
            note_words.append(text)
            continue
        if x0 < first_value_x - Decimal("15"):
            label_words.append(text)

    if not label_words and not data_words_by_col:
        return None

    row[0] = normalize_whitespace(" ".join(label_words))
    row[1] = normalize_whitespace(" ".join(note_words))
    for column_index, values in data_words_by_col.items():
        row[column_index] = normalize_whitespace(" ".join(values))
    if not row[0] and not any(row[2:]):
        return None
    return row


def nearest_period_column_index(
    x0: Decimal,
    period_columns: list[tuple[Decimal, str]],
) -> Optional[int]:
    nearest: Optional[tuple[int, Decimal]] = None
    for offset, (period_x0, _) in enumerate(period_columns, start=2):
        distance = abs(x0 - period_x0)
        if nearest is None or distance < nearest[1]:
            nearest = (offset, distance)
    if nearest and nearest[1] <= Decimal("45"):
        return nearest[0]
    return None


def load_active_synonyms(cur: Any, context: RunDocumentContext) -> list[dict[str, Any]]:
    return _fetchall(
        cur,
        """
        SELECT
            s.field_path,
            s.synonym_text,
            s.match_type,
            s.priority,
            s.confidence,
            s.profile_id,
            s.profile_version,
            s.connector_id,
            s.connector_version,
            s.environment,
            c.statement_type,
            c.data_type,
            (
                CASE WHEN s.profile_id = %s THEN 16 ELSE 0 END +
                CASE WHEN s.profile_version = %s THEN 8 ELSE 0 END +
                CASE WHEN s.connector_id = %s THEN 4 ELSE 0 END +
                CASE WHEN s.connector_version = %s THEN 2 ELSE 0 END +
                CASE WHEN s.environment = %s THEN 1 ELSE 0 END
            ) AS scope_score
        FROM fsre_config.field_synonym_registry s
        JOIN fsre_config.field_catalog c
          ON c.field_path = s.field_path
        WHERE s.status = 'active'
          AND c.status = 'active'
          AND s.profile_id IN ('*', %s)
          AND s.profile_version IN ('*', %s)
          AND s.connector_id IN ('*', %s)
          AND s.connector_version IN ('*', %s)
          AND s.environment IN ('*', %s)
          AND (s.effective_from IS NULL OR s.effective_from <= now())
          AND (s.effective_to IS NULL OR s.effective_to > now())
        ORDER BY scope_score DESC, s.priority ASC, length(s.synonym_text) DESC
        """,
        (
            context.profile_id,
            context.profile_version,
            context.connector_id,
            context.connector_version or "*",
            context.environment or "*",
            context.profile_id,
            context.profile_version,
            context.connector_id,
            context.connector_version or "*",
            context.environment or "*",
        ),
    )


def with_generic_financial_synonyms(synonyms: list[dict[str, Any]]) -> list[dict[str, Any]]:
    existing = {
        (
            str(row.get("field_path")),
            normalize_label(str(row.get("synonym_text") or "")),
            str(row.get("match_type") or ""),
        )
        for row in synonyms
    }
    merged = list(synonyms)
    for index, synonym in enumerate(GENERIC_FINANCIAL_SYNONYMS, start=1):
        key = (
            str(synonym["field_path"]),
            normalize_label(str(synonym["synonym_text"])),
            str(synonym["match_type"]),
        )
        if key in existing:
            continue
        merged.append(
            {
                **synonym,
                "priority": 900 + index,
                "profile_id": "*",
                "profile_version": "*",
                "connector_id": "*",
                "connector_version": "*",
                "environment": "*",
                "scope_score": 0,
                "source": "generic_financial_statement_synonyms_v1",
            }
        )
    return merged


def with_generic_negative_patterns(patterns: list[dict[str, Any]]) -> list[dict[str, Any]]:
    existing = {
        (
            str(row.get("field_path")),
            normalize_label(str(row.get("negative_pattern_text") or "")),
            str(row.get("match_type") or ""),
        )
        for row in patterns
    }
    merged = list(patterns)
    for pattern in GENERIC_NEGATIVE_PATTERNS:
        key = (
            str(pattern["field_path"]),
            normalize_label(str(pattern["negative_pattern_text"])),
            str(pattern["match_type"]),
        )
        if key in existing:
            continue
        merged.append(
            {
                **pattern,
                "profile_id": "*",
                "profile_version": "*",
                "connector_id": "*",
                "connector_version": "*",
                "environment": "*",
                "scope_score": 0,
                "source": "generic_financial_statement_negative_patterns_v1",
            }
        )
    return merged


def load_active_negative_patterns(cur: Any, context: RunDocumentContext) -> list[dict[str, Any]]:
    registry = _fetchone(
        cur,
        "SELECT to_regclass('fsre_config.field_synonym_negative_registry') AS relation_name",
        (),
    )
    if not registry or not registry.get("relation_name"):
        return []

    return _fetchall(
        cur,
        """
        SELECT
            n.field_path,
            n.negative_pattern_text,
            n.match_type,
            n.priority,
            n.profile_id,
            n.profile_version,
            n.connector_id,
            n.connector_version,
            n.environment,
            (
                CASE WHEN n.profile_id = %s THEN 16 ELSE 0 END +
                CASE WHEN n.profile_version = %s THEN 8 ELSE 0 END +
                CASE WHEN n.connector_id = %s THEN 4 ELSE 0 END +
                CASE WHEN n.connector_version = %s THEN 2 ELSE 0 END +
                CASE WHEN n.environment = %s THEN 1 ELSE 0 END
            ) AS scope_score
        FROM fsre_config.field_synonym_negative_registry n
        JOIN fsre_config.field_catalog c
          ON c.field_path = n.field_path
        WHERE n.status = 'active'
          AND c.status = 'active'
          AND n.profile_id IN ('*', %s)
          AND n.profile_version IN ('*', %s)
          AND n.connector_id IN ('*', %s)
          AND n.connector_version IN ('*', %s)
          AND n.environment IN ('*', %s)
          AND (n.effective_from IS NULL OR n.effective_from <= now())
          AND (n.effective_to IS NULL OR n.effective_to > now())
        ORDER BY scope_score DESC, n.priority ASC, length(n.negative_pattern_text) DESC
        """,
        (
            context.profile_id,
            context.profile_version,
            context.connector_id,
            context.connector_version or "*",
            context.environment or "*",
            context.profile_id,
            context.profile_version,
            context.connector_id,
            context.connector_version or "*",
            context.environment or "*",
        ),
    )


def load_active_zero_evidence_patterns(
    cur: Any,
    context: RunDocumentContext,
    required_field_paths: set[str],
) -> list[dict[str, Any]]:
    registry = _fetchone(
        cur,
        "SELECT to_regclass('fsre_config.numeric_zero_evidence_registry') AS relation_name",
        (),
    )
    if not registry or not registry.get("relation_name"):
        return []

    return _fetchall(
        cur,
        """
        SELECT
            z.field_path,
            z.evidence_pattern_text,
            z.match_type,
            z.period_role,
            z.priority,
            z.confidence,
            z.profile_id,
            z.profile_version,
            z.connector_id,
            z.connector_version,
            z.environment,
            (
                CASE WHEN z.profile_id = %s THEN 16 ELSE 0 END +
                CASE WHEN z.profile_version = %s THEN 8 ELSE 0 END +
                CASE WHEN z.connector_id = %s THEN 4 ELSE 0 END +
                CASE WHEN z.connector_version = %s THEN 2 ELSE 0 END +
                CASE WHEN z.environment = %s THEN 1 ELSE 0 END
            ) AS scope_score
        FROM fsre_config.numeric_zero_evidence_registry z
        JOIN fsre_config.field_catalog c
          ON c.field_path = z.field_path
        WHERE z.status = 'active'
          AND c.status = 'active'
          AND c.data_type = 'number'
          AND z.field_path = ANY(%s)
          AND z.profile_id IN ('*', %s)
          AND z.profile_version IN ('*', %s)
          AND z.connector_id IN ('*', %s)
          AND z.connector_version IN ('*', %s)
          AND z.environment IN ('*', %s)
          AND (z.effective_from IS NULL OR z.effective_from <= now())
          AND (z.effective_to IS NULL OR z.effective_to > now())
        ORDER BY scope_score DESC, z.priority ASC, length(z.evidence_pattern_text) DESC
        """,
        (
            context.profile_id,
            context.profile_version,
            context.connector_id,
            context.connector_version or "*",
            context.environment or "*",
            list(required_field_paths),
            context.profile_id,
            context.profile_version,
            context.connector_id,
            context.connector_version or "*",
            context.environment or "*",
        ),
    )


def load_required_numeric_field_paths(cur: Any, run_id: str) -> set[str]:
    return set(load_required_numeric_field_requirements(cur, run_id))


def load_required_numeric_field_requirements(cur: Any, run_id: str) -> dict[str, set[str]]:
    rows = _fetchall(
        cur,
        """
        SELECT DISTINCT m.canonical_field_path, m.period_role
        FROM fsre_rules.run_required_field_manifest m
        JOIN fsre_config.field_catalog c
          ON c.field_path = m.canonical_field_path
        WHERE m.run_id = %s
          AND c.status = 'active'
          AND c.data_type = 'number'
          AND c.statement_type <> 'external_connector'
        """,
        (run_id,),
    )
    requirements: dict[str, set[str]] = {}
    for row in rows:
        requirements.setdefault(str(row["canonical_field_path"]), set()).add(
            str(row["period_role"] or "unspecified")
        )
    add_derived_extraction_requirements(requirements)
    return requirements


def load_default_numeric_field_requirements(cur: Any) -> dict[str, set[str]]:
    rows = _fetchall(
        cur,
        """
        SELECT field_path
        FROM fsre_config.field_catalog
        WHERE status = 'active'
          AND data_type = 'number'
          AND COALESCE(statement_type, '') <> 'external_connector'
          AND field_path LIKE 'financials.%'
        ORDER BY field_path
        """,
        (),
    )
    requirements = {
        str(row["field_path"]): {"current", "prior"}
        for row in rows
    }
    add_derived_extraction_requirements(requirements)
    return requirements


def add_derived_extraction_requirements(requirements: dict[str, set[str]]) -> None:
    working_capital_roles = requirements.get("financials.working_capital")
    if not working_capital_roles:
        return
    for helper_field in ("financials.current_assets", "financials.current_liabilities"):
        requirements.setdefault(helper_field, set()).update(working_capital_roles)


def is_required_period_role(
    field_path: str,
    period_role: str,
    required_field_requirements: dict[str, set[str]],
) -> bool:
    required_roles = required_field_requirements.get(field_path)
    if not required_roles:
        return False
    if period_role in required_roles:
        return True
    return bool(required_roles.intersection({"any", "historical", "unspecified"}))


def match_field(
    label: str,
    synonyms: list[dict[str, Any]],
    required_field_paths: Optional[set[str]] = None,
    page_type: Optional[str] = None,
    negative_patterns: Optional[list[dict[str, Any]]] = None,
) -> Optional[dict[str, Any]]:
    normalized = normalize_label(label)
    if not normalized:
        return None
    matches: list[dict[str, Any]] = []
    for synonym in synonyms:
        if required_field_paths is not None and synonym["field_path"] not in required_field_paths:
            continue
        pattern = normalize_label(synonym["synonym_text"])
        if not pattern:
            continue
        match_type = synonym["match_type"]
        matched = (
            (match_type == "exact" and normalized == pattern)
            or (match_type == "contains" and pattern in normalized)
            or (match_type == "regex" and re.search(synonym["synonym_text"], label, flags=re.IGNORECASE))
        )
        if not matched:
            continue
        negative_match = match_negative_pattern(
            label,
            synonym["field_path"],
            negative_patterns or [],
        )
        if negative_match:
            continue

        candidate = dict(synonym)
        confidence = Decimal(str(candidate["confidence"]))
        confidence += statement_page_adjustment(candidate.get("statement_type"), page_type)
        candidate["confidence"] = min(Decimal("0.9900"), max(Decimal("0.1000"), confidence))
        candidate["normalized_label"] = normalized
        matches.append(candidate)

    if not matches:
        return None
    return sorted(
        matches,
        key=lambda item: (
            int(item.get("scope_score") or 0),
            Decimal(str(item["confidence"])),
            -int(item["priority"]),
            len(str(item["synonym_text"])),
        ),
        reverse=True,
    )[0]


def match_negative_pattern(
    label: str,
    field_path: str,
    negative_patterns: list[dict[str, Any]],
) -> Optional[dict[str, Any]]:
    normalized = normalize_label(label)
    for pattern_row in negative_patterns:
        if pattern_row["field_path"] != field_path:
            continue
        raw_pattern = str(pattern_row["negative_pattern_text"])
        pattern = normalize_label(raw_pattern)
        if not pattern:
            continue
        match_type = pattern_row["match_type"]
        matched = (
            (match_type == "exact" and normalized == pattern)
            or (match_type == "contains" and pattern in normalized)
            or (match_type == "regex" and re.search(raw_pattern, label, flags=re.IGNORECASE))
        )
        if matched:
            if is_permitted_negative_pattern_exception(normalized, field_path, pattern):
                continue
            return pattern_row
    return None


def is_permitted_negative_pattern_exception(
    normalized_label: str,
    field_path: str,
    normalized_negative_pattern: str,
) -> bool:
    if field_path == "financials.accounts_receivable":
        is_receivable_balance = (
            "trade receivable" in normalized_label
            or "accounts receivable" in normalized_label
            or "receivables from customers" in normalized_label
        )
        is_net_of_allowance_context = (
            "net of allowance" in normalized_label
            or "allowance for doubtful" in normalized_label
            or "less allowance" in normalized_label
        )
        if is_receivable_balance and is_net_of_allowance_context:
            return normalized_negative_pattern in {"allowance", "doubtful", "provision"}
    return False


def statement_page_adjustment(statement_type: Optional[str], page_type: Optional[str]) -> Decimal:
    if not statement_type or not page_type:
        return Decimal("0")
    compatible_pages = STATEMENT_PAGE_COMPATIBILITY.get(statement_type, {statement_type})
    if page_type in compatible_pages:
        return Decimal("0.0400")
    if page_type == "other":
        return Decimal("-0.0300")
    return Decimal("-0.0800")


def resolve_financial_fields(
    cur: Any,
    run_id: str,
    raw_document_id: Optional[str] = None,
    resolution_config: Optional[dict[str, Any]] = None,
) -> dict[str, Any]:
    context = get_run_context(cur, run_id, raw_document_id)
    resolution_config = resolution_config or {}
    current_period = normalize_period_label(context.reporting_period_label)
    prior_period = prior_period_label(current_period)

    synonyms = with_generic_financial_synonyms(load_active_synonyms(cur, context))
    if not synonyms:
        raise ValueError(
            "No active field synonyms found in fsre_config.field_synonym_registry "
            f"for profile={context.profile_id}/{context.profile_version}, "
            f"connector={context.connector_id}/{context.connector_version or '*'}, "
            f"environment={context.environment or '*'}"
        )
    negative_patterns = with_generic_negative_patterns(load_active_negative_patterns(cur, context))

    required_field_requirements = load_required_numeric_field_requirements(cur, run_id)
    if not required_field_requirements:
        build_required_field_manifest(cur, run_id)
        required_field_requirements = load_required_numeric_field_requirements(cur, run_id)
    manifest_fallback_used = False
    if not required_field_requirements:
        required_field_requirements = load_default_numeric_field_requirements(cur)
        manifest_fallback_used = True
    required_field_paths = set(required_field_requirements)
    if not required_field_paths:
        raise ValueError(
            "No active numeric financial fields are available in fsre_config.field_catalog "
            f"for fallback field resolution, run_id={run_id}"
        )

    cur.execute(
        "DELETE FROM fsre_ingestion.field_candidates WHERE raw_document_id = %s",
        (context.raw_document_id,),
    )
    cur.execute(
        "DELETE FROM fsre_ingestion.resolved_fields WHERE raw_document_id = %s",
        (context.raw_document_id,),
    )

    allowed_page_types = set(resolution_config.get("allowed_page_types") or [])
    accepted_extractor_versions = set(resolution_config.get("accepted_extractor_versions") or [])
    min_confidence = Decimal(str(resolution_config.get("min_confidence_score", "0.8500")))
    primary_reporting_scope = normalize_label(
        str(resolution_config.get("primary_reporting_scope", "group"))
    )

    tables = _fetchall(
        cur,
        """
        SELECT document_table_id, page_number, table_index, page_type, extractor_version
        FROM fsre_ingestion.document_tables
        WHERE run_id = %s
          AND raw_document_id = %s
        ORDER BY page_number, table_index
        """,
        (run_id, context.raw_document_id),
    )

    candidate_count = 0
    resolved_count = 0
    skipped_table_count = 0
    for table in tables:
        if allowed_page_types and table.get("page_type") and table.get("page_type") not in allowed_page_types:
            skipped_table_count += 1
            continue
        if accepted_extractor_versions and table.get("extractor_version") not in accepted_extractor_versions:
            skipped_table_count += 1
            continue
        cells = _fetchall(
            cur,
            """
            SELECT table_cell_id, row_index, column_index, raw_text, normalized_text
            FROM fsre_ingestion.document_table_cells
            WHERE document_table_id = %s
            ORDER BY row_index, column_index
            """,
            (table["document_table_id"],),
        )
        rows: dict[int, list[dict[str, Any]]] = {}
        for cell in cells:
            rows.setdefault(cell["row_index"], []).append(cell)

        table_context = infer_table_context(rows, current_period, prior_period)
        for row_index, row_cells in rows.items():
            if row_index <= 2 and looks_like_header_row(row_cells):
                continue

            label_cell = first_label_cell(row_cells)
            if not label_cell:
                continue
            field_match = match_field(
                label_cell["raw_text"],
                synonyms,
                required_field_paths=required_field_paths,
                page_type=table.get("page_type"),
                negative_patterns=negative_patterns,
            )
            if not field_match:
                continue

            for value_cell in row_cells:
                if value_cell["column_index"] == label_cell["column_index"]:
                    continue
                if value_cell["column_index"] in table_context.note_columns:
                    continue
                numeric_value = normalize_numeric_with_table_unit(
                    value_cell["raw_text"],
                    table_context.unit_multiplier,
                )
                if numeric_value is None:
                    continue

                period_label = infer_period_for_value_cell(
                    value_cell,
                    label_cell,
                    row_cells,
                    table_context,
                    current_period,
                    prior_period,
                )
                if not period_label:
                    continue

                period_role = period_role_for_label(period_label, current_period, prior_period)
                if not is_required_period_role(
                    field_match["field_path"],
                    period_role,
                    required_field_requirements,
                ):
                    continue
                reporting_scope = table_context.column_scope_by_col.get(value_cell["column_index"])
                if (
                    primary_reporting_scope
                    and reporting_scope
                    and reporting_scope != primary_reporting_scope
                ):
                    continue
                confidence = Decimal(str(field_match["confidence"]))
                if confidence < min_confidence:
                    continue
                source_ref = {
                    "source": "pdfplumber_table",
                    "page_number": table["page_number"],
                    "table_index": table["table_index"],
                    "extractor_version": table.get("extractor_version"),
                    "row_index": row_index,
                    "column_index": value_cell["column_index"],
                    "raw_label": label_cell["raw_text"],
                    "column_header": table_context.header_by_col.get(value_cell["column_index"]),
                    "table_cell_id": str(value_cell["table_cell_id"]),
                    "field_synonym": field_match["synonym_text"],
                    "field_synonym_source": field_match.get("source") or "field_synonym_registry",
                    "synonym_scope": {
                        "profile_id": field_match.get("profile_id"),
                        "profile_version": field_match.get("profile_version"),
                        "connector_id": field_match.get("connector_id"),
                        "connector_version": field_match.get("connector_version"),
                        "environment": field_match.get("environment"),
                        "scope_score": field_match.get("scope_score"),
                    },
                    "page_type": table.get("page_type"),
                    "currency": table_context.currency,
                    "unit": table_context.unit,
                    "unit_multiplier": str(table_context.unit_multiplier),
                    "reporting_scope": reporting_scope,
                    "primary_reporting_scope": primary_reporting_scope,
                    "required_field_manifest_scoped": True,
                }
                cur.execute(
                    """
                    INSERT INTO fsre_ingestion.field_candidates (
                        run_id,
                        raw_document_id,
                        document_table_id,
                        table_cell_id,
                        entity_id,
                        candidate_field_path,
                        raw_label,
                        raw_value_text,
                        normalized_value_numeric,
                        normalized_value_text,
                        period_label,
                        period_role,
                        currency,
                        unit,
                        page_number,
                        extraction_method,
                        confidence_score,
                        source_ref_json
                    )
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s::jsonb)
                    RETURNING field_candidate_id
                    """,
                    (
                        run_id,
                        context.raw_document_id,
                        table["document_table_id"],
                        value_cell["table_cell_id"],
                        context.entity_id,
                        field_match["field_path"],
                        label_cell["raw_text"],
                        value_cell["raw_text"],
                        numeric_value,
                        None,
                        period_label,
                        period_role,
                        table_context.currency,
                        table_context.unit,
                        table["page_number"],
                        "pdfplumber_table_synonym_v2",
                        confidence,
                        json_dumps(source_ref),
                    ),
                )
                field_candidate_id = cur.fetchone()["field_candidate_id"]
                candidate_count += 1

                field_name = str(field_match["field_path"]).split(".")[-1]
                needs_review = confidence < Decimal("0.8500")
                cur.execute(
                    """
                    INSERT INTO fsre_ingestion.resolved_fields (
                        run_id,
                        raw_document_id,
                        field_candidate_id,
                        entity_id,
                        field_path,
                        field_name,
                        period_label,
                        period_role,
                        raw_value_text,
                        normalized_value_numeric,
                        normalized_value_text,
                        currency,
                        unit,
                        page_number,
                        extraction_method,
                        confidence_score,
                        is_accepted,
                        needs_review,
                        review_reason,
                        source_ref_json
                    )
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, TRUE, %s, %s, %s::jsonb)
                    """,
                    (
                        run_id,
                        context.raw_document_id,
                        field_candidate_id,
                        context.entity_id,
                        field_match["field_path"],
                        field_name,
                        period_label,
                        period_role,
                        value_cell["raw_text"],
                        numeric_value,
                        None,
                        table_context.currency,
                        table_context.unit,
                        table["page_number"],
                        "pdfplumber_table_synonym_v2",
                        confidence,
                        needs_review,
                        "confidence_below_review_threshold" if needs_review else None,
                        json_dumps(source_ref),
                    ),
                )
                resolved_count += 1

        subtotal_result = resolve_section_subtotals(
            cur,
            context,
            table,
            rows,
            table_context,
            required_field_requirements,
            required_field_paths,
            synonyms,
            negative_patterns,
            current_period,
            prior_period,
            primary_reporting_scope,
            min_confidence,
        )
        candidate_count += subtotal_result["candidate_count"]
        resolved_count += subtotal_result["resolved_count"]

    text_fallback_result = resolve_text_chunk_financial_fields(
        cur,
        context,
        required_field_requirements,
        required_field_paths,
        synonyms,
        negative_patterns,
        current_period,
        prior_period,
        primary_reporting_scope,
        resolution_config,
    )
    candidate_count += text_fallback_result["candidate_count"]
    resolved_count += text_fallback_result["resolved_count"]

    dedupe_result = accept_best_resolved_fields(cur, context)
    derived_count = create_derived_financial_fields(cur, context)
    zero_evidence_count = resolve_numeric_zero_evidence_fields(
        cur,
        context,
        required_field_requirements,
    )
    accepted_count = dedupe_result["accepted_count"] + derived_count + zero_evidence_count

    log_event(
        cur,
        run_id,
        "field_resolution",
        "financial_fields_resolved",
        "INFO" if accepted_count else "WARN",
        f"Resolved {accepted_count} accepted fields from {candidate_count} candidates.",
        {
            "raw_document_id": context.raw_document_id,
            "candidate_count": candidate_count,
            "resolved_count": resolved_count,
            "accepted_count": accepted_count,
            "rejected_duplicate_count": dedupe_result["rejected_duplicate_count"],
            "derived_count": derived_count,
            "zero_evidence_count": zero_evidence_count,
            "skipped_table_count": skipped_table_count,
            "required_numeric_field_count": len(required_field_paths),
            "manifest_fallback_used": manifest_fallback_used,
            "text_chunk_fallback_candidate_count": text_fallback_result["candidate_count"],
            "text_chunk_fallback_resolved_count": text_fallback_result["resolved_count"],
        },
    )
    return {
        "run_id": run_id,
        "raw_document_id": context.raw_document_id,
        "candidate_count": candidate_count,
        "resolved_count": resolved_count,
        "accepted_count": accepted_count,
        "rejected_duplicate_count": dedupe_result["rejected_duplicate_count"],
        "derived_count": derived_count,
        "zero_evidence_count": zero_evidence_count,
        "skipped_table_count": skipped_table_count,
        "required_numeric_field_count": len(required_field_paths),
        "manifest_fallback_used": manifest_fallback_used,
        "text_chunk_fallback_candidate_count": text_fallback_result["candidate_count"],
        "text_chunk_fallback_resolved_count": text_fallback_result["resolved_count"],
    }


def resolve_text_chunk_financial_fields(
    cur: Any,
    context: RunDocumentContext,
    required_field_requirements: dict[str, set[str]],
    required_field_paths: set[str],
    synonyms: list[dict[str, Any]],
    negative_patterns: list[dict[str, Any]],
    current_period: Optional[str],
    prior_period: Optional[str],
    primary_reporting_scope: str,
    resolution_config: dict[str, Any],
) -> dict[str, int]:
    if resolution_config.get("text_chunk_fallback_enabled", True) is False:
        return {"candidate_count": 0, "resolved_count": 0}

    min_confidence = Decimal(str(resolution_config.get("text_chunk_min_confidence", "0.6500")))
    max_lines_per_chunk = int(resolution_config.get("text_chunk_max_lines_per_chunk", 250))
    chunks = _fetchall(
        cur,
        """
        SELECT
            c.text_chunk_id,
            c.page_number,
            c.chunk_index,
            c.section_label,
            c.text_content,
            pi.page_type
        FROM fsre_ingestion.document_text_chunks c
        LEFT JOIN fsre_ingestion.document_page_inventory pi
          ON pi.raw_document_id = c.raw_document_id
         AND pi.page_number = c.page_number
        WHERE c.run_id = %s
          AND c.raw_document_id = %s
        ORDER BY c.page_number NULLS LAST, c.chunk_index
        """,
        (context.run_id, context.raw_document_id),
    )

    candidate_count = 0
    resolved_count = 0
    for chunk in chunks:
        text = str(chunk.get("text_content") or "")
        if not text.strip():
            continue
        chunk_unit, chunk_multiplier = infer_text_numeric_unit(text)
        lines = [normalize_whitespace(line) for line in text.splitlines()]
        for line_index, line in enumerate(lines[:max_lines_per_chunk]):
            if not line or not re.search(r"\d", line):
                continue
            page_type = chunk.get("page_type")
            field_match = match_field(
                line,
                synonyms,
                required_field_paths=required_field_paths,
                page_type=page_type,
                negative_patterns=negative_patterns,
            )
            if not field_match:
                continue

            line_unit, line_multiplier = infer_text_numeric_unit(line)
            unit = line_unit or chunk_unit
            unit_multiplier = line_multiplier if line_unit else chunk_multiplier
            values = extract_line_numeric_values(line, unit_multiplier)
            if not values:
                continue
            periods = infer_periods_for_text_line(line, current_period, prior_period, len(values))

            for value_index, value in enumerate(values):
                period_label = periods[value_index] if value_index < len(periods) else None
                if not period_label:
                    continue
                period_role = period_role_for_label(period_label, current_period, prior_period)
                if not is_required_period_role(
                    field_match["field_path"],
                    period_role,
                    required_field_requirements,
                ):
                    continue

                confidence = Decimal(str(field_match["confidence"])) * Decimal("0.8800")
                if confidence < min_confidence:
                    continue
                source_ref = {
                    "source": "ocr_or_text_chunk",
                    "text_chunk_id": str(chunk["text_chunk_id"]),
                    "page_number": chunk.get("page_number"),
                    "chunk_index": chunk.get("chunk_index"),
                    "line_index": line_index,
                    "raw_line": line,
                    "value_index": value_index,
                    "field_synonym": field_match["synonym_text"],
                    "field_synonym_source": field_match.get("source") or "field_synonym_registry",
                    "page_type": page_type,
                    "unit": unit,
                    "unit_multiplier": str(unit_multiplier),
                    "primary_reporting_scope": primary_reporting_scope,
                    "required_field_manifest_scoped": True,
                    "fallback_reason": "financial table extraction was unavailable or incomplete",
                }
                cur.execute(
                    """
                    INSERT INTO fsre_ingestion.field_candidates (
                        run_id,
                        raw_document_id,
                        document_table_id,
                        table_cell_id,
                        entity_id,
                        candidate_field_path,
                        raw_label,
                        raw_value_text,
                        normalized_value_numeric,
                        normalized_value_text,
                        period_label,
                        period_role,
                        currency,
                        unit,
                        page_number,
                        extraction_method,
                        confidence_score,
                        source_ref_json
                    )
                    VALUES (%s, %s, NULL, NULL, %s, %s, %s, %s, %s, %s, %s, %s, NULL, %s, %s, %s, %s, %s::jsonb)
                    RETURNING field_candidate_id
                    """,
                    (
                        context.run_id,
                        context.raw_document_id,
                        context.entity_id,
                        field_match["field_path"],
                        line,
                        value["raw_text"],
                        value["numeric_value"],
                        None,
                        period_label,
                        period_role,
                        unit,
                        chunk.get("page_number"),
                        "ocr_text_chunk_synonym_v1",
                        confidence,
                        json_dumps(source_ref),
                    ),
                )
                field_candidate_id = cur.fetchone()["field_candidate_id"]
                candidate_count += 1

                field_path = str(field_match["field_path"])
                cur.execute(
                    """
                    INSERT INTO fsre_ingestion.resolved_fields (
                        run_id,
                        raw_document_id,
                        field_candidate_id,
                        entity_id,
                        field_path,
                        field_name,
                        period_label,
                        period_role,
                        raw_value_text,
                        normalized_value_numeric,
                        normalized_value_text,
                        currency,
                        unit,
                        page_number,
                        extraction_method,
                        confidence_score,
                        is_accepted,
                        needs_review,
                        review_reason,
                        source_ref_json
                    )
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, NULL, %s, %s, %s, %s, TRUE, TRUE, %s, %s::jsonb)
                    """,
                    (
                        context.run_id,
                        context.raw_document_id,
                        field_candidate_id,
                        context.entity_id,
                        field_path,
                        field_path.split(".")[-1],
                        period_label,
                        period_role,
                        value["raw_text"],
                        value["numeric_value"],
                        None,
                        unit,
                        chunk.get("page_number"),
                        "ocr_text_chunk_synonym_v1",
                        confidence,
                        "resolved_from_ocr_or_text_chunk_fallback",
                        json_dumps(source_ref),
                    ),
                )
                resolved_count += 1

    return {"candidate_count": candidate_count, "resolved_count": resolved_count}


def infer_text_numeric_unit(text: str) -> tuple[Optional[str], Decimal]:
    raw = text.lower()
    normalized = normalize_label(text)
    if re.search(r"\b(million|millions)\b", normalized) or re.search(r"(?:us|s)?\$\s*m\b", raw):
        return "million", Decimal("1000000")
    if (
        re.search(r"\b(thousand|thousands)\b", normalized)
        or re.search(r"(?:us|s)?\$?\s*['’]?\s*000\b", raw)
    ):
        return "thousand", Decimal("1000")
    return None, Decimal("1")


def extract_line_numeric_values(line: str, unit_multiplier: Decimal) -> list[dict[str, Any]]:
    token_pattern = r"(?<![A-Za-z])\(?-?\d[\d,]*(?:\.\d+)?\)?(?![A-Za-z])"
    raw_tokens = re.findall(token_pattern, line)
    values: list[dict[str, Any]] = []
    for raw_token in raw_tokens:
        token = normalize_whitespace(raw_token)
        if re.fullmatch(r"(?:19|20)\d{2}", token):
            continue
        numeric_value = normalize_numeric(token)
        if numeric_value is None:
            continue
        values.append(
            {
                "raw_text": token,
                "numeric_value": numeric_value * unit_multiplier,
            }
        )

    if len(values) > 2 and abs(values[0]["numeric_value"]) <= Decimal("100"):
        values = values[1:]
    return values[:2]


def infer_periods_for_text_line(
    line: str,
    current_period: Optional[str],
    prior_period: Optional[str],
    value_count: int,
) -> list[Optional[str]]:
    year_labels = [
        f"FY{match}"
        for match in re.findall(r"\b((?:19|20)\d{2})\b", line)
    ]
    if len(year_labels) >= value_count:
        return year_labels[:value_count]
    periods: list[Optional[str]] = []
    if value_count >= 1:
        periods.append(current_period)
    if value_count >= 2:
        periods.append(prior_period)
    while len(periods) < value_count:
        periods.append(None)
    return periods


def resolve_section_subtotals(
    cur: Any,
    context: RunDocumentContext,
    table: dict[str, Any],
    rows: dict[int, list[dict[str, Any]]],
    table_context: TableExtractionContext,
    required_field_requirements: dict[str, set[str]],
    required_field_paths: set[str],
    synonyms: list[dict[str, Any]],
    negative_patterns: list[dict[str, Any]],
    current_period: Optional[str],
    prior_period: Optional[str],
    primary_reporting_scope: str,
    min_confidence: Decimal,
) -> dict[str, int]:
    active_section_label: Optional[str] = None
    active_field_path: Optional[str] = None
    section_field_paths = {
        field_path
        for field_path in required_field_paths
        if field_path in {"financials.current_assets", "financials.current_liabilities"}
    }
    candidate_count = 0
    resolved_count = 0
    confidence = Decimal("0.9400")
    if confidence < min_confidence or not section_field_paths:
        return {"candidate_count": 0, "resolved_count": 0}

    for row_index in sorted(rows):
        row_cells = rows[row_index]
        label_cell = first_label_cell(row_cells)
        if label_cell:
            section_match = match_field(
                label_cell["raw_text"],
                synonyms,
                required_field_paths=section_field_paths,
                page_type=table.get("page_type"),
                negative_patterns=negative_patterns,
            )
            if section_match:
                active_section_label = label_cell["raw_text"]
                active_field_path = section_match["field_path"]
            continue

        if not active_field_path or active_field_path not in required_field_paths:
            continue

        numeric_cells = [
            cell
            for cell in row_cells
            if cell["column_index"] not in table_context.note_columns
            and normalize_numeric_with_table_unit(cell["raw_text"], table_context.unit_multiplier) is not None
        ]
        if not numeric_cells:
            continue

        for value_cell in numeric_cells:
            reporting_scope = table_context.column_scope_by_col.get(value_cell["column_index"])
            if (
                primary_reporting_scope
                and reporting_scope
                and reporting_scope != primary_reporting_scope
            ):
                continue
            period_label = infer_period_for_subtotal_cell(
                value_cell,
                row_cells,
                table_context,
                current_period,
                prior_period,
            )
            if not period_label:
                continue
            period_role = period_role_for_label(period_label, current_period, prior_period)
            if not is_required_period_role(
                active_field_path,
                period_role,
                required_field_requirements,
            ):
                continue
            numeric_value = normalize_numeric_with_table_unit(
                value_cell["raw_text"],
                table_context.unit_multiplier,
            )
            if numeric_value is None:
                continue

            source_ref = {
                "source": "section_subtotal_resolver",
                "page_number": table["page_number"],
                "table_index": table["table_index"],
                "extractor_version": table.get("extractor_version"),
                "row_index": row_index,
                "column_index": value_cell["column_index"],
                "raw_label": active_section_label,
                "section_label": active_section_label,
                "column_header": table_context.header_by_col.get(value_cell["column_index"]),
                "table_cell_id": str(value_cell["table_cell_id"]),
                "page_type": table.get("page_type"),
                "currency": table_context.currency,
                "unit": table_context.unit,
                "unit_multiplier": str(table_context.unit_multiplier),
                "reporting_scope": reporting_scope,
                "primary_reporting_scope": primary_reporting_scope,
                "required_field_manifest_scoped": True,
            }
            raw_label = f"{active_section_label} subtotal"
            cur.execute(
                """
                INSERT INTO fsre_ingestion.field_candidates (
                    run_id,
                    raw_document_id,
                    document_table_id,
                    table_cell_id,
                    entity_id,
                    candidate_field_path,
                    raw_label,
                    raw_value_text,
                    normalized_value_numeric,
                    normalized_value_text,
                    period_label,
                    period_role,
                    currency,
                    unit,
                    page_number,
                    extraction_method,
                    confidence_score,
                    source_ref_json
                )
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s::jsonb)
                RETURNING field_candidate_id
                """,
                (
                    context.run_id,
                    context.raw_document_id,
                    table["document_table_id"],
                    value_cell["table_cell_id"],
                    context.entity_id,
                    active_field_path,
                    raw_label,
                    value_cell["raw_text"],
                    numeric_value,
                    None,
                    period_label,
                    period_role,
                    table_context.currency,
                    table_context.unit,
                    table["page_number"],
                    "section_subtotal_resolver_v1",
                    confidence,
                    json_dumps(source_ref),
                ),
            )
            field_candidate_id = cur.fetchone()["field_candidate_id"]
            candidate_count += 1

            field_name = active_field_path.split(".")[-1]
            cur.execute(
                """
                INSERT INTO fsre_ingestion.resolved_fields (
                    run_id,
                    raw_document_id,
                    field_candidate_id,
                    entity_id,
                    field_path,
                    field_name,
                    period_label,
                    period_role,
                    raw_value_text,
                    normalized_value_numeric,
                    normalized_value_text,
                    currency,
                    unit,
                    page_number,
                    extraction_method,
                    confidence_score,
                    is_accepted,
                    needs_review,
                    review_reason,
                    source_ref_json
                )
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, TRUE, FALSE, NULL, %s::jsonb)
                """,
                (
                    context.run_id,
                    context.raw_document_id,
                    field_candidate_id,
                    context.entity_id,
                    active_field_path,
                    field_name,
                    period_label,
                    period_role,
                    value_cell["raw_text"],
                    numeric_value,
                    None,
                    table_context.currency,
                    table_context.unit,
                    table["page_number"],
                    "section_subtotal_resolver_v1",
                    confidence,
                    json_dumps(source_ref),
                ),
            )
            resolved_count += 1

        active_section_label = None
        active_field_path = None

    return {"candidate_count": candidate_count, "resolved_count": resolved_count}


def infer_period_for_subtotal_cell(
    value_cell: dict[str, Any],
    row_cells: list[dict[str, Any]],
    table_context: TableExtractionContext,
    current_period: Optional[str],
    prior_period: Optional[str],
) -> Optional[str]:
    column_index = value_cell["column_index"]
    explicit_period = normalize_period_label(table_context.header_by_col.get(column_index))
    if explicit_period:
        return explicit_period

    numeric_value_columns = sorted(
        cell["column_index"]
        for cell in row_cells
        if cell["column_index"] not in table_context.note_columns
        and normalize_numeric(cell["raw_text"]) is not None
    )
    if column_index in numeric_value_columns:
        offset = numeric_value_columns.index(column_index)
        if offset == 0:
            return current_period
        if offset == 1:
            return prior_period
    return None


def accept_best_resolved_fields(cur: Any, context: RunDocumentContext) -> dict[str, int]:
    cur.execute(
        """
        WITH ranked AS (
            SELECT
                resolved_field_id,
                row_number() OVER (
                    PARTITION BY run_id, raw_document_id, entity_id, field_path, period_label
                    ORDER BY
                        CASE COALESCE(source_ref_json ->> 'page_type', '')
                            WHEN 'income_statement' THEN 0
                            WHEN 'balance_sheet' THEN 0
                            WHEN 'cash_flow' THEN 0
                            WHEN 'notes' THEN 1
                            WHEN 'financial_summary' THEN 3
                            WHEN 'management_discussion' THEN 4
                            ELSE 2
                        END ASC,
                        confidence_score DESC NULLS LAST,
                        page_number ASC NULLS LAST,
                        created_at DESC
                ) AS rn
            FROM fsre_ingestion.resolved_fields
            WHERE run_id = %s
              AND raw_document_id = %s
              AND extraction_method <> 'derived_formula_v1'
        )
        UPDATE fsre_ingestion.resolved_fields rf
        SET
            is_accepted = ranked.rn = 1,
            needs_review = CASE WHEN ranked.rn = 1 THEN rf.needs_review ELSE TRUE END,
            review_reason = CASE
                WHEN ranked.rn = 1 THEN rf.review_reason
                ELSE COALESCE(rf.review_reason, 'lower_ranked_duplicate_candidate')
            END
        FROM ranked
        WHERE rf.resolved_field_id = ranked.resolved_field_id
        """,
        (context.run_id, context.raw_document_id),
    )
    rows = _fetchall(
        cur,
        """
        SELECT
            count(*) FILTER (WHERE is_accepted = TRUE) AS accepted_count,
            count(*) FILTER (WHERE is_accepted = FALSE) AS rejected_duplicate_count
        FROM fsre_ingestion.resolved_fields
        WHERE run_id = %s
          AND raw_document_id = %s
          AND extraction_method <> 'derived_formula_v1'
        """,
        (context.run_id, context.raw_document_id),
    )
    row = rows[0] if rows else {}
    return {
        "accepted_count": int(row.get("accepted_count") or 0),
        "rejected_duplicate_count": int(row.get("rejected_duplicate_count") or 0),
    }


def create_derived_financial_fields(cur: Any, context: RunDocumentContext) -> int:
    fields = _fetchall(
        cur,
        """
        SELECT *
        FROM fsre_ingestion.resolved_fields
        WHERE run_id = %s
          AND raw_document_id = %s
          AND is_accepted = TRUE
          AND field_path IN (
              'financials.revenue',
              'financials.gross_profit',
              'financials.cost_of_goods_sold',
              'financials.current_assets',
              'financials.current_liabilities',
              'financials.total_assets',
              'financials.total_equity',
              'financials.total_liabilities'
          )
        """,
        (context.run_id, context.raw_document_id),
    )
    by_period: dict[str, dict[str, dict[str, Any]]] = {}
    for field in fields:
        period = field.get("period_label")
        if not period:
            continue
        by_period.setdefault(period, {})
        existing = by_period[period].get(field["field_path"])
        if not existing or (field.get("confidence_score") or 0) > (existing.get("confidence_score") or 0):
            by_period[period][field["field_path"]] = field

    inserted = 0
    for period_label, period_fields in by_period.items():
        revenue = period_fields.get("financials.revenue")
        gross_profit = period_fields.get("financials.gross_profit")
        cogs = period_fields.get("financials.cost_of_goods_sold")
        if not revenue or not revenue.get("normalized_value_numeric"):
            continue

        revenue_value = Decimal(str(revenue["normalized_value_numeric"]))
        if revenue_value == 0:
            continue
        if gross_profit and gross_profit.get("normalized_value_numeric") is not None:
            numerator = Decimal(str(gross_profit["normalized_value_numeric"]))
            formula = "gross_profit / revenue"
            sources = [gross_profit, revenue]
        elif cogs and cogs.get("normalized_value_numeric") is not None:
            numerator = revenue_value - Decimal(str(cogs["normalized_value_numeric"]))
            formula = "(revenue - cost_of_goods_sold) / revenue"
            sources = [revenue, cogs]
        else:
            continue

        gross_margin = numerator / revenue_value
        confidence_values = [
            Decimal(str(source["confidence_score"]))
            for source in sources
            if source.get("confidence_score") is not None
        ]
        confidence = min(confidence_values) if confidence_values else Decimal("0.8000")
        source_ref = {
            "source": "derived_formula",
            "formula": formula,
            "source_resolved_field_ids": [str(source["resolved_field_id"]) for source in sources],
            "source_pages": [source.get("page_number") for source in sources],
        }
        cur.execute(
            """
            INSERT INTO fsre_ingestion.resolved_fields (
                run_id,
                raw_document_id,
                field_candidate_id,
                entity_id,
                field_path,
                field_name,
                period_label,
                period_role,
                raw_value_text,
                normalized_value_numeric,
                normalized_value_text,
                page_number,
                extraction_method,
                confidence_score,
                is_accepted,
                needs_review,
                review_reason,
                source_ref_json
            )
            VALUES (%s, %s, NULL, %s, 'financials.gross_margin', 'gross_margin',
                    %s, %s, %s, %s, %s, %s, 'derived_formula_v1', %s, TRUE, %s, %s, %s::jsonb)
            """,
            (
                context.run_id,
                context.raw_document_id,
                context.entity_id,
                period_label,
                period_role_for_label(
                    period_label,
                    normalize_period_label(context.reporting_period_label),
                    prior_period_label(context.reporting_period_label),
                ),
                None,
                gross_margin,
                None,
                sources[0].get("page_number"),
                confidence,
                confidence < Decimal("0.8500"),
                "derived_from_low_confidence_source" if confidence < Decimal("0.8500") else None,
                json_dumps(source_ref),
            ),
        )
        inserted += 1

    for period_label, period_fields in by_period.items():
        current_assets = period_fields.get("financials.current_assets")
        current_liabilities = period_fields.get("financials.current_liabilities")
        if (
            not current_assets
            or not current_liabilities
            or current_assets.get("normalized_value_numeric") is None
            or current_liabilities.get("normalized_value_numeric") is None
        ):
            continue

        sources = [current_assets, current_liabilities]
        working_capital = Decimal(str(current_assets["normalized_value_numeric"])) - Decimal(
            str(current_liabilities["normalized_value_numeric"])
        )
        confidence_values = [
            Decimal(str(source["confidence_score"]))
            for source in sources
            if source.get("confidence_score") is not None
        ]
        confidence = min(confidence_values) if confidence_values else Decimal("0.8000")
        source_ref = {
            "source": "derived_formula",
            "formula": "current_assets - current_liabilities",
            "source_resolved_field_ids": [str(source["resolved_field_id"]) for source in sources],
            "source_pages": [source.get("page_number") for source in sources],
        }
        cur.execute(
            """
            INSERT INTO fsre_ingestion.resolved_fields (
                run_id,
                raw_document_id,
                field_candidate_id,
                entity_id,
                field_path,
                field_name,
                period_label,
                period_role,
                raw_value_text,
                normalized_value_numeric,
                normalized_value_text,
                page_number,
                extraction_method,
                confidence_score,
                is_accepted,
                needs_review,
                review_reason,
                source_ref_json
            )
            VALUES (%s, %s, NULL, %s, 'financials.working_capital', 'working_capital',
                    %s, %s, %s, %s, %s, %s, 'derived_formula_v1', %s, TRUE, %s, %s, %s::jsonb)
            """,
            (
                context.run_id,
                context.raw_document_id,
                context.entity_id,
                period_label,
                period_role_for_label(
                    period_label,
                    normalize_period_label(context.reporting_period_label),
                    prior_period_label(context.reporting_period_label),
                ),
                None,
                working_capital,
                None,
                current_assets.get("page_number") or current_liabilities.get("page_number"),
                confidence,
                confidence < Decimal("0.8500"),
                "derived_from_low_confidence_source" if confidence < Decimal("0.8500") else None,
                json_dumps(source_ref),
            ),
        )
        inserted += 1

    for period_label, period_fields in by_period.items():
        if period_fields.get("financials.total_liabilities"):
            continue
        total_assets = period_fields.get("financials.total_assets")
        total_equity = period_fields.get("financials.total_equity")
        if (
            not total_assets
            or not total_equity
            or total_assets.get("normalized_value_numeric") is None
            or total_equity.get("normalized_value_numeric") is None
        ):
            continue

        sources = [total_assets, total_equity]
        total_liabilities = Decimal(str(total_assets["normalized_value_numeric"])) - Decimal(
            str(total_equity["normalized_value_numeric"])
        )
        confidence_values = [
            Decimal(str(source["confidence_score"]))
            for source in sources
            if source.get("confidence_score") is not None
        ]
        confidence = min(confidence_values) if confidence_values else Decimal("0.8000")
        source_ref = {
            "source": "derived_formula",
            "formula": "total_assets - total_equity",
            "source_resolved_field_ids": [str(source["resolved_field_id"]) for source in sources],
            "source_pages": [source.get("page_number") for source in sources],
            "derivation_reason": "Direct total liabilities row was not resolved.",
        }
        cur.execute(
            """
            INSERT INTO fsre_ingestion.resolved_fields (
                run_id,
                raw_document_id,
                field_candidate_id,
                entity_id,
                field_path,
                field_name,
                period_label,
                period_role,
                raw_value_text,
                normalized_value_numeric,
                normalized_value_text,
                page_number,
                extraction_method,
                confidence_score,
                is_accepted,
                needs_review,
                review_reason,
                source_ref_json
            )
            VALUES (%s, %s, NULL, %s, 'financials.total_liabilities', 'total_liabilities',
                    %s, %s, %s, %s, %s, %s, 'derived_formula_v1', %s, TRUE, %s, %s, %s::jsonb)
            """,
            (
                context.run_id,
                context.raw_document_id,
                context.entity_id,
                period_label,
                period_role_for_label(
                    period_label,
                    normalize_period_label(context.reporting_period_label),
                    prior_period_label(context.reporting_period_label),
                ),
                None,
                total_liabilities,
                None,
                total_assets.get("page_number") or total_equity.get("page_number"),
                confidence,
                True,
                "derived_total_liabilities_from_assets_less_equity",
                json_dumps(source_ref),
            ),
        )
        inserted += 1
    return inserted


def resolve_numeric_zero_evidence_fields(
    cur: Any,
    context: RunDocumentContext,
    required_field_requirements: dict[str, set[str]],
) -> int:
    required_field_paths = set(required_field_requirements)
    patterns = load_active_zero_evidence_patterns(cur, context, required_field_paths)
    if not patterns:
        return 0

    current_period = normalize_period_label(context.reporting_period_label)
    prior_period = prior_period_label(current_period)
    next_period = next_period_label(current_period)
    chunks = _fetchall(
        cur,
        """
        SELECT
            c.text_chunk_id,
            c.page_number,
            c.chunk_index,
            c.text_content,
            pi.page_type
        FROM fsre_ingestion.document_text_chunks c
        LEFT JOIN fsre_ingestion.document_page_inventory pi
          ON pi.raw_document_id = c.raw_document_id
         AND pi.page_number = c.page_number
        WHERE c.run_id = %s
          AND c.raw_document_id = %s
        ORDER BY c.page_number NULLS LAST, c.chunk_index
        """,
        (context.run_id, context.raw_document_id),
    )

    inserted = 0
    for pattern in patterns:
        field_path = str(pattern["field_path"])
        period_role = str(pattern.get("period_role") or "current")
        if not is_required_period_role(field_path, period_role, required_field_requirements):
            continue
        period_label = expected_period_for_role(period_role, current_period, prior_period, next_period)
        if not period_label and period_role in {"current", "prior", "next_period"}:
            continue
        if accepted_resolved_field_exists(
            cur,
            context,
            field_path,
            period_label,
            period_role,
        ):
            continue

        for chunk in chunks:
            evidence = match_zero_evidence_text(
                str(chunk["text_content"] or ""),
                str(pattern["evidence_pattern_text"]),
                str(pattern["match_type"]),
            )
            if evidence is None:
                continue

            confidence = Decimal(str(pattern.get("confidence") or "0.9000"))
            source_ref = {
                "source": "numeric_zero_evidence",
                "text_chunk_id": str(chunk["text_chunk_id"]),
                "page_number": chunk.get("page_number"),
                "chunk_index": chunk.get("chunk_index"),
                "evidence_pattern": pattern["evidence_pattern_text"],
                "match_type": pattern["match_type"],
                "evidence_text": evidence,
                "zero_value_policy": {
                    "profile_id": pattern.get("profile_id"),
                    "profile_version": pattern.get("profile_version"),
                    "connector_id": pattern.get("connector_id"),
                    "connector_version": pattern.get("connector_version"),
                    "environment": pattern.get("environment"),
                    "scope_score": pattern.get("scope_score"),
                },
            }
            cur.execute(
                """
                INSERT INTO fsre_ingestion.resolved_fields (
                    run_id,
                    raw_document_id,
                    field_candidate_id,
                    entity_id,
                    field_path,
                    field_name,
                    period_label,
                    period_role,
                    raw_value_text,
                    normalized_value_numeric,
                    normalized_value_text,
                    page_number,
                    extraction_method,
                    confidence_score,
                    is_accepted,
                    needs_review,
                    review_reason,
                    source_ref_json
                )
                VALUES (%s, %s, NULL, %s, %s, %s, %s, %s, %s, 0, '0',
                        %s, 'numeric_zero_evidence_v1', %s, TRUE, %s, %s, %s::jsonb)
                """,
                (
                    context.run_id,
                    context.raw_document_id,
                    context.entity_id,
                    field_path,
                    field_path.split(".")[-1],
                    period_label,
                    period_role,
                    "0",
                    chunk.get("page_number"),
                    confidence,
                    confidence < Decimal("0.8500"),
                    "zero_evidence_below_review_threshold" if confidence < Decimal("0.8500") else None,
                    json_dumps(source_ref),
                ),
            )
            inserted += 1
            break

    return inserted


def load_required_narrative_field_requirements(cur: Any, run_id: str) -> list[dict[str, Any]]:
    return _fetchall(
        cur,
        """
        WITH required_narrative AS (
            SELECT DISTINCT
                m.required_field_path,
                m.canonical_field_path,
                m.period_role,
                c.field_name,
                c.data_type,
                FALSE AS is_optional,
                m.rule_id,
                m.rule_version
            FROM fsre_rules.run_required_field_manifest m
            JOIN fsre_config.field_catalog c
              ON c.field_path = m.canonical_field_path
            WHERE m.run_id = %s
              AND c.status = 'active'
              AND c.data_type IN ('text', 'json', 'number')
              AND (
                  m.canonical_field_path LIKE 'notes.%%'
                  OR m.canonical_field_path LIKE 'events.%%'
                  OR m.canonical_field_path LIKE 'sgx_announcements.%%'
                  OR m.canonical_field_path LIKE 'related_party%%'
                  OR m.canonical_field_path LIKE 'benchmarks.%%'
                  OR m.canonical_field_path LIKE 'ownership%%'
                  OR m.canonical_field_path LIKE 'governance.%%'
                  OR m.canonical_field_path = 'financials.provisions_and_contingent_liabilities'
              )
        ),
        optional_narrative AS (
            SELECT DISTINCT
                optional_path.required_field_path,
                split_part(optional_path.required_field_path, '.', 1)
                    || '.' ||
                    split_part(optional_path.required_field_path, '.', 2) AS canonical_field_path_guess,
                CASE
                    WHEN optional_path.required_field_path LIKE '%%.current' THEN 'current'
                    WHEN optional_path.required_field_path LIKE '%%.prior' THEN 'prior'
                    WHEN optional_path.required_field_path LIKE '%%.next_period' THEN 'next_period'
                    ELSE 'unspecified'
                END AS period_role,
                m.rule_id,
                m.rule_version
            FROM fsre_rules.run_required_field_manifest m
            JOIN fsre_rules.rule_registry rr
              ON rr.rule_id = m.rule_id
             AND rr.rule_version = m.rule_version
            CROSS JOIN LATERAL jsonb_array_elements_text(
                COALESCE(rr.threshold_config_json -> 'optional_fields', '[]'::jsonb)
            ) AS optional_path(required_field_path)
            WHERE m.run_id = %s
        ),
        optional_narrative_normalized AS (
            SELECT DISTINCT
                o.required_field_path,
                CASE
                    WHEN o.period_role = 'current' THEN regexp_replace(o.required_field_path, '[.]current$', '')
                    WHEN o.period_role = 'prior' THEN regexp_replace(o.required_field_path, '[.]prior$', '')
                    WHEN o.period_role = 'next_period' THEN regexp_replace(o.required_field_path, '[.]next_period$', '')
                    ELSE o.required_field_path
                END AS canonical_field_path,
                o.period_role,
                c.field_name,
                c.data_type,
                TRUE AS is_optional,
                o.rule_id,
                o.rule_version
            FROM optional_narrative o
            JOIN fsre_config.field_catalog c
              ON c.field_path = CASE
                    WHEN o.period_role = 'current' THEN regexp_replace(o.required_field_path, '[.]current$', '')
                    WHEN o.period_role = 'prior' THEN regexp_replace(o.required_field_path, '[.]prior$', '')
                    WHEN o.period_role = 'next_period' THEN regexp_replace(o.required_field_path, '[.]next_period$', '')
                    ELSE o.required_field_path
                END
            WHERE c.status = 'active'
              AND c.data_type IN ('text', 'json', 'number')
              AND (
                  c.field_path LIKE 'notes.%%'
                  OR c.field_path LIKE 'events.%%'
                  OR c.field_path LIKE 'sgx_announcements.%%'
                  OR c.field_path LIKE 'related_party%%'
                  OR c.field_path LIKE 'benchmarks.%%'
                  OR c.field_path LIKE 'ownership%%'
                  OR c.field_path LIKE 'governance.%%'
                  OR c.field_path = 'financials.provisions_and_contingent_liabilities'
              )
        )
        SELECT DISTINCT
            m.required_field_path,
            m.canonical_field_path,
            m.period_role,
            m.field_name,
            m.data_type,
            m.is_optional,
            m.rule_id,
            m.rule_version
        FROM (
            SELECT * FROM required_narrative
            UNION ALL
            SELECT * FROM optional_narrative_normalized
        ) m
        ORDER BY m.canonical_field_path, m.period_role, m.is_optional
        """,
        (run_id, run_id),
    )


def load_active_narrative_evidence_patterns(
    cur: Any,
    context: RunDocumentContext,
    required_field_paths: set[str],
) -> list[dict[str, Any]]:
    registry = _fetchone(
        cur,
        "SELECT to_regclass('fsre_config.narrative_evidence_registry') AS relation_name",
        (),
    )
    if not registry or not registry.get("relation_name") or not required_field_paths:
        return []

    return _fetchall(
        cur,
        """
        SELECT
            n.narrative_pattern_id,
            n.field_path,
            c.field_name,
            n.evidence_pattern_text,
            n.match_type,
            n.priority,
            n.confidence,
            n.evidence_window_chars,
            n.metadata_json,
            n.profile_id,
            n.profile_version,
            n.connector_id,
            n.connector_version,
            n.environment,
            n.reason,
            (
                CASE WHEN n.profile_id = %s THEN 16 ELSE 0 END +
                CASE WHEN n.profile_version = %s THEN 8 ELSE 0 END +
                CASE WHEN n.connector_id = %s THEN 4 ELSE 0 END +
                CASE WHEN n.connector_version = %s THEN 2 ELSE 0 END +
                CASE WHEN n.environment = %s THEN 1 ELSE 0 END
            ) AS scope_score
        FROM fsre_config.narrative_evidence_registry n
        JOIN fsre_config.field_catalog c
          ON c.field_path = n.field_path
        WHERE n.status = 'active'
          AND c.status = 'active'
          AND c.data_type IN ('text', 'json', 'number')
          AND n.field_path = ANY(%s)
          AND n.profile_id IN ('*', %s)
          AND n.profile_version IN ('*', %s)
          AND n.connector_id IN ('*', %s)
          AND n.connector_version IN ('*', %s)
          AND n.environment IN ('*', %s)
          AND (n.effective_from IS NULL OR n.effective_from <= now())
          AND (n.effective_to IS NULL OR n.effective_to > now())
        ORDER BY scope_score DESC, n.priority ASC, length(n.evidence_pattern_text) DESC
        """,
        (
            context.profile_id,
            context.profile_version,
            context.connector_id,
            context.connector_version or "*",
            context.environment or "*",
            list(required_field_paths),
            context.profile_id,
            context.profile_version,
            context.connector_id,
            context.connector_version or "*",
            context.environment or "*",
        ),
    )


def resolve_narrative_evidence_fields(
    cur: Any,
    run_id: str,
    raw_document_id: Optional[str] = None,
) -> dict[str, Any]:
    context = get_run_context(cur, run_id, raw_document_id)
    requirements = load_required_narrative_field_requirements(cur, run_id)
    required_field_paths = {str(row["canonical_field_path"]) for row in requirements}
    patterns = load_active_narrative_evidence_patterns(cur, context, required_field_paths)
    current_period = normalize_period_label(context.reporting_period_label)
    prior_period = prior_period_label(current_period)
    next_period = next_period_label(current_period)

    cur.execute(
        """
        DELETE FROM fsre_ingestion.resolved_fields
        WHERE run_id = %s
          AND (entity_id = %s OR (entity_id IS NULL AND %s IS NULL))
          AND extraction_method = 'narrative_evidence_pattern_v1'
        """,
        (context.run_id, context.entity_id, context.entity_id),
    )
    narrative_trace_table_exists = relation_exists(
        cur,
        "fsre_ingestion.narrative_candidate_trace",
    )
    if narrative_trace_table_exists:
        cur.execute(
            """
            DELETE FROM fsre_ingestion.narrative_candidate_trace
            WHERE run_id = %s
              AND (entity_id = %s OR (entity_id IS NULL AND %s IS NULL))
            """,
            (context.run_id, context.entity_id, context.entity_id),
        )

    if not requirements:
        return {
            "run_id": context.run_id,
            "raw_document_id": context.raw_document_id,
            "required_narrative_field_count": 0,
            "configured_pattern_count": 0,
            "resolved_narrative_field_count": 0,
        }
    if not patterns:
        return {
            "run_id": context.run_id,
            "raw_document_id": context.raw_document_id,
            "required_narrative_field_count": len(requirements),
            "configured_pattern_count": 0,
            "resolved_narrative_field_count": 0,
        }

    patterns_by_field: dict[str, list[dict[str, Any]]] = {}
    for pattern in patterns:
        patterns_by_field.setdefault(str(pattern["field_path"]), []).append(pattern)

    chunks_by_raw_document_id: dict[str, list[dict[str, Any]]] = {}

    inserted = 0
    candidate_count = 0
    accepted_candidate_count = 0
    rejected_candidate_count = 0
    referenced_candidate_count = 0
    unresolved: list[str] = []
    for requirement in requirements:
        field_path = str(requirement["canonical_field_path"])
        period_role = str(requirement.get("period_role") or "unspecified")
        period_label = expected_period_for_role(period_role, current_period, prior_period, next_period)
        if not period_label and period_role in {"current", "prior", "next_period"}:
            unresolved.append(str(requirement["required_field_path"]))
            continue
        if accepted_resolved_field_exists(cur, context, field_path, period_label, period_role):
            continue

        candidate_contexts = select_narrative_document_contexts(
            cur,
            context,
            period_role,
            period_label,
        )
        matched = False
        for pattern in patterns_by_field.get(field_path, []):
            window = int(pattern.get("evidence_window_chars") or 400)
            for document_context in candidate_contexts:
                chunks = chunks_by_raw_document_id.get(document_context.raw_document_id)
                if chunks is None:
                    chunks = fetch_narrative_chunks(cur, document_context)
                    chunks_by_raw_document_id[document_context.raw_document_id] = chunks
                is_expected_period_document = is_context_for_expected_period(
                    document_context,
                    period_label,
                )
                for chunk in chunks:
                    if not narrative_pattern_allows_chunk(pattern, chunk):
                        continue
                    evidence = match_narrative_evidence_text(
                        str(chunk["text_content"] or ""),
                        str(pattern["evidence_pattern_text"]),
                        str(pattern["match_type"]),
                        window=window,
                    )
                    if evidence is None:
                        continue

                    metadata = normalize_metadata_dict(pattern.get("metadata_json") or {})
                    evidence = trim_narrative_evidence_to_accepted_section(metadata, evidence)
                    evidence_check = narrative_metadata_check(metadata, evidence)
                    section_heading = str(chunk.get("section_heading") or "")
                    numeric_value = extract_narrative_numeric_value(
                        metadata,
                        evidence,
                        period_role,
                    )
                    decision, decision_reason = decide_narrative_candidate(
                        metadata,
                        evidence,
                        section_heading,
                        evidence_check,
                        period_role,
                        is_expected_period_document,
                    )
                    candidate_count += 1
                    if decision == "accepted":
                        accepted_candidate_count += 1
                    elif decision == "referenced":
                        referenced_candidate_count += 1
                    else:
                        rejected_candidate_count += 1

                    confidence = Decimal(str(pattern.get("confidence") or "0.9000"))
                    source_ref = build_narrative_source_ref(
                        pattern,
                        requirement,
                        chunk,
                        evidence,
                        decision,
                        decision_reason,
                        evidence_check,
                    )
                    source_ref["source_document"] = {
                        "source_run_id": document_context.source_run_id or document_context.run_id,
                        "raw_document_id": document_context.raw_document_id,
                        "file_name": document_context.file_name,
                        "reporting_period_label": document_context.reporting_period_label,
                        "storage_uri": document_context.storage_uri,
                        "period_match": is_expected_period_document,
                    }
                    insert_narrative_candidate_trace(
                        cur,
                        document_context,
                        requirement,
                        pattern,
                        chunk,
                        period_label,
                        period_role,
                        evidence,
                        decision,
                        decision_reason,
                        confidence,
                        evidence_check,
                        source_ref,
                        narrative_trace_table_exists,
                    )

                    if decision != "accepted":
                        continue

                    cur.execute(
                        """
                        INSERT INTO fsre_ingestion.resolved_fields (
                            run_id,
                            raw_document_id,
                            field_candidate_id,
                            entity_id,
                            field_path,
                            field_name,
                            period_label,
                            period_role,
                            raw_value_text,
                            normalized_value_numeric,
                            normalized_value_text,
                            page_number,
                            extraction_method,
                            confidence_score,
                            is_accepted,
                            needs_review,
                            review_reason,
                            source_ref_json
                        )
                        VALUES (%s, %s, NULL, %s, %s, %s, %s, %s, %s, %s,
                                %s, %s, 'narrative_evidence_pattern_v1', %s, TRUE, %s, %s, %s::jsonb)
                        """,
                        (
                            document_context.run_id,
                            document_context.raw_document_id,
                            document_context.entity_id,
                            field_path,
                            requirement.get("field_name") or field_path.split(".")[-1],
                            period_label,
                            period_role,
                            evidence,
                            numeric_value,
                            evidence,
                            chunk.get("page_number"),
                            confidence,
                            confidence < Decimal("0.8500"),
                            "narrative_evidence_below_review_threshold"
                            if confidence < Decimal("0.8500")
                            else None,
                            json_dumps(source_ref),
                        ),
                    )
                    inserted += 1
                    matched = True
                    break
                if matched:
                    break
            if matched:
                break
        if not matched:
            unresolved.append(str(requirement["required_field_path"]))

    log_event(
        cur,
        context.run_id,
        "narrative_resolution",
        "narrative_fields_resolved",
        "INFO" if inserted else "WARN",
        f"Resolved {inserted} narrative fields from governed evidence patterns.",
        {
            "raw_document_id": context.raw_document_id,
            "required_narrative_field_count": len(requirements),
            "configured_pattern_count": len(patterns),
            "candidate_count": candidate_count,
            "accepted_candidate_count": accepted_candidate_count,
            "rejected_candidate_count": rejected_candidate_count,
            "referenced_candidate_count": referenced_candidate_count,
            "resolved_narrative_field_count": inserted,
            "unresolved_required_fields": unresolved,
        },
    )
    return {
        "run_id": context.run_id,
        "raw_document_id": context.raw_document_id,
        "required_narrative_field_count": len(requirements),
        "configured_pattern_count": len(patterns),
        "candidate_count": candidate_count,
        "accepted_candidate_count": accepted_candidate_count,
        "rejected_candidate_count": rejected_candidate_count,
        "referenced_candidate_count": referenced_candidate_count,
        "resolved_narrative_field_count": inserted,
        "unresolved_required_fields": unresolved,
    }


def accepted_resolved_field_exists(
    cur: Any,
    context: RunDocumentContext,
    field_path: str,
    period_label: Optional[str],
    period_role: str,
) -> bool:
    params: list[Any] = [context.run_id, context.entity_id, context.entity_id, field_path]
    period_filter = ""
    if period_label:
        period_filter = "AND period_label = %s"
        params.append(period_label)
    else:
        period_filter = "AND period_role = %s"
        params.append(period_role)
    row = _fetchone(
        cur,
        f"""
        SELECT resolved_field_id
        FROM fsre_ingestion.resolved_fields
        WHERE run_id = %s
          AND (entity_id = %s OR (entity_id IS NULL AND %s IS NULL))
          AND field_path = %s
          AND is_accepted = TRUE
          {period_filter}
        LIMIT 1
        """,
        tuple(params),
    )
    return row is not None


def select_narrative_document_contexts(
    cur: Any,
    context: RunDocumentContext,
    period_role: str,
    period_label: Optional[str],
) -> list[RunDocumentContext]:
    if period_role == "prior" and period_label:
        matched_context = find_narrative_document_context_for_period(
            cur,
            context,
            period_label,
        )
        if matched_context:
            if matched_context.raw_document_id == context.raw_document_id:
                return [matched_context]
            return [matched_context, context]
        return [context]
    return [context]


def find_narrative_document_context_for_period(
    cur: Any,
    context: RunDocumentContext,
    period_label: str,
) -> Optional[RunDocumentContext]:
    row = _fetchone(
        cur,
        """
        SELECT
            rd.*,
            er.profile_id AS run_profile_id,
            er.profile_version AS run_profile_version,
            er.environment AS run_environment,
            cr.connector_version AS run_connector_version
        FROM fsre_ingestion.raw_documents rd
        JOIN fsre_audit.execution_runs er
          ON er.run_id = rd.run_id
        LEFT JOIN fsre_ingestion.connector_runs cr
          ON cr.connector_run_id = rd.connector_run_id
        WHERE (rd.entity_id = %s OR (rd.entity_id IS NULL AND %s IS NULL))
          AND upper(coalesce(rd.reporting_period_label, '')) = upper(%s)
          AND lower(coalesce(rd.document_type, '')) IN (
              'annual_report',
              'sgx_financial_statement',
              'management_discussion_analysis'
          )
        ORDER BY
            CASE WHEN rd.run_id = %s THEN 0 ELSE 1 END,
            CASE lower(coalesce(rd.document_type, ''))
                WHEN 'annual_report' THEN 1
                WHEN 'sgx_financial_statement' THEN 2
                WHEN 'management_discussion_analysis' THEN 3
                ELSE 9
            END,
            rd.created_at DESC
        LIMIT 1
        """,
        (context.entity_id, context.entity_id, period_label, context.run_id),
    )
    if not row:
        return None
    return RunDocumentContext(
        run_id=context.run_id,
        raw_document_id=str(row["raw_document_id"]),
        entity_id=row.get("entity_id"),
        profile_id=context.profile_id,
        profile_version=context.profile_version,
        environment=context.environment,
        connector_id=str(row["connector_id"]),
        connector_version=row.get("run_connector_version"),
        reporting_period_label=row.get("reporting_period_label"),
        file_name=row.get("file_name"),
        storage_uri=row.get("storage_uri"),
        source_run_id=str(row["run_id"]),
    )


def fetch_narrative_chunks(
    cur: Any,
    context: RunDocumentContext,
) -> list[dict[str, Any]]:
    chunks = _fetchall(
        cur,
        """
        SELECT text_chunk_id, page_number, chunk_index, text_content
        FROM fsre_ingestion.document_text_chunks
        WHERE run_id = %s
          AND raw_document_id = %s
        ORDER BY page_number NULLS LAST, chunk_index
        """,
        (context.source_run_id or context.run_id, context.raw_document_id),
    )
    return annotate_narrative_sections(chunks)


def is_context_for_expected_period(
    context: RunDocumentContext,
    period_label: Optional[str],
) -> bool:
    if not period_label:
        return False
    return normalize_period_label(context.reporting_period_label) == normalize_period_label(period_label)


def relation_exists(cur: Any, relation_name: str) -> bool:
    row = _fetchone(cur, "SELECT to_regclass(%s) AS relation_name", (relation_name,))
    return bool(row and row.get("relation_name"))


def annotate_narrative_sections(chunks: list[dict[str, Any]]) -> list[dict[str, Any]]:
    current_heading: Optional[str] = None
    annotated: list[dict[str, Any]] = []
    for chunk in chunks:
        item = dict(chunk)
        heading = detect_narrative_section_heading(str(item.get("text_content") or ""))
        if heading:
            current_heading = heading
        item["section_heading"] = current_heading
        item["section_key"] = normalize_label(current_heading)
        annotated.append(item)
    return annotated


def detect_narrative_section_heading(text: str) -> Optional[str]:
    if not text:
        return None
    patterns = (
        r"(?im)^\s*(?:note\s*)?([0-9]{1,2}(?:\.[0-9]{1,2})?)\s+([A-Z][A-Za-z0-9&,'’() /\-]{5,90})\s*$",
        r"(?im)\b([0-9]{1,2}(?:\.[0-9]{1,2})?)\s+([A-Z][A-Za-z0-9&,'’() /\-]{5,70})(?:\s+\(Cont'?d\))?",
    )
    for pattern in patterns:
        match = re.search(pattern, text)
        if match:
            return normalize_whitespace(f"{match.group(1)} {match.group(2)}")
    return None


def narrative_pattern_allows_chunk(pattern: dict[str, Any], chunk: dict[str, Any]) -> bool:
    metadata = pattern.get("metadata_json") or {}
    metadata = normalize_metadata_dict(metadata)

    page_number = chunk.get("page_number")
    if metadata.get("min_page_number") is not None and page_number is not None:
        if int(page_number) < int(metadata["min_page_number"]):
            return False
    if metadata.get("max_page_number") is not None and page_number is not None:
        if int(page_number) > int(metadata["max_page_number"]):
            return False

    page_type = str(chunk.get("page_type") or "")
    allowed_page_types = normalize_metadata_list(metadata.get("allowed_page_types"))
    if allowed_page_types and page_type and page_type not in allowed_page_types:
        return False
    excluded_page_types = normalize_metadata_list(metadata.get("excluded_page_types"))
    if excluded_page_types and page_type in excluded_page_types:
        return False

    text = str(chunk.get("text_content") or "")
    return narrative_text_passes_metadata(metadata, text)


def narrative_pattern_allows_evidence(pattern: dict[str, Any], evidence_text: str) -> bool:
    metadata = normalize_metadata_dict(pattern.get("metadata_json") or {})
    return narrative_metadata_check(metadata, evidence_text)["passed"]


def narrative_metadata_check(metadata: dict[str, Any], text: str) -> dict[str, Any]:
    normalized_text = normalize_label(text)
    required_all_terms = normalize_metadata_list(metadata.get("required_all_terms"))
    required_any_terms = normalize_metadata_list(metadata.get("required_any_terms"))
    excluded_terms = normalize_metadata_list(metadata.get("excluded_terms"))
    required_regex = normalize_metadata_list(metadata.get("required_regex"))
    excluded_regex = normalize_metadata_list(metadata.get("excluded_regex"))

    required_all_found = [
        term for term in required_all_terms if normalize_label(term) in normalized_text
    ]
    required_any_found = [
        term for term in required_any_terms if normalize_label(term) in normalized_text
    ]
    excluded_terms_found = [
        term for term in excluded_terms if normalize_label(term) in normalized_text
    ]
    required_regex_found = [
        regex for regex in required_regex if re.search(regex, text, flags=re.IGNORECASE | re.DOTALL)
    ]
    excluded_regex_found = [
        regex for regex in excluded_regex if re.search(regex, text, flags=re.IGNORECASE | re.DOTALL)
    ]

    missing_required_all = bool(required_all_terms) and len(required_all_found) != len(required_all_terms)
    missing_required_any = bool(required_any_terms) and not required_any_found
    missing_required_regex = bool(required_regex) and len(required_regex_found) != len(required_regex)
    has_excluded = bool(excluded_terms_found or excluded_regex_found)
    return {
        "passed": not (
            missing_required_all
            or missing_required_any
            or missing_required_regex
            or has_excluded
        ),
        "required_all_found": required_all_found,
        "required_any_found": required_any_found,
        "required_regex_found": required_regex_found,
        "excluded_terms_found": excluded_terms_found,
        "excluded_regex_found": excluded_regex_found,
        "missing_required_all": missing_required_all,
        "missing_required_any": missing_required_any,
        "missing_required_regex": missing_required_regex,
        "has_excluded": has_excluded,
    }


def extract_narrative_numeric_value(
    metadata: dict[str, Any],
    evidence_text: str,
    period_role: str,
) -> Optional[Decimal]:
    if metadata.get("numeric_override") is not None:
        return normalize_numeric(metadata.get("numeric_override"))
    regex_by_role = metadata.get("numeric_regex_by_period_role") or {}
    if not isinstance(regex_by_role, dict):
        return None

    regex = regex_by_role.get(period_role) or regex_by_role.get("unspecified")
    if not regex:
        return None

    match = re.search(str(regex), evidence_text, flags=re.IGNORECASE | re.DOTALL)
    if not match:
        return None

    raw_value = match.group(1) if match.groups() else match.group(0)
    number = normalize_numeric(raw_value)
    return apply_numeric_scale(number, metadata.get("numeric_scale"))


def decide_narrative_candidate(
    metadata: dict[str, Any],
    evidence_text: str,
    section_heading: str,
    evidence_check: dict[str, Any],
    period_role: str,
    is_expected_period_document: bool,
) -> tuple[str, str]:
    if not evidence_check["passed"]:
        if evidence_check["has_excluded"]:
            return "rejected", "evidence_contains_excluded_terms"
        return "rejected", "evidence_missing_required_terms"

    allow_prior_from_current = str(
        metadata.get("allow_prior_from_current_report") or ""
    ).strip().lower() in {"1", "true", "yes", "y"}
    if period_role == "prior" and not is_expected_period_document and not allow_prior_from_current:
        return "rejected", "prior_narrative_requires_prior_period_document"

    referenced_regex = normalize_metadata_list(metadata.get("referenced_evidence_regex"))
    if referenced_regex and any(
        re.search(regex, evidence_text, flags=re.IGNORECASE | re.DOTALL)
        for regex in referenced_regex
    ):
        return "referenced", "evidence_points_to_another_note_or_source"

    accepted_section_regex = normalize_metadata_list(metadata.get("accepted_section_regex"))
    if accepted_section_regex and not any(
        re.search(
            regex,
            f"{section_heading or ''}\n{evidence_text or ''}",
            flags=re.IGNORECASE | re.DOTALL,
        )
        for regex in accepted_section_regex
    ):
        return "rejected", "evidence_outside_accepted_section"

    configured_decision = str(metadata.get("candidate_decision") or "").strip().lower()
    if configured_decision in {"accepted", "rejected", "referenced"}:
        reason = normalize_whitespace(str(metadata.get("candidate_decision_reason") or "configured_decision"))
        return configured_decision, reason

    if re.search(r"\bdisclosed in Note\s+[0-9]", evidence_text, flags=re.IGNORECASE):
        return "referenced", "evidence_points_to_another_note_or_source"

    return "accepted", "direct_evidence_passed_metadata"


def trim_narrative_evidence_to_accepted_section(metadata: dict[str, Any], evidence_text: str) -> str:
    accepted_section_regex = normalize_metadata_list(metadata.get("accepted_section_regex"))
    if not accepted_section_regex or not evidence_text:
        return evidence_text
    for regex in accepted_section_regex:
        match = re.search(regex, evidence_text, flags=re.IGNORECASE | re.DOTALL)
        if match:
            return normalize_whitespace(evidence_text[match.start() :])
    return evidence_text


def build_narrative_source_ref(
    pattern: dict[str, Any],
    requirement: dict[str, Any],
    chunk: dict[str, Any],
    evidence: str,
    decision: str,
    decision_reason: str,
    evidence_check: dict[str, Any],
) -> dict[str, Any]:
    return {
        "source": "narrative_evidence",
        "resolver_version": NARRATIVE_EVIDENCE_RESOLVER_VERSION,
        "narrative_pattern_id": pattern["narrative_pattern_id"],
        "text_chunk_id": str(chunk["text_chunk_id"]),
        "page_number": chunk.get("page_number"),
        "page_type": chunk.get("page_type"),
        "chunk_index": chunk.get("chunk_index"),
        "section_heading": chunk.get("section_heading"),
        "section_key": chunk.get("section_key"),
        "evidence_pattern": pattern["evidence_pattern_text"],
        "match_type": pattern["match_type"],
        "required_field_path": requirement["required_field_path"],
        "evidence_text": evidence,
        "decision": decision,
        "decision_reason": decision_reason,
        "evidence_check": evidence_check,
        "narrative_policy": {
            "profile_id": pattern.get("profile_id"),
            "profile_version": pattern.get("profile_version"),
            "connector_id": pattern.get("connector_id"),
            "connector_version": pattern.get("connector_version"),
            "environment": pattern.get("environment"),
            "scope_score": pattern.get("scope_score"),
            "reason": pattern.get("reason"),
            "metadata_json": pattern.get("metadata_json") or {},
        },
    }


def insert_narrative_candidate_trace(
    cur: Any,
    context: RunDocumentContext,
    requirement: dict[str, Any],
    pattern: dict[str, Any],
    chunk: dict[str, Any],
    period_label: Optional[str],
    period_role: str,
    evidence: str,
    decision: str,
    decision_reason: str,
    confidence: Decimal,
    evidence_check: dict[str, Any],
    source_ref: dict[str, Any],
    trace_table_exists: bool,
) -> None:
    if not trace_table_exists:
        return
    cur.execute(
        """
        INSERT INTO fsre_ingestion.narrative_candidate_trace (
            run_id,
            raw_document_id,
            entity_id,
            required_field_path,
            field_path,
            period_label,
            period_role,
            narrative_pattern_id,
            evidence_pattern_text,
            match_type,
            page_number,
            chunk_index,
            text_chunk_id,
            section_heading,
            section_key,
            matched_text,
            evidence_text,
            required_terms_found,
            required_regex_found,
            excluded_terms_found,
            excluded_regex_found,
            decision,
            decision_reason,
            confidence_score,
            resolver_version,
            trace_json
        )
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,
                %s::jsonb, %s::jsonb, %s::jsonb, %s::jsonb, %s, %s, %s, %s, %s::jsonb)
        """,
        (
            context.run_id,
            context.raw_document_id,
            context.entity_id,
            requirement["required_field_path"],
            requirement["canonical_field_path"],
            period_label,
            period_role,
            pattern.get("narrative_pattern_id"),
            pattern.get("evidence_pattern_text"),
            pattern.get("match_type"),
            chunk.get("page_number"),
            chunk.get("chunk_index"),
            chunk.get("text_chunk_id"),
            chunk.get("section_heading"),
            chunk.get("section_key"),
            pattern.get("evidence_pattern_text"),
            evidence,
            json_dumps(
                evidence_check.get("required_all_found", [])
                + evidence_check.get("required_any_found", [])
            ),
            json_dumps(evidence_check.get("required_regex_found", [])),
            json_dumps(evidence_check.get("excluded_terms_found", [])),
            json_dumps(evidence_check.get("excluded_regex_found", [])),
            decision,
            decision_reason,
            confidence,
            NARRATIVE_EVIDENCE_RESOLVER_VERSION,
            json_dumps(source_ref),
        ),
    )


def normalize_metadata_dict(value: Any) -> dict[str, Any]:
    if isinstance(value, str):
        try:
            value = json.loads(value)
        except json.JSONDecodeError:
            value = {}
    if not isinstance(value, dict):
        return {}
    return value


def narrative_text_passes_metadata(metadata: dict[str, Any], text: str) -> bool:
    normalized_text = normalize_label(text)
    required_all_terms = normalize_metadata_list(metadata.get("required_all_terms"))
    if required_all_terms and not all(normalize_label(term) in normalized_text for term in required_all_terms):
        return False
    required_any_terms = normalize_metadata_list(metadata.get("required_any_terms"))
    if required_any_terms and not any(normalize_label(term) in normalized_text for term in required_any_terms):
        return False
    excluded_terms = normalize_metadata_list(metadata.get("excluded_terms"))
    if excluded_terms and any(normalize_label(term) in normalized_text for term in excluded_terms):
        return False

    required_regex = normalize_metadata_list(metadata.get("required_regex"))
    if required_regex and not all(re.search(regex, text, flags=re.IGNORECASE | re.DOTALL) for regex in required_regex):
        return False
    excluded_regex = normalize_metadata_list(metadata.get("excluded_regex"))
    if excluded_regex and any(re.search(regex, text, flags=re.IGNORECASE | re.DOTALL) for regex in excluded_regex):
        return False

    return True


def normalize_metadata_list(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        return [value]
    if isinstance(value, (list, tuple, set)):
        return [str(item) for item in value if item is not None and str(item).strip()]
    return [str(value)]


def match_narrative_evidence_text(
    text: str,
    pattern_text: str,
    match_type: str,
    window: int = 400,
) -> Optional[str]:
    if not text or not pattern_text:
        return None
    if match_type == "regex":
        match = re.search(pattern_text, text, flags=re.IGNORECASE | re.DOTALL)
        if not match:
            return None
        return evidence_excerpt(text, match.start(), match.end(), window=window)

    normalized_text = normalize_label(text)
    normalized_pattern = normalize_label(pattern_text)
    if not normalized_text or not normalized_pattern:
        return None
    if match_type == "exact" and normalized_text != normalized_pattern:
        return None
    if match_type == "contains" and normalized_pattern not in normalized_text:
        return None
    if match_type not in {"exact", "contains"}:
        return None

    raw_match = re.search(re.escape(pattern_text), text, flags=re.IGNORECASE)
    if raw_match:
        return evidence_excerpt(text, raw_match.start(), raw_match.end(), window=window)
    return evidence_excerpt(text, 0, min(len(text), window), window=window)


def match_zero_evidence_text(
    text: str,
    pattern_text: str,
    match_type: str,
) -> Optional[str]:
    if not text or not pattern_text:
        return None
    if match_type == "regex":
        match = re.search(pattern_text, text, flags=re.IGNORECASE)
        if not match:
            return None
        return evidence_excerpt(text, match.start(), match.end())

    normalized_text = normalize_label(text)
    normalized_pattern = normalize_label(pattern_text)
    if not normalized_text or not normalized_pattern:
        return None
    if match_type == "exact" and normalized_text != normalized_pattern:
        return None
    if match_type == "contains" and normalized_pattern not in normalized_text:
        return None
    if match_type not in {"exact", "contains"}:
        return None

    raw_match = re.search(re.escape(pattern_text), text, flags=re.IGNORECASE)
    if raw_match:
        return evidence_excerpt(text, raw_match.start(), raw_match.end())
    return evidence_excerpt(text, 0, min(len(text), 240))


def evidence_excerpt(text: str, start: int, end: int, window: int = 180) -> str:
    left = max(0, start - window)
    right = min(len(text), end + window)
    return normalize_whitespace(text[left:right])


def infer_table_context(
    rows: dict[int, list[dict[str, Any]]],
    current_period: Optional[str],
    prior_period: Optional[str],
) -> TableExtractionContext:
    header_by_col = infer_headers(rows, current_period, prior_period)
    column_scope_by_col = infer_column_scopes(rows, header_by_col)
    note_columns = infer_note_columns(rows, header_by_col)
    currency, unit, unit_multiplier = infer_currency_unit(rows)
    return TableExtractionContext(
        header_by_col=header_by_col,
        column_scope_by_col=column_scope_by_col,
        note_columns=note_columns,
        currency=currency,
        unit=unit,
        unit_multiplier=unit_multiplier,
    )


def infer_headers(
    rows: dict[int, list[dict[str, Any]]],
    current_period: Optional[str] = None,
    prior_period: Optional[str] = None,
) -> dict[int, str]:
    header_by_col: dict[int, str] = {}
    for row_index in sorted(rows)[:8]:
        for cell in rows[row_index]:
            if cell["column_index"] <= 2:
                continue
            text = normalize_whitespace(cell["raw_text"])
            period = normalize_period_label(text)
            if period:
                header_by_col[cell["column_index"]] = period

    if not header_by_col:
        columns: dict[int, list[str]] = {}
        for row_index in sorted(rows)[:12]:
            for cell in rows[row_index]:
                columns.setdefault(cell["column_index"], []).append(normalize_whitespace(cell["raw_text"]))
        for column_index, values in columns.items():
            joined = " ".join(values)
            period = normalize_period_label(joined)
            if period:
                header_by_col[column_index] = period

    if not header_by_col:
        candidate_columns = sorted(
            {
                cell["column_index"]
                for row in rows.values()
                for cell in row
                if normalize_numeric(cell["raw_text"]) is not None
            }
        )
        if len(candidate_columns) >= 1 and current_period:
            header_by_col[candidate_columns[0]] = current_period
        if len(candidate_columns) >= 2 and prior_period:
            header_by_col[candidate_columns[1]] = prior_period
    return header_by_col


def infer_column_scopes(
    rows: dict[int, list[dict[str, Any]]],
    header_by_col: dict[int, str],
) -> dict[int, str]:
    scope_by_col: dict[int, str] = {}
    for row_index in sorted(rows)[:8]:
        row = rows[row_index]
        for cell in row:
            text = normalize_label(cell["raw_text"])
            if text in {"group", "company"}:
                nearest_columns = nearest_header_columns(cell["column_index"], header_by_col)
                for column_index in nearest_columns:
                    scope_by_col[column_index] = text

    if scope_by_col:
        return scope_by_col

    period_columns = sorted(header_by_col)
    period_sequence = [header_by_col[column_index] for column_index in period_columns]
    midpoint = len(period_columns) // 2
    if (
        len(period_columns) >= 4
        and len(period_columns) % 2 == 0
        and period_sequence[:midpoint] == period_sequence[midpoint:]
    ):
        for column_index in period_columns[:midpoint]:
            scope_by_col[column_index] = "group"
        for column_index in period_columns[midpoint:]:
            scope_by_col[column_index] = "company"
    return scope_by_col


def nearest_header_columns(column_index: int, header_by_col: dict[int, str]) -> list[int]:
    if not header_by_col:
        return []
    header_columns = sorted(header_by_col)
    nearest = min(abs(candidate - column_index) for candidate in header_columns)
    return [
        candidate
        for candidate in header_columns
        if abs(candidate - column_index) == nearest
    ]


def infer_note_columns(rows: dict[int, list[dict[str, Any]]], header_by_col: dict[int, str]) -> set[int]:
    note_columns: set[int] = set()
    for row_index in sorted(rows)[:8]:
        for cell in rows[row_index]:
            column_index = cell["column_index"]
            if column_index in header_by_col:
                continue
            text = normalize_label(cell["raw_text"])
            if re.fullmatch(r"notes?", text or ""):
                note_columns.add(column_index)
    return note_columns


def infer_currency_unit(rows: dict[int, list[dict[str, Any]]]) -> tuple[Optional[str], Optional[str], Decimal]:
    texts = [
        normalize_whitespace(cell["raw_text"])
        for row_index in sorted(rows)[:12]
        for cell in rows[row_index]
        if normalize_whitespace(cell["raw_text"])
    ]
    joined = " ".join(texts).lower()
    currency = None
    if "s$" in joined or re.search(r"\b(sgd|singapore dollars?)\b", joined):
        currency = "SGD"
    elif "us$" in joined or re.search(r"\b(usd|u\.s\. dollars?)\b", joined):
        currency = "USD"
    elif "$" in joined:
        currency = "UNKNOWN_DOLLAR"

    unit = None
    multiplier = Decimal("1")
    if re.search(r"\b(million|millions)\b|\$m\b|\bs\$m\b|\bsgd\s*m\b", joined):
        unit = "million"
        multiplier = Decimal("1000000")
    elif re.search(r"\b(thousand|thousands)\b|\$'000|\$000|\bsgd\s*000\b", joined):
        unit = "thousand"
        multiplier = Decimal("1000")
    return currency, unit, multiplier


def normalize_numeric_with_table_unit(value: Any, unit_multiplier: Decimal) -> Optional[Decimal]:
    number = normalize_numeric(value)
    if number is None:
        return None
    text = normalize_whitespace(str(value)).lower()
    has_inline_unit = bool(re.search(r"\b(million|thousand|m|k)\b", text))
    if unit_multiplier != Decimal("1") and not has_inline_unit:
        return number * unit_multiplier
    return number


def infer_period_for_value_cell(
    value_cell: dict[str, Any],
    label_cell: dict[str, Any],
    row_cells: list[dict[str, Any]],
    table_context: TableExtractionContext,
    current_period: Optional[str],
    prior_period: Optional[str],
) -> Optional[str]:
    column_index = value_cell["column_index"]
    explicit_period = normalize_period_label(table_context.header_by_col.get(column_index))
    if explicit_period:
        return explicit_period

    numeric_value_columns = sorted(
        cell["column_index"]
        for cell in row_cells
        if cell["column_index"] != label_cell["column_index"]
        and cell["column_index"] not in table_context.note_columns
        and normalize_numeric(cell["raw_text"]) is not None
    )
    if column_index in numeric_value_columns:
        offset = numeric_value_columns.index(column_index)
        if offset == 0:
            return current_period
        if offset == 1:
            return prior_period

    return infer_period_from_position(
        column_index,
        label_cell["column_index"],
        current_period,
        prior_period,
    )


def looks_like_header_row(row_cells: list[dict[str, Any]]) -> bool:
    texts = [normalize_whitespace(cell["raw_text"]) for cell in row_cells]
    period_count = sum(1 for text in texts if normalize_period_label(text))
    numeric_count = sum(1 for text in texts if normalize_numeric(text) is not None)
    return period_count >= 1 and numeric_count == 0


def first_label_cell(row_cells: list[dict[str, Any]]) -> Optional[dict[str, Any]]:
    for cell in row_cells:
        text = normalize_whitespace(cell["raw_text"])
        if text and normalize_numeric(text) is None:
            return cell
    return None


def infer_period_from_position(
    column_index: int,
    label_column_index: int,
    current_period: Optional[str],
    prior_period: Optional[str],
) -> Optional[str]:
    offset = column_index - label_column_index
    if offset == 1:
        return current_period
    if offset == 2:
        return prior_period
    return None


def period_role_for_label(
    period_label: Optional[str],
    current_period: Optional[str],
    prior_period: Optional[str],
) -> str:
    if period_label and current_period and period_label == current_period:
        return "current"
    if period_label and prior_period and period_label == prior_period:
        return "prior"
    return "unspecified"


def manifest_requires_narrative(cur: Any, run_id: str) -> bool:
    return bool(load_required_narrative_field_requirements(cur, run_id))


def validate_rule_inputs(
    cur: Any,
    run_id: str,
    raw_document_id: Optional[str] = None,
    validation_config: Optional[dict[str, Any]] = None,
) -> dict[str, Any]:
    context = get_run_context(cur, run_id, raw_document_id)
    validation_config = validation_config or {}
    current_period = normalize_period_label(context.reporting_period_label)
    prior_period = prior_period_label(current_period)
    next_period = next_period_label(current_period)
    field_data_types = load_field_data_types(cur)

    cur.execute(
        "DELETE FROM fsre_rules.rule_input_validation_results WHERE run_id = %s",
        (run_id,),
    )

    manifest = _fetchall(
        cur,
        """
        SELECT *
        FROM fsre_rules.run_required_field_manifest
        WHERE run_id = %s
        ORDER BY execution_order NULLS LAST, rule_id, required_field_path
        """,
        (run_id,),
    )
    if not manifest:
        raise ValueError(f"No required field manifest found for run_id={run_id}")

    counts = {"pass": 0, "warn": 0, "fail": 0, "blocked": 0}
    for item in manifest:
        expected_period = expected_period_for_role(
            item["period_role"],
            current_period,
            prior_period,
            next_period,
        )
        resolved = find_resolved_field(
            cur,
            run_id,
            context.raw_document_id,
            context.entity_id,
            item["canonical_field_path"],
            expected_period,
            item["period_role"],
        )
        status = "pass"
        message = "Required field resolved with evidence."
        if not resolved:
            missing_policy = missing_requirement_policy_for_requirement(item, validation_config)
            if missing_policy:
                status = missing_policy["status"]
                message = missing_policy["message"]
            elif item["period_role"] == "next_period":
                status = "blocked"
                message = (
                    "Required field is for a future/next reporting period and was not "
                    "available in the current annual report."
                )
            elif is_external_or_non_numeric_requirement(item["canonical_field_path"], field_data_types):
                status = "blocked"
                data_type = field_data_types.get(item["canonical_field_path"])
                if str(item["canonical_field_path"]).startswith(FINANCIAL_PREFIX) and data_type != "number":
                    message = "Required field is non-scalar and needs a dedicated composite/JSON resolver."
                else:
                    message = "Required field depends on narrative/external connector data not yet resolved."
            else:
                missing_policy = missing_numeric_policy_for_requirement(item, validation_config)
                if missing_policy:
                    status = missing_policy["status"]
                    message = missing_policy["message"]
                else:
                    status = "fail"
                    message = "Required numeric field is missing."
        elif (
            field_data_types.get(str(item["canonical_field_path"])) == "number"
            and resolved.get("normalized_value_numeric") is None
        ):
            missing_policy = missing_requirement_policy_for_requirement(item, validation_config)
            if missing_policy:
                status = missing_policy["status"]
                message = missing_policy["message"]
            else:
                status = "fail"
                message = "Required numeric field resolved with evidence text but no numeric value."
        elif resolved.get("needs_review"):
            status = "warn"
            message = "Required field resolved but requires review due to confidence policy."

        counts[status] += 1
        cur.execute(
            """
            INSERT INTO fsre_rules.rule_input_validation_results (
                run_id,
                raw_document_id,
                entity_id,
                rule_id,
                rule_version,
                required_field_path,
                canonical_field_path,
                period_role,
                expected_period_label,
                validation_status,
                resolved_field_id,
                confidence_score,
                message,
                validation_json
            )
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s::jsonb)
            """,
            (
                run_id,
                context.raw_document_id,
                context.entity_id,
                item["rule_id"],
                item["rule_version"],
                item["required_field_path"],
                item["canonical_field_path"],
                item["period_role"],
                expected_period,
                status,
                resolved["resolved_field_id"] if resolved else None,
                resolved["confidence_score"] if resolved else None,
                message,
                json_dumps(
                    {
                        "source": "rule_input_validation_v1",
                        "expected_period_label": expected_period,
                        "resolved_field": resolved,
                        "missing_requirement_policy": (
                            missing_requirement_policy_for_requirement(item, validation_config)
                            if not resolved
                            else None
                        ),
                    }
                ),
            ),
        )

    overall_status = "pass" if counts["fail"] == 0 and counts["blocked"] == 0 else "fail"
    cur.execute(
        """
        INSERT INTO fsre_audit.validation_results (
            run_id,
            validation_scope,
            object_type,
            object_id,
            validation_name,
            status,
            message,
            details_json
        )
        VALUES (%s, 'rule_input', 'run', %s, 'required_rule_inputs_available', %s, %s, %s::jsonb)
        """,
        (
            run_id,
            run_id,
            overall_status,
            "Rule input validation completed.",
            json_dumps(counts),
        ),
    )
    log_event(
        cur,
        run_id,
        "rule_input_validation",
        "rule_inputs_validated",
        "INFO" if overall_status == "pass" else "WARN",
        "Rule input validation completed.",
        counts,
    )
    return {"run_id": run_id, "raw_document_id": context.raw_document_id, **counts}


def missing_requirement_policy_for_requirement(
    item: dict[str, Any],
    validation_config: dict[str, Any],
) -> Optional[dict[str, str]]:
    policy = configured_missing_policy_for_requirement(
        item,
        validation_config.get("missing_requirement_policies") or [],
        allowed_statuses={"warn", "blocked", "fail"},
    )
    if policy:
        return policy
    return missing_numeric_policy_for_requirement(item, validation_config)


def missing_numeric_policy_for_requirement(
    item: dict[str, Any],
    validation_config: dict[str, Any],
) -> Optional[dict[str, str]]:
    return configured_missing_policy_for_requirement(
        item,
        validation_config.get("missing_numeric_field_policies") or [],
        allowed_statuses={"blocked", "fail"},
    )


def configured_missing_policy_for_requirement(
    item: dict[str, Any],
    policies: Any,
    allowed_statuses: set[str],
) -> Optional[dict[str, str]]:
    if not isinstance(policies, list):
        return None

    canonical_field_path = str(item["canonical_field_path"])
    required_field_path = str(item["required_field_path"])
    period_role = str(item["period_role"] or "unspecified")
    for policy in policies:
        if not isinstance(policy, dict):
            continue
        field_paths = policy.get("field_paths") or []
        if isinstance(field_paths, str):
            field_paths = [field_paths]
        required_paths = policy.get("required_field_paths") or []
        if isinstance(required_paths, str):
            required_paths = [required_paths]
        period_roles = policy.get("period_roles") or []
        if isinstance(period_roles, str):
            period_roles = [period_roles]

        field_matches = canonical_field_path in field_paths or required_field_path in required_paths
        role_matches = not period_roles or period_role in period_roles
        if not field_matches or not role_matches:
            continue

        status = str(policy.get("status") or "blocked")
        if status not in allowed_statuses:
            status = "blocked"
        message = normalize_whitespace(str(policy.get("message") or "Required numeric field is unavailable."))
        return {
            "status": status,
            "message": message,
            "policy_id": str(policy.get("policy_id") or ""),
        }
    return None


def expected_period_for_role(
    period_role: str,
    current_period: Optional[str],
    prior_period: Optional[str],
    next_period: Optional[str],
) -> Optional[str]:
    if period_role == "current":
        return current_period
    if period_role == "prior":
        return prior_period
    if period_role == "next_period":
        return next_period
    return None


def find_resolved_field(
    cur: Any,
    run_id: str,
    raw_document_id: str,
    entity_id: Optional[str],
    field_path: str,
    expected_period: Optional[str],
    period_role: str,
) -> Optional[dict[str, Any]]:
    params: list[Any] = [run_id, field_path]
    period_filter = ""
    if expected_period:
        period_filter = "AND period_label = %s"
        params.append(expected_period)
    elif period_role not in {"unspecified", "any"}:
        period_filter = "AND period_role = %s"
        params.append(period_role)

    raw_document_filter = ""
    if not expected_period:
        raw_document_filter = "AND raw_document_id = %s"
        params.append(raw_document_id)

    entity_filter = ""
    if entity_id:
        entity_filter = "AND (entity_id = %s OR entity_id IS NULL)"
        params.append(entity_id)

    return _fetchone(
        cur,
        f"""
        SELECT *
        FROM fsre_ingestion.resolved_fields
        WHERE run_id = %s
          AND field_path = %s
          AND is_accepted = TRUE
          {period_filter}
          {raw_document_filter}
          {entity_filter}
        ORDER BY
          CASE WHEN raw_document_id = %s THEN 0 ELSE 1 END,
          confidence_score DESC NULLS LAST,
          created_at DESC
        LIMIT 1
        """,
        tuple(params + [raw_document_id]),
    )


def load_field_data_types(cur: Any) -> dict[str, str]:
    rows = _fetchall(
        cur,
        """
        SELECT field_path, data_type
        FROM fsre_config.field_catalog
        WHERE status = 'active'
        """,
        (),
    )
    return {str(row["field_path"]): str(row["data_type"]) for row in rows}


def is_external_or_non_numeric_requirement(
    field_path: str,
    field_data_types: Optional[dict[str, str]] = None,
) -> bool:
    if not field_path.startswith(FINANCIAL_PREFIX):
        return True
    if field_data_types and field_data_types.get(field_path) not in {None, "number"}:
        return True
    return False


def log_event(
    cur: Any,
    run_id: str,
    stage: str,
    event_type: str,
    severity: str,
    message: str,
    event_json: dict[str, Any],
) -> None:
    cur.execute(
        """
        INSERT INTO fsre_audit.run_events (
            run_id,
            event_stage,
            event_type,
            severity,
            message,
            event_json
        )
        VALUES (%s, %s, %s, %s, %s, %s::jsonb)
        """,
        (run_id, stage, event_type, severity, message, json_dumps(event_json)),
    )
