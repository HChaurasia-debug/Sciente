-- Ordered, database-driven derivations for the Manufacturing & Industrials template.
BEGIN;

CREATE TABLE IF NOT EXISTS financial_risk_intelligence.financial_template_rules (
  rule_key text PRIMARY KEY,
  template_key text NOT NULL REFERENCES financial_risk_intelligence.financial_templates(template_key),
  target_concept_key text NOT NULL REFERENCES financial_risk_intelligence.financial_concepts(concept_key),
  operator text NOT NULL CHECK (operator IN ('DIRECT','LINEAR_COMBINATION')),
  priority integer NOT NULL,
  output_sign text NOT NULL DEFAULT 'AS_REPORTED' CHECK (output_sign IN ('AS_REPORTED','ABSOLUTE')),
  active boolean NOT NULL DEFAULT true,
  approval_status text NOT NULL DEFAULT 'APPROVED' CHECK (approval_status IN ('PENDING','APPROVED','REJECTED')),
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(template_key,target_concept_key,priority)
);

CREATE TABLE IF NOT EXISTS financial_risk_intelligence.financial_rule_components (
  rule_key text NOT NULL REFERENCES financial_risk_intelligence.financial_template_rules(rule_key) ON DELETE CASCADE,
  component_concept_key text NOT NULL REFERENCES financial_risk_intelligence.financial_concepts(concept_key),
  coefficient numeric(12,6) NOT NULL DEFAULT 1,
  component_sign text NOT NULL DEFAULT 'AS_REPORTED' CHECK (component_sign IN ('AS_REPORTED','ABSOLUTE')),
  component_order integer NOT NULL,
  PRIMARY KEY(rule_key,component_concept_key)
);

ALTER TABLE financial_risk_intelligence.financial_rule_components
  ADD COLUMN IF NOT EXISTS component_sign text NOT NULL DEFAULT 'AS_REPORTED';

INSERT INTO financial_risk_intelligence.financial_concepts(concept_key,statement_type,canonical_label,is_required,active)
VALUES
 ('distribution_expense','INCOME_STATEMENT','Distribution expense',false,true),
 ('selling_expense','INCOME_STATEMENT','Selling expense',false,true),
 ('depreciation_ppe','CASH_FLOW_STATEMENT','Depreciation of PP&E',false,true),
 ('depreciation_rou','CASH_FLOW_STATEMENT','Depreciation of right-of-use assets',false,true),
 ('amortization_intangibles','CASH_FLOW_STATEMENT','Amortisation of intangible assets',false,true),
 ('gross_profit','INCOME_STATEMENT','Gross profit',false,true),
 ('interest_income','INCOME_STATEMENT','Interest income',false,true),
 ('profit_before_tax','INCOME_STATEMENT','Profit before tax',false,true),
 ('income_tax_expense','INCOME_STATEMENT','Income tax expense',false,true),
 ('total_non_current_assets','BALANCE_SHEET','Total non-current assets',false,true),
 ('total_non_current_liabilities','BALANCE_SHEET','Total non-current liabilities',false,true),
 ('gross_trade_receivables','BALANCE_SHEET','Gross trade receivables',false,true),
 ('receivables_loss_allowance','BALANCE_SHEET','Receivables loss allowance',false,true),
 ('gross_ppe','BALANCE_SHEET','Gross PP&E',false,true),
 ('accumulated_depreciation_ppe','BALANCE_SHEET','Accumulated depreciation - PP&E',false,true),
 ('ppe_impairment','BALANCE_SHEET','PP&E impairment',false,true),
 ('non_current_borrowings','BALANCE_SHEET','Non-current borrowings',false,true),
 ('non_current_lease_liabilities','BALANCE_SHEET','Non-current lease liabilities',false,true),
 ('issued_shares','BALANCE_SHEET','Issued shares',false,true),
 ('treasury_shares_count','BALANCE_SHEET','Treasury shares count',false,true),
 ('cash_generated_from_operations','CASH_FLOW_STATEMENT','Cash generated from operations',false,true),
 ('operating_tax_paid','CASH_FLOW_STATEMENT','Operating tax paid',false,true)
ON CONFLICT(concept_key) DO UPDATE SET canonical_label=EXCLUDED.canonical_label,active=true,updated_at=now();

-- These labels are individual formula inputs, not complete target values.
-- Remove earlier broad aliases so a single component cannot win a DIRECT rule.
DELETE FROM financial_risk_intelligence.financial_concept_aliases
WHERE concept_key='sg_and_a_expense'
  AND normalized_alias_text IN (
    financial_risk_intelligence.normalize_financial_alias_text('Administrative expenses'),
    financial_risk_intelligence.normalize_financial_alias_text('General and administrative expenses'),
    financial_risk_intelligence.normalize_financial_alias_text('Selling expenses')
  );
DELETE FROM financial_risk_intelligence.financial_concept_aliases
WHERE concept_key='depreciation_amortization'
  AND normalized_alias_text IN (
    financial_risk_intelligence.normalize_financial_alias_text('Depreciation of property, plant and equipment'),
    financial_risk_intelligence.normalize_financial_alias_text('Depreciation of right-of-use assets'),
    financial_risk_intelligence.normalize_financial_alias_text('Amortisation of intangible assets'),
    financial_risk_intelligence.normalize_financial_alias_text('Amortization of intangible assets')
  );

INSERT INTO financial_risk_intelligence.financial_concept_aliases
 (concept_key,alias_text,normalized_alias_text,sector_key,priority,active,approval_status,approved_by,approved_at)
SELECT v.concept_key,v.alias_text,financial_risk_intelligence.normalize_financial_alias_text(v.alias_text),'COMMERCIAL',v.priority,true,'APPROVED','DERIVATION_CONFIG',now()
FROM (VALUES
 ('distribution_expense','Distribution expenses',1),('selling_expense','Selling expenses',1),
 ('depreciation_ppe','Depreciation of property, plant and equipment',1),
 ('depreciation_rou','Depreciation of right-of-use assets',1),
 ('amortization_intangibles','Amortisation of intangible assets',1),
 ('gross_profit','Gross profit',1),('interest_income','Finance income',1),('interest_income','Interest income',2),
 ('finance_costs','Finance costs',1),('finance_costs','Finance cost',2),
 ('profit_before_tax','Profit before tax',1),('income_tax_expense','Income tax expense',1),
 ('gross_trade_receivables','Gross trade receivables',1),('receivables_loss_allowance','Loss allowance',1),
 ('gross_ppe','Gross carrying amount',10),('accumulated_depreciation_ppe','Accumulated depreciation',10),
 ('ppe_impairment','Accumulated impairment',10),('non_current_borrowings','Non-current borrowings',1),
 ('non_current_lease_liabilities','Non-current lease liabilities',1),('issued_shares','Issued shares',1),
 ('issued_shares','Issued shares at end',2),
 ('issued_shares','No. of ordinary shares at end of the financial year/period',2),
 ('treasury_shares_count','Treasury shares',10),('treasury_shares_count','No. of treasury shares at beginning and end of the financial year/period',11),
 ('treasury_shares_count','Treasury shares count at end',12),
 ('operating_tax_paid','Tax paid',1),('operating_tax_paid','Income taxes paid',2),
 ('operating_cash_flow','Net cash flows generated from operating activities',1),
 ('total_shareholders_equity','Total equity',2)
) v(concept_key,alias_text,priority)
ON CONFLICT DO NOTHING;

INSERT INTO financial_risk_intelligence.financial_template_rules
 (rule_key,template_key,target_concept_key,operator,priority,output_sign,active,approval_status)
SELECT rule_key,'MANUFACTURING_INDUSTRIALS_GENERIC',target,operator,priority,sign,true,'APPROVED'
FROM (VALUES
 ('REV_DIRECT','revenue','DIRECT',10,'ABSOLUTE'),
 ('COGS_DIRECT','cost_of_goods_sold','DIRECT',10,'ABSOLUTE'),('COGS_FROM_GROSS_PROFIT','cost_of_goods_sold','LINEAR_COMBINATION',20,'ABSOLUTE'),
 ('SGA_DIRECT','sg_and_a_expense','DIRECT',10,'ABSOLUTE'),('SGA_COMPONENTS','sg_and_a_expense','LINEAR_COMBINATION',20,'ABSOLUTE'),('SGA_SELLING_ADMIN','sg_and_a_expense','LINEAR_COMBINATION',21,'ABSOLUTE'),
 ('DA_DIRECT','depreciation_amortization','DIRECT',10,'ABSOLUTE'),('DA_COMPONENTS','depreciation_amortization','LINEAR_COMBINATION',20,'ABSOLUTE'),
 ('DA_PPE_ONLY','depreciation_amortization','LINEAR_COMBINATION',30,'ABSOLUTE'),
 ('EBIT_DIRECT','operating_income_ebit','DIRECT',10,'AS_REPORTED'),('EBIT_FROM_PBT_FINANCE','operating_income_ebit','LINEAR_COMBINATION',20,'AS_REPORTED'),('EBIT_FROM_PBT_INTEREST','operating_income_ebit','LINEAR_COMBINATION',30,'AS_REPORTED'),
 ('INTEREST_DIRECT','interest_expense','DIRECT',10,'ABSOLUTE'),('INTEREST_FROM_FINANCE_COSTS','interest_expense','LINEAR_COMBINATION',20,'ABSOLUTE'),
 ('NET_INCOME_DIRECT','net_profit','DIRECT',10,'AS_REPORTED'),('NET_INCOME_FROM_PBT_TAX','net_profit','LINEAR_COMBINATION',20,'AS_REPORTED'),
 ('TCA_DIRECT','total_current_assets','DIRECT',10,'ABSOLUTE'),('RECEIVABLES_DIRECT','trade_receivables_net','DIRECT',10,'ABSOLUTE'),('RECEIVABLES_NET','trade_receivables_net','LINEAR_COMBINATION',20,'ABSOLUTE'),
 ('INVENTORY_DIRECT','inventory','DIRECT',10,'ABSOLUTE'),('PPE_DIRECT','net_ppe','DIRECT',10,'ABSOLUTE'),('PPE_NET','net_ppe','LINEAR_COMBINATION',20,'ABSOLUTE'),
 ('ASSETS_DIRECT','total_assets','DIRECT',10,'ABSOLUTE'),('ASSETS_SUM','total_assets','LINEAR_COMBINATION',20,'ABSOLUTE'),
 ('TCL_DIRECT','total_current_liabilities','DIRECT',10,'ABSOLUTE'),('LTD_DIRECT','long_term_debt','DIRECT',10,'ABSOLUTE'),('LTD_SUM','long_term_debt','LINEAR_COMBINATION',5,'ABSOLUTE'),
 ('LIAB_DIRECT','total_liabilities','DIRECT',10,'ABSOLUTE'),('LIAB_SUM','total_liabilities','LINEAR_COMBINATION',20,'ABSOLUTE'),
 ('RETAINED_DIRECT','retained_earnings','DIRECT',10,'AS_REPORTED'),('EQUITY_DIRECT','total_shareholders_equity','DIRECT',10,'AS_REPORTED'),('EQUITY_IDENTITY','total_shareholders_equity','LINEAR_COMBINATION',20,'AS_REPORTED'),('EQUITY_FROM_TOTAL_EQUITY','total_shareholders_equity','LINEAR_COMBINATION',30,'AS_REPORTED'),
 ('SHARES_DIRECT','shares_outstanding','DIRECT',10,'ABSOLUTE'),('SHARES_NET','shares_outstanding','LINEAR_COMBINATION',5,'ABSOLUTE'),
 ('CFO_DIRECT','operating_cash_flow','DIRECT',10,'AS_REPORTED'),
 ('CFO_FROM_GENERATED','operating_cash_flow','LINEAR_COMBINATION',20,'AS_REPORTED'),
 ('CFO_FROM_NET_CHANGE','operating_cash_flow','LINEAR_COMBINATION',30,'AS_REPORTED')
) v(rule_key,target,operator,priority,sign)
ON CONFLICT(rule_key) DO UPDATE SET priority=EXCLUDED.priority,output_sign=EXCLUDED.output_sign,active=true,approval_status='APPROVED',updated_at=now();

INSERT INTO financial_risk_intelligence.financial_rule_components(rule_key,component_concept_key,coefficient,component_sign,component_order)
VALUES
 ('COGS_FROM_GROSS_PROFIT','revenue',1,'ABSOLUTE',1),('COGS_FROM_GROSS_PROFIT','gross_profit',-1,'ABSOLUTE',2),
 ('SGA_COMPONENTS','distribution_expense',1,'ABSOLUTE',1),('SGA_COMPONENTS','administrative_expenses',1,'ABSOLUTE',2),
 ('SGA_SELLING_ADMIN','selling_expense',1,'ABSOLUTE',1),('SGA_SELLING_ADMIN','administrative_expenses',1,'ABSOLUTE',2),
 ('DA_COMPONENTS','depreciation_ppe',1,'ABSOLUTE',1),('DA_COMPONENTS','depreciation_rou',1,'ABSOLUTE',2),('DA_COMPONENTS','amortization_intangibles',1,'ABSOLUTE',3),
 ('DA_PPE_ONLY','depreciation_ppe',1,'ABSOLUTE',1),
 ('EBIT_FROM_PBT_FINANCE','profit_before_tax',1,'AS_REPORTED',1),('EBIT_FROM_PBT_FINANCE','interest_expense',1,'ABSOLUTE',2),('EBIT_FROM_PBT_FINANCE','interest_income',-1,'ABSOLUTE',3),
 ('EBIT_FROM_PBT_INTEREST','profit_before_tax',1,'AS_REPORTED',1),('EBIT_FROM_PBT_INTEREST','interest_expense',1,'ABSOLUTE',2),
 ('INTEREST_FROM_FINANCE_COSTS','finance_costs',1,'ABSOLUTE',1),
 ('NET_INCOME_FROM_PBT_TAX','profit_before_tax',1,'AS_REPORTED',1),('NET_INCOME_FROM_PBT_TAX','income_tax_expense',-1,'ABSOLUTE',2),
 ('RECEIVABLES_NET','gross_trade_receivables',1,'ABSOLUTE',1),('RECEIVABLES_NET','receivables_loss_allowance',-1,'ABSOLUTE',2),
 ('PPE_NET','gross_ppe',1,'ABSOLUTE',1),('PPE_NET','accumulated_depreciation_ppe',-1,'ABSOLUTE',2),('PPE_NET','ppe_impairment',-1,'ABSOLUTE',3),
 ('ASSETS_SUM','total_current_assets',1,'ABSOLUTE',1),('ASSETS_SUM','total_non_current_assets',1,'ABSOLUTE',2),
 ('LTD_SUM','non_current_borrowings',1,'ABSOLUTE',1),('LTD_SUM','non_current_lease_liabilities',1,'ABSOLUTE',2),
 ('LIAB_SUM','total_current_liabilities',1,'ABSOLUTE',1),('LIAB_SUM','total_non_current_liabilities',1,'ABSOLUTE',2),
 ('EQUITY_IDENTITY','total_assets',1,'AS_REPORTED',1),('EQUITY_IDENTITY','total_liabilities',-1,'AS_REPORTED',2),
 ('EQUITY_FROM_TOTAL_EQUITY','total_equity',1,'AS_REPORTED',1),
 ('SHARES_NET','issued_shares',1,'ABSOLUTE',1),('SHARES_NET','treasury_shares_count',-1,'ABSOLUTE',2),
 ('CFO_FROM_GENERATED','cash_generated_from_operations',1,'AS_REPORTED',1),('CFO_FROM_GENERATED','operating_tax_paid',-1,'ABSOLUTE',2),
 -- Cash reconciliation identity: net change = operating + investing + financing.
 -- Reported signs must be preserved; investing/financing are commonly negative.
 ('CFO_FROM_NET_CHANGE','net_change_cash',1,'AS_REPORTED',1),
 ('CFO_FROM_NET_CHANGE','investing_cash_flow',-1,'AS_REPORTED',2),
 ('CFO_FROM_NET_CHANGE','financing_cash_flow',-1,'AS_REPORTED',3)
ON CONFLICT(rule_key,component_concept_key) DO UPDATE SET coefficient=EXCLUDED.coefficient,component_sign=EXCLUDED.component_sign,component_order=EXCLUDED.component_order;

CREATE OR REPLACE VIEW financial_risk_intelligence.manufacturing_derivation_configuration AS
SELECT r.rule_key,r.template_key,r.target_concept_key,r.operator,r.priority,r.output_sign,
       c.component_concept_key,c.coefficient,c.component_sign,c.component_order
FROM financial_risk_intelligence.financial_template_rules r
LEFT JOIN financial_risk_intelligence.financial_rule_components c USING(rule_key)
WHERE r.template_key='MANUFACTURING_INDUSTRIALS_GENERIC' AND r.active AND r.approval_status='APPROVED';
COMMIT;
