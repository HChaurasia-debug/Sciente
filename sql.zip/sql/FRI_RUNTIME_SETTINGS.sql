CREATE SCHEMA IF NOT EXISTS financial_risk_intelligence;

CREATE TABLE IF NOT EXISTS financial_risk_intelligence.runtime_settings (
    setting_key TEXT PRIMARY KEY,
    setting_value TEXT NOT NULL,
    is_secret BOOLEAN NOT NULL DEFAULT FALSE,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO financial_risk_intelligence.runtime_settings
    (setting_key, setting_value, is_secret)
VALUES
    ('fri_llm_provider', 'groq', FALSE),
    ('fri_groq_base_url', 'https://api.groq.com/openai/v1', FALSE),
    ('fri_groq_model', 'groq/compound', FALSE),
    ('fri_groq_timeout_seconds', '120', FALSE),
    ('fri_llm_governance_enabled', 'false', FALSE),
    ('fri_llm_narrative_enabled', 'false', FALSE),
    ('fri_llm_debug_validation_enabled', 'false', FALSE),
    ('fri_ollama_base_url', 'http://172.31.20.9:11434', FALSE),
    ('fri_ollama_model', 'llama3.2:3b', FALSE),
    ('fri_ollama_timeout_seconds', '600', FALSE),
    ('fri_ollama_narrative_timeout_seconds', '600', FALSE),
    ('fri_narrative_max_fragments', '12', FALSE),
    ('fri_narrative_max_fragment_characters', '2500', FALSE),
    ('fri_ollama_retries', '2', FALSE),
    ('fri_ollama_max_output_tokens', '700', FALSE),
    ('fri_ollama_workers', '1', FALSE),
    ('fri_llm_fallback_enabled', 'true', FALSE),
    ('fri_ollama_enabled', 'true', FALSE)
    ,('fri_relevant_news_limit', '5', FALSE)
    ,('fri_relevant_news_max_pages', '3', FALSE)
    ,('fri_news_provider', 'newsdata', FALSE)
ON CONFLICT (setting_key) DO UPDATE SET
    setting_value = EXCLUDED.setting_value,
    active = TRUE,
    updated_at = CURRENT_TIMESTAMP;

CREATE INDEX IF NOT EXISTS ix_runtime_settings_active
    ON financial_risk_intelligence.runtime_settings(active);
