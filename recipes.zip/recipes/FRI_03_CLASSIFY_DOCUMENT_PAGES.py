"""Dataiku recipe: extract and classify registered document pages.

Inputs:
- Dataset: FRI_UPLOAD_REGISTRATION_RESULTS
- Managed folder: FRI_REGISTERED_REPORTS_FOLDER (folder id t4d04GkB)

Output:
- Dataset: FRI_DOCUMENT_FRAGMENTS
"""

from __future__ import annotations

import json
import os
import posixpath
import tempfile
import traceback
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

import dataiku
import pandas as pd

from fsre.document_ingestion import (
    chunk_text,
    estimate_token_count,
    extract_pages,
)


INPUT_DATASET_NAME = "FRI_UPLOAD_REGISTRATION_RESULTS"
REGISTERED_FOLDER_ID = "t4d04GkB"
OUTPUT_DATASET_NAME = "FRI_DOCUMENT_FRAGMENTS"

# Keep False during initial integration testing. When True, the recipe fails
# after writing diagnostic rows if any document could not be extracted.
FAIL_RECIPE_WHEN_ANY_DOCUMENT_FAILS = False

MAX_CHARS_PER_CHUNK = 4000
OVERLAP_CHARS = 300
MIN_EXTRACTABLE_PAGE_CHARACTERS = 30

OUTPUT_COLUMNS = [
    "tenant_id",
    "entity_id",
    "assessment_run_id",
    "source_document_id",
    "fragment_id",
    "fragment_type",
    "sequence_number",
    "page_number",
    "content_text",
    "content_json",
    "storage_uri",
    "extractor_version",
    "character_count",
    "word_count",
    "token_count",
    "requires_ocr",
    "extraction_status",
    "error_message",
    "created_at",
]


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def safe_string(value: Any) -> str:
    if value is None or pd.isna(value):
        return ""
    return str(value).strip()


def safe_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return safe_string(value).lower() in {"true", "1", "yes", "y"}


def download_to_temporary_file(
    folder: dataiku.Folder,
    registered_path: str,
    file_name: str,
) -> str:
    suffix = Path(file_name).suffix or Path(registered_path).suffix or ".pdf"
    temporary_file = tempfile.NamedTemporaryFile(delete=False, suffix=suffix)

    try:
        try:
            stream_context = folder.get_download_stream(registered_path)
        except Exception:
            stream_context = folder.get_download_stream(registered_path.lstrip("/"))

        with stream_context as stream:
            while True:
                block = stream.read(1024 * 1024)
                if not block:
                    break
                temporary_file.write(block)

        temporary_file.close()
        return temporary_file.name
    except Exception:
        temporary_file.close()
        try:
            os.unlink(temporary_file.name)
        except OSError:
            pass
        raise


def classify_page(text: str, requires_ocr: bool) -> str:
    """Return a structural fragment type without financial-rule scoring."""
    if requires_ocr:
        return "page_image_or_empty"
    return "page_text"


def base_output_record(row: pd.Series) -> Dict[str, Any]:
    return {
        "tenant_id": safe_string(row.get("tenant_id")),
        "entity_id": safe_string(row.get("entity_id")),
        "assessment_run_id": safe_string(row.get("assessment_run_id")),
        "source_document_id": safe_string(row.get("source_document_id")),
        "storage_uri": safe_string(row.get("registered_path")),
    }


def failure_record(
    row: pd.Series,
    message: str,
    page_number: int = 0,
) -> Dict[str, Any]:
    record = base_output_record(row)
    record.update(
        {
            "fragment_id": str(uuid.uuid4()),
            "fragment_type": "document_error",
            "sequence_number": 0,
            "page_number": page_number,
            "content_text": "",
            "content_json": json.dumps(
                {"source_path": safe_string(row.get("source_path"))}
            ),
            "extractor_version": "none",
            "character_count": 0,
            "word_count": 0,
            "token_count": 0,
            "requires_ocr": False,
            "extraction_status": "FAILED",
            "error_message": message,
            "created_at": utc_now(),
        }
    )
    return record


def extract_document_fragments(
    folder: dataiku.Folder,
    row: pd.Series,
) -> List[Dict[str, Any]]:
    registered_path = safe_string(row.get("registered_path"))
    file_name = safe_string(row.get("file_name"))

    if not registered_path:
        raise ValueError("registered_path is empty")
    if not file_name:
        file_name = posixpath.basename(registered_path)

    temporary_path = download_to_temporary_file(
        folder,
        registered_path,
        file_name,
    )

    try:
        pages = extract_pages(Path(temporary_path))
        fragments: List[Dict[str, Any]] = []
        sequence_number = 0

        for page in pages:
            page_number = int(page.get("page_number") or 0)
            page_text = str(page.get("text") or "").strip()
            extractor = str(page.get("extractor") or "unknown")
            requires_ocr = len(page_text) < MIN_EXTRACTABLE_PAGE_CHARACTERS
            page_chunks = chunk_text(
                page_text,
                max_chars=MAX_CHARS_PER_CHUNK,
                overlap_chars=OVERLAP_CHARS,
            )

            # Keep an auditable page record even when no text was extracted.
            if not page_chunks:
                page_chunks = [""]

            for page_chunk_index, content in enumerate(page_chunks, start=1):
                sequence_number += 1
                record = base_output_record(row)
                record.update(
                    {
                        "fragment_id": str(uuid.uuid4()),
                        "fragment_type": classify_page(content, requires_ocr),
                        "sequence_number": sequence_number,
                        "page_number": page_number,
                        "content_text": content,
                        "content_json": json.dumps(
                            {
                                "page_chunk_index": page_chunk_index,
                                "page_chunk_count": len(page_chunks),
                                "document_checksum": safe_string(
                                    row.get("document_checksum")
                                ),
                                "source_path": safe_string(row.get("source_path")),
                                "registered_path": registered_path,
                            }
                        ),
                        "extractor_version": extractor,
                        "character_count": len(content),
                        "word_count": len(content.split()) if content else 0,
                        "token_count": estimate_token_count(content),
                        "requires_ocr": requires_ocr,
                        "extraction_status": (
                            "OCR_REQUIRED" if requires_ocr else "EXTRACTED"
                        ),
                        "error_message": "",
                        "created_at": utc_now(),
                    }
                )
                fragments.append(record)

        if not pages:
            return [failure_record(row, "Document contains no readable pages")]
        return fragments
    finally:
        try:
            os.unlink(temporary_path)
        except OSError:
            pass


def select_documents(registration_df: pd.DataFrame) -> pd.DataFrame:
    required_columns = {
        "registration_status",
        "source_document_id",
        "registered_path",
        "file_name",
        "tenant_id",
        "entity_id",
        "assessment_run_id",
    }
    missing = sorted(required_columns - set(registration_df.columns))
    if missing:
        raise ValueError(
            "FRI_UPLOAD_REGISTRATION_RESULTS is missing columns: "
            + ", ".join(missing)
        )

    selected = registration_df[
        registration_df["registration_status"].astype(str).str.upper() == "SUCCESS"
    ].copy()

    # Duplicate detections have no registered_path in Recipe 00. Their original
    # document was already registered and should not be processed a second time.
    if "duplicate_document" in selected.columns:
        selected = selected[
            ~selected["duplicate_document"].apply(safe_bool)
        ]

    selected = selected[
        selected["registered_path"].fillna("").astype(str).str.strip() != ""
    ]
    return selected.drop_duplicates(subset=["source_document_id"], keep="last")


def main() -> None:
    registration_dataset = dataiku.Dataset(INPUT_DATASET_NAME)
    registered_folder = dataiku.Folder(REGISTERED_FOLDER_ID)
    output_dataset = dataiku.Dataset(OUTPUT_DATASET_NAME)

    registration_df = registration_dataset.get_dataframe()
    documents_df = select_documents(registration_df)
    results: List[Dict[str, Any]] = []
    document_failures = 0

    for _, document_row in documents_df.iterrows():
        try:
            document_fragments = extract_document_fragments(
                registered_folder,
                document_row,
            )
            results.extend(document_fragments)

            if any(
                item["extraction_status"] == "FAILED"
                for item in document_fragments
            ):
                document_failures += 1
        except Exception as exc:
            document_failures += 1
            error_message = f"{type(exc).__name__}: {exc}"
            print("=" * 80)
            print("DOCUMENT PAGE EXTRACTION FAILURE")
            print(
                "Source document ID: "
                f"{safe_string(document_row.get('source_document_id'))}"
            )
            print(f"Registered path: {safe_string(document_row.get('registered_path'))}")
            print(f"Error: {error_message}")
            print(traceback.format_exc())
            print("=" * 80)
            results.append(failure_record(document_row, error_message))

    result_df = pd.DataFrame(results, columns=OUTPUT_COLUMNS)
    output_dataset.write_with_schema(result_df)

    extracted_count = (
        int((result_df["extraction_status"] == "EXTRACTED").sum())
        if not result_df.empty else 0
    )
    ocr_count = (
        int((result_df["requires_ocr"] == True).sum())  # noqa: E712
        if not result_df.empty else 0
    )
    print(
        json.dumps(
            {
                "registered_rows_read": len(registration_df),
                "documents_selected": len(documents_df),
                "fragments_written": len(result_df),
                "text_fragments_extracted": extracted_count,
                "ocr_required_fragments": ocr_count,
                "document_failures": document_failures,
            },
            indent=2,
        )
    )

    if document_failures and FAIL_RECIPE_WHEN_ANY_DOCUMENT_FAILS:
        raise RuntimeError(
            f"{document_failures} document(s) failed page extraction. "
            "Review FRI_DOCUMENT_FRAGMENTS and the job log."
        )


main()
