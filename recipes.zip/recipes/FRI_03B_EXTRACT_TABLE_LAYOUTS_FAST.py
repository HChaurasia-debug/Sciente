"""Fast, bounded-memory PDF table layout extraction for Dataiku.

Inputs: FRI_UPLOAD_REGISTRATION_RESULTS, FRI_DOCUMENT_FRAGMENTS,
        registered managed folder t4d04GkB
Outputs: FRI_EXTRACTED_TABLES, FRI_EXTRACTED_TABLE_CELLS

Output schemas must exist before using streaming writers.
"""
from __future__ import annotations

import json
import os
import re
import tempfile
import uuid
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

import dataiku
import pandas as pd
import pdfplumber

REGISTRATION_DATASET = "FRI_UPLOAD_REGISTRATION_RESULTS"
FRAGMENTS_DATASET = "FRI_DOCUMENT_FRAGMENTS"
REGISTERED_FOLDER_ID = "t4d04GkB"
TABLES_DATASET = "FRI_EXTRACTED_TABLES"
CELLS_DATASET = "FRI_EXTRACTED_TABLE_CELLS"

LINE_SETTINGS = {
    "vertical_strategy": "lines", "horizontal_strategy": "lines",
    "snap_tolerance": 4, "join_tolerance": 4,
    "intersection_tolerance": 5, "edge_min_length": 3,
}
TEXT_SETTINGS = {
    "vertical_strategy": "text", "horizontal_strategy": "text",
    "min_words_vertical": 2, "min_words_horizontal": 1,
    "text_x_tolerance": 3, "text_y_tolerance": 3,
}
TABLE_KEYWORDS = re.compile(
    r"\b(balance sheet|financial position|income statement|profit and loss|"
    r"cash flows?|changes in equity|note|table|schedule|assets|liabilities|revenue)\b",
    re.IGNORECASE,
)
NUMERIC_TOKEN = re.compile(r"(?<!\w)\(?[-+]?\d[\d, ]*(?:\.\d+)?\)?(?!\w)")


def runtime_int(name: str, default: int, minimum: int, maximum: int) -> int:
    raw = dataiku.get_custom_variables().get(name, default)
    try:
        return max(minimum, min(int(raw), maximum))
    except (TypeError, ValueError):
        return default


MIN_NUMERIC_TOKENS = runtime_int("fsre_table_min_numeric_tokens", 6, 2, 50)
MAX_CANDIDATE_PAGES = runtime_int("fsre_table_max_candidate_pages", 500, 1, 5000)


def text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except (TypeError, ValueError):
        pass
    return re.sub(r"\s+", " ", str(value)).strip()


def numeric(value: Any) -> Optional[Decimal]:
    raw = text(value)
    if not raw or raw.lower() in {"-", "--", "—", "–", "nil", "na", "n/a"}:
        return None
    negative = raw.startswith("(") and raw.endswith(")")
    cleaned = re.sub(r"[$€£₹,\s]", "", raw.strip("()"))
    if not re.fullmatch(r"[-+]?\d+(?:\.\d+)?", cleaned):
        return None
    try:
        result = Decimal(cleaned)
        return -result if negative else result
    except InvalidOperation:
        return None


def currency_unit(content: str) -> Tuple[str, str, Decimal]:
    lower = content.lower()
    currency = ""
    for pattern, code in (
        (r"\bsgd\b|s\$|singapore dollars?", "SGD"),
        (r"\busd\b|us\$", "USD"), (r"\binr\b|₹", "INR"),
        (r"\beur\b|€", "EUR"), (r"\bgbp\b|£", "GBP"),
    ):
        if re.search(pattern, lower):
            currency = code
            break
    if re.search(r"\bbillions?\b|\bbn\b", lower):
        return currency, "billion", Decimal("1000000000")
    if re.search(r"\bmillions?\b|\bmn\b|\$m\b", lower):
        return currency, "million", Decimal("1000000")
    if re.search(r"\bthousands?\b|\b'000\b|\b000s\b", lower):
        return currency, "thousand", Decimal("1000")
    return currency, "unit", Decimal("1")


def statement_type(content: str) -> str:
    lower = content.lower()
    if "changes in equity" in lower:
        return "changes_in_equity"
    if "cash flow" in lower or "cash flows" in lower:
        return "cash_flow"
    if "profit and loss" in lower or "income statement" in lower:
        return "income_statement"
    if "balance sheet" in lower or "financial position" in lower:
        return "balance_sheet"
    return "unclassified_table"


def candidate_pages(fragments: pd.DataFrame) -> Dict[str, Set[int]]:
    pages: Dict[str, Set[int]] = {}
    extracted = fragments[
        fragments["extraction_status"].fillna("").astype(str).str.upper().eq("EXTRACTED")
    ]
    grouped = extracted.groupby(["source_document_id", "page_number"], dropna=False)
    scored = []
    for (document_id, page_number), group in grouped:
        content = "\n".join(group["content_text"].fillna("").astype(str))
        numeric_count = len(NUMERIC_TOKEN.findall(content))
        keyword = bool(TABLE_KEYWORDS.search(content))
        if numeric_count >= MIN_NUMERIC_TOKENS or (keyword and numeric_count >= 2):
            scored.append((numeric_count + (10 if keyword else 0), str(document_id), int(page_number)))
    for _, document_id, page_number in sorted(scored, reverse=True)[:MAX_CANDIDATE_PAGES]:
        pages.setdefault(document_id, set()).add(page_number)
    return pages


def download(folder, registered_path: str, file_name: str) -> str:
    temporary = tempfile.NamedTemporaryFile(delete=False, suffix=Path(file_name).suffix or ".pdf")
    try:
        try:
            stream = folder.get_download_stream(registered_path)
        except Exception:
            stream = folder.get_download_stream(registered_path.lstrip("/"))
        with stream:
            for block in iter(lambda: stream.read(1024 * 1024), b""):
                temporary.write(block)
        temporary.close()
        return temporary.name
    except Exception:
        temporary.close()
        try:
            os.unlink(temporary.name)
        except OSError:
            pass
        raise


def valid_grid(grid: List[List[Any]]) -> bool:
    return len(grid) >= 2 and max((len(row) for row in grid), default=0) >= 2


def find_tables(page):
    line_tables = page.find_tables(table_settings=LINE_SETTINGS)
    line_tables = [table for table in line_tables if valid_grid(table.extract() or [])]
    if line_tables:
        return line_tables, "pdfplumber_lines_fast"
    text_tables = page.find_tables(table_settings=TEXT_SETTINGS)
    text_tables = [table for table in text_tables if valid_grid(table.extract() or [])]
    return text_tables, "pdfplumber_text_fallback"


def header_count(grid: List[List[Any]]) -> int:
    for index, row in enumerate(grid[:5]):
        values = [numeric(cell) for cell in row]
        first = next((text(cell) for cell in row if text(cell)), "")
        if index > 0 and first and numeric(first) is None and sum(v is not None for v in values) >= 1:
            return index
    return 1


def headers(grid: List[List[Any]], count: int, columns: int) -> List[str]:
    levels = []
    for row in grid[:count]:
        current, last = [], ""
        for column in range(columns):
            item = text(row[column]) if column < len(row) else ""
            if item:
                last = item
            current.append(last)
        levels.append(current)
    result = []
    for column in range(columns):
        values = []
        for level in levels:
            if level[column] and level[column] not in values:
                values.append(level[column])
        result.append(" / ".join(values))
    return result


def row_label(row: List[Any]) -> str:
    return next((text(cell) for cell in row if text(cell) and numeric(cell) is None), "")


def scope(header: str) -> str:
    lower = header.lower()
    if "company" in lower:
        return "company"
    if "group" in lower or "consolidated" in lower:
        return "group"
    return "unspecified"


def period(header: str) -> str:
    values = re.findall(r"\b(?:19|20)\d{2}\b", header)
    return values[-1] if values else ""


def bbox(table, row_index, column_index):
    try:
        value = table.rows[row_index].cells[column_index]
        return json.dumps(list(value)) if value else ""
    except Exception:
        return ""


def process_document(folder, document, page_numbers, table_writer, cell_writer):
    local_path = download(folder, text(document["registered_path"]), text(document["file_name"]))
    counts = {"pages": 0, "tables": 0, "cells": 0}
    try:
        with pdfplumber.open(local_path) as pdf:
            for page_number in sorted(page_numbers):
                if page_number < 1 or page_number > len(pdf.pages):
                    continue
                page = pdf.pages[page_number - 1]
                counts["pages"] += 1
                page_text = page.extract_text(x_tolerance=2, y_tolerance=2) or ""
                found, method = find_tables(page)
                for table_index, table in enumerate(found, start=1):
                    grid = table.extract() or []
                    columns = max(len(row) for row in grid)
                    grid = [list(row) + [None] * (columns - len(row)) for row in grid]
                    head_count = header_count(grid)
                    header_paths = headers(grid, head_count, columns)
                    title = " | ".join([line.strip() for line in page_text.splitlines()[:12] if line.strip()])[:2000]
                    combined = title + " " + " ".join(text(cell) for row in grid[:head_count + 2] for cell in row)
                    currency, unit, multiplier = currency_unit(combined)
                    table_id, created = str(uuid.uuid4()), datetime.now(timezone.utc)
                    table_writer.write_row_dict({
                        "tenant_id": text(document["tenant_id"]), "entity_id": text(document["entity_id"]),
                        "assessment_run_id": text(document["assessment_run_id"]),
                        "source_document_id": text(document["source_document_id"]), "table_id": table_id,
                        "page_number": page_number, "table_index": table_index,
                        "statement_title": title, "statement_type": statement_type(combined),
                        "reporting_date": "", "currency": currency, "unit": unit,
                        "unit_multiplier": float(multiplier), "row_count": len(grid),
                        "column_count": columns, "table_bbox_json": json.dumps(list(table.bbox)),
                        "header_rows_json": json.dumps(grid[:head_count], ensure_ascii=False),
                        "table_json": json.dumps(grid, ensure_ascii=False), "extraction_method": method,
                        "extraction_status": "EXTRACTED", "error_message": "", "created_at": created,
                    })
                    counts["tables"] += 1
                    for row_index, row in enumerate(grid):
                        label = row_label(row) if row_index >= head_count else ""
                        total = bool(re.search(r"\b(total|net assets|shareholders.? funds)\b", label, re.I))
                        for column_index, raw in enumerate(row):
                            value = numeric(raw)
                            cell_writer.write_row_dict({
                                "tenant_id": text(document["tenant_id"]), "entity_id": text(document["entity_id"]),
                                "assessment_run_id": text(document["assessment_run_id"]),
                                "source_document_id": text(document["source_document_id"]),
                                "table_id": table_id, "cell_id": str(uuid.uuid4()), "page_number": page_number,
                                "table_index": table_index, "row_index": row_index, "column_index": column_index,
                                "row_label": label, "header_path": header_paths[column_index],
                                "column_scope": scope(header_paths[column_index]),
                                "period_label": period(header_paths[column_index]), "raw_text": text(raw),
                                "numeric_value": float(value) if value is not None else None,
                                "currency": currency, "unit": unit, "unit_multiplier": float(multiplier),
                                "normalized_value": float(value * multiplier) if value is not None else None,
                                "cell_bbox_json": bbox(table, row_index, column_index),
                                "is_header": row_index < head_count, "is_total": total,
                                "extraction_status": "EXTRACTED", "created_at": created,
                            })
                            counts["cells"] += 1
                if hasattr(page, "close"):
                    page.close()
    finally:
        try:
            os.unlink(local_path)
        except OSError:
            pass
    return counts


def main():
    registrations = dataiku.Dataset(REGISTRATION_DATASET).get_dataframe()
    fragments = dataiku.Dataset(FRAGMENTS_DATASET).get_dataframe()
    registrations = registrations[
        registrations["registration_status"].fillna("").astype(str).str.upper().eq("SUCCESS")
    ].drop_duplicates("source_document_id", keep="last")
    page_map = candidate_pages(fragments)
    folder = dataiku.Folder(REGISTERED_FOLDER_ID)
    totals = {"documents": 0, "candidate_pages": 0, "tables": 0, "cells": 0}
    with dataiku.Dataset(TABLES_DATASET).get_writer() as table_writer:
        with dataiku.Dataset(CELLS_DATASET).get_writer() as cell_writer:
            for _, document in registrations.iterrows():
                document_id = text(document["source_document_id"])
                pages = page_map.get(document_id, set())
                if not pages or not text(document.get("registered_path")):
                    continue
                counts = process_document(folder, document, pages, table_writer, cell_writer)
                totals["documents"] += 1
                totals["candidate_pages"] += counts["pages"]
                totals["tables"] += counts["tables"]
                totals["cells"] += counts["cells"]
                print(json.dumps({"document_id": document_id, **counts}))
    print(json.dumps(totals, indent=2))
    if totals["documents"] == 0:
        raise RuntimeError("No documents had candidate table pages")


main()
