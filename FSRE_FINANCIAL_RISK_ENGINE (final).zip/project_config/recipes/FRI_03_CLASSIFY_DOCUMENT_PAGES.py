"""Extract page text for every successful registered document.

Input: FRI_UPLOAD_REGISTRATION_RESULTS and registered folder t4d04GkB
Output: FRI_DOCUMENT_FRAGMENTS

Successful duplicate registrations are included because canonical Recipe 00
returns their original registered_path and source_document_id.
"""
from __future__ import annotations

import json
import os
import tempfile
import traceback
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

import dataiku
import pandas as pd

from fsre.document_ingestion import chunk_text, estimate_token_count, extract_pages

INPUT_DATASET = "FRI_UPLOAD_REGISTRATION_RESULTS"
REGISTERED_FOLDER_ID = "t4d04GkB"
OUTPUT_DATASET = "FRI_DOCUMENT_FRAGMENTS"
FAIL_RECIPE_WHEN_ANY_DOCUMENT_FAILS = False
MAX_CHARS = 4000
OVERLAP_CHARS = 300
MIN_PAGE_CHARACTERS = 30
OUTPUT_COLUMNS = [
    "tenant_id", "entity_id", "assessment_run_id", "source_document_id",
    "fragment_id", "fragment_type", "sequence_number", "page_number",
    "content_text", "content_json", "storage_uri", "extractor_version",
    "character_count", "word_count", "token_count", "requires_ocr",
    "extraction_status", "error_message", "created_at",
]


def text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except (TypeError, ValueError):
        pass
    return str(value).strip()


def base(row: pd.Series) -> Dict[str, Any]:
    return {
        "tenant_id": text(row.get("tenant_id")),
        "entity_id": text(row.get("entity_id")),
        "assessment_run_id": text(row.get("assessment_run_id")),
        "source_document_id": text(row.get("source_document_id")),
        "storage_uri": text(row.get("registered_path")),
    }


def select_documents(frame: pd.DataFrame) -> pd.DataFrame:
    required = {
        "registration_status", "tenant_id", "entity_id", "assessment_run_id",
        "source_document_id", "registered_path", "file_name",
    }
    missing = sorted(required - set(frame.columns))
    if missing:
        raise ValueError(f"{INPUT_DATASET} is missing: {', '.join(missing)}")

    selected = frame[
        frame["registration_status"].fillna("").astype(str).str.upper().eq("SUCCESS")
    ].copy()
    for column in (
        "tenant_id", "entity_id", "assessment_run_id", "source_document_id",
        "registered_path", "file_name",
    ):
        selected = selected[
            selected[column].fillna("").astype(str).str.strip().ne("")
        ]

    # Do not filter duplicate_document. Rebuilds must be reproducible.
    return selected.drop_duplicates(subset=["source_document_id"], keep="last")


def download(folder, registered_path: str, file_name: str) -> str:
    suffix = Path(file_name).suffix or ".pdf"
    temporary = tempfile.NamedTemporaryFile(delete=False, suffix=suffix)
    try:
        try:
            stream = folder.get_download_stream(registered_path)
        except Exception:
            stream = folder.get_download_stream(registered_path.lstrip("/"))
        with stream:
            while True:
                block = stream.read(1024 * 1024)
                if not block:
                    break
                temporary.write(block)
        temporary.close()
        return temporary.name
    except Exception:
        temporary.close()
        try:
            os.unlink(temporary.name)
        except OSError:
            pass
        raise


def failure(row: pd.Series, message: str) -> Dict[str, Any]:
    result = base(row)
    result.update({
        "fragment_id": str(uuid.uuid4()), "fragment_type": "document_error",
        "sequence_number": 0, "page_number": 0, "content_text": "",
        "content_json": json.dumps({"registered_path": text(row.get("registered_path"))}),
        "extractor_version": "none", "character_count": 0, "word_count": 0,
        "token_count": 0, "requires_ocr": False, "extraction_status": "FAILED",
        "error_message": message, "created_at": datetime.now(timezone.utc),
    })
    return result


def extract_document(folder, row: pd.Series) -> List[Dict[str, Any]]:
    path = download(folder, text(row["registered_path"]), text(row["file_name"]))
    try:
        pages = extract_pages(Path(path))
        if not pages:
            return [failure(row, "Document contains no pages")]
        results: List[Dict[str, Any]] = []
        sequence = 0
        for page in pages:
            page_number = int(page.get("page_number") or 0)
            page_text = str(page.get("text") or "").strip()
            extractor = str(page.get("extractor") or "unknown")
            requires_ocr = len(page_text) < MIN_PAGE_CHARACTERS
            chunks = chunk_text(page_text, max_chars=MAX_CHARS, overlap_chars=OVERLAP_CHARS) or [""]
            for chunk_index, content in enumerate(chunks, start=1):
                sequence += 1
                result = base(row)
                result.update({
                    "fragment_id": str(uuid.uuid4()),
                    "fragment_type": "page_image_or_empty" if requires_ocr else "page_text",
                    "sequence_number": sequence, "page_number": page_number,
                    "content_text": content,
                    "content_json": json.dumps({
                        "page_chunk_index": chunk_index,
                        "page_chunk_count": len(chunks),
                        "document_checksum": text(row.get("document_checksum")),
                    }),
                    "extractor_version": extractor,
                    "character_count": len(content),
                    "word_count": len(content.split()) if content else 0,
                    "token_count": estimate_token_count(content),
                    "requires_ocr": requires_ocr,
                    "extraction_status": "OCR_REQUIRED" if requires_ocr else "EXTRACTED",
                    "error_message": "", "created_at": datetime.now(timezone.utc),
                })
                results.append(result)
        return results
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass


def main():
    registrations = dataiku.Dataset(INPUT_DATASET).get_dataframe()
    documents = select_documents(registrations)
    folder = dataiku.Folder(REGISTERED_FOLDER_ID)
    rows: List[Dict[str, Any]] = []
    failures = 0

    for _, document in documents.iterrows():
        try:
            extracted = extract_document(folder, document)
            rows.extend(extracted)
            failures += int(any(row["extraction_status"] == "FAILED" for row in extracted))
        except Exception as exc:
            failures += 1
            message = f"{type(exc).__name__}: {exc}"
            print(traceback.format_exc())
            rows.append(failure(document, message))

    output = pd.DataFrame(rows, columns=OUTPUT_COLUMNS)
    dataiku.Dataset(OUTPUT_DATASET).write_with_schema(output)
    print(json.dumps({
        "registration_rows": len(registrations),
        "documents_selected": len(documents),
        "fragments_written": len(output),
        "document_failures": failures,
    }, indent=2))

    if documents.empty:
        raise RuntimeError(
            "No successful registered documents with a registered path are available"
        )
    if failures and FAIL_RECIPE_WHEN_ANY_DOCUMENT_FAILS:
        raise RuntimeError(f"{failures} documents failed page extraction")


main()
