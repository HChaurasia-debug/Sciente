"""One forensic scoring recipe for all configured sectors."""
from __future__ import annotations

import datetime as dt
import json
import math
import re
from typing import Any, Dict, Optional

import dataiku
import pandas as pd

INPUT_VALUES = "FRI_SECTOR_TEMPLATE_VALUES"
INPUT_CONFIG = "FRI_SECTOR_SCORING_CONFIGURATION"
# Alias resolution belongs upstream in FRI_04E. This input is used only when
# a configured template field was unavailable in 04F, so Beneish can reuse a
# governed, source-backed canonical fact rather than failing unnecessarily.
INPUT_CANONICAL_FACTS = "FRI_RESOLVED_FINANCIAL_FACTS"
INPUT_STANDARDIZED_VALUES = "FRI_STANDARDIZED_STATEMENT_VALUES"
OUTPUT_RESULTS = "FRI_SECTOR_FORENSIC_SCORES"
OUTPUT_EXCEPTIONS = "FRI_SECTOR_SCORING_EXCEPTIONS"
VERSION = "sector-forensic-scoring-1.0.0"
RESULT_COLUMNS = ["tenant_id","entity_id","assessment_run_id","source_document_id","sector_key","template_key",
                  "model_key","model_name","status","score","risk_band","components_json","parameters_json",
                  "configuration_version","scored_at"]
EXCEPTION_COLUMNS = ["tenant_id","entity_id","assessment_run_id","source_document_id","sector_key","template_key",
                     "model_key","exception_code","message","created_at"]


def read(name: str) -> pd.DataFrame:
    try:
        frame = dataiku.Dataset(name).get_dataframe(infer_with_pandas=True)
    except (TypeError, ValueError):
        frame = dataiku.Dataset(name).get_dataframe()
    frame = frame.copy(); frame.columns = [str(column).strip().lower() for column in frame.columns]
    return frame


def text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value): return ""
    except Exception: pass
    return str(value).strip()


def num(value: Any) -> Optional[float]:
    try:
        result = float(value)
        return result if math.isfinite(result) else None
    except (TypeError, ValueError): return None


def div(a: Optional[float], b: Optional[float]) -> Optional[float]:
    return None if a is None or b in (None, 0) else a / b


def complete(values): return all(value is not None and math.isfinite(value) for value in values)


def preferred_text(frame: pd.DataFrame, column: str) -> str:
    if column not in frame.columns:
        return ""
    values=[text(value) for value in frame[column].tolist()]
    values=[value for value in values if value]
    return values[0] if values else ""


def canonical_facts_for_filing(frame: pd.DataFrame, identity: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    """Index Group-level alias-resolved canonical facts for one filing."""
    if frame.empty:
        return {}
    matched = frame.copy()
    for column in ("tenant_id", "entity_id", "assessment_run_id", "source_document_id"):
        if column in matched.columns and text(identity.get(column)):
            matched = matched[matched[column].astype(str).eq(text(identity[column]))]
    chosen: Dict[str, Dict[str, Any]] = {}
    for row in matched.to_dict("records"):
        concept = text(row.get("concept_key"))
        if not concept:
            continue
        current, prior = num(row.get("current_value")), num(row.get("prior_value"))
        scope = text(row.get("scope") or row.get("entity_scope")).upper()
        confidence = num(row.get("confidence") or row.get("extraction_confidence")) or 0.0
        rank = (
            (100000 if "GROUP" in scope or "CONSOLIDATED" in scope else 0)
            + 1000 * int(current is not None)
            + 1000 * int(prior is not None)
            + confidence
        )
        candidate = {
            "current": current,
            "prior": prior,
            "rank": rank,
            "source": text(row.get("resolution_method") or "DATABASE_ALIAS"),
        }
        if concept not in chosen or candidate["rank"] > chosen[concept]["rank"]:
            chosen[concept] = candidate
    # Annual reports often disclose D&A only as separate PP&E, right-of-use,
    # and intangible-asset components. Build the aggregate from identical
    # filing coordinates when no direct governed D&A fact exists.
    if not chosen.get("depreciation_amortization"):
        component_keys = {
            "depreciation_ppe", "depreciation_property_plant_equipment",
            "depreciation_rou", "depreciation_right_of_use_assets",
            "amortization_intangibles", "amortisation_intangible_assets",
            "amortization_intangible_assets",
        }
        components = [chosen[key] for key in component_keys if key in chosen]
        current_components = [abs(item["current"]) for item in components if item.get("current") is not None]
        prior_components = [abs(item["prior"]) for item in components if item.get("prior") is not None]
        if current_components and prior_components:
            chosen["depreciation_amortization"] = {
                "current": sum(current_components),
                "prior": sum(prior_components),
                "rank": min(item["rank"] for item in components),
                "source": "CANONICAL_DEPRECIATION_COMPONENT_SUM",
            }
    return chosen


def apply_canonical_alias_fallback(
    current: Dict[str, Optional[float]],
    prior: Dict[str, Optional[float]],
    canonical: Dict[str, Dict[str, Any]],
) -> Dict[str, str]:
    """Fill only absent template values from identical canonical concepts."""
    used: Dict[str, str] = {}
    for concept, candidate in canonical.items():
        current.setdefault(concept, None)
        prior.setdefault(concept, None)
        changed = False
        if current.get(concept) is None and candidate.get("current") is not None:
            current[concept] = candidate["current"]
            changed = True
        if prior.get(concept) is None and candidate.get("prior") is not None:
            prior[concept] = candidate["prior"]
            changed = True
        if changed:
            used[concept] = "CANONICAL_ALIAS_FALLBACK_" + (candidate.get("source") or "DATABASE_ALIAS")
    return used


def standardized_da_for_filing(frame: pd.DataFrame, identity: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Resolve disclosed D&A on the fly without zero/default substitution."""
    if frame.empty or "row_label" not in frame.columns or "numeric_value" not in frame.columns:
        return None
    matched = frame.copy()
    for column in ("tenant_id", "entity_id", "assessment_run_id", "source_document_id"):
        if column in matched.columns and text(identity.get(column)):
            matched = matched[matched[column].astype(str).eq(text(identity[column]))]
    if "entity_scope" in matched.columns:
        scope = matched["entity_scope"].fillna("").astype(str).str.upper()
        group_rows = matched[scope.str.contains("GROUP|CONSOLIDATED", regex=True)]
        if not group_rows.empty:
            matched = group_rows

    def normalized(value: Any) -> str:
        return re.sub(r"[^a-z0-9]+", " ", text(value).lower()).strip()

    direct_labels = {
        "depreciation and amortisation", "depreciation and amortization",
        "depreciation amortisation", "depreciation amortization",
        "depreciation of property plant and equipment",
    }
    component_labels = {
        "depreciation of right of use assets",
        "amortisation of intangible assets", "amortization of intangible assets",
    }
    records = []
    for row in matched.to_dict("records"):
        label = normalized(row.get("row_label"))
        value = num(row.get("numeric_value"))
        if value is None or label not in direct_labels | component_labels:
            continue
        period = text(row.get("period_label") or row.get("period_end"))
        year_match = re.search(r"\b(?:19|20)\d{2}\b", period)
        year = int(year_match.group(0)) if year_match else (2 if period.upper() == "CURRENT" else 1 if period.upper() == "PRIOR" else 0)
        records.append({"label": label, "value": abs(value), "period": period, "year": year})
    if not records:
        return None

    periods = sorted({(item["year"], item["period"]) for item in records}, reverse=True)
    if len(periods) < 2:
        return None
    values = []
    for year, period in periods[:2]:
        period_rows = [item for item in records if item["year"] == year and item["period"] == period]
        direct = [item["value"] for item in period_rows if item["label"] in direct_labels]
        # Prefer the disclosed aggregate/PPE total. ROU depreciation is often
        # already included in PPE and must not be added a second time.
        if direct:
            values.append(max(direct))
        else:
            components = [item["value"] for item in period_rows if item["label"] in component_labels]
            if not components:
                return None
            values.append(sum(components))
    return {"current": values[0], "prior": values[1], "source": "STANDARDIZED_DISCLOSED_DA"}


def beneish(c, p, _):
    # Financial statements commonly report expenses as either positive
    # magnitudes or parenthesized/negative amounts. Beneish ratios use expense
    # magnitudes, so normalize locally without changing governed source values.
    cogs_c, cogs_p = abs(c["cost_of_goods_sold"]), abs(p["cost_of_goods_sold"])
    sga_c, sga_p = abs(c["sg_and_a_expense"]), abs(p["sg_and_a_expense"])
    gm_c, gm_p = div(c["revenue"]-cogs_c, c["revenue"]), div(p["revenue"]-cogs_p, p["revenue"])
    aq_c, aq_p = 1-div(c["total_current_assets"]+c["net_ppe"], c["total_assets"]), 1-div(p["total_current_assets"]+p["net_ppe"], p["total_assets"])
    da_c, da_p = abs(c["depreciation_amortization"]), abs(p["depreciation_amortization"])
    dep_c, dep_p = div(da_c, da_c+c["net_ppe"]), div(da_p, da_p+p["net_ppe"])
    lev_c, lev_p = div(c["total_current_liabilities"]+c["long_term_debt"], c["total_assets"]), div(p["total_current_liabilities"]+p["long_term_debt"], p["total_assets"])
    parts = {"DSRI": div(div(c["trade_receivables_net"],c["revenue"]),div(p["trade_receivables_net"],p["revenue"])), "GMI": div(gm_p,gm_c),
             "AQI": div(aq_c,aq_p), "SGI": div(c["revenue"],p["revenue"]), "DEPI": div(dep_p,dep_c),
             "SGAI": div(div(sga_c,c["revenue"]),div(sga_p,p["revenue"])),
             "LVGI": div(lev_c,lev_p), "TATA": div(c["net_profit"]-c["operating_cash_flow"],c["total_assets"])}
    if not complete(parts.values()): return None
    score = -4.84+0.92*parts["DSRI"]+0.528*parts["GMI"]+0.404*parts["AQI"]+0.892*parts["SGI"]+0.115*parts["DEPI"]-0.172*parts["SGAI"]+4.679*parts["TATA"]-0.327*parts["LVGI"]
    return score, "HIGH" if score > -1.78 else "LOW", parts


def altman(c, _p, _):
    parts = {"X1":div(c["total_current_assets"]-c["total_current_liabilities"],c["total_assets"]), "X2":div(c["retained_earnings"],c["total_assets"]),
             "X3":div(c["operating_income_ebit"],c["total_assets"]), "X4":div(c["total_shareholders_equity"],c["total_liabilities"])}
    if not complete(parts.values()): return None
    score=6.56*parts["X1"]+3.26*parts["X2"]+6.72*parts["X3"]+1.05*parts["X4"]
    return score, "LOW" if score>2.6 else "ELEVATED" if score>=1.1 else "HIGH", parts


def sloan(c,p,_):
    ratio=div(c["net_profit"]-c["operating_cash_flow"],(c["total_assets"]+p["total_assets"])/2)
    if ratio is None:return None
    return ratio,"HIGH" if ratio>0.10 else "ELEVATED" if ratio>0.05 else "LOW",{"accrual_ratio":ratio}


def piotroski(c,p,params):
    roa_c,roa_p=div(c["net_profit"],c["total_assets"]),div(p["net_profit"],p["total_assets"])
    cogs_c, cogs_p = abs(c["cost_of_goods_sold"]), abs(p["cost_of_goods_sold"])
    gm_c,gm_p=div(c["revenue"]-cogs_c,c["revenue"]),div(p["revenue"]-cogs_p,p["revenue"])
    # A missing share-count disclosure must never be treated as evidence of
    # "no dilution". A sector/model configuration can elect to leave this
    # single binary signal unscored; it then contributes zero points and the
    # result is marked SCORED_WITH_ASSUMPTIONS by main().
    shares_available = (
        c.get("shares_outstanding") is not None
        and p.get("shares_outstanding") is not None
    )
    no_dilution = c["shares_outstanding"]<=p["shares_outstanding"] if shares_available else False
    tests={"positive_roa":roa_c>0,"positive_cfo":c["operating_cash_flow"]>0,"improving_roa":roa_c>roa_p,
           "low_accruals":div(c["operating_cash_flow"],c["total_assets"])>roa_c,
           "falling_leverage":div(c["long_term_debt"],c["total_assets"])<div(p["long_term_debt"],p["total_assets"]),
           "improving_liquidity":div(c["total_current_assets"],c["total_current_liabilities"])>div(p["total_current_assets"],p["total_current_liabilities"]),
           "no_dilution":no_dilution,"improving_margin":gm_c>gm_p,
           "improving_turnover":div(c["revenue"],c["total_assets"])>div(p["revenue"],p["total_assets"])}
    score=sum(tests.values()); return score,"LOW" if score>=7 else "ELEVATED" if score>=4 else "HIGH",tests


def montier(c,p,params):
    inv_enabled=params.get("inventory_signal_enabled",True) and c.get("inventory") is not None and p.get("inventory") not in (None,0)
    da_c, da_p = abs(c["depreciation_amortization"]), abs(p["depreciation_amortization"])
    tests={"income_exceeds_cfo":c["net_profit"]>c["operating_cash_flow"],
           "dso_rising":div(c["trade_receivables_net"],c["revenue"])>div(p["trade_receivables_net"],p["revenue"]),
           "other_current_assets_rising":div(c["total_current_assets"]-c["trade_receivables_net"]-(c.get("inventory") or 0),c["revenue"])>div(p["total_current_assets"]-p["trade_receivables_net"]-(p.get("inventory") or 0),p["revenue"]),
           "depreciation_rate_declining":div(da_c,da_c+c["net_ppe"])<div(da_p,da_p+p["net_ppe"]),
           "asset_growth_above_20pct":div(c["total_assets"],p["total_assets"])-1>0.2}
    if inv_enabled: tests["inventory_days_rising"]=div(c["inventory"],abs(c["cost_of_goods_sold"]))>div(p["inventory"],abs(p["cost_of_goods_sold"]))
    score=sum(tests.values()); denominator=len(tests); normalized=score/denominator*6
    return normalized,"HIGH" if normalized>=4 else "ELEVATED" if normalized>=2 else "LOW",tests


def bank_metrics(c,p,_):
    metrics={"nim_current":div(c["net_interest_income"],c["total_assets"]),"nim_prior":div(p["net_interest_income"],p["total_assets"]),
             "ecl_coverage":div(c["ecl_balance"],c["stage3_npa"]),"stage3_ratio":div(c["stage3_npa"],c["gross_loans_advances"]),
             "prior_stage3_ratio":div(p["stage3_npa"],p["gross_loans_advances"]),"loan_growth":div(c["gross_loans_advances"],p["gross_loans_advances"])-1,
             "cet1_ratio":c["cet1_ratio"]}
    flags=sum([metrics["ecl_coverage"]<0.6,metrics["stage3_ratio"]>0.03,metrics["loan_growth"]>0.25,c["cet1_ratio"]<11,
               metrics["nim_current"]<metrics["nim_prior"]*0.9])
    return flags,"HIGH" if flags>=3 else "ELEVATED" if flags else "LOW",metrics


ENGINES={"beneish":beneish,"altman":altman,"sloan":sloan,"piotroski":piotroski,"montier":montier,"bank_metrics":bank_metrics}


def main():
    values,config,canonical=read(INPUT_VALUES),read(INPUT_CONFIG),read(INPUT_CANONICAL_FACTS)
    standardized=read(INPUT_STANDARDIZED_VALUES)
    now=dt.datetime.now(dt.timezone.utc).isoformat(); results=[]; errors=[]
    filing_ids=["tenant_id","entity_id","assessment_run_id","source_document_id"]
    for identity,group in values.groupby(filing_ids,dropna=False,sort=False):
        base=dict(zip(filing_ids,identity if isinstance(identity, tuple) else (identity,)))
        # 04F emits one Group-level template per filing.  This fallback keeps
        # legacy outputs from being split merely because source rows carried
        # different scope/currency/unit metadata.
        base["sector_key"]=preferred_text(group,"sector_key")
        base["template_key"]=preferred_text(group,"template_key")
        current={text(r["concept_key"]):num(r["current_value"]) for r in group.to_dict("records")}; prior={text(r["concept_key"]):num(r["prior_value"]) for r in group.to_dict("records")}
        canonical_inputs = canonical_facts_for_filing(canonical, base)
        if not canonical_inputs.get("depreciation_amortization"):
            disclosed_da = standardized_da_for_filing(standardized, base)
            if disclosed_da:
                canonical_inputs["depreciation_amortization"] = {
                    **disclosed_da, "rank": 1, "source": disclosed_da["source"],
                }
        alias_fallbacks = apply_canonical_alias_fallback(
            current,
            prior,
            canonical_inputs,
        )
        cfg=config[config["sector_key"].astype(str).eq(text(base["sector_key"]))]
        for model_key,model_rows in cfg.groupby("model_key",sort=False):
            first=model_rows.iloc[0].to_dict(); enabled=str(first.get("enabled")).lower() in {"true","1","yes"}
            if not enabled:
                results.append({**base,"model_key":model_key,"model_name":text(first.get("model_name")),"status":"NOT_APPLICABLE","score":None,"risk_band":"NOT_APPLICABLE","components_json":"{}","parameters_json":text(first.get("parameters")),"configuration_version":text(first.get("configuration_version")),"scored_at":now}); continue
            parameters=first.get("parameters") if isinstance(first.get("parameters"),dict) else json.loads(text(first.get("parameters")) or "{}")
            # Defaults are deliberately limited to explicit, approved policy
            # entries in the model configuration. They are not generic zero
            # filling: a missing revenue, asset or profit value still blocks
            # the score.
            model_current, model_prior = current.copy(), prior.copy()
            assumptions=[]
            defaults=parameters.get("missing_input_defaults", {})
            for concept, configured in defaults.items():
                configured = configured if isinstance(configured, dict) else {"current": configured, "prior": configured}
                current_default, prior_default = num(configured.get("current")), num(configured.get("prior"))
                if model_current.get(concept) is None and current_default is not None:
                    model_current[concept]=current_default; assumptions.append(f"{concept}: current default={current_default:g}")
                if model_prior.get(concept) is None and prior_default is not None:
                    model_prior[concept]=prior_default; assumptions.append(f"{concept}: prior default={prior_default:g}")
            optional_signals={text(value) for value in parameters.get("optional_signal_inputs", [])}
            missing=[]
            for row in model_rows.to_dict("records"):
                if not str(row.get("input_required")).lower() in {"true","1","yes"}: continue
                concept=text(row.get("input_concept_key")); requirement=text(row.get("period_requirement"))
                unavailable = model_current.get(concept) is None or requirement=="CURRENT_AND_PRIOR" and model_prior.get(concept) is None
                if unavailable and concept in optional_signals:
                    assumptions.append(f"{concept}: optional signal unavailable; conservative result used")
                    continue
                if unavailable: missing.append(concept)
            if missing:
                errors.append({**base,"model_key":model_key,"exception_code":"MANDATORY_MODEL_INPUT_MISSING","message":", ".join(sorted(set(missing))),"created_at":now}); continue
            try:
                outcome=ENGINES[model_key](model_current,model_prior,parameters)
            except (ArithmeticError, TypeError, ValueError) as exc:
                errors.append({**base,"model_key":model_key,"exception_code":"INVALID_MODEL_ARITHMETIC","message":f"{type(exc).__name__}: {exc}","created_at":now}); continue
            if outcome is None:
                errors.append({**base,"model_key":model_key,"exception_code":"INVALID_MODEL_ARITHMETIC","message":"Division by zero or non-finite model component","created_at":now}); continue
            score,band,components=outcome
            if alias_fallbacks:
                components["alias_input_fallbacks"] = alias_fallbacks
            if assumptions:
                components["calculation_assumptions"] = assumptions
            results.append({**base,"model_key":model_key,"model_name":text(first.get("model_name")),"status":"SCORED_WITH_ASSUMPTIONS" if assumptions else "SCORED","score":score,"risk_band":band,"components_json":json.dumps(components),"parameters_json":json.dumps(parameters),"configuration_version":text(first.get("configuration_version")),"scored_at":now})
    dataiku.Dataset(OUTPUT_RESULTS).write_with_schema(pd.DataFrame(results, columns=RESULT_COLUMNS))
    dataiku.Dataset(OUTPUT_EXCEPTIONS).write_with_schema(pd.DataFrame(errors, columns=EXCEPTION_COLUMNS))
    if errors:
        print(f"Sector scoring completed with {len(errors)} exception(s); affected models were not scored")


main()
