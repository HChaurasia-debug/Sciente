-- Generic Piotroski prerequisites for commercial/manufacturing templates.
-- Values remain source-driven; this migration only governs aliases and formulas.
BEGIN;

INSERT INTO financial_risk_intelligence.financial_concept_aliases
 (concept_key,alias_text,normalized_alias_text,sector_key,priority,active,
  approval_status,approved_by,approved_at)
SELECT concept_key,alias_text,
       financial_risk_intelligence.normalize_financial_alias_text(alias_text),
       'COMMERCIAL',priority,true,'APPROVED','PIOTROSKI_GENERIC_FIX',now()
FROM (VALUES
 ('issued_shares','Issued shares at end',2),
 ('issued_shares','Number of ordinary shares at end of the financial year',3),
 ('issued_shares','Number of ordinary shares at end of the financial period',4),
 ('treasury_shares_count','Treasury shares count at end',12),
 ('treasury_shares_count','Number of treasury shares at end',13)
) v(concept_key,alias_text,priority)
ON CONFLICT DO NOTHING;

-- Prefer comparable component identities to ambiguous direct labels such as
-- "Borrowings" or "Issued shares".
UPDATE financial_risk_intelligence.financial_template_rules
SET priority=5,active=true,approval_status='APPROVED',updated_at=now()
WHERE rule_key IN ('LTD_SUM','SHARES_NET')
  AND template_key='MANUFACTURING_INDUSTRIALS_GENERIC';

COMMIT;

SELECT r.rule_key,r.target_concept_key,r.priority,r.operator,
       c.component_concept_key,c.coefficient,c.component_sign,c.component_order
FROM financial_risk_intelligence.financial_template_rules r
JOIN financial_risk_intelligence.financial_rule_components c USING(rule_key)
WHERE r.rule_key IN ('LTD_SUM','SHARES_NET')
ORDER BY r.rule_key,c.component_order;
