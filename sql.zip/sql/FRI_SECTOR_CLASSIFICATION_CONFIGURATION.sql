-- Database-owned rules for ingestion-stage entity sector classification.
BEGIN;

CREATE TABLE IF NOT EXISTS financial_risk_intelligence.sector_classification_rules (
  rule_id bigserial PRIMARY KEY,
  sector_key text NOT NULL REFERENCES financial_risk_intelligence.sector_profiles(sector_key),
  phrase text NOT NULL,
  normalized_phrase text NOT NULL,
  weight numeric(8,3) NOT NULL CHECK(weight > 0),
  evidence_type text NOT NULL DEFAULT 'BUSINESS_DESCRIPTION'
    CHECK(evidence_type IN ('BUSINESS_DESCRIPTION','PRINCIPAL_ACTIVITY','SEGMENT_REVENUE','REGULATORY_IDENTITY')),
  active boolean NOT NULL DEFAULT true,
  approval_status text NOT NULL DEFAULT 'APPROVED'
    CHECK(approval_status IN ('PENDING','APPROVED','REJECTED')),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(sector_key,normalized_phrase)
);

INSERT INTO financial_risk_intelligence.sector_classification_rules
 (sector_key,phrase,normalized_phrase,weight,evidence_type)
SELECT sector_key,phrase,lower(regexp_replace(trim(phrase),'[^a-zA-Z0-9]+',' ','g')),weight,evidence_type
FROM (VALUES
 ('consumer','lifestyle retail',12,'PRINCIPAL_ACTIVITY'),('consumer','consumer retail',10,'PRINCIPAL_ACTIVITY'),
 ('consumer','retail business',8,'BUSINESS_DESCRIPTION'),('consumer','entertainment outlets',9,'BUSINESS_DESCRIPTION'),
 ('consumer','consumer services',8,'BUSINESS_DESCRIPTION'),('consumer','food and beverage',7,'BUSINESS_DESCRIPTION'),
 ('trading','commodity trading',12,'PRINCIPAL_ACTIVITY'),('trading','commodities trading',12,'PRINCIPAL_ACTIVITY'),
 ('trading','wholesale trading',9,'BUSINESS_DESCRIPTION'),('trading','trading and distribution',8,'BUSINESS_DESCRIPTION'),
 ('manufacturing','manufacturing',10,'PRINCIPAL_ACTIVITY'),('manufacturing','manufacturing facilities',10,'BUSINESS_DESCRIPTION'),
 ('manufacturing','production plant',9,'BUSINESS_DESCRIPTION'),('manufacturing','industrial products',7,'BUSINESS_DESCRIPTION'),
 ('technology','software development',12,'PRINCIPAL_ACTIVITY'),('technology','software as a service',12,'BUSINESS_DESCRIPTION'),
 ('technology','information technology services',10,'BUSINESS_DESCRIPTION'),('technology','technology solutions',7,'BUSINESS_DESCRIPTION'),
 ('realestate','property development',12,'PRINCIPAL_ACTIVITY'),('realestate','real estate development',12,'PRINCIPAL_ACTIVITY'),
 ('realestate','investment properties',8,'BUSINESS_DESCRIPTION'),('realestate','infrastructure development',9,'BUSINESS_DESCRIPTION'),
 ('energy','oil and gas',12,'PRINCIPAL_ACTIVITY'),('energy','mining operations',12,'PRINCIPAL_ACTIVITY'),
 ('energy','power generation',11,'PRINCIPAL_ACTIVITY'),('energy','utility services',9,'BUSINESS_DESCRIPTION'),
 ('pharma','pharmaceutical products',12,'PRINCIPAL_ACTIVITY'),('pharma','healthcare services',10,'PRINCIPAL_ACTIVITY'),
 ('pharma','drug development',10,'BUSINESS_DESCRIPTION'),('pharma','medical services',8,'BUSINESS_DESCRIPTION'),
 ('banking','banking business',14,'REGULATORY_IDENTITY'),('banking','licensed bank',14,'REGULATORY_IDENTITY'),
 ('banking','commercial banking',12,'PRINCIPAL_ACTIVITY'),('banking','customer deposits',8,'BUSINESS_DESCRIPTION'),
 ('nbfc','insurance business',14,'REGULATORY_IDENTITY'),('nbfc','insurance company',14,'REGULATORY_IDENTITY'),
 ('nbfc','non banking financial',14,'REGULATORY_IDENTITY'),('nbfc','finance company',11,'PRINCIPAL_ACTIVITY')
) v(sector_key,phrase,weight,evidence_type)
ON CONFLICT(sector_key,normalized_phrase) DO UPDATE SET phrase=EXCLUDED.phrase,weight=EXCLUDED.weight,
 evidence_type=EXCLUDED.evidence_type,active=true,approval_status='APPROVED',updated_at=now();

CREATE OR REPLACE VIEW financial_risk_intelligence.active_sector_classification_rules AS
SELECT r.rule_id,r.sector_key,s.sector_name,r.phrase,r.normalized_phrase,r.weight,r.evidence_type
FROM financial_risk_intelligence.sector_classification_rules r
JOIN financial_risk_intelligence.sector_profiles s USING(sector_key)
WHERE r.active AND r.approval_status='APPROVED' AND s.active;

COMMIT;
