-- FSRE complete PostgreSQL bootstrap.
-- Generated from the four ordered bootstrap migrations listed below.
-- 1. Runtime settings
-- 2. Canonical concepts
-- 3. Governed synonym registry
-- 4. Manufacturing generic template mapping
-- Follow with the database-driven formula registry:
--    FRI_MANUFACTURING_DERIVATION_CONFIGURATION.sql after this bootstrap)

-- ============================================================================
-- SOURCE: dataiku\sql\FRI_RUNTIME_SETTINGS.sql
-- ============================================================================
CREATE SCHEMA IF NOT EXISTS financial_risk_intelligence;

CREATE TABLE IF NOT EXISTS financial_risk_intelligence.runtime_settings (
    setting_key TEXT PRIMARY KEY,
    setting_value TEXT NOT NULL,
    is_secret BOOLEAN NOT NULL DEFAULT FALSE,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO financial_risk_intelligence.runtime_settings
    (setting_key, setting_value, is_secret)
VALUES
    ('fri_llm_provider', 'groq', FALSE),
    ('fri_groq_base_url', 'https://api.groq.com/openai/v1', FALSE),
    ('fri_groq_model', 'groq/compound', FALSE),
    ('fri_groq_timeout_seconds', '120', FALSE),
    ('fri_llm_governance_enabled', 'false', FALSE),
    ('fri_llm_narrative_enabled', 'false', FALSE),
    ('fri_llm_debug_validation_enabled', 'false', FALSE),
    ('fri_ollama_base_url', 'http://172.31.20.9:11434', FALSE),
    ('fri_ollama_model', 'llama3.2:3b', FALSE),
    ('fri_ollama_timeout_seconds', '600', FALSE),
    ('fri_ollama_retries', '2', FALSE),
    ('fri_ollama_max_output_tokens', '700', FALSE),
    ('fri_ollama_workers', '1', FALSE),
    ('fri_llm_fallback_enabled', 'true', FALSE),
    ('fri_ollama_enabled', 'true', FALSE)
ON CONFLICT (setting_key) DO UPDATE SET
    setting_value = EXCLUDED.setting_value,
    active = TRUE,
    updated_at = CURRENT_TIMESTAMP;

CREATE INDEX IF NOT EXISTS ix_runtime_settings_active
    ON financial_risk_intelligence.runtime_settings(active);


-- ============================================================================
-- SOURCE: dataiku\sql\FRI_CANONICAL_FACTS_CONFIGURATION.sql
-- ============================================================================
-- Canonical concept bootstrap. Run the governed synonym registry next.
BEGIN;
CREATE SCHEMA IF NOT EXISTS financial_risk_intelligence;
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS financial_risk_intelligence.financial_concepts (
    concept_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    concept_key text NOT NULL UNIQUE,
    statement_type text NOT NULL CHECK (statement_type IN ('INCOME_STATEMENT','BALANCE_SHEET','CASH_FLOW_STATEMENT')),
    canonical_label text NOT NULL,
    is_required boolean NOT NULL DEFAULT true,
    active boolean NOT NULL DEFAULT true,
    validation_definition jsonb NOT NULL DEFAULT '{}'::jsonb,
    scope_preference text NOT NULL DEFAULT 'GROUP_THEN_REPORTED_THEN_COMPANY',
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE financial_risk_intelligence.financial_concepts
    ADD COLUMN IF NOT EXISTS scope_preference text
    DEFAULT 'GROUP_THEN_REPORTED_THEN_COMPANY';

CREATE TABLE IF NOT EXISTS financial_risk_intelligence.financial_derivation_rules (
    derivation_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    concept_key text NOT NULL REFERENCES financial_risk_intelligence.financial_concepts(concept_key),
    expression text NOT NULL,
    required_concepts text[] NOT NULL,
    priority integer NOT NULL DEFAULT 100,
    active boolean NOT NULL DEFAULT true,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    UNIQUE (concept_key,expression)
);

INSERT INTO financial_risk_intelligence.financial_concepts
    (concept_key,statement_type,canonical_label,is_required,active)
VALUES
    ('revenue','INCOME_STATEMENT','Revenue',true,true),
    ('total_income','INCOME_STATEMENT','Total income',false,true),
    ('cost_of_sales','INCOME_STATEMENT','Cost of sales',false,true),
    ('cost_of_goods_sold','INCOME_STATEMENT','Cost of goods sold',true,true),
    ('gross_profit','INCOME_STATEMENT','Gross profit',false,true),
    ('net_interest_income','INCOME_STATEMENT','Net interest income',false,true),
    ('non_interest_income','INCOME_STATEMENT','Non-interest income',false,true),
    ('other_income','INCOME_STATEMENT','Other income',false,true),
    ('operating_expenses','INCOME_STATEMENT','Operating expenses',false,true),
    ('administrative_expenses','INCOME_STATEMENT','Administrative expenses',false,true),
    ('sg_and_a_expense','INCOME_STATEMENT','SG&A expense',true,true),
    ('depreciation_amortization','INCOME_STATEMENT','Depreciation and amortisation',true,true),
    ('finance_costs','INCOME_STATEMENT','Finance costs',false,true),
    ('interest_expense','INCOME_STATEMENT','Interest expense',true,true),
    ('provisions_impairment','INCOME_STATEMENT','Provisions / impairment',false,true),
    ('operating_income_ebit','INCOME_STATEMENT','Operating income (EBIT)',true,true),
    ('profit_before_tax','INCOME_STATEMENT','Profit before tax',false,true),
    ('income_tax_expense','INCOME_STATEMENT','Income tax expense',false,true),
    ('net_profit','INCOME_STATEMENT','Net income',true,true),
    ('cash_and_cash_equivalents','BALANCE_SHEET','Cash and cash equivalents',false,true),
    ('total_current_assets','BALANCE_SHEET','Total current assets',true,true),
    ('total_non_current_assets','BALANCE_SHEET','Total non-current assets',false,true),
    ('trade_receivables_net','BALANCE_SHEET','Trade receivables (net)',true,true),
    ('inventory','BALANCE_SHEET','Inventory',true,true),
    ('net_ppe','BALANCE_SHEET','Net PP&E (fixed assets)',true,true),
    ('property_plant_equipment','BALANCE_SHEET','Property, plant and equipment',false,true),
    ('gross_loans_advances','BALANCE_SHEET','Gross loans and advances',false,true),
    ('stage3_npa','BALANCE_SHEET','Stage-3 / NPA loans',false,true),
    ('ecl_balance','BALANCE_SHEET','Loan-loss provision / ECL balance',false,true),
    ('investments','BALANCE_SHEET','Investments',false,true),
    ('total_assets','BALANCE_SHEET','Total assets',true,true),
    ('total_current_liabilities','BALANCE_SHEET','Total current liabilities',true,true),
    ('total_non_current_liabilities','BALANCE_SHEET','Total non-current liabilities',false,true),
    ('long_term_debt','BALANCE_SHEET','Long-term debt',true,true),
    ('borrowings','BALANCE_SHEET','Borrowings',false,true),
    ('customer_deposits','BALANCE_SHEET','Customer deposits',false,true),
    ('total_liabilities','BALANCE_SHEET','Total liabilities',true,true),
    ('retained_earnings','BALANCE_SHEET','Retained earnings',true,true),
    ('total_shareholders_equity','BALANCE_SHEET','Total shareholders'' equity',true,true),
    ('total_equity','BALANCE_SHEET','Total equity',false,true),
    ('shares_outstanding','BALANCE_SHEET','Shares outstanding',true,true),
    ('cet1_ratio','BALANCE_SHEET','CET-1 / capital ratio',false,true),
    ('cash_generated_from_operations','CASH_FLOW_STATEMENT','Cash generated from operations',false,true),
    ('operating_cash_flow','CASH_FLOW_STATEMENT','Cash flow from operations',true,true),
    ('investing_cash_flow','CASH_FLOW_STATEMENT','Investing cash flow',false,true),
    ('financing_cash_flow','CASH_FLOW_STATEMENT','Financing cash flow',false,true),
    ('net_change_cash','CASH_FLOW_STATEMENT','Net change in cash',false,true),
    ('beginning_cash','CASH_FLOW_STATEMENT','Cash and cash equivalents at beginning of period',false,true),
    ('ending_cash','CASH_FLOW_STATEMENT','Cash and cash equivalents at end of period',false,true)
ON CONFLICT (concept_key) DO UPDATE SET
    statement_type=EXCLUDED.statement_type,canonical_label=EXCLUDED.canonical_label,
    is_required=EXCLUDED.is_required,active=EXCLUDED.active,updated_at=now();

COMMIT;

SELECT statement_type,count(*) AS active_concept_count
FROM financial_risk_intelligence.financial_concepts
WHERE active=true GROUP BY statement_type ORDER BY statement_type;


-- ============================================================================
-- SOURCE: dataiku\sql\FRI_FINANCIAL_SYNONYM_REGISTRY.sql
-- ============================================================================
-- FRI financial synonym registry - clean PostgreSQL rebuild.
-- Destructive scope is limited to synonym-registry views/functions/table.
-- Canonical concepts, financial facts and derivation rules are retained.

BEGIN;

CREATE SCHEMA IF NOT EXISTS financial_risk_intelligence;

DROP VIEW IF EXISTS financial_risk_intelligence.pending_financial_concept_aliases;
DROP VIEW IF EXISTS financial_risk_intelligence.approved_financial_concept_aliases;
DROP VIEW IF EXISTS financial_risk_intelligence.financial_concept_configuration;
DROP VIEW IF EXISTS financial_risk_intelligence.approved_financial_statement_aliases;
DROP TABLE IF EXISTS financial_risk_intelligence.financial_statement_aliases;
DROP TABLE IF EXISTS financial_risk_intelligence.financial_concept_aliases CASCADE;
DROP FUNCTION IF EXISTS financial_risk_intelligence.set_financial_alias_normalized_text();
DROP FUNCTION IF EXISTS financial_risk_intelligence.normalize_financial_alias_text(text);

CREATE TABLE IF NOT EXISTS financial_risk_intelligence.financial_concepts (
    concept_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    concept_key text NOT NULL UNIQUE,
    statement_type text NOT NULL,
    canonical_label text NOT NULL,
    is_required boolean NOT NULL DEFAULT true,
    active boolean NOT NULL DEFAULT true,
    validation_definition jsonb NOT NULL DEFAULT '{}'::jsonb,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

INSERT INTO financial_risk_intelligence.financial_concepts
    (concept_key, statement_type, canonical_label, is_required, active)
VALUES
    ('revenue','INCOME_STATEMENT','Revenue',true,true),
    ('total_income','INCOME_STATEMENT','Total income',true,true),
    ('cost_of_sales','INCOME_STATEMENT','Cost of sales',false,true),
    ('cost_of_goods_sold','INCOME_STATEMENT','Cost of goods sold',false,true),
    ('gross_profit','INCOME_STATEMENT','Gross profit',false,true),
    ('net_interest_income','INCOME_STATEMENT','Net interest income',false,true),
    ('non_interest_income','INCOME_STATEMENT','Non-interest income',false,true),
    ('other_income','INCOME_STATEMENT','Other income',false,true),
    ('operating_expenses','INCOME_STATEMENT','Operating expenses',true,true),
    ('administrative_expenses','INCOME_STATEMENT','Administrative expenses',false,true),
    ('sg_and_a_expense','INCOME_STATEMENT','SG&A expense',false,true),
    ('depreciation_amortization','INCOME_STATEMENT','Depreciation and amortisation',false,true),
    ('finance_costs','INCOME_STATEMENT','Finance costs',false,true),
    ('interest_expense','INCOME_STATEMENT','Interest expense',false,true),
    ('provisions_impairment','INCOME_STATEMENT','Provisions / impairment',false,true),
    ('operating_income_ebit','INCOME_STATEMENT','Operating income (EBIT)',false,true),
    ('profit_before_tax','INCOME_STATEMENT','Profit before tax',true,true),
    ('income_tax_expense','INCOME_STATEMENT','Income tax expense',false,true),
    ('net_profit','INCOME_STATEMENT','Net profit or loss',true,true),
    ('cash_and_cash_equivalents','BALANCE_SHEET','Cash and cash equivalents',false,true),
    ('total_current_assets','BALANCE_SHEET','Total current assets',false,true),
    ('total_non_current_assets','BALANCE_SHEET','Total non-current assets',false,true),
    ('trade_receivables_net','BALANCE_SHEET','Trade receivables (net)',false,true),
    ('inventory','BALANCE_SHEET','Inventory',false,true),
    ('net_ppe','BALANCE_SHEET','Net PP&E',false,true),
    ('property_plant_equipment','BALANCE_SHEET','Property, plant and equipment',false,true),
    ('gross_loans_advances','BALANCE_SHEET','Gross loans and advances',false,true),
    ('stage3_npa','BALANCE_SHEET','Stage-3 / NPA loans',false,true),
    ('ecl_balance','BALANCE_SHEET','Loan-loss provision / ECL balance',false,true),
    ('investments','BALANCE_SHEET','Investments',false,true),
    ('total_assets','BALANCE_SHEET','Total assets',true,true),
    ('total_current_liabilities','BALANCE_SHEET','Total current liabilities',false,true),
    ('total_non_current_liabilities','BALANCE_SHEET','Total non-current liabilities',false,true),
    ('long_term_debt','BALANCE_SHEET','Long-term debt',false,true),
    ('borrowings','BALANCE_SHEET','Borrowings',false,true),
    ('customer_deposits','BALANCE_SHEET','Customer deposits',false,true),
    ('total_liabilities','BALANCE_SHEET','Total liabilities',true,true),
    ('retained_earnings','BALANCE_SHEET','Retained earnings',false,true),
    ('total_shareholders_equity','BALANCE_SHEET','Total shareholders equity',false,true),
    ('total_equity','BALANCE_SHEET','Total equity',true,true),
    ('shares_outstanding','BALANCE_SHEET','Shares outstanding',false,true),
    ('cet1_ratio','BALANCE_SHEET','CET-1 / capital ratio',false,true),
    ('cash_generated_from_operations','CASH_FLOW_STATEMENT','Cash generated from operations',false,true),
    ('operating_cash_flow','CASH_FLOW_STATEMENT','Operating cash flow',true,true),
    ('investing_cash_flow','CASH_FLOW_STATEMENT','Investing cash flow',true,true),
    ('financing_cash_flow','CASH_FLOW_STATEMENT','Financing cash flow',true,true),
    ('net_change_cash','CASH_FLOW_STATEMENT','Net change in cash',true,true),
    ('beginning_cash','CASH_FLOW_STATEMENT','Cash and cash equivalents at beginning of period',false,true),
    ('ending_cash','CASH_FLOW_STATEMENT','Cash and cash equivalents at end of period',true,true)
ON CONFLICT (concept_key) DO UPDATE SET
    statement_type=EXCLUDED.statement_type,
    canonical_label=EXCLUDED.canonical_label,
    is_required=EXCLUDED.is_required,
    active=true,
    updated_at=now();

CREATE FUNCTION financial_risk_intelligence.normalize_financial_alias_text(value text)
RETURNS text LANGUAGE sql IMMUTABLE RETURNS NULL ON NULL INPUT AS $$
    SELECT trim(regexp_replace(lower(value), '[^a-z0-9]+', ' ', 'g'));
$$;

CREATE TABLE financial_risk_intelligence.financial_concept_aliases (
    alias_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    concept_key text NOT NULL REFERENCES financial_risk_intelligence.financial_concepts(concept_key),
    alias_text text NOT NULL,
    normalized_alias_text text NOT NULL,
    sector_key text,
    country_code text,
    priority integer NOT NULL DEFAULT 100,
    active boolean NOT NULL DEFAULT true,
    approval_status text NOT NULL DEFAULT 'APPROVED'
        CHECK (approval_status IN ('PENDING','APPROVED','REJECTED')),
    source_document_id text,
    proposed_by text,
    approved_by text,
    approved_at timestamptz,
    match_confidence numeric(5,2),
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE financial_risk_intelligence.financial_statement_aliases (
    statement_alias_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    statement_type text NOT NULL CHECK (statement_type IN
        ('BALANCE_SHEET','INCOME_STATEMENT','CASH_FLOW_STATEMENT')),
    alias_text text NOT NULL,
    normalized_alias_text text NOT NULL,
    sector_key text,
    priority integer NOT NULL DEFAULT 100,
    active boolean NOT NULL DEFAULT true,
    approval_status text NOT NULL DEFAULT 'APPROVED'
        CHECK (approval_status IN ('PENDING','APPROVED','REJECTED')),
    approved_by text,
    approved_at timestamptz,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX uq_financial_statement_alias
ON financial_risk_intelligence.financial_statement_aliases
    (statement_type,normalized_alias_text,COALESCE(sector_key,''))
WHERE active=true AND approval_status='APPROVED';

INSERT INTO financial_risk_intelligence.financial_statement_aliases
    (statement_type,alias_text,normalized_alias_text,sector_key,priority,
     active,approval_status,approved_by,approved_at)
SELECT statement_type,alias_text,
       financial_risk_intelligence.normalize_financial_alias_text(alias_text),
       sector_key,priority,true,'APPROVED','REGISTRY_REBUILD',now()
FROM (VALUES
    ('BALANCE_SHEET','Balance sheet',NULL,1),
    ('BALANCE_SHEET','Balance sheets',NULL,2),
    ('BALANCE_SHEET','Statement of financial position',NULL,1),
    ('BALANCE_SHEET','Statements of financial position',NULL,2),
    ('BALANCE_SHEET','Consolidated statement of financial position',NULL,3),
    ('BALANCE_SHEET','Consolidated statements of financial position',NULL,4),
    ('INCOME_STATEMENT','Income statement',NULL,1),
    ('INCOME_STATEMENT','Statement of income',NULL,2),
    ('INCOME_STATEMENT','Statement of profit or loss',NULL,1),
    ('INCOME_STATEMENT','Consolidated statement of profit or loss',NULL,2),
    ('INCOME_STATEMENT','Statement of profit or loss and other comprehensive income',NULL,3),
    ('INCOME_STATEMENT','Consolidated statement of profit or loss and other comprehensive income',NULL,4),
    ('INCOME_STATEMENT','Statement of comprehensive income',NULL,10),
    ('CASH_FLOW_STATEMENT','Cash flow statement',NULL,1),
    ('CASH_FLOW_STATEMENT','Statement of cash flows',NULL,1),
    ('CASH_FLOW_STATEMENT','Consolidated statement of cash flows',NULL,2)
) AS seed(statement_type,alias_text,sector_key,priority);

CREATE FUNCTION financial_risk_intelligence.set_financial_alias_normalized_text()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    NEW.normalized_alias_text := financial_risk_intelligence.normalize_financial_alias_text(NEW.alias_text);
    NEW.updated_at := now();
    IF NEW.approval_status='APPROVED' AND NEW.approved_at IS NULL THEN NEW.approved_at:=now(); END IF;
    RETURN NEW;
END;
$$;

CREATE TRIGGER trg_set_financial_alias_normalized_text
BEFORE INSERT OR UPDATE OF alias_text, approval_status
ON financial_risk_intelligence.financial_concept_aliases
FOR EACH ROW EXECUTE FUNCTION financial_risk_intelligence.set_financial_alias_normalized_text();

CREATE UNIQUE INDEX uq_financial_alias_governed
ON financial_risk_intelligence.financial_concept_aliases
    (concept_key,normalized_alias_text,COALESCE(sector_key,''),COALESCE(country_code,''))
WHERE active=true AND approval_status='APPROVED';

CREATE INDEX ix_financial_alias_runtime
ON financial_risk_intelligence.financial_concept_aliases
    (concept_key,priority,normalized_alias_text)
WHERE active=true AND approval_status='APPROVED';

-- Every seed below is inserted active and APPROVED.
INSERT INTO financial_risk_intelligence.financial_concept_aliases
    (concept_key,alias_text,normalized_alias_text,sector_key,priority,
     active,approval_status,approved_by,approved_at)
SELECT DISTINCT ON (
       seed.concept_key,
       financial_risk_intelligence.normalize_financial_alias_text(seed.alias_text),
       COALESCE(seed.sector_key,'')
   )
       seed.concept_key,seed.alias_text,
       financial_risk_intelligence.normalize_financial_alias_text(seed.alias_text),
       seed.sector_key,seed.priority,true,'APPROVED','REGISTRY_REBUILD',now()
FROM (VALUES
    ('revenue','Revenue','COMMERCIAL',1),('revenue','Sales','COMMERCIAL',10),
    ('revenue','Net sales','COMMERCIAL',15),('revenue','Turnover','COMMERCIAL',20),
    ('total_income','Total income',NULL,1),('total_income','Total operating income',NULL,10),
    ('total_income','Total revenue',NULL,20),
    ('cost_of_sales','Cost of sales','COMMERCIAL',1),('cost_of_sales','Cost of revenue','COMMERCIAL',10),
    ('cost_of_goods_sold','Cost of goods sold','COMMERCIAL',1),('cost_of_goods_sold','COGS','COMMERCIAL',10),
    ('gross_profit','Gross profit','COMMERCIAL',1),('gross_profit','Gross income','COMMERCIAL',10),
    ('other_income','Other income',NULL,1),('other_income','Other operating income','COMMERCIAL',10),
    ('net_interest_income','Net interest income','BANK',1),('net_interest_income','Net interest revenue','BANK',10),
    ('net_interest_income','Net banking income','BANK',20),
    ('non_interest_income','Non-interest income','BANK',1),
    ('non_interest_income','Fee and commission income','BANK',10),
    ('non_interest_income','Fees and commissions','BANK',20),
    ('operating_expenses','Operating expenses',NULL,1),
    ('operating_expenses','Total operating expenses',NULL,10),
    ('operating_expenses','Total expenses',NULL,20),('operating_expenses','Operating costs',NULL,30),
    ('administrative_expenses','Administrative expenses','COMMERCIAL',1),
    ('administrative_expenses','General and administrative expenses','COMMERCIAL',10),
    ('sg_and_a_expense','SG&A expense','COMMERCIAL',1),
    ('sg_and_a_expense','Selling, general and administrative expenses','COMMERCIAL',10),
    ('depreciation_amortization','Depreciation and amortisation',NULL,1),
    ('depreciation_amortization','Depreciation and amortization',NULL,2),
    ('depreciation_amortization','Amortisation of intangible assets',NULL,10),
    ('finance_costs','Finance costs','COMMERCIAL',1),('finance_costs','Finance expenses','COMMERCIAL',10),
    ('interest_expense','Interest expense','BANK',1),('interest_expense','Interest expenses',NULL,10),
    ('provisions_impairment','Allowances for credit and other losses','BANK',1),
    ('provisions_impairment','Credit impairment losses','BANK',10),
    ('provisions_impairment','Expected credit loss',NULL,20),
    ('provisions_impairment','ECL charge','BANK',30),('provisions_impairment','Impairment losses',NULL,40),
    ('operating_income_ebit','Operating profit','COMMERCIAL',1),
    ('operating_income_ebit','Operating income','COMMERCIAL',10),('operating_income_ebit','EBIT','COMMERCIAL',20),
    ('profit_before_tax','Profit before tax',NULL,1),('profit_before_tax','Profit before taxation',NULL,5),
    ('profit_before_tax','Profit before income tax',NULL,10),('profit_before_tax','Income before tax',NULL,20),
    ('profit_before_tax','Loss before tax',NULL,5),('profit_before_tax','Loss before income tax',NULL,5),
    ('income_tax_expense','Income tax expense',NULL,1),('income_tax_expense','Tax expense',NULL,10),
    ('net_profit','Net profit',NULL,1),('net_profit','Net income',NULL,10),
    ('net_profit','Profit for the year',NULL,20),('net_profit','Profit for the period',NULL,21),
    ('net_profit','Loss for the year',NULL,20),('net_profit','Loss for the period',NULL,21),
    ('net_profit','Loss for the year/period',NULL,22),
    ('cash_and_cash_equivalents','Cash and cash equivalents',NULL,1),
    ('cash_and_cash_equivalents','Cash and bank balances',NULL,10),
    ('total_current_assets','Total current assets',NULL,1),
    ('total_non_current_assets','Total non-current assets',NULL,1),
    ('trade_receivables_net','Trade receivables','COMMERCIAL',1),
    ('trade_receivables_net','Trade receivables, net','COMMERCIAL',5),
    ('trade_receivables_net','Accounts receivable','COMMERCIAL',10),
    ('inventory','Inventory','COMMERCIAL',1),('inventory','Inventories','COMMERCIAL',2),
    ('net_ppe','Net PP&E','COMMERCIAL',1),
    ('property_plant_equipment','Property, plant and equipment','COMMERCIAL',1),
    ('property_plant_equipment','Property plant and equipment','COMMERCIAL',2),
    ('gross_loans_advances','Loans and advances to customers','BANK',1),
    ('gross_loans_advances','Gross loans','BANK',10),('gross_loans_advances','Gross loans and advances','BANK',20),
    ('stage3_npa','Stage 3 loans','BANK',1),('stage3_npa','Stage-3 loans','BANK',2),
    ('stage3_npa','Non-performing loans','BANK',10),('stage3_npa','NPA loans','BANK',20),
    ('stage3_npa','GNPA','BANK',30),('ecl_balance','ECL balance','BANK',1),
    ('ecl_balance','Loan-loss provision','BANK',10),('ecl_balance','Loss allowance',NULL,20),
    ('investments','Investments',NULL,1),('investments','Investment securities','BANK',10),
    ('investments','Bank and corporate securities','BANK',20),('total_assets','Total assets',NULL,1),
    ('total_current_liabilities','Total current liabilities',NULL,1),
    ('total_non_current_liabilities','Total non-current liabilities',NULL,1),
    ('long_term_debt','Long-term debt',NULL,1),('long_term_debt','Long term debt',NULL,2),
    ('borrowings','Borrowings',NULL,1),('borrowings','Loans and borrowings','COMMERCIAL',10),
    ('borrowings','Due to banks','BANK',10),
    ('customer_deposits','Deposits and balances from customers','BANK',1),
    ('customer_deposits','Customer deposits','BANK',10),('total_liabilities','Total liabilities',NULL,1),
    ('retained_earnings','Retained earnings',NULL,1),('retained_earnings','Accumulated profits',NULL,10),
    ('retained_earnings','Accumulated losses','COMMERCIAL',20),
    ('total_shareholders_equity','Shareholders equity',NULL,1),
    ('total_shareholders_equity','Shareholders funds','BANK',10),('total_equity','Total equity',NULL,1),
    ('shares_outstanding','Shares outstanding',NULL,1),('cet1_ratio','CET-1','BANK',1),
    ('cet1_ratio','CET1 ratio','BANK',5),('cet1_ratio','Common Equity Tier 1','BANK',10),
    ('cet1_ratio','Capital adequacy ratio','BANK',20),
    ('cash_generated_from_operations','Cash generated from operations',NULL,1),
    ('cash_generated_from_operations','Cash used in operations',NULL,10),
    ('operating_cash_flow','Cash flow from operating activities',NULL,1),
    ('operating_cash_flow','Cash flows from operating activities',NULL,2),
    ('operating_cash_flow','Net cash from operating activities',NULL,5),
    ('operating_cash_flow','Net cash generated from operating activities',NULL,10),
    ('operating_cash_flow','Net cash used in operating activities',NULL,11),
    ('operating_cash_flow','Net cash flows generated from operating activities',NULL,12),
    ('operating_cash_flow','Net cash flows used in operating activities',NULL,13),
    ('investing_cash_flow','Cash flow from investing activities',NULL,1),
    ('investing_cash_flow','Cash flows from investing activities',NULL,2),
    ('investing_cash_flow','Net cash from investing activities',NULL,5),
    ('investing_cash_flow','Net cash generated from investing activities',NULL,10),
    ('investing_cash_flow','Net cash used in investing activities',NULL,11),
    ('investing_cash_flow','Net cash flows generated from investing activities',NULL,12),
    ('investing_cash_flow','Net cash flows used in investing activities',NULL,13),
    ('financing_cash_flow','Cash flow from financing activities',NULL,1),
    ('financing_cash_flow','Cash flows from financing activities',NULL,2),
    ('financing_cash_flow','Net cash from financing activities',NULL,5),
    ('financing_cash_flow','Net cash generated from financing activities',NULL,10),
    ('financing_cash_flow','Net cash used in financing activities',NULL,11),
    ('financing_cash_flow','Net cash flows generated from financing activities',NULL,12),
    ('financing_cash_flow','Net cash flows used in financing activities',NULL,13),
    ('net_change_cash','Net increase in cash and cash equivalents',NULL,1),
    ('net_change_cash','Net decrease in cash and cash equivalents',NULL,2),
    ('net_change_cash','Net change in cash and cash equivalents',NULL,5),
    ('beginning_cash','Cash and cash equivalents at beginning of period',NULL,1),
    ('beginning_cash','Cash and cash equivalents at beginning of the financial year',NULL,2),
    ('beginning_cash','Cash and cash equivalents at beginning of the financial year/period',NULL,3),
    ('ending_cash','Cash and cash equivalents at end of period',NULL,1),
    ('ending_cash','Cash and cash equivalents at year end',NULL,2),
    ('ending_cash','Closing cash and cash equivalents',NULL,3),
    ('ending_cash','Cash and cash equivalents at end of the financial year',NULL,4),
    ('ending_cash','Cash and cash equivalents at end of the financial year/period',NULL,5)
) AS seed(concept_key,alias_text,sector_key,priority)
ORDER BY
    seed.concept_key,
    financial_risk_intelligence.normalize_financial_alias_text(seed.alias_text),
    COALESCE(seed.sector_key,''),
    seed.priority,
    seed.alias_text;

CREATE VIEW financial_risk_intelligence.approved_financial_concept_aliases AS
SELECT a.alias_id,a.concept_key,c.statement_type,c.canonical_label,
       a.alias_text,a.normalized_alias_text,a.sector_key,a.country_code,
       a.priority,a.active,a.approval_status,a.source_document_id,
       a.match_confidence,a.approved_by,a.approved_at,a.created_at,a.updated_at
FROM financial_risk_intelligence.financial_concept_aliases a
JOIN financial_risk_intelligence.financial_concepts c USING (concept_key)
WHERE a.active=true AND a.approval_status='APPROVED' AND c.active=true;

CREATE VIEW financial_risk_intelligence.pending_financial_concept_aliases AS
SELECT a.*,c.statement_type,c.canonical_label
FROM financial_risk_intelligence.financial_concept_aliases a
JOIN financial_risk_intelligence.financial_concepts c USING (concept_key)
WHERE a.approval_status='PENDING';

CREATE VIEW financial_risk_intelligence.approved_financial_statement_aliases AS
SELECT statement_alias_id,statement_type,alias_text,normalized_alias_text,
       sector_key,priority,active,approval_status,approved_by,approved_at,
       created_at,updated_at
FROM financial_risk_intelligence.financial_statement_aliases
WHERE active=true AND approval_status='APPROVED';

CREATE VIEW financial_risk_intelligence.financial_concept_configuration AS
SELECT c.concept_key,c.canonical_label,c.statement_type,c.is_required,c.active,
       COALESCE(c.scope_preference,'GROUP_THEN_REPORTED_THEN_COMPANY') AS scope_preference,
       c.validation_definition,
       COALESCE(string_agg(a.alias_text,' | ' ORDER BY a.priority,a.alias_text)
           FILTER (WHERE a.alias_id IS NOT NULL),c.canonical_label) AS aliases
FROM financial_risk_intelligence.financial_concepts c
LEFT JOIN financial_risk_intelligence.financial_concept_aliases a
  ON a.concept_key=c.concept_key AND a.active=true AND a.approval_status='APPROVED'
WHERE c.active=true
GROUP BY c.concept_key,c.canonical_label,c.statement_type,c.is_required,
         c.active,c.validation_definition,c.scope_preference;

-- Runtime configuration maintenance functions. Use these after the initial
-- rebuild; do not rerun this destructive file merely to add an alias.
CREATE OR REPLACE FUNCTION financial_risk_intelligence.upsert_statement_alias(
    p_statement_type text,
    p_alias_text text,
    p_sector_key text DEFAULT NULL,
    p_priority integer DEFAULT 100,
    p_approved_by text DEFAULT 'CONFIG_ADMIN'
)
RETURNS uuid
LANGUAGE plpgsql
AS $$
DECLARE
    v_id uuid;
    v_type text := upper(trim(p_statement_type));
    v_normalized text := financial_risk_intelligence.normalize_financial_alias_text(p_alias_text);
BEGIN
    IF v_type NOT IN ('BALANCE_SHEET','INCOME_STATEMENT','CASH_FLOW_STATEMENT') THEN
        RAISE EXCEPTION 'Unsupported statement type: %', p_statement_type;
    END IF;
    IF v_normalized IS NULL OR v_normalized = '' THEN
        RAISE EXCEPTION 'Alias text cannot be empty';
    END IF;

    SELECT statement_alias_id INTO v_id
    FROM financial_risk_intelligence.financial_statement_aliases
    WHERE statement_type = v_type
      AND normalized_alias_text = v_normalized
      AND sector_key IS NOT DISTINCT FROM nullif(trim(p_sector_key),'')
    ORDER BY active DESC, priority ASC, created_at ASC
    LIMIT 1;

    IF v_id IS NULL THEN
        INSERT INTO financial_risk_intelligence.financial_statement_aliases (
            statement_type,alias_text,normalized_alias_text,sector_key,priority,
            active,approval_status,approved_by,approved_at
        ) VALUES (
            v_type,trim(p_alias_text),v_normalized,nullif(trim(p_sector_key),''),
            p_priority,true,'APPROVED',p_approved_by,now()
        ) RETURNING statement_alias_id INTO v_id;
    ELSE
        UPDATE financial_risk_intelligence.financial_statement_aliases
        SET alias_text=trim(p_alias_text),priority=p_priority,active=true,
            approval_status='APPROVED',approved_by=p_approved_by,
            approved_at=now(),updated_at=now()
        WHERE statement_alias_id=v_id;
    END IF;
    RETURN v_id;
END;
$$;

CREATE OR REPLACE FUNCTION financial_risk_intelligence.upsert_concept_alias(
    p_concept_key text,
    p_alias_text text,
    p_sector_key text DEFAULT NULL,
    p_country_code text DEFAULT NULL,
    p_priority integer DEFAULT 100,
    p_source_document_id text DEFAULT NULL,
    p_match_confidence numeric DEFAULT NULL,
    p_approved_by text DEFAULT 'CONFIG_ADMIN'
)
RETURNS uuid
LANGUAGE plpgsql
AS $$
DECLARE
    v_id uuid;
    v_concept text := trim(p_concept_key);
    v_normalized text := financial_risk_intelligence.normalize_financial_alias_text(p_alias_text);
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM financial_risk_intelligence.financial_concepts
        WHERE concept_key=v_concept AND active=true
    ) THEN
        RAISE EXCEPTION 'Unknown or inactive concept key: %', p_concept_key;
    END IF;
    IF v_normalized IS NULL OR v_normalized = '' THEN
        RAISE EXCEPTION 'Alias text cannot be empty';
    END IF;

    SELECT alias_id INTO v_id
    FROM financial_risk_intelligence.financial_concept_aliases
    WHERE concept_key=v_concept
      AND normalized_alias_text=v_normalized
      AND sector_key IS NOT DISTINCT FROM nullif(trim(p_sector_key),'')
      AND country_code IS NOT DISTINCT FROM nullif(upper(trim(p_country_code)),'')
    ORDER BY active DESC,priority ASC,created_at ASC
    LIMIT 1;

    IF v_id IS NULL THEN
        INSERT INTO financial_risk_intelligence.financial_concept_aliases (
            concept_key,alias_text,normalized_alias_text,sector_key,country_code,
            priority,active,approval_status,source_document_id,proposed_by,
            approved_by,approved_at,match_confidence
        ) VALUES (
            v_concept,trim(p_alias_text),v_normalized,nullif(trim(p_sector_key),''),
            nullif(upper(trim(p_country_code)),''),p_priority,true,'APPROVED',
            p_source_document_id,'DATABASE_UPSERT',p_approved_by,now(),p_match_confidence
        ) RETURNING alias_id INTO v_id;
    ELSE
        UPDATE financial_risk_intelligence.financial_concept_aliases
        SET alias_text=trim(p_alias_text),priority=p_priority,active=true,
            approval_status='APPROVED',source_document_id=COALESCE(p_source_document_id,source_document_id),
            match_confidence=COALESCE(p_match_confidence,match_confidence),
            approved_by=p_approved_by,approved_at=now(),updated_at=now()
        WHERE alias_id=v_id;
    END IF;
    RETURN v_id;
END;
$$;

COMMIT;

SELECT statement_type,count(*) AS approved_alias_count
FROM financial_risk_intelligence.approved_financial_concept_aliases
GROUP BY statement_type ORDER BY statement_type;

SELECT approval_status,active,count(*) AS alias_count
FROM financial_risk_intelligence.financial_concept_aliases
GROUP BY approval_status,active ORDER BY approval_status,active;


-- ============================================================================
-- SOURCE: dataiku\sql\FRI_MANUFACTURING_GENERIC_TEMPLATE_MAPPING.sql
-- ============================================================================
-- Manufacturing & Industrials generic financial template configuration.
-- Run after FRI_FINANCIAL_SYNONYM_REGISTRY.sql.
-- Database-only mapping: no recipe code changes are required.

BEGIN;

CREATE TABLE IF NOT EXISTS financial_risk_intelligence.financial_templates (
    template_key text PRIMARY KEY,
    template_name text NOT NULL,
    sector_key text NOT NULL,
    active boolean NOT NULL DEFAULT true,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS financial_risk_intelligence.financial_template_fields (
    template_key text NOT NULL REFERENCES financial_risk_intelligence.financial_templates(template_key),
    field_key text NOT NULL,
    concept_key text NOT NULL REFERENCES financial_risk_intelligence.financial_concepts(concept_key),
    display_label text NOT NULL,
    statement_type text NOT NULL CHECK (statement_type IN
        ('INCOME_STATEMENT','BALANCE_SHEET','CASH_FLOW_STATEMENT')),
    display_order integer NOT NULL,
    required boolean NOT NULL DEFAULT true,
    active boolean NOT NULL DEFAULT true,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (template_key,field_key),
    UNIQUE (template_key,concept_key)
);

INSERT INTO financial_risk_intelligence.financial_templates
    (template_key,template_name,sector_key,active)
VALUES ('MANUFACTURING_INDUSTRIALS_GENERIC','Financial inputs - Manufacturing & Industrials','COMMERCIAL',true)
ON CONFLICT (template_key) DO UPDATE SET
    template_name=EXCLUDED.template_name,sector_key=EXCLUDED.sector_key,
    active=true,updated_at=now();

INSERT INTO financial_risk_intelligence.financial_template_fields
    (template_key,field_key,concept_key,display_label,statement_type,display_order,required,active)
VALUES
    ('MANUFACTURING_INDUSTRIALS_GENERIC','net_revenue_sales','revenue','Net revenue / sales','INCOME_STATEMENT',10,true,true),
    ('MANUFACTURING_INDUSTRIALS_GENERIC','cost_of_goods_sold','cost_of_goods_sold','Cost of goods sold','INCOME_STATEMENT',20,true,true),
    ('MANUFACTURING_INDUSTRIALS_GENERIC','sg_and_a_expense','sg_and_a_expense','SG&A expense','INCOME_STATEMENT',30,true,true),
    ('MANUFACTURING_INDUSTRIALS_GENERIC','depreciation_amortisation','depreciation_amortization','Depreciation & amortisation','INCOME_STATEMENT',40,true,true),
    ('MANUFACTURING_INDUSTRIALS_GENERIC','operating_income_ebit','operating_income_ebit','Operating income (EBIT)','INCOME_STATEMENT',50,true,true),
    ('MANUFACTURING_INDUSTRIALS_GENERIC','interest_expense','interest_expense','Interest expense','INCOME_STATEMENT',60,true,true),
    ('MANUFACTURING_INDUSTRIALS_GENERIC','net_income','net_profit','Net income','INCOME_STATEMENT',70,true,true),
    ('MANUFACTURING_INDUSTRIALS_GENERIC','total_current_assets','total_current_assets','Total current assets','BALANCE_SHEET',110,true,true),
    ('MANUFACTURING_INDUSTRIALS_GENERIC','trade_receivables_net','trade_receivables_net','Trade receivables (net)','BALANCE_SHEET',120,true,true),
    ('MANUFACTURING_INDUSTRIALS_GENERIC','inventory','inventory','Inventory','BALANCE_SHEET',130,true,true),
    ('MANUFACTURING_INDUSTRIALS_GENERIC','net_ppe','net_ppe','Net PP&E (fixed assets)','BALANCE_SHEET',140,true,true),
    ('MANUFACTURING_INDUSTRIALS_GENERIC','total_assets','total_assets','Total assets','BALANCE_SHEET',150,true,true),
    ('MANUFACTURING_INDUSTRIALS_GENERIC','total_current_liabilities','total_current_liabilities','Total current liabilities','BALANCE_SHEET',160,true,true),
    ('MANUFACTURING_INDUSTRIALS_GENERIC','long_term_debt','long_term_debt','Long-term debt','BALANCE_SHEET',170,true,true),
    ('MANUFACTURING_INDUSTRIALS_GENERIC','total_liabilities','total_liabilities','Total liabilities','BALANCE_SHEET',180,true,true),
    ('MANUFACTURING_INDUSTRIALS_GENERIC','retained_earnings','retained_earnings','Retained earnings','BALANCE_SHEET',190,true,true),
    ('MANUFACTURING_INDUSTRIALS_GENERIC','total_shareholders_equity','total_shareholders_equity','Total shareholders'' equity','BALANCE_SHEET',200,true,true),
    ('MANUFACTURING_INDUSTRIALS_GENERIC','shares_outstanding','shares_outstanding','Shares outstanding','BALANCE_SHEET',210,true,true),
    ('MANUFACTURING_INDUSTRIALS_GENERIC','cash_flow_from_operations','operating_cash_flow','Cash flow from operations','CASH_FLOW_STATEMENT',310,true,true)
ON CONFLICT (template_key,field_key) DO UPDATE SET
    concept_key=EXCLUDED.concept_key,display_label=EXCLUDED.display_label,
    statement_type=EXCLUDED.statement_type,display_order=EXCLUDED.display_order,
    required=EXCLUDED.required,active=true,updated_at=now();

-- Curated from the PDFs in /data. DISTINCT ON + the governed unique index means
-- repeated labels across reports are stored once, not once per document.
INSERT INTO financial_risk_intelligence.financial_concept_aliases
    (concept_key,alias_text,normalized_alias_text,sector_key,priority,
     active,approval_status,approved_by,approved_at,match_confidence)
SELECT DISTINCT ON (concept_key,normalized_alias_text,COALESCE(sector_key,''))
       concept_key,alias_text,normalized_alias_text,sector_key,priority,
       true,'APPROVED','PDF_CORPUS_2026',now(),confidence
FROM (
    SELECT v.concept_key,v.alias_text,
           financial_risk_intelligence.normalize_financial_alias_text(v.alias_text) AS normalized_alias_text,
           'COMMERCIAL'::text AS sector_key,v.priority,v.confidence
    FROM (VALUES
      ('revenue','Revenue',1,99.00),('revenue','Net revenue',2,99.00),
      ('revenue','Sales',5,98.00),('revenue','Net sales',6,98.00),('revenue','Turnover',10,98.00),
      ('revenue','Revenue from contracts with customers',12,98.00),('revenue','Revenue from contract with customer',13,98.00),
      ('cost_of_goods_sold','Cost of goods sold',1,99.00),('cost_of_goods_sold','Cost of sales',2,99.00),
      ('cost_of_goods_sold','Cost of revenue',5,98.00),('cost_of_goods_sold','Cost of inventories sold',10,96.00),
      ('sg_and_a_expense','SG&A expense',1,99.00),('sg_and_a_expense','Selling, general and administrative expenses',2,99.00),
      ('sg_and_a_expense','General and administrative expenses',5,97.00),('sg_and_a_expense','Administrative expenses',10,95.00),
      ('sg_and_a_expense','Selling expenses',11,95.00),
      ('depreciation_amortization','Depreciation and amortisation',1,99.00),
      ('depreciation_amortization','Depreciation and amortization',2,99.00),
      ('depreciation_amortization','Depreciation & amortisation',3,99.00),
      ('operating_income_ebit','Operating profit',1,99.00),('operating_income_ebit','Operating income',2,99.00),
      ('operating_income_ebit','Profit from operations',5,98.00),('operating_income_ebit','Income from operations',6,98.00),
      ('operating_income_ebit','EBIT',10,99.00),
      ('interest_expense','Interest expense',1,99.00),('interest_expense','Interest expenses',2,99.00),
      ('interest_expense','Finance costs',5,98.00),('interest_expense','Finance cost',6,98.00),
      ('interest_expense','Finance expense',7,98.00),('interest_expense','Finance expenses',8,98.00),
      ('interest_expense','Interest cost',10,96.00),
      ('net_profit','Net income',1,99.00),('net_profit','Net profit',2,99.00),
      ('net_profit','Profit for the year',5,99.00),('net_profit','Profit for the financial year',6,99.00),
      ('net_profit','Loss for the year',7,99.00),('net_profit','Loss for the financial year',8,99.00),
      ('net_profit','Profit after tax',10,98.00),('net_profit','Loss after tax',11,98.00),
      ('net_profit','Profit after taxation',12,98.00),('net_profit','Loss after taxation',13,98.00),
      ('total_current_assets','Total current assets',1,99.00),
      ('trade_receivables_net','Trade receivables',1,99.00),('trade_receivables_net','Trade receivables, net',2,99.00),
      ('trade_receivables_net','Trade receivable',3,98.00),('trade_receivables_net','Accounts receivable',5,98.00),
      ('trade_receivables_net','Accounts receivable, net',6,98.00),
      ('inventory','Inventory',1,99.00),('inventory','Inventories',2,99.00),('inventory','Inventories, net',3,98.00),
      ('net_ppe','Property, plant and equipment',1,99.00),('net_ppe','Property, plant and equipment, net',2,99.00),
      ('net_ppe','Fixed assets',5,96.00),('net_ppe','Net fixed assets',6,98.00),
      ('total_assets','Total assets',1,99.00),
      ('total_current_liabilities','Total current liabilities',1,99.00),
      ('long_term_debt','Long-term debt',1,99.00),('long_term_debt','Long term debt',2,99.00),
      ('long_term_debt','Long-term loans',5,97.00),('long_term_debt','Non-current borrowings',6,97.00),
      ('long_term_debt','Borrowings - non-current',7,97.00),
      ('total_liabilities','Total liabilities',1,99.00),
      ('retained_earnings','Retained earnings',1,99.00),('retained_earnings','Retained profits',2,99.00),
      ('retained_earnings','Accumulated profits',5,98.00),('retained_earnings','Accumulated losses',6,98.00),
      ('total_shareholders_equity','Total shareholders'' equity',1,99.00),
      ('total_shareholders_equity','Shareholders'' equity',2,99.00),
      ('total_shareholders_equity','Shareholders'' funds',3,98.00),
      ('total_shareholders_equity','Equity attributable to owners of the Company',5,97.00),
      ('total_shareholders_equity','Equity attributable to owners',6,96.00),
      ('shares_outstanding','Shares outstanding',1,99.00),('shares_outstanding','Number of shares outstanding',2,99.00),
      ('shares_outstanding','Issued shares',5,97.00),('shares_outstanding','Shares in issue',6,97.00),
      ('operating_cash_flow','Cash flow from operating activities',1,99.00),
      ('operating_cash_flow','Cash flows from operating activities',2,99.00),
      ('operating_cash_flow','Net cash from operating activities',3,99.00),
      ('operating_cash_flow','Net cash generated from operating activities',4,99.00),
      ('operating_cash_flow','Net cash used in operating activities',5,99.00),
      ('operating_cash_flow','Net cash flows generated from operating activities',6,99.00),
      ('operating_cash_flow','Net cash flows used in operating activities',7,99.00)
    ) AS v(concept_key,alias_text,priority,confidence)
) seed
ORDER BY concept_key,normalized_alias_text,COALESCE(sector_key,''),priority
ON CONFLICT DO NOTHING;

INSERT INTO financial_risk_intelligence.financial_statement_aliases
    (statement_type,alias_text,normalized_alias_text,sector_key,priority,
     active,approval_status,approved_by,approved_at)
SELECT DISTINCT ON (statement_type,normalized_alias_text,COALESCE(sector_key,''))
       statement_type,alias_text,normalized_alias_text,sector_key,priority,
       true,'APPROVED','PDF_CORPUS_2026',now()
FROM (
    SELECT v.statement_type,v.alias_text,
           financial_risk_intelligence.normalize_financial_alias_text(v.alias_text) normalized_alias_text,
           'COMMERCIAL'::text sector_key,v.priority
    FROM (VALUES
      ('BALANCE_SHEET','Balance sheet',1),('BALANCE_SHEET','Balance sheets',2),
      ('BALANCE_SHEET','Statement of financial position',3),('BALANCE_SHEET','Statements of financial position',4),
      ('BALANCE_SHEET','Consolidated statement of financial position',5),
      ('BALANCE_SHEET','Consolidated statements of financial position',6),
      ('INCOME_STATEMENT','Income statement',1),('INCOME_STATEMENT','Income statements',2),
      ('INCOME_STATEMENT','Statement of income',3),('INCOME_STATEMENT','Consolidated statement of income',4),
      ('INCOME_STATEMENT','Statement of profit or loss',5),('INCOME_STATEMENT','Statements of profit or loss',6),
      ('INCOME_STATEMENT','Consolidated statement of profit or loss',7),
      ('INCOME_STATEMENT','Statement of comprehensive income',8),
      ('INCOME_STATEMENT','Statements of comprehensive income',9),
      ('INCOME_STATEMENT','Consolidated statement of comprehensive income',10),
      ('INCOME_STATEMENT','Consolidated statements of comprehensive income',11),
      ('INCOME_STATEMENT','Statement of profit or loss and other comprehensive income',12),
      ('INCOME_STATEMENT','Statements of profit or loss and other comprehensive income',13),
      ('INCOME_STATEMENT','Consolidated statement of profit or loss and other comprehensive income',14),
      ('INCOME_STATEMENT','Consolidated statements of profit or loss and other comprehensive income',15),
      ('CASH_FLOW_STATEMENT','Cash flow statement',1),('CASH_FLOW_STATEMENT','Statement of cash flow',2),
      ('CASH_FLOW_STATEMENT','Statement of cash flows',3),('CASH_FLOW_STATEMENT','Statements of cash flows',4),
      ('CASH_FLOW_STATEMENT','Consolidated statement of cash flow',5),
      ('CASH_FLOW_STATEMENT','Consolidated statement of cash flows',6),
      ('CASH_FLOW_STATEMENT','Consolidated statements of cash flows',7)
    ) AS v(statement_type,alias_text,priority)
) seed
ORDER BY statement_type,normalized_alias_text,COALESCE(sector_key,''),priority
ON CONFLICT DO NOTHING;

-- Runtime configuration consumed by a generic extractor/template renderer.
-- Alias_rank=1 is the deterministic winner if legacy data contains duplicates.
CREATE OR REPLACE VIEW financial_risk_intelligence.manufacturing_generic_template_mapping AS
SELECT template_key,field_key,display_label,statement_type,display_order,required,
       concept_key,alias_text,normalized_alias_text,priority,match_confidence
FROM (
    SELECT f.template_key,f.field_key,f.display_label,f.statement_type,
           f.display_order,f.required,f.concept_key,a.alias_text,
           a.normalized_alias_text,a.priority,a.match_confidence,
           row_number() OVER (
             PARTITION BY f.template_key,f.field_key,a.normalized_alias_text
             ORDER BY a.priority,a.updated_at DESC,a.alias_id
           ) AS alias_rank
    FROM financial_risk_intelligence.financial_template_fields f
    JOIN financial_risk_intelligence.financial_concept_aliases a
      ON a.concept_key=f.concept_key
     AND a.active=true AND a.approval_status='APPROVED'
     AND (a.sector_key IS NULL OR a.sector_key='COMMERCIAL')
    WHERE f.template_key='MANUFACTURING_INDUSTRIALS_GENERIC' AND f.active=true
) ranked
WHERE alias_rank=1;

COMMIT;

-- Expected: 19 template fields; no duplicate normalized alias per field.
SELECT count(*) AS template_field_count
FROM financial_risk_intelligence.financial_template_fields
WHERE template_key='MANUFACTURING_INDUSTRIALS_GENERIC' AND active=true;

SELECT template_key,field_key,normalized_alias_text,count(*) AS duplicate_count
FROM financial_risk_intelligence.manufacturing_generic_template_mapping
GROUP BY template_key,field_key,normalized_alias_text
HAVING count(*) > 1;

