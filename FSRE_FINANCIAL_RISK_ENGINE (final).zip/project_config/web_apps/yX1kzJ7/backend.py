from __future__ import annotations

import collections
import concurrent.futures
import datetime as dt
import functools
import hashlib
import importlib
import importlib.util
import io
import json
import math
import os
import re
import shutil
import tempfile
import threading
import time
import traceback
import uuid
import zipfile
import urllib.request
from pathlib import Path
from typing import Any, Dict, List
from urllib.parse import urljoin
import dataiku
import pandas as pd
import requests
from flask import Flask, Response, jsonify, request, send_file, stream_with_context


# Required for a Dataiku standard webapp backend.
# Do not call app.run(); Dataiku starts the server.
app = Flask(__name__)
BACKEND_BUILD_ID = "generic-validated-score-pipeline-v157"
FINANCIAL_VALIDATION_ALGORITHM_VERSION = "univer sal-statement-columns-v3"
print("ACTIVE WEBAPP BACKEND:", BACKEND_BUILD_ID)


def json_api_errors(function):
    """Keep Dataiku/Flask error pages from leaking into JSON API clients."""
    @functools.wraps(function)
    def wrapped(*args, **kwargs):
        try:
            return function(*args, **kwargs)
        except Exception as exc:
            detail = f"{type(exc).__name__}: {exc}"
            print(f"{function.__name__} failed: {detail}\n{traceback.format_exc()}")
            return jsonify({"error": detail, "stage": function.__name__, "backend_build": BACKEND_BUILD_ID}), 500
    return wrapped

DATASETS_TO_EXPORT = [
    "FRI_RUNTIME_SETTINGS",
    "FRI_SECTOR_FORENSIC_SCORES", "FRI_SECTOR_SCORING_EXCEPTIONS",
    "FRI_SECTOR_TEMPLATE_VALUES", "FRI_SECTOR_TEMPLATE_EXCEPTIONS",
    "FRI_RESOLVED_FINANCIAL_FACTS",
    "FRI_FINANCIAL_FACT_VALIDATION_EXCEPTIONS",
    "FRI_STANDARDIZED_STATEMENT_VALUES", "FRI_STATEMENT_NORMALIZATION_EXCEPTIONS",
    "FRI_FINANCIAL_TABLE_JSON", "FRI_VALIDATED_TABLE_CELLS",
    "FRI_VALIDATED_TABLE_ARTIFACTS", "FRI_TABLE_VALIDATION_EXCEPTIONS",
    "FRI_EXTRACTED_TABLE_CELLS", "FRI_EXTRACTED_TABLES",
    "FRI_DOCUMENT_FRAGMENTS", "FRI_REQUIRED_FIELD_MANIFEST",
    "FRI_UPLOAD_REGISTRATION_RESULTS",
]


BALANCE_INPUTS_DATASET = "FRI_BALANCE_SHEET_INPUTS"
INCOME_INPUTS_DATASET = "FRI_INCOME_STATEMENT_INPUTS"
CANONICAL_FACTS_DATASET = "FRI_RESOLVED_FINANCIAL_FACTS"
SECTOR_TEMPLATE_VALUES_DATASET = "FRI_SECTOR_TEMPLATE_VALUES"
SECTOR_TEMPLATE_CONFIG_DATASET = "FRI_SECTOR_TEMPLATE_CONFIGURATION"
SECTOR_SCORING_CONFIG_DATASET = "FRI_SECTOR_SCORING_CONFIGURATION"
REGISTRATIONS_DATASET = "FRI_UPLOAD_REGISTRATION_RESULTS"
TABLE_JSON_DATASET = "FRI_FINANCIAL_TABLE_JSON"
VALIDATED_TABLE_CELLS_DATASET = "FRI_VALIDATED_TABLE_CELLS"
EXTRACTED_TABLE_CELLS_DATASET = "FRI_EXTRACTED_TABLE_CELLS"
STANDARDIZED_VALUES_DATASET = "FRI_STANDARDIZED_STATEMENT_VALUES"
APPROVED_CONCEPT_ALIASES_DATASET = "FRI_APPROVED_FINANCIAL_CONCEPT_ALIASES"
FORENSIC_SCORES_DATASET = "FRI_SECTOR_FORENSIC_SCORES"
FORENSIC_EXCEPTIONS_DATASET = "FRI_SECTOR_SCORING_EXCEPTIONS"
DOCUMENT_FRAGMENTS_DATASET = "FRI_DOCUMENT_FRAGMENTS"
RUNTIME_SETTINGS_DATASET = "FRI_RUNTIME_SETTINGS"
DEFAULT_REPORTS_FOLDER_ID = "avBJ7Lwp"
SGX_START_URL = "https://www.sgx.com/stock-exchange/annual-reports-related-documents"
SGX_SYNC_LOCK = threading.Lock()
SGX_SYNC_STATE: Dict[str, Any] = {
    "status": "IDLE", "message": "No SGX sync has been started.",
    "downloaded": 0, "announcements": 0, "job_id": "",
}
BATCH_AUTOMATION_LOCK = threading.Lock()
BATCH_AUTOMATION_STATE: Dict[str, Any] = {
    "status": "IDLE", "message": "NO AUTOMATED BATCH HAS BEEN STARTED.",
    "job_id": "", "batch_size": 100, "downloaded": 0, "total": 0,
    "completed": 0, "failed": 0, "current_file": "", "cancel_requested": False,
    "results": [], "next_offset": 0,
}
ANALYSIS_JOB_LOCK = threading.Lock()
ANALYSIS_PIPELINE_LOCK = threading.Lock()
ANALYSIS_JOBS: Dict[str, Dict[str, Any]] = {}
MAX_ANALYSIS_JOB_HISTORY = 100
AUTO_RESOLUTION_LOCK = threading.Lock()
AUTO_RESOLUTION_STATE: Dict[str, Dict[str, Any]] = {}
ANALYSIS_PIPELINE_NAME = "FSRE Financial Statement Analysis Pipeline"
ANALYSIS_RECIPES = [
    "FRI_00A_PUBLISH_RUNTIME_SETTINGS",
    "FRI_00_DETECT_AND_REGISTER_UPLOAD",
    "FRI_03_CLASSIFY_DOCUMENT_PAGES",
    "FRI_00B_CLASSIFY_ENTITY_SECTOR",
    "FRI_01A_BUILD_REQUIRED_FIELD_MANIFEST",
    "FRI_03B_EXTRACT_TABLE_LAYOUTS",
    "FRI_03C_VALIDATE_TABLE_STRUCTURE",
    "FRI_03D_PRESERVE_FINANCIAL_TABLE_JSON",
    "FRI_04A_STANDARDIZE_FINANCIAL_STATEMENTS",
    "FRI_04E_LLM_BUILD_CANONICAL_FINANCIAL_FACTS",
    "FRI_04F_RESOLVE_SECTOR_TEMPLATE",
    "FRI_05_SCORE_SECTOR_FORENSICS",
]
ANALYSIS_STAGE_NAMES = {
    "FRI_00A_PUBLISH_RUNTIME_SETTINGS": "Load database runtime configuration",
    "FRI_00_DETECT_AND_REGISTER_UPLOAD": "Register uploaded report",
    "FRI_03_CLASSIFY_DOCUMENT_PAGES": "Classify document pages",
    "FRI_00B_CLASSIFY_ENTITY_SECTOR": "Identify entity sector",
    "FRI_01A_BUILD_REQUIRED_FIELD_MANIFEST": "Build required financial fields",
    "FRI_03B_EXTRACT_TABLE_LAYOUTS": "Extract financial tables",
    "FRI_03C_VALIDATE_TABLE_STRUCTURE": "Validate statement structure",
    "FRI_03D_PRESERVE_FINANCIAL_TABLE_JSON": "Preserve validated statement evidence",
    "FRI_04A_STANDARDIZE_FINANCIAL_STATEMENTS": "Standardize financial statements",
    "FRI_04E_LLM_BUILD_CANONICAL_FINANCIAL_FACTS": "Resolve canonical financial facts",
    "FRI_04F_RESOLVE_SECTOR_TEMPLATE": "Apply sector financial template",
    "FRI_05_SCORE_SECTOR_FORENSICS": "Calculate forensic scores",
}

PRIMARY_STATEMENTS = {
    "BALANCE_SHEET",
    "INCOME_STATEMENT",
    "CASH_FLOW_STATEMENT",
}


@app.route("/api/sector-configuration", methods=["GET"])
def sector_configuration():
    """Return the database-owned UI and scoring contract for every sector."""
    fields = read_optional(SECTOR_TEMPLATE_CONFIG_DATASET)
    scoring = read_optional(SECTOR_SCORING_CONFIG_DATASET)
    if fields.empty:
        return jsonify({"error": "FRI_SECTOR_TEMPLATE_CONFIGURATION is unavailable"}), 503
    sectors = []
    for sector_key, sector_fields in fields.groupby("sector_key", sort=False):
        first = sector_fields.iloc[0].to_dict()
        sections = []
        for statement_type, statement_fields in sector_fields.sort_values("display_order").groupby("statement_type", sort=False):
            sections.append({
                "statement_type": canonical_statement(statement_type),
                "label": {"INCOME_STATEMENT": "Income statement", "BALANCE_SHEET": "Balance sheet", "CASH_FLOW_STATEMENT": "Cash flow"}.get(canonical_statement(statement_type), text(statement_type)),
                "fields": [{
                    "field_key": text(row.get("field_key")), "concept_key": text(row.get("concept_key")),
                    "input_key": text(row.get("input_key") or row.get("concept_key")), "display_label": text(row.get("display_label")),
                    "display_order": integer(row.get("display_order"), 0), "applicability_status": text(row.get("applicability_status")),
                    "applicability_reason": text(row.get("applicability_reason")),
                } for row in statement_fields.to_dict(orient="records")]
            })
        models = []
        selected_models = scoring[scoring["sector_key"].astype(str).eq(str(sector_key))] if not scoring.empty else pd.DataFrame()
        for model_key, model_rows in selected_models.groupby("model_key", sort=False):
            model = model_rows.iloc[0].to_dict()
            parameters = model.get("parameters")
            if isinstance(parameters, str):
                try: parameters = json.loads(parameters)
                except json.JSONDecodeError: parameters = {}
            models.append({"model_key": text(model_key), "model_name": text(model.get("model_name")),
                           "enabled": text(model.get("enabled")).lower() in {"true", "1", "yes"}, "weight": number(model.get("weight")),
                           "parameters": parameters or {}, "disabled_reason": text(model.get("disabled_reason")),
                           "configuration_version": text(model.get("configuration_version"))})
        sectors.append({"sector_key": text(sector_key), "sector_name": text(first.get("sector_name")),
                        "profile_type": text(first.get("profile_type")), "template_key": text(first.get("template_key")),
                        "sections": sections, "models": models})
    return jsonify({"configuration_source": "POSTGRESQL", "sectors": sectors})


@app.route("/__ping", methods=["GET"])
def dataiku_ping():
    """Lightweight health probe used by the Dataiku webapp supervisor."""
    return "pong", 200, {"Content-Type": "text/plain; charset=utf-8"}


def missing(value: Any) -> bool:
    if value is None:
        return True

    try:
        result = pd.isna(value)
        if isinstance(result, bool) and result:
            return True
    except Exception:
        pass

    return str(value).strip().lower() in {
        "",
        "nan",
        "none",
        "null",
        "nat",
    }


def text(value: Any) -> str:
    return "" if missing(value) else str(value).strip()


def number(value: Any):
    if missing(value):
        return None

    try:
        result = float(value)
        return None if math.isnan(result) else result
    except Exception:
        return None


def integer(value: Any, default: int = -1) -> int:
    try:
        return int(float(value))
    except Exception:
        return default


def canonical_statement(value: Any) -> str:
    normalized = re.sub(
        r"[^a-z0-9]+",
        "_",
        text(value).lower(),
    ).strip("_")

    aliases = {
        "balance": "BALANCE_SHEET",
        "balance_sheet": "BALANCE_SHEET",
        "balance_sheets": "BALANCE_SHEET",
        "statement_of_financial_position": "BALANCE_SHEET",
        "income": "INCOME_STATEMENT",
        "income_statement": "INCOME_STATEMENT",
        "income_statements": "INCOME_STATEMENT",
        "profit_and_loss": "INCOME_STATEMENT",
        "p_and_l": "INCOME_STATEMENT",
        "pnl": "INCOME_STATEMENT",
        "statement_of_income": "INCOME_STATEMENT",
        "statement_of_comprehensive_income": "INCOME_STATEMENT",
        "cash_flow": "CASH_FLOW_STATEMENT",
        "cash_flow_statement": "CASH_FLOW_STATEMENT",
    }

    return aliases.get(normalized, normalized.upper())


def read_dataset(name: str) -> pd.DataFrame:
    try:
        frame = dataiku.Dataset(name).get_dataframe(
            infer_with_pandas=False
        )
    except TypeError:
        frame = dataiku.Dataset(name).get_dataframe()

    if frame.empty:
        return frame

    frame = frame.copy()

    # Normalize column names so recipes with different casing remain usable.
    frame.columns = [
        str(column).strip().lower()
        for column in frame.columns
    ]

    if "statement_type" in frame.columns:
        frame["statement_type"] = frame["statement_type"].map(
            canonical_statement
        )

    if "field_label" not in frame.columns:
        if "canonical_label" in frame.columns:
            frame["field_label"] = frame["canonical_label"]
        elif "concept_label" in frame.columns:
            frame["field_label"] = frame["concept_label"]
        elif "concept_key" in frame.columns:
            frame["field_label"] = frame["concept_key"]
        elif "line_item" in frame.columns:
            frame["field_label"] = frame["line_item"]
        else:
            frame["field_label"] = ""

    if "concept_key" not in frame.columns:
        frame["concept_key"] = (
            frame["field_label"]
            .fillna("")
            .astype(str)
            .str.lower()
            .str.replace(r"[^a-z0-9]+", "_", regex=True)
            .str.strip("_")
        )

    defaults = {
        "current_period": "",
        "prior_period": "",
        "current_value": None,
        "prior_value": None,
        "resolution_method": "",
        "confidence": None,
    }

    for column, default in defaults.items():
        if column not in frame.columns:
            frame[column] = default

    return frame


def read_optional(name: str) -> pd.DataFrame:
    try:
        return read_dataset(name)
    except Exception as exc:
        print(f"Optional dataset unavailable: {name}: {exc}")
        return pd.DataFrame()


def clean_filename(value: Any) -> str:
    cleaned = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", text(value)).strip(" .")
    return cleaned[:180] or "unnamed"


def reports_folder_id() -> str:
    try:
        variables = dataiku.get_custom_variables()
    except Exception:
        variables = {}
    return (
        text(variables.get("fsre_financial_reports_folder_id"))
        or DEFAULT_REPORTS_FOLDER_ID
    )


def update_analysis_job(job_id: str, **values: Any) -> None:
    with ANALYSIS_JOB_LOCK:
        ANALYSIS_JOBS.setdefault(job_id, {}).update(values)
        while len(ANALYSIS_JOBS) > MAX_ANALYSIS_JOB_HISTORY:
            oldest_job_id = next(iter(ANALYSIS_JOBS))
            if oldest_job_id == job_id and len(ANALYSIS_JOBS) == 1:
                break
            ANALYSIS_JOBS.pop(oldest_job_id, None)


def recipe_name(item: Any) -> str:
    if isinstance(item, dict):
        return text(item.get("name") or item.get("id") or item.get("recipeName"))
    return text(getattr(item, "name", item))


def dataiku_error_detail(exc: Exception) -> str:
    details = []
    for attribute in ("get_detailed_message", "get_message"):
        method = getattr(exc, attribute, None)
        if callable(method):
            try:
                value = text(method())
                if value and value not in details:
                    details.append(value)
            except Exception:
                pass
    for attribute in ("detailed_message", "message"):
        value = text(getattr(exc, attribute, ""))
        if value and value not in details:
            details.append(value)
    fallback = text(exc)
    if fallback and fallback not in details:
        details.append(fallback)
    return " | ".join(details) or type(exc).__name__


def analysis_pipeline_worker(job_id: str) -> None:
    try:
        client = dataiku.api_client()
        project = client.get_default_project()
        available = {recipe_name(item) for item in project.list_recipes()}
        missing_recipes = [name for name in ANALYSIS_RECIPES if name not in available]
        if missing_recipes:
            raise RuntimeError("Missing Dataiku recipes: " + ", ".join(missing_recipes))

        total = len(ANALYSIS_RECIPES)
        for index, name in enumerate(ANALYSIS_RECIPES, start=1):
            stage_name = ANALYSIS_STAGE_NAMES[name]
            update_analysis_job(
                job_id,
                status="RUNNING",
                current_step=index,
                total_steps=total,
                current_recipe=name,
                stage_name=stage_name,
                message=f"Step {index}/{total}: {stage_name}",
            )
            try:
                project.get_recipe(name).run()
            except Exception as exc:
                detail = dataiku_error_detail(exc)
                update_analysis_job(
                    job_id,
                    status="FAILED",
                    failed_step=index,
                    failed_recipe=name,
                    stage_name=stage_name,
                    error_type=type(exc).__name__,
                    error_message=detail,
                    message=f"Step {index}/{total} failed - {stage_name} ({name}): {detail}",
                )
                return

        update_analysis_job(
            job_id,
            status="RUNNING",
            current_step=total,
            total_steps=total,
            current_recipe="",
            stage_name="Persisting history",
            message="Saving completed run details to PostgreSQL analysis history.",
        )
        capture_completed_analysis_runs()

        # Persist the complete page text while the upload is still present in
        # the managed folder.  Later recipe runs may replace that folder, but
        # historical statement resolution must remain available from DB.
        persisted_pages = 0
        persisted_statement_digests = 0
        evidence_persistence_warning = ""
        try:
            with ANALYSIS_JOB_LOCK:
                uploaded_names = {Path(text(item.get("file_name"))).name.casefold()
                                  for item in (ANALYSIS_JOBS.get(job_id, {}).get("files") or [])
                                  if text(item.get("file_name"))}
            registrations = registration_lookup()
            resolved_frame, _ = resolved_values()
            run_by_document = {}
            if not resolved_frame.empty:
                for resolved_row in resolved_frame.to_dict(orient="records"):
                    resolved_document_id = text(resolved_row.get("source_document_id"))
                    resolved_run_id = text(resolved_row.get("assessment_run_id") or resolved_row.get("run_id"))
                    if resolved_document_id and resolved_run_id:
                        run_by_document[resolved_document_id] = resolved_run_id
            for resolved_document_id, metadata in registrations.items():
                if Path(text(metadata.get("file_name"))).name.casefold() not in uploaded_names:
                    continue
                resolved_run_id = run_by_document.get(resolved_document_id, "")
                persisted_pages += len(hydrate_report_evidence(resolved_document_id, resolved_run_id))
                persisted_statement_digests += len(report_statement_evidence_digest(
                    resolved_document_id, resolved_run_id,
                ))
        except Exception as evidence_error:
            evidence_persistence_warning = f"{type(evidence_error).__name__}: {evidence_error}"
            print(f"REPORT EVIDENCE PERSISTENCE WARNING: {evidence_persistence_warning}", flush=True)

        # The recipe chain is deliberately completed before AI-assisted repair.
        # At this point the selected PDFs, validated tables and durable evidence
        # all exist, so the resolver cannot accidentally inspect a previous
        # upload or run against a half-built statement. Resolve each document
        # once, persist approved overrides, and rebuild its forensic result.
        resolution_results = []
        resolution_warning = ""
        try:
            with ANALYSIS_JOB_LOCK:
                uploaded_files = list(ANALYSIS_JOBS.get(job_id, {}).get("files") or [])
            for file_number, uploaded_file in enumerate(uploaded_files, start=1):
                file_name = Path(text(uploaded_file.get("file_name"))).name
                context = newest_context_for_file(file_name)
                run_id = text(context.get("assessment_run_id"))
                document_id = text(context.get("source_document_id"))
                if not run_id or not document_id:
                    resolution_results.append({
                        "file_name": file_name,
                        "status": "CONTEXT_NOT_FOUND",
                        "saved_count": 0,
                        "unresolved_count": 0,
                    })
                    continue
                update_analysis_job(
                    job_id,
                    status="RUNNING",
                    current_step=total,
                    total_steps=total,
                    current_recipe="",
                    stage_name="Validating financial statements",
                    message=(f"Steps {total}/{total} completed. Python-validating Income Statement, "
                             f"Balance Sheet and Cash Flow for {file_name} "
                             f"({file_number}/{len(uploaded_files)}), then resolving only remaining cells."),
                    active_assessment_run_id=run_id,
                    active_source_document_id=document_id,
                )
                full_validation = invoke_full_statement_validation(run_id, document_id)
                resolution = full_validation.get("validation") or full_validation
                # Full validation already persists scores from the refreshed
                # override layer; retain a fallback for legacy response shapes.
                score = full_validation.get("score") or invoke_forensic_result_persistence(run_id, document_id)
                resolution_results.append({
                    "file_name": file_name,
                    "assessment_run_id": run_id,
                    "source_document_id": document_id,
                    "status": text(full_validation.get("status") or resolution.get("status") or "COMPLETED"),
                    "saved_count": integer(resolution.get("saved_count"), 0),
                    "replaced_count": integer(resolution.get("replaced_count"), 0),
                    "validated_skip_count": integer(resolution.get("validated_skip_count"), 0),
                    "unresolved_count": integer(
                        resolution.get("unresolved_count"),
                        len(resolution.get("unresolved") or resolution.get("deferred") or []),
                    ),
                    "model_calls": integer(resolution.get("model_calls"), 0),
                    "risk_index": (score.get("risk_summary") or {}).get("index"),
                })
        except Exception as resolution_error:
            # Extraction remains valid if the external provider is unavailable.
            # Preserve the report and expose a retryable warning instead of
            # turning a successfully completed 12-step pipeline into a failure.
            resolution_warning = f"{type(resolution_error).__name__}: {resolution_error}"
            print(f"POST-PIPELINE MISSING-VALUE RESOLUTION WARNING: {resolution_warning}", flush=True)

        total_resolved = sum(integer(item.get("saved_count"), 0) for item in resolution_results)
        total_corrected = sum(integer(item.get("replaced_count"), 0) for item in resolution_results)
        total_prevalidated = sum(integer(item.get("validated_skip_count"), 0) for item in resolution_results)
        total_unresolved = sum(integer(item.get("unresolved_count"), 0) for item in resolution_results)
        completion_message = (
            f"Analysis pipeline completed successfully; {persisted_pages} report-evidence pages saved; "
            f"{total_resolved} financial values saved; {total_corrected} populated values corrected; "
            f"{total_prevalidated} unchanged values reused from validation cache"
        )
        if total_unresolved:
            completion_message += f"; {total_unresolved} values still require review"
        if resolution_warning:
            completion_message += "; automatic resolution could not finish and may be retried"
        completion_message += "."

        update_analysis_job(
            job_id,
            status="SUCCESS",
            current_step=total,
            total_steps=total,
            current_recipe="",
            stage_name="Complete",
            message=completion_message,
            persisted_evidence_pages=persisted_pages,
            persisted_statement_digests=persisted_statement_digests,
            evidence_persistence_warning=evidence_persistence_warning,
            automatic_resolution_results=resolution_results,
            automatic_resolution_saved_count=total_resolved,
            automatic_resolution_unresolved_count=total_unresolved,
            automatic_resolution_warning=resolution_warning,
        )
    except Exception as exc:
        detail = dataiku_error_detail(exc)
        update_analysis_job(
            job_id,
            status="FAILED",
            message=f"Pipeline setup failed: {type(exc).__name__}: {detail}",
            error_type=type(exc).__name__,
            error_message=detail,
        )
    finally:
        if ANALYSIS_PIPELINE_LOCK.locked():
            ANALYSIS_PIPELINE_LOCK.release()


@app.route("/api/upload-financial-reports", methods=["POST"])
def upload_financial_reports():
    """Replace the analysis input set and start one upload-scoped pipeline run.

    The registration recipe reads the complete managed input folder.  Leaving a
    previous upload in that folder therefore silently adds it to a new run.
    Treat the selected files as the complete input set: clear the folder only
    after every requested upload has passed validation, then write this set and
    start the pipeline while the pipeline lock is held.
    """
    uploads = request.files.getlist("files")
    if not uploads:
        return jsonify({"error": "At least one PDF file is required."}), 400

    prepared = []
    seen_names = set()
    for upload in uploads:
        original_name = text(upload.filename)
        filename = clean_filename(Path(original_name).name)
        if not filename.lower().endswith(".pdf"):
            return jsonify({"error": f"Only PDF files are accepted: {original_name}"}), 400
        content = upload.read()
        if not content.startswith(b"%PDF"):
            return jsonify({"error": f"The uploaded file is not a valid PDF: {original_name}"}), 400
        normalized_name = filename.casefold()
        if normalized_name in seen_names:
            return jsonify({"error": f"Duplicate filename in this upload: {filename}"}), 400
        seen_names.add(normalized_name)
        prepared.append((filename, content))

    if not ANALYSIS_PIPELINE_LOCK.acquire(blocking=False):
        return jsonify({
            "error": "Another financial-report analysis is already running. Try again after it completes."
        }), 409

    try:
        folder_id = reports_folder_id()
        folder = dataiku.Folder(folder_id)
        # The FRI_00_DETECT_AND_REGISTER_UPLOAD recipe enumerates this folder.
        # Delete every prior input so this run cannot pick up an older report
        # with a different name.  The pipeline lock prevents another upload
        # from observing the short replacement window.
        previous_paths = [
            text(path)
            for path in folder.list_paths_in_partition()
            if text(path) and text(path) != "/"
        ]
        for previous_path in previous_paths:
            folder.delete_path(previous_path)

        results = []
        for filename, content in prepared:
            with folder.get_writer(filename) as destination:
                destination.write(content)
            results.append({
                "file_name": filename,
                "folder_path": filename,
                "size_bytes": len(content),
                "replaced": False,
            })
    except Exception as exc:
        ANALYSIS_PIPELINE_LOCK.release()
        return jsonify({"error": f"{type(exc).__name__}: {exc}"}), 500

    job_id = str(uuid.uuid4())
    update_analysis_job(
        job_id,
        status="QUEUED",
        message="Reports uploaded; waiting for the analysis pipeline.",
        files=results,
        current_step=0,
        total_steps=len(ANALYSIS_RECIPES),
        current_recipe="",
        stage_name="Waiting",
        pipeline_name=ANALYSIS_PIPELINE_NAME,
    )
    try:
        threading.Thread(target=analysis_pipeline_worker, args=(job_id,), daemon=True).start()
    except Exception:
        ANALYSIS_PIPELINE_LOCK.release()
        raise

    return jsonify({
        "status": "PROCESSING",
        "folder_id": folder_id,
        "uploaded_count": len(results),
        "replaced_previous_upload_count": len(previous_paths),
        "files": results,
        "job_id": job_id,
    }), 202


@app.route("/api/upload-financial-reports", methods=["DELETE"])
def clear_uploaded_financial_reports():
    """Clear the managed input set before the user starts a new analysis."""
    if not ANALYSIS_PIPELINE_LOCK.acquire(blocking=False):
        return jsonify({
            "error": "An analysis is running. Wait for it to finish before clearing uploaded reports."
        }), 409

    try:
        folder = dataiku.Folder(reports_folder_id())
        paths = [
            text(path)
            for path in folder.list_paths_in_partition()
            if text(path) and text(path) != "/"
        ]
        for path in paths:
            folder.delete_path(path)
        return jsonify({
            "status": "CLEARED",
            "cleared_report_count": len(paths),
        })
    except Exception as exc:
        return jsonify({"error": f"{type(exc).__name__}: {exc}"}), 500
    finally:
        ANALYSIS_PIPELINE_LOCK.release()


@app.route("/api/analysis-jobs/<job_id>", methods=["GET"])
def analysis_job_status(job_id: str):
    with ANALYSIS_JOB_LOCK:
        job = ANALYSIS_JOBS.get(job_id)
        if not job:
            return jsonify({"error": "Analysis job was not found."}), 404
        return jsonify({"job_id": job_id, **dict(job)})


def update_sgx_state(**values: Any) -> None:
    with SGX_SYNC_LOCK:
        SGX_SYNC_STATE.update(values)


def sgx_sync_worker(job_id: str, maximum_override: int = 0, announcement_offset: int = 0) -> None:
    temporary_root = Path(tempfile.mkdtemp(prefix="fri_sgx_"))
    try:
        try:
            from playwright.sync_api import sync_playwright
        except ImportError as exc:
            raise RuntimeError(
                "Playwright is not installed in the webapp code environment. "
                "Install playwright and its Chromium browser in fsre_py39."
            ) from exc

        maximum = maximum_override or 500
        try:
            maximum = maximum_override or int(dataiku.get_custom_variables().get("fsre_sgx_max_announcements", 500))
        except Exception:
            pass
        session = requests.Session()
        session.headers.update({"User-Agent": "Mozilla/5.0 (compatible; FSRE-SGX-Sync/1.0)"})
        proxy_url = text(dataiku.get_custom_variables().get("fsre_sgx_proxy_url")).strip()
        if proxy_url:
            session.proxies.update({"http": proxy_url, "https": proxy_url})
        downloaded: List[Dict[str, str]] = []

        with sync_playwright() as playwright:
            launch_options: Dict[str, Any] = {"headless": True}
            if proxy_url:
                launch_options["proxy"] = {"server": proxy_url}
            browser = playwright.chromium.launch(**launch_options)
            page = browser.new_page(viewport={"width": 1600, "height": 1200})
            update_sgx_state(status="DISCOVERING", message="Loading SGX annual-report announcements…")
            page.goto(SGX_START_URL, wait_until="domcontentloaded", timeout=120000)
            try:
                page.locator('button:has-text("Accept Cookies")').click(timeout=3000)
            except Exception:
                pass
            try:
                page.wait_for_selector('a[href*="/corporate-announcements/"]', timeout=90000)
            except Exception as exc:
                title = text(page.title())
                body_preview = text(page.locator("body").inner_text())[:300]
                if "access denied" in f"{title} {body_preview}".lower():
                    raise RuntimeError(
                        "SGX BLOCKED THE DATAIKU SERVER'S OUTBOUND IP. ALLOW HTTPS/443 ACCESS "
                        "TO www.sgx.com, api.sgx.com, api2.sgx.com AND links.sgx.com, OR SET "
                        "THE DATAIKU CUSTOM VARIABLE fsre_sgx_proxy_url TO AN "
                        "ORGANISATION-APPROVED EGRESS PROXY. NO EXISTING "
                        "REPORTS WERE CHANGED."
                    ) from exc
                raise RuntimeError(f"SGX ANNUAL-REPORT TABLE DID NOT LOAD. PAGE={title}; PREVIEW={body_preview}") from exc
            previous_height = 0
            for _ in range(30):
                page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
                page.wait_for_timeout(1200)
                height = page.evaluate("document.body.scrollHeight")
                if height == previous_height:
                    break
                previous_height = height
            announcement_urls = []
            links = page.locator('a[href*="/corporate-announcements/"]')
            for index in range(links.count()):
                link = links.nth(index)
                report_type = re.sub(r"\s+", " ", text(link.inner_text())).strip().lower()
                href = link.get_attribute("href")
                # Strictly exclude interim, quarterly, summary, sustainability,
                # information and disclosure statements.  The SGX table's
                # report-type link is the authoritative classification.
                if href and report_type == "annual report":
                    absolute = urljoin("https://links.sgx.com", href)
                    if absolute not in announcement_urls:
                        announcement_urls.append(absolute)
            announcement_urls = announcement_urls[announcement_offset:announcement_offset + maximum]
            if not announcement_urls:
                raise RuntimeError("SGX RETURNED NO ANNUAL REPORT ROWS FOR THIS BATCH OFFSET; NON-ANNUAL REPORT TYPES WERE EXCLUDED.")
            update_sgx_state(announcements=len(announcement_urls), status="DOWNLOADING", message="Downloading and validating annual-report PDF attachments only…")

            for announcement_number, announcement_url in enumerate(announcement_urls, 1):
                page.goto(announcement_url, wait_until="domcontentloaded", timeout=60000)
                page.wait_for_timeout(900)
                body = page.locator("body").inner_text()
                match = re.search(r"Issuer/ Manager\s*\n([^\n]+)", body)
                company = clean_filename(match.group(1) if match else "unknown_company")
                pdf_links = page.locator('a[href*="FileOpen"], a[href$=".pdf"], a[href*=".pdf?"]')
                candidates = []
                for attachment_number in range(pdf_links.count()):
                    link = pdf_links.nth(attachment_number)
                    href = link.get_attribute("href")
                    label = re.sub(r"\s+", " ", text(link.inner_text())).strip()
                    if href:
                        candidates.append({"href": href, "label": label})
                annual_candidates = [item for item in candidates
                                     if "annual" in item["label"].lower() and "report" in item["label"].lower()]
                selected_attachment = annual_candidates[0] if annual_candidates else candidates[0] if len(candidates) == 1 else None
                if not selected_attachment:
                    update_sgx_state(message=f"Skipped {company}: no unambiguous annual-report PDF attachment.")
                    continue
                url = urljoin("https://links.sgx.com", selected_attachment["href"])
                filename = clean_filename(selected_attachment["label"] or f"{company}_Annual_Report.pdf")
                if not filename.lower().endswith(".pdf"):
                    filename += ".pdf"
                response = session.get(url, timeout=90)
                response.raise_for_status()
                content_type = text(response.headers.get("content-type")).lower()
                if not response.content.startswith(b"%PDF-"):
                    raise RuntimeError(f"ANNUAL REPORT ATTACHMENT IS NOT A VALID PDF: {url}; CONTENT-TYPE={content_type}")
                relative_path = f"{company}/{filename}"
                local_path = temporary_root / company / filename
                local_path.parent.mkdir(parents=True, exist_ok=True)
                local_path.write_bytes(response.content)
                downloaded.append({"relative_path": relative_path, "local_path": str(local_path)})
                update_sgx_state(downloaded=len(downloaded), message=f"Processed announcement {announcement_number}/{len(announcement_urls)}; {len(downloaded)} PDFs staged.")
                if maximum_override and len(downloaded) >= maximum_override:
                    break
            browser.close()

        if not downloaded:
            raise RuntimeError("No valid PDFs were downloaded; existing reports were not changed.")

        update_sgx_state(status="REPLACING", message=f"All {len(downloaded)} PDFs validated. Replacing managed-folder contents…")
        folder = dataiku.Folder(reports_folder_id())
        for existing_path in folder.list_paths_in_partition():
            if existing_path and existing_path != "/":
                folder.delete_path(existing_path)
        for item in downloaded:
            with open(item["local_path"], "rb") as source:
                with folder.get_writer(item["relative_path"]) as destination:
                    shutil.copyfileobj(source, destination, length=1024 * 1024)
        update_sgx_state(status="SUCCESS", downloaded=len(downloaded), message=f"SGX sync complete. Replaced the folder with {len(downloaded)} validated PDFs.")
    except Exception as exc:
        update_sgx_state(status="FAILED", message=f"{type(exc).__name__}: {exc}")
    finally:
        shutil.rmtree(temporary_root, ignore_errors=True)


@app.route("/api/sgx-sync", methods=["POST"])
def start_sgx_sync():
    with SGX_SYNC_LOCK:
        if SGX_SYNC_STATE.get("status") in {"DISCOVERING", "DOWNLOADING", "REPLACING"}:
            return jsonify(dict(SGX_SYNC_STATE)), 409
        job_id = str(uuid.uuid4())
        SGX_SYNC_STATE.update({"status": "STARTING", "message": "Starting SGX sync…", "downloaded": 0, "announcements": 0, "job_id": job_id})
    threading.Thread(target=sgx_sync_worker, args=(job_id,), daemon=True).start()
    return jsonify(dict(SGX_SYNC_STATE)), 202


@app.route("/api/sgx-sync", methods=["GET"])
def sgx_sync_status():
    with SGX_SYNC_LOCK:
        return jsonify(dict(SGX_SYNC_STATE))


def update_batch_automation_state(**values: Any) -> None:
    with BATCH_AUTOMATION_LOCK:
        BATCH_AUTOMATION_STATE.update(values)


def batch_cancel_requested() -> bool:
    with BATCH_AUTOMATION_LOCK:
        return bool(BATCH_AUTOMATION_STATE.get("cancel_requested"))


def newest_context_for_file(file_name: str) -> Dict[str, Any]:
    expected = Path(file_name).name.casefold()
    matches = [item for item in load_analysis_history_contexts()
               if Path(text(item.get("file_name"))).name.casefold() == expected]
    return matches[0] if matches else {}


def invoke_batch_missing_value_resolution(run_id: str, document_id: str) -> Dict[str, Any]:
    body = {"assessment_run_id": run_id, "source_document_id": document_id,
            "maximum_targets": 60}
    with app.test_request_context("/api/financial-fact-resolution/batch-preview", method="POST", json=body):
        outcome = batch_financial_fact_resolution_preview()
        response, status_code = (outcome[0], outcome[1]) if isinstance(outcome, tuple) else (outcome, 200)
        payload = response.get_json() if hasattr(response, "get_json") else {}
        if status_code >= 400:
            raise RuntimeError(text(payload.get("error")) or f"MISSING VALUE RESOLUTION FAILED ({status_code})")
        return payload


def invoke_full_statement_validation(run_id: str, document_id: str) -> Dict[str, Any]:
    """Run the governed Python-first repair path before publishing an upload.

    This intentionally uses the same source-validation -> compact missing-value
    batch -> residual propose/approve workflow as the explicit Resolve Missing
    Values action.  The former ``llm_validate_all`` upload mode split the report
    into three broad provider calls and bypassed the proven per-cell fallback,
    leaving otherwise resolvable blanks behind.
    """
    body = {
        "assessment_run_id": run_id,
        "source_document_id": document_id,
        "llm_validate_all": False,
        "target_concepts": VALIDATED_RUN_CONCEPTS,
    }
    with app.test_request_context("/api/run-analysis-validated", method="POST", json=body):
        outcome = run_analysis_validated()
        response, status_code = ((outcome[0], outcome[1])
                                 if isinstance(outcome, tuple) else (outcome, 200))
        payload = response.get_json() if hasattr(response, "get_json") else {}
        if status_code >= 400:
            raise RuntimeError(text(payload.get("error")) or
                               f"FULL STATEMENT VALIDATION FAILED ({status_code})")
        if status_code == 202:
            raise RuntimeError(text(payload.get("message")) or
                               "FULL STATEMENT VALIDATION IS ALREADY RUNNING")
        return payload


def invoke_forensic_result_persistence(run_id: str, document_id: str) -> Dict[str, Any]:
    query = f"/api/forensic-scores?assessment_run_id={run_id}&source_document_id={document_id}"
    with app.test_request_context(query, method="GET"):
        outcome = forensic_scores()
        response, status_code = (outcome[0], outcome[1]) if isinstance(outcome, tuple) else (outcome, 200)
        payload = response.get_json() if hasattr(response, "get_json") else {}
        if status_code >= 400:
            raise RuntimeError(text(payload.get("error")) or f"FORENSIC SCORING FAILED ({status_code})")
        return payload


def automated_folder_batch_worker(job_id: str, batch_size: int, announcement_offset: int,
                                  manual_staging_path: str = "") -> None:
    staging_root = Path(manual_staging_path) if manual_staging_path else Path(tempfile.mkdtemp(prefix="fri_batch_source_"))
    acquired = False
    results: List[Dict[str, Any]] = []
    try:
        folder = dataiku.Folder(reports_folder_id())
        staged = []
        if manual_staging_path:
            update_batch_automation_state(status="WAITING", message=f"VALIDATING {batch_size} MANUALLY UPLOADED REPORTS.")
            candidates = sorted(path for path in staging_root.iterdir() if path.is_file())[:batch_size]
            for target in candidates:
                with target.open("rb") as verification_stream:
                    header = verification_stream.read(5)
                if header != b"%PDF-":
                    results.append({"file_name": target.name, "status": "FAILED", "message": "INVALID PDF HEADER"})
                    continue
                staged.append((target.name, target))
        else:
            update_batch_automation_state(status="DOWNLOADING", message=f"DOWNLOADING UP TO {batch_size} VALIDATED FINANCIAL REPORTS.")
            sgx_sync_worker(job_id + "-download", maximum_override=batch_size, announcement_offset=announcement_offset)
            with SGX_SYNC_LOCK:
                sync_state = dict(SGX_SYNC_STATE)
            if sync_state.get("status") != "SUCCESS":
                raise RuntimeError(text(sync_state.get("message")) or "REPORT DOWNLOAD FAILED")
            source_paths = [text(path) for path in folder.list_paths_in_partition()
                            if text(path) and text(path) != "/"][:batch_size]
            if not source_paths:
                raise RuntimeError("NO VALIDATED REPORTS WERE DOWNLOADED")
            for index, source_path in enumerate(source_paths, 1):
                target = staging_root / f"{index:03d}_{clean_filename(Path(source_path).name)}"
                with folder.get_download_stream(source_path) as source, target.open("wb") as destination:
                    shutil.copyfileobj(source, destination, length=1024 * 1024)
                with target.open("rb") as verification_stream:
                    header = verification_stream.read(5)
                if header != b"%PDF-":
                    results.append({"file_name": Path(source_path).name, "status": "FAILED", "message": "INVALID PDF HEADER"})
                    continue
                staged.append((Path(source_path).name, target))
        if not staged:
            raise RuntimeError("NO VALID PDF REPORTS WERE AVAILABLE FOR THIS BATCH")
        update_batch_automation_state(downloaded=len(staged), total=len(staged), results=list(results),
                                      status="WAITING", message="REPORT DOWNLOAD COMPLETE. WAITING FOR THE ANALYSIS PIPELINE.")

        acquired = ANALYSIS_PIPELINE_LOCK.acquire(timeout=30)
        if not acquired:
            raise RuntimeError("ANOTHER FINANCIAL REPORT ANALYSIS IS RUNNING")
        client = dataiku.api_client()
        project = client.get_default_project()
        available = {recipe_name(item) for item in project.list_recipes()}
        missing_recipes = [name for name in ANALYSIS_RECIPES if name not in available]
        if missing_recipes:
            raise RuntimeError("MISSING DATAIKU RECIPES: " + ", ".join(missing_recipes))

        for report_number, (file_name, local_path) in enumerate(staged, 1):
            if batch_cancel_requested():
                update_batch_automation_state(status="CANCELLED", message="BATCH STOPPED AFTER THE CURRENT REPORT.")
                break
            update_batch_automation_state(status="ANALYZING", current_file=file_name,
                                          message=f"ANALYZING REPORT {report_number}/{len(staged)}: {file_name}")
            try:
                for existing_path in folder.list_paths_in_partition():
                    if existing_path and existing_path != "/":
                        folder.delete_path(existing_path)
                with local_path.open("rb") as source, folder.get_writer(clean_filename(file_name)) as destination:
                    shutil.copyfileobj(source, destination, length=1024 * 1024)
                for recipe_number, recipe in enumerate(ANALYSIS_RECIPES, 1):
                    update_batch_automation_state(
                        message=f"REPORT {report_number}/{len(staged)} · STEP {recipe_number}/{len(ANALYSIS_RECIPES)} · {ANALYSIS_STAGE_NAMES[recipe]}")
                    project.get_recipe(recipe).run()
                capture_completed_analysis_runs()
                context = newest_context_for_file(file_name)
                if not context:
                    raise RuntimeError("COMPLETED PIPELINE DID NOT PRODUCE A RUN CONTEXT")
                run_id, document_id = context["assessment_run_id"], context["source_document_id"]
                update_batch_automation_state(
                    status="RESOLVING",
                    message=(f"VALIDATING INCOME STATEMENT, BALANCE SHEET AND CASH FLOW "
                             f"FOR {file_name} BEFORE PUBLISHING THE REPORT"),
                )
                # Historical and automated uploads use the same database-first
                # evidence path as the interactive upload and Risk Analysis.
                hydrate_report_evidence(document_id, run_id)
                report_statement_evidence_digest(document_id, run_id)
                full_validation = invoke_full_statement_validation(run_id, document_id)
                resolution = full_validation.get("validation") or full_validation
                score = full_validation.get("score") or invoke_forensic_result_persistence(run_id, document_id)
                results.append({"file_name": file_name, "status": "SUCCESS",
                                "assessment_run_id": run_id, "source_document_id": document_id,
                                "resolved_values": integer(resolution.get("saved_count"), 0),
                                "corrected_values": integer(resolution.get("replaced_count"), 0),
                                "review_values": integer(resolution.get("unresolved_count"), 0),
                                "risk_index": (score.get("risk_summary") or {}).get("index")})
            except Exception as report_error:
                results.append({"file_name": file_name, "status": "FAILED",
                                "message": f"{type(report_error).__name__}: {report_error}"})
            completed = sum(1 for item in results if item.get("status") == "SUCCESS")
            failed = sum(1 for item in results if item.get("status") == "FAILED")
            update_batch_automation_state(completed=completed, failed=failed, results=list(results))
        if not batch_cancel_requested():
            update_batch_automation_state(status="SUCCESS", current_file="", results=list(results),
                                          next_offset=(announcement_offset if manual_staging_path else announcement_offset + batch_size),
                                          message=f"BATCH COMPLETE: {sum(1 for x in results if x.get('status') == 'SUCCESS')} SUCCEEDED, {sum(1 for x in results if x.get('status') == 'FAILED')} FAILED.")
    except Exception as exc:
        update_batch_automation_state(status="FAILED", message=f"{type(exc).__name__}: {exc}", results=list(results))
    finally:
        if acquired:
            ANALYSIS_PIPELINE_LOCK.release()
        shutil.rmtree(staging_root, ignore_errors=True)


@app.route("/api/automated-folder-batch", methods=["POST"])
def start_automated_folder_batch():
    payload = request.get_json(silent=True) or {}
    batch_size = max(1, min(100, integer(payload.get("batch_size"), 100)))
    with BATCH_AUTOMATION_LOCK:
        if BATCH_AUTOMATION_STATE.get("status") in {"DOWNLOADING", "WAITING", "ANALYZING", "RESOLVING"}:
            return jsonify(dict(BATCH_AUTOMATION_STATE)), 409
        job_id = str(uuid.uuid4())
        announcement_offset = 0 if bool(payload.get("restart_from_first")) else integer(BATCH_AUTOMATION_STATE.get("next_offset"), 0)
        BATCH_AUTOMATION_STATE.update({"status": "STARTING", "message": "STARTING AUTOMATED REPORT BATCH.",
                                       "job_id": job_id, "batch_size": batch_size, "downloaded": 0,
                                       "total": 0, "completed": 0, "failed": 0, "current_file": "",
                                       "cancel_requested": False, "results": []})
    threading.Thread(target=automated_folder_batch_worker, args=(job_id, batch_size, announcement_offset), daemon=True).start()
    return jsonify(dict(BATCH_AUTOMATION_STATE)), 202


@app.route("/api/automated-folder-batch", methods=["GET"])
def automated_folder_batch_status():
    with BATCH_AUTOMATION_LOCK:
        return jsonify(dict(BATCH_AUTOMATION_STATE))


@app.route("/api/automated-folder-batch/manual-upload", methods=["POST"])
def start_manual_folder_batch():
    uploads = request.files.getlist("files")
    if not uploads:
        return jsonify({"error": "SELECT AT LEAST ONE PDF REPORT."}), 400
    if len(uploads) > 100:
        return jsonify({"error": "A MANUAL BATCH CAN CONTAIN A MAXIMUM OF 100 PDF REPORTS."}), 400
    with BATCH_AUTOMATION_LOCK:
        if BATCH_AUTOMATION_STATE.get("status") in {"DOWNLOADING", "WAITING", "ANALYZING", "RESOLVING"}:
            return jsonify(dict(BATCH_AUTOMATION_STATE)), 409
    staging_root = Path(tempfile.mkdtemp(prefix="fri_manual_batch_"))
    seen_names = set()
    try:
        for upload in uploads:
            original_name = text(upload.filename)
            filename = clean_filename(Path(original_name).name)
            if not filename.lower().endswith(".pdf"):
                raise ValueError(f"ONLY PDF FILES ARE ACCEPTED: {original_name}")
            if filename.casefold() in seen_names:
                raise ValueError(f"DUPLICATE FILENAME: {filename}")
            content = upload.read()
            if not content.startswith(b"%PDF-"):
                raise ValueError(f"INVALID PDF FILE: {original_name}")
            seen_names.add(filename.casefold())
            (staging_root / filename).write_bytes(content)
    except Exception as exc:
        shutil.rmtree(staging_root, ignore_errors=True)
        return jsonify({"error": text(exc)}), 400
    job_id = str(uuid.uuid4())
    with BATCH_AUTOMATION_LOCK:
        BATCH_AUTOMATION_STATE.update({"status": "STARTING", "message": "MANUAL PDF BATCH UPLOADED; STARTING ANALYSIS.",
                                       "job_id": job_id, "batch_size": len(uploads), "downloaded": len(uploads),
                                       "total": len(uploads), "completed": 0, "failed": 0, "current_file": "",
                                       "cancel_requested": False, "results": [], "source": "MANUAL UPLOAD"})
    threading.Thread(target=automated_folder_batch_worker,
                     args=(job_id, len(uploads), integer(BATCH_AUTOMATION_STATE.get("next_offset"), 0), str(staging_root)),
                     daemon=True).start()
    return jsonify(dict(BATCH_AUTOMATION_STATE)), 202


@app.route("/api/automated-folder-batch/stop", methods=["POST"])
def stop_automated_folder_batch():
    with BATCH_AUTOMATION_LOCK:
        if BATCH_AUTOMATION_STATE.get("status") not in {"DOWNLOADING", "WAITING", "ANALYZING", "RESOLVING"}:
            return jsonify(dict(BATCH_AUTOMATION_STATE)), 409
        BATCH_AUTOMATION_STATE["cancel_requested"] = True
        BATCH_AUTOMATION_STATE["message"] = "STOP REQUESTED. THE CURRENT REPORT WILL FINISH SAFELY."
        return jsonify(dict(BATCH_AUTOMATION_STATE)), 202


def validated_table_lookup(document_id: str) -> Dict[str, Any]:
    """Return the 03D validation gate for one source document."""
    frame = read_optional(TABLE_JSON_DATASET)
    if frame.empty:
        return {"available": False, "status": "NOT_AVAILABLE", "valid_table_ids": set(), "invalid_tables": []}
    if "source_document_id" in frame.columns:
        frame = frame[frame["source_document_id"].fillna("").astype(str).eq(document_id)]
    valid_ids = set()
    invalid = []
    for row in frame.to_dict(orient="records"):
        key = text(row.get("table_artifact_id"))
        status = text(row.get("validation_status")).upper()
        if status == "VALID" and key:
            valid_ids.add(key)
        else:
            invalid.append({
                "table_artifact_id": key,
                "statement_type": canonical_statement(row.get("statement_type")),
                "validation_status": status or "INVALID",
                "issue_count": integer(row.get("issue_count"), 0),
            })
    return {
        "available": True,
        "status": "VALID" if not invalid and bool(valid_ids) else "INVALID",
        "valid_table_ids": valid_ids,
        "invalid_tables": invalid,
        "table_count": int(len(frame)),
        "valid_table_count": int(len(valid_ids)),
    }


def raw_validated_tables(document_id: str) -> List[Dict[str, Any]]:
    """Return lossless 03D table documents without financial transformations."""
    frame = read_optional(TABLE_JSON_DATASET)
    if frame.empty or "table_json" not in frame.columns:
        return []
    if "source_document_id" in frame.columns:
        frame = frame[frame["source_document_id"].fillna("").astype(str).eq(document_id)]
    candidates = []
    for row in frame.to_dict(orient="records"):
        if text(row.get("validation_status")).upper() != "VALID":
            continue
        try:
            document = json.loads(text(row.get("table_json")))
        except (json.JSONDecodeError, TypeError):
            continue
        table = document.get("table") or {}
        source = document.get("source") or {}
        identity = document.get("identity") or {}
        candidate = {
            "table_artifact_id": text(identity.get("table_artifact_id") or row.get("table_artifact_id")),
            "statement_type": canonical_statement(table.get("statement_type") or row.get("statement_type")),
            "table_title": text(table.get("title")),
            "page_number": source.get("page_number"),
            "currency": text(table.get("currency")),
            "unit": text(table.get("unit")),
            "row_count": integer(table.get("row_count"), 0),
            "column_count": integer(table.get("column_count"), 0),
            "rows": table.get("rows") or [],
            "merged_cells": table.get("merged_cells") or [],
            "validation_status": "VALID",
        }
        candidates.append(candidate)

    def normalized(value: Any) -> str:
        return re.sub(r"[^a-z0-9]+", " ", text(value).lower()).strip()

    def evidence(table: Dict[str, Any]) -> Dict[str, Any]:
        row_labels = []
        all_text = []
        for row in table.get("rows") or []:
            cells = sorted(
                row.get("cells") or [],
                key=lambda cell: integer(cell.get("column_index"), 0),
            )
            texts = [text(cell.get("raw_text")) for cell in cells if text(cell.get("raw_text"))]
            if texts:
                row_labels.append(normalized(texts[0]))
                all_text.extend(texts)
        complete = normalized(" ".join([table.get("table_title", ""), *all_text]))
        return {"labels": set(row_labels), "text": complete}

    def recognition_score(table: Dict[str, Any], statement: str) -> int:
        source = evidence(table)
        labels, complete = source["labels"], source["text"]
        declared = canonical_statement(table.get("statement_type"))
        score = 900 if declared == statement else 0
        if statement == "BALANCE_SHEET":
            heading = bool(re.search(r"balance sheets?|statements? of financial (?:position|condition)", complete))
            dated = bool(re.search(r"as at (?:31 )?(?:december|march|june|september)", complete))
            anchors = sum(label in labels for label in {
                "total assets", "total liabilities", "net assets", "total equity",
            })
            score += (600 if heading else 0) + (250 if dated else 0) + anchors * 500
        elif statement == "INCOME_STATEMENT":
            heading = bool(re.search(r"income statements?|statements? of (?:comprehensive income|profit (?:or|and) loss|operations)", complete))
            dated = "year ended" in complete or "period ended" in complete
            anchors = sum(any(re.search(pattern, label) for label in labels) for pattern in [
                r"^revenue$", r"^cost of sales$", r"^gross profit$",
                r"^(?:profit|loss) before (?:income )?tax$",
                r"^(?:profit|loss) for the (?:year|period)(?: period)?$", r"^finance costs?$",
            ])
            score += (600 if heading else 0) + (250 if dated else 0) + anchors * 500
        elif statement == "CASH_FLOW_STATEMENT":
            heading = bool(re.search(r"cash flow statements?|statements? of cash flows?", complete))
            dated = "year ended" in complete or "period ended" in complete
            anchors = sum(any(phrase in label for label in labels) for phrase in {
                "operating activities", "investing activities", "financing activities",
            })
            score += (600 if heading else 0) + (250 if dated else 0) + anchors * 500
        if declared != statement and any(term in complete for term in (
            "guideline", "directors statement", "independent auditor report",
            "notes to the financial statements", "segment reporting",
        )):
            score -= 1200
        return score

    # Classify from table evidence rather than trusting page-level labels, then
    # return only one confidently recognized primary table per statement.
    selected = []
    minimum_score = 900
    for statement in sorted(PRIMARY_STATEMENTS):
        ranked = sorted(
            ((recognition_score(table, statement), table) for table in candidates),
            key=lambda item: item[0],
            reverse=True,
        )
        if not ranked or ranked[0][0] < minimum_score:
            continue
        qualifying = ranked if statement == "CASH_FLOW_STATEMENT" else ranked[:1]
        for score, table in qualifying:
            if score < minimum_score:
                continue
            table = dict(table)
            table["statement_type"] = statement
            table["recognition_score"] = score
            table["recognition_status"] = "PRIMARY_STATEMENT_CONFIRMED"
            selected.append(table)

    # Shares outstanding normally appears in the share-capital note rather
    # than a primary statement. Include the best validated supporting table so
    # the configured screen can resolve issued shares less treasury shares.
    supporting = sorted(
        (
            table for table in candidates
            if re.search(
                r"(?:number|no) of (?:issued|ordinary|treasury) shares|issued and fully paid shares|shares in issue",
                evidence(table)["text"],
            )
        ),
        key=lambda table: (integer(table.get("page_number"), 0), text(table.get("table_artifact_id"))),
    )
    if supporting:
        support = dict(supporting[0])
        support["recognition_status"] = "SUPPORTING_SHARE_NOTE"
        selected.append(support)

    # Depreciation is often disclosed only in the PP&E note rather than on
    # the face of the income statement. Include that validated note so the
    # governed UI fallback can skip its note-reference column and use the two
    # reported year amounts (for example Note 11: 2026 and 2025).
    depreciation_supporting = sorted(
        (
            table for table in candidates
            if re.search(
                r"(?:depreciation(?: of (?:property plant and equipment|right of use assets))?"
                r"|amorti[sz]ation of intangible assets)",
                evidence(table)["text"],
            )
        ),
        key=lambda table: (
            0 if re.search(r"statements? of cash flows?|cash flow statements?",
                           evidence(table)["text"]) else 1,
            0 if ("depreciation" in evidence(table)["text"]
                  and re.search(r"amorti[sz]ation", evidence(table)["text"])) else 1,
            integer(table.get("page_number"), 0),
            text(table.get("table_artifact_id")),
        ),
    )
    selected_ids = {text(table.get("table_artifact_id")) for table in selected}
    if depreciation_supporting:
        support = dict(depreciation_supporting[0])
        if text(support.get("table_artifact_id")) not in selected_ids:
            support["recognition_status"] = "SUPPORTING_DEPRECIATION_NOTE"
            selected.append(support)
    return selected


def disclosed_share_pair_from_validated_tables(document_id: str) -> Dict[str, Any]:
    """Read the closing issued-share pair from the stored validated table.

    This is the fast path used by Run analysis. It avoids reopening and
    extracting every PDF page and is resilient to merged headers where the row
    itself is labelled only "At end of the financial year/period".
    """
    candidates = []
    for table in raw_validated_tables(document_id):
        table_rows = table.get("rows") or []
        table_text = " ".join(
            text(cell.get("raw_text"))
            for row in table_rows for cell in (row.get("cells") or [])
        ).lower()
        if "share capital" not in table_text or not re.search(
                r"(?:no\.?|number) of ordinary shares|ordinary shares in issue", table_text):
            continue
        for row in table_rows:
            cells = sorted(row.get("cells") or [], key=lambda cell: integer(cell.get("column_index"), 0))
            label = " ".join(text(cell.get("raw_text")) for cell in cells if number(cell.get("raw_text")) is None)
            if not re.match(
                    r"^(?:at end of (?:the )?(?:financial )?(?:year|period)"
                    r"|(?:at|balance at)\s+\d{1,2}\s+[a-z]+(?:\s+20\d{2})?)\b",
                    label.lower().strip()):
                continue
            amounts = [number(cell.get("raw_text")) for cell in cells]
            amounts = [value for value in amounts if value is not None]
            if len(amounts) < 2:
                continue
            current_value, prior_value = amounts[0], amounts[1]
            if (len(amounts) >= 4 and abs(amounts[0]) >= 1000000
                    and abs(amounts[2]) >= 1000000):
                # Interleaved share-note layout: current count, current share
                # capital, prior count, prior share capital.
                current_value, prior_value = amounts[0], amounts[2]
            candidates.append({
                "current_value": current_value, "prior_value": prior_value,
                "page_number": integer(table.get("page_number"), 0),
                "source_line": " | ".join(text(cell.get("raw_text")) for cell in cells),
                "table_artifact_id": text(table.get("table_artifact_id")),
            })
    if candidates:
        issued = max(candidates, key=lambda item: max(abs(item["current_value"]), abs(item["prior_value"])))
        # A model field named shares_outstanding must exclude treasury shares.
        # Prefer a governed net-count candidate from the same selected report;
        # fall back to the disclosed issued count where no treasury count exists.
        try:
            evidence = managed_pdf_evidence_fallback(
                document_id, "BALANCE_SHEET", "shares_outstanding",
                "Shares outstanding", max_fragments=10,
            )
            parsed = build_resolution_candidate_table(
                evidence, "shares_outstanding", "Shares outstanding",
            )
            net = next((item for item in parsed
                        if text(item.get("derivation_method")) == "ISSUED_LESS_TREASURY_SHARES"), None)
            if net:
                return net
        except Exception as exc:
            print(f"Net outstanding-share reconciliation unavailable: {type(exc).__name__}: {exc}", flush=True)
        return {
            **issued,
            "description": "Issued ordinary shares before treasury-share adjustment",
            "derivation_method": "ISSUED_SHARES_PROXY",
        }

    # A share note can fail the conservative table-level validation gate while
    # its individual extracted cells remain sound. Read those persisted cells
    # directly, still scoped to this document and one table artifact.
    for dataset_name in (VALIDATED_TABLE_CELLS_DATASET, EXTRACTED_TABLE_CELLS_DATASET):
        cells = read_optional(dataset_name)
        if cells.empty or "source_document_id" not in cells.columns:
            continue
        cells = cells[cells["source_document_id"].fillna("").astype(str).eq(document_id)].copy()
        if cells.empty:
            continue
        table_key = "table_artifact_id" if "table_artifact_id" in cells.columns else "source_table_id"
        if table_key not in cells.columns:
            continue
        for table_id, table_cells in cells.groupby(table_key, dropna=False, sort=False):
            table_text = " ".join(
                text(value) for column in ("raw_text", "normalized_text", "row_label", "header_path")
                if column in table_cells.columns for value in table_cells[column].tolist()
            ).lower()
            if not re.search(r"(?:no\.?|number) of ordinary shares|ordinary shares in issue", table_text):
                continue
            if "share capital" not in table_text and "ordinary shares" not in table_text:
                continue
            if "row_index" not in table_cells.columns:
                continue
            for _, row_cells in table_cells.groupby("row_index", dropna=False, sort=False):
                row_label = next((text(value) for value in row_cells.get(
                    "row_label", pd.Series(dtype=str)).tolist() if text(value)), "")
                if not re.match(
                        r"^(?:at end of (?:the )?(?:financial )?(?:year|period)"
                        r"|(?:at|balance at)\s+\d{1,2}\s+[a-z]+(?:\s+20\d{2})?)\b",
                        row_label.lower()):
                    continue
                ordered = row_cells.sort_values("column_index", kind="stable") \
                    if "column_index" in row_cells.columns else row_cells
                numeric_cells = []
                for cell in ordered.to_dict(orient="records"):
                    value = number(cell.get("numeric_value"))
                    if value is None:
                        value = number(cell.get("raw_text"))
                    if value is not None:
                        numeric_cells.append((cell, value))
                # Prefer cells explicitly beneath the ordinary-share header.
                share_cells = [(cell, value) for cell, value in numeric_cells
                    if re.search(r"ordinary shares|no\.? of ordinary shares",
                                 text(cell.get("header_path")).lower())]
                chosen = share_cells if len(share_cells) >= 2 else numeric_cells
                if len(chosen) < 2:
                    continue
                result = {
                    "current_value": chosen[0][1], "prior_value": chosen[1][1],
                    "page_number": integer(chosen[0][0].get("page_number"), 0),
                    "source_line": row_label + " | " + " | ".join(
                        text(cell.get("raw_text")) for cell, _ in chosen
                    ),
                    "table_artifact_id": text(table_id),
                    "evidence_dataset": dataset_name,
                }
                if max(abs(result["current_value"]), abs(result["prior_value"])) > 1000000:
                    return {
                        **result,
                        "description": "Issued ordinary shares before treasury-share adjustment",
                        "derivation_method": "ISSUED_SHARES_PROXY",
                    }
    return {}


def period_year(value: Any):
    match = re.findall(r"\b(?:19|20)\d{2}\b", text(value))
    return int(match[-1]) if match else None


def normalize_resolved_shape(frame: pd.DataFrame) -> pd.DataFrame:
    """Pivot legacy row-per-period outputs into canonical current/prior rows."""
    if frame.empty or "numeric_value" not in frame.columns:
        return frame

    # A Note reference is an identifier, never a financial amount.  Some PDF
    # extractors incorrectly attach the adjacent year's period label to the
    # Note cell; reject it from metadata before the period pivot sees it.
    note_header_columns = [column for column in (
        "header_path", "column_header", "column_label", "column_name",
        "source_column", "value_header",
    ) if column in frame.columns]
    if note_header_columns:
        def is_explicit_note_cell(row: pd.Series) -> bool:
            headers = " ".join(text(row.get(column)) for column in note_header_columns)
            normalized = re.sub(r"[^a-z0-9]+", " ", headers.lower()).strip()
            value = number(row.get("numeric_value"))
            return bool(
                value is not None
                and abs(value - round(value)) < 0.000001
                and abs(value) <= 999
                and re.search(r"(?:^| )(?:note|notes|note no|ref|reference)(?: |$)", normalized)
                and not re.search(r"\b(?:19|20)\d{2}\b", normalized)
            )
        frame = frame.loc[~frame.apply(is_explicit_note_cell, axis=1)].copy()
        if frame.empty:
            return frame

    if (
        "current_value" in frame.columns
        and "prior_value" in frame.columns
        and frame[["current_value", "prior_value"]].notna().any().any()
    ):
        return frame

    identity = [column for column in [
        "tenant_id", "entity_id", "assessment_run_id", "source_document_id",
        "table_artifact_id", "statement_type", "concept_key", "field_label",
        "canonical_label", "currency", "unit",
    ] if column in frame.columns]
    if not identity:
        return frame

    output = []
    for _, group in frame.groupby(identity, dropna=False, sort=False):
        candidates = []
        for row in group.to_dict(orient="records"):
            value = number(row.get("numeric_value"))
            if value is None:
                continue
            candidates.append({
                "period": text(row.get("period_label") or row.get("period_end")),
                "year": period_year(row.get("period_label") or row.get("period_end")) or -1,
                "scope": text(row.get("scope") or row.get("entity_scope")).upper(),
                "value": value,
            })
        candidates.sort(key=lambda item: (
            -item["year"],
            0 if item["scope"] in {"GROUP", "REPORTED"} else 1,
        ))
        chosen = []
        seen = set()
        for item in candidates:
            if item["year"] not in seen:
                chosen.append(item)
                seen.add(item["year"])
            if len(chosen) == 2:
                break
        if not chosen:
            continue
        base = group.iloc[0].to_dict()
        base["current_period"] = chosen[0]["period"]
        base["prior_period"] = chosen[1]["period"] if len(chosen) > 1 else "Prior period"
        base["current_value"] = chosen[0]["value"]
        base["prior_value"] = chosen[1]["value"] if len(chosen) > 1 else None
        base["field_label"] = base.get("field_label") or base.get("canonical_label") or base.get("concept_key")
        base["resolution_method"] = base.get("resolution_method") or "LEGACY_PERIOD_PIVOT"
        output.append(base)

    return pd.DataFrame(output) if output else frame


def looks_like_note_identifier(value: Any, adjacent_amount: Any) -> bool:
    candidate, adjacent = number(value), number(adjacent_amount)
    return bool(
        candidate is not None and adjacent is not None
        and abs(candidate) <= 999
        and abs(candidate - round(candidate)) < 0.000001
        and abs(adjacent) >= 1000
        and abs(adjacent) >= max(100.0, abs(candidate) * 100.0)
    )


def isolate_note_shifted_value_pairs(frame: pd.DataFrame) -> pd.DataFrame:
    """Quarantine the common [Note, current, prior] -> [current, prior] shift.

    This runs on every resolved source, including database overrides.  It does
    not guess a comparative amount: the displaced disclosed amount is restored
    to current and the unavailable prior value is left missing for governed
    evidence resolution.  A genuine small amount is retained unless the pair
    has the extreme magnitude pattern characteristic of a Note identifier.
    """
    if frame.empty or not {"concept_key", "current_value", "prior_value"}.issubset(frame.columns):
        return frame
    result = frame.copy()
    non_monetary = {"shares_outstanding", "cet1_ratio", "capital_ratio"}
    for index, row in result.iterrows():
        concept_key = text(row.get("concept_key")).lower()
        current_value = number(row.get("current_value"))
        prior_value = number(row.get("prior_value"))
        if concept_key in non_monetary or current_value is None or prior_value is None:
            continue
        if not looks_like_note_identifier(current_value, prior_value):
            continue
        result.at[index, "current_value"] = prior_value
        result.at[index, "prior_value"] = None
        if "value_status" in result.columns:
            result.at[index, "value_status"] = "NOTE_COLUMN_QUARANTINED"
        if "resolution_method" in result.columns:
            result.at[index, "resolution_method"] = "NOTE_COLUMN_SHIFT_REPAIR"
        if "validation_message" in result.columns:
            result.at[index, "validation_message"] = (
                "Rejected a small integer Note reference; restored the adjacent "
                "reported amount and left the comparative period unresolved."
            )
    # A previously saved override may contain only [Note, zero], so the
    # displaced amount is no longer available on that row. Apply a narrow
    # accounting plausibility guard: revenue cannot be a tiny integer while
    # same-report COGS is several orders of magnitude larger. Quarantine it;
    # the selected-report candidate resolver will then restore the audited row.
    identity_columns = [column for column in (
        "assessment_run_id", "run_id", "source_document_id"
    ) if column in result.columns]
    groups = result.groupby(identity_columns, dropna=False, sort=False) if identity_columns else [(None, result)]
    for _, group in groups:
        revenue_rows = group[group["concept_key"].astype(str).eq("revenue")]
        cogs_rows = group[group["concept_key"].astype(str).eq("cost_of_goods_sold")]
        if revenue_rows.empty or cogs_rows.empty:
            continue
        for role in ("current", "prior"):
            value_column = role + "_value"
            if value_column not in result.columns:
                continue
            cogs_values = [abs(value) for value in cogs_rows[value_column].map(number) if value is not None]
            if not cogs_values:
                continue
            cogs_reference = max(cogs_values)
            for index in revenue_rows.index:
                revenue_value = number(result.at[index, value_column])
                if (revenue_value is None or revenue_value == 0
                        or not looks_like_note_identifier(revenue_value, cogs_reference)):
                    continue
                result.at[index, value_column] = None
                if "value_status" in result.columns:
                    result.at[index, "value_status"] = "NOTE_COLUMN_QUARANTINED"
                if "resolution_method" in result.columns:
                    result.at[index, "resolution_method"] = "CROSS_STATEMENT_NOTE_REJECTION"
    # Shares outstanding is a closing security count. Monetary share-capital
    # balances, percentages, EPS denominators with decimals and accumulated
    # losses are never valid substitutes for this field.
    share_rows = result[result["concept_key"].astype(str).eq("shares_outstanding")]
    for index in share_rows.index:
        for role in ("current", "prior"):
            value_column = role + "_value"
            if value_column not in result.columns:
                continue
            share_value = number(result.at[index, value_column])
            if share_value is None:
                continue
            if share_value < 0 or abs(share_value - round(share_value)) > 0.000001:
                result.at[index, value_column] = None
                if "value_status" in result.columns:
                    result.at[index, "value_status"] = "INVALID_SHARE_COUNT_QUARANTINED"
                if "resolution_method" in result.columns:
                    result.at[index, "resolution_method"] = "SHARE_COUNT_VALIDATION_REJECTION"
    return result


def standardized_table_values() -> pd.DataFrame:
    """Use validated row-per-cell table values directly in the webapp."""
    frame = read_optional(STANDARDIZED_VALUES_DATASET)
    if frame.empty:
        return frame
    # Legacy fallback only. When the database-backed alias dataset is present,
    # it is the sole mapping source below. This fallback keeps the app usable
    # during a temporary Dataiku dataset outage.
    aliases = {
        "revenue": "revenue", "net revenue": "revenue", "sales": "revenue",
        "net sales": "revenue", "turnover": "revenue", "gross revenue": "revenue",
        "operating revenue": "revenue",
        "gross rental income": "revenue", "rental income": "revenue",
        "property revenue": "revenue", "property income": "revenue",
        "revenue from contracts with customers": "revenue",
        "revenue from contract with customer": "revenue",
        "cost of goods sold": "cost_of_goods_sold", "cost of sales": "cost_of_goods_sold",
        "cost of revenue": "cost_of_goods_sold", "cost of inventories sold": "cost_of_goods_sold",
        "sg a expense": "sg_and_a_expense",
        "selling general and administrative expenses": "sg_and_a_expense",
        "general and administrative expenses": "sg_and_a_expense",
        "administrative expenses": "sg_and_a_expense", "distribution expenses": "sg_and_a_expense",
        "selling expenses": "sg_and_a_expense",
        "marketing and distribution expenses": "sg_and_a_expense",
        "depreciation and amortisation": "depreciation_amortization",
        "depreciation and amortization": "depreciation_amortization",
        "depreciation of property plant and equipment": "depreciation_amortization",
        "depreciation of right of use assets": "depreciation_amortization",
        "amortisation of intangible assets": "depreciation_amortization",
        "amortization of intangible assets": "depreciation_amortization",
        "operating profit": "operating_income_ebit", "operating income": "operating_income_ebit",
        "profit from operations": "operating_income_ebit", "income from operations": "operating_income_ebit",
        "results from operating activities": "operating_income_ebit",
        "ebit": "operating_income_ebit",
        "interest expense": "interest_expense", "interest expenses": "interest_expense",
        "finance cost": "interest_expense", "finance costs": "interest_expense",
        "finance expense": "interest_expense", "finance expenses": "interest_expense",
        "interest cost": "interest_expense",
        "net income": "net_profit", "net profit": "net_profit",
        "profit for the year": "net_profit", "profit for the financial year": "net_profit",
        "loss for the year": "net_profit", "loss for the financial year": "net_profit",
        "profit after tax": "net_profit", "loss after tax": "net_profit",
        "profit after taxation": "net_profit", "loss after taxation": "net_profit",
        "loss before income tax": "profit_before_tax",
        "profit before income tax": "profit_before_tax",
        "loss before tax": "profit_before_tax", "profit before tax": "profit_before_tax",
        "total current assets": "total_current_assets", "current assets": "total_current_assets",
        # A combined "trade and other receivables" row contains deposits,
        # taxes and miscellaneous balances and must not feed Beneish DSRI.
        # Resolve that broad label from the detailed receivables note instead.
        "trade receivables": "trade_receivables_net",
        "trade receivables net": "trade_receivables_net",
        "trade receivable": "trade_receivables_net", "accounts receivable": "trade_receivables_net",
        "accounts receivable net": "trade_receivables_net",
        "inventory": "inventory", "inventories": "inventory", "inventories net": "inventory",
        "property plant and equipment": "net_ppe", "property plant and equipment net": "net_ppe",
        "fixed assets": "net_ppe", "net fixed assets": "net_ppe", "net pp e": "net_ppe",
        "total assets": "total_assets", "total current liabilities": "total_current_liabilities",
        "current liabilities": "total_current_liabilities",
        "long term debt": "long_term_debt", "long term loans": "long_term_debt",
        "non current borrowings": "long_term_debt", "borrowings non current": "long_term_debt",
        "loans and borrowings": "long_term_debt",
        "total liabilities": "total_liabilities", "retained earnings": "retained_earnings",
        "retained profits": "retained_earnings", "accumulated profits": "retained_earnings",
        "accumulated losses": "retained_earnings", "accumulated deficit": "retained_earnings",
        "total shareholders equity": "total_shareholders_equity",
        "shareholders equity": "total_shareholders_equity", "shareholders funds": "total_shareholders_equity",
        "total equity": "total_shareholders_equity",
        "equity attributable to owners of the company": "total_shareholders_equity",
        "equity attributable to owners": "total_shareholders_equity",
        "shares outstanding": "shares_outstanding", "number of shares outstanding": "shares_outstanding",
        "issued shares": "shares_outstanding", "shares in issue": "shares_outstanding",
        "cash flow from operating activities": "operating_cash_flow",
        "cash flows from operating activities": "operating_cash_flow",
        "net cash from operating activities": "operating_cash_flow",
        "net cash generated from operating activities": "operating_cash_flow",
        "net cash provided by operating activities": "operating_cash_flow",
        "net cash used in operating activities": "operating_cash_flow",
        "net cash flows generated from operating activities": "operating_cash_flow",
        "net cash flows used in operating activities": "operating_cash_flow",
        "net cash flows from used in operating activities": "operating_cash_flow",
        "cash flows from used in operations": "operating_cash_flow",
        "cash flow from investing activities": "investing_cash_flow",
        "cash flows from investing activities": "investing_cash_flow",
        "net cash flows used in investing activities": "investing_cash_flow",
        "net cash used in investing activities": "investing_cash_flow",
        "cash flow from financing activities": "financing_cash_flow",
        "cash flows from financing activities": "financing_cash_flow",
        "net cash flows used in financing activities": "financing_cash_flow",
        "net cash used in financing activities": "financing_cash_flow",
        "net increase in cash and cash equivalents": "net_change_cash",
        "net decrease in cash and cash equivalents": "net_change_cash",
        "cash and cash equivalents at end of the year": "ending_cash",
        "cash and cash equivalents at end of the financial year": "ending_cash",
        "cash and cash equivalents at end of the period": "ending_cash",
        "cash and cash equivalents at end of the financial year period": "ending_cash",
        "cash and bank balances at end of the financial year": "ending_cash",
        "cash and bank balances at the end of the financial year": "ending_cash",
        "cash and bank balances at end of the year": "ending_cash",
        "cash and bank balances at end of period": "ending_cash",
    }

    def label_key(value: Any) -> str:
        return re.sub(r"[^a-z0-9]+", " ", text(value).lower()).strip()

    frame = frame.copy()
    if "entity_scope" in frame.columns:
        scope = frame["entity_scope"].fillna("").astype(str).str.upper()
        frame = frame[scope.isin({"GROUP", "CONSOLIDATED", ""})]
    # Notes are commonly the first numeric-looking column in annual-report
    # tables. Never allow a note identifier (for example 4 or 6) to become a
    # current-period amount.
    if "note_reference" in frame.columns and "numeric_value" in frame.columns:
        note_values = frame["note_reference"].map(number)
        numeric_values = frame["numeric_value"].map(number)
        column_indexes = frame.get(
            "column_index", pd.Series([999] * len(frame), index=frame.index)
        ).map(lambda value: integer(value, 999))
        note_cells = (
            note_values.notna()
            & numeric_values.notna()
            & (column_indexes <= 1)
            & ((note_values - numeric_values).abs() < 0.000001)
        )
        frame = frame[~note_cells].copy()

    # Some extractors do not populate note_reference but still emit the Note
    # column as a numeric cell. Detect it structurally: it is the left-most
    # small integer on a row that also contains at least two financial values.
    structural_note_indexes = []
    row_identity = [column for column in [
        "source_document_id", "table_artifact_id", "source_table_id", "row_index"
    ] if column in frame.columns]
    if row_identity and "column_index" in frame.columns:
        for _, row_group in frame.groupby(row_identity, dropna=False, sort=False):
            numeric_rows = []
            for row_index, row in row_group.iterrows():
                parsed = number(row.get("numeric_value"))
                if parsed is not None:
                    numeric_rows.append((row_index, integer(row.get("column_index"), 999), parsed))
            if len(numeric_rows) < 2:
                continue
            numeric_rows.sort(key=lambda item: item[1])
            candidate_index, candidate_column, candidate_value = numeric_rows[0]
            later_amounts = [item for item in numeric_rows[1:] if item[1] > candidate_column]
            candidate_row = row_group.loc[candidate_index]
            candidate_headers = " ".join(text(candidate_row.get(column)) for column in (
                "header_path", "column_header", "column_label", "column_name",
                "source_column", "value_header",
            ))
            explicitly_note_column = bool(re.search(
                r"(?:^|\b)(?:note|notes|note\s*no\.?|ref(?:erence)?)(?:\b|$)",
                candidate_headers, re.I,
            ))
            magnitude_separates_identifier = bool(later_amounts) and any(
                abs(item[2]) >= max(1000.0, abs(candidate_value) * 100.0)
                for item in later_amounts
            )
            if (
                later_amounts
                and abs(candidate_value) <= 999
                and abs(candidate_value - round(candidate_value)) < 0.000001
                and (len(later_amounts) >= 2 or explicitly_note_column
                     or magnitude_separates_identifier)
            ):
                structural_note_indexes.append(candidate_index)
    if structural_note_indexes:
        frame = frame.drop(index=structural_note_indexes).copy()

    # Preserve accounting signs even when numeric_value was emitted as an
    # absolute value by the table extractor.
    def signed_source_value(row: pd.Series) -> Optional[float]:
        parsed = number(row.get("numeric_value"))
        raw = text(row.get("raw_value") or row.get("raw_text"))
        if parsed is not None and parsed > 0 and re.match(r"^\s*\(.*\)\s*$", raw):
            return -parsed
        return parsed

    if "numeric_value" in frame.columns:
        frame["numeric_value"] = frame.apply(signed_source_value, axis=1)
    frame["field_label"] = frame.get("row_label", "")

    database_aliases = read_optional(APPROVED_CONCEPT_ALIASES_DATASET)
    aliases_by_label: Dict[str, List[str]] = collections.defaultdict(list)
    if not database_aliases.empty and {"alias_text", "concept_key"}.issubset(database_aliases.columns):
        if "active" in database_aliases.columns:
            database_aliases = database_aliases[
                database_aliases["active"].fillna(False).astype(str).str.lower().isin({"true", "1", "yes", "y"})
            ]
        if "approval_status" in database_aliases.columns:
            database_aliases = database_aliases[
                database_aliases["approval_status"].fillna("").astype(str).str.upper().eq("APPROVED")
            ]
        if "priority" in database_aliases.columns:
            database_aliases = database_aliases.sort_values(["priority", "concept_key"], kind="stable")
        for alias_row in database_aliases.to_dict(orient="records"):
            alias_label = label_key(alias_row.get("alias_text") or alias_row.get("normalized_alias_text"))
            concept_key = text(alias_row.get("concept_key"))
            if alias_label and concept_key and concept_key not in aliases_by_label[alias_label]:
                aliases_by_label[alias_label].append(concept_key)
        print(
            f"Loaded {sum(len(values) for values in aliases_by_label.values())} "
            f"approved concept aliases from {APPROVED_CONCEPT_ALIASES_DATASET}",
            flush=True,
        )

    def concepts_for(value: Any) -> List[str]:
        label = label_key(value)
        if aliases_by_label:
            if label in aliases_by_label:
                return aliases_by_label[label]
            # The built-in set contains only exact, conservative statement
            # labels and safely supplements an incomplete database alias set.
            if label in aliases:
                return [aliases[label]]
            # Pattern fallback applies only to well-defined profit/loss terms;
            # all other labels must be governed by database configuration.
            if re.search(r"\b(?:profit|loss)\s+for\s+the\s+year(?:\s+period)?\b", label):
                return ["net_profit"]
            if re.search(r"\b(?:profit|loss)\s+before\s+(?:income\s+)?tax\b", label):
                return ["profit_before_tax"]
            return [label.replace(" ", "_")]
        if label in aliases:
            return [aliases[label]]
        if re.search(r"\b(?:profit|loss)\s+for\s+the\s+year(?:\s+period)?\b", label):
            return ["net_profit"]
        if re.search(r"\b(?:profit|loss)\s+before\s+(?:income\s+)?tax\b", label):
            return ["profit_before_tax"]
        if "net cash" in label and "operating activities" in label:
            return ["operating_cash_flow"]
        return [label.replace(" ", "_")]

    expanded_rows = []
    for source_row in frame.to_dict(orient="records"):
        for concept_key in concepts_for(source_row.get("field_label")):
            expanded = dict(source_row)
            source_label = label_key(source_row.get("field_label"))
            # Preserve standalone SG&A components instead of collapsing each
            # one into the aggregate. Otherwise whichever row wins dataframe
            # precedence (usually Administrative expenses) is incorrectly
            # displayed as the complete SG&A value.
            if source_label in {
                "administrative expense", "administrative expenses",
                "general and administrative expense",
                "general and administrative expenses",
            }:
                concept_key = "administrative_expenses"
            elif source_label in {
                "selling expense", "selling expenses", "distribution cost",
                "distribution costs", "distribution expense", "distribution expenses",
                "selling and distribution expense", "selling and distribution expenses",
                "marketing expense", "marketing expenses",
                "marketing and distribution expense", "marketing and distribution expenses",
            }:
                concept_key = "marketing_and_distribution_expenses"
            expanded["concept_key"] = concept_key
            expanded_rows.append(expanded)
    frame = pd.DataFrame(expanded_rows) if expanded_rows else frame

    # Build the governed SG&A aggregate only when both components occur in the
    # same selected-report statement table, period and entity scope. This is
    # report-neutral, prevents cross-table/cross-period addition, and leaves an
    # explicitly disclosed combined SG&A row untouched.
    component_keys = {"marketing_and_distribution_expenses", "administrative_expenses"}
    component_frame = frame[frame["concept_key"].isin(component_keys)].copy()
    if not component_frame.empty:
        grouping_columns = [column for column in [
            "tenant_id", "entity_id", "assessment_run_id", "source_document_id",
            "table_artifact_id", "source_table_id", "statement_type", "entity_scope",
            "period_label", "period_end", "currency", "unit",
        ] if column in component_frame.columns]
        aggregate_rows = []
        if grouping_columns:
            def aggregate_group_key(row: Dict[str, Any]) -> tuple:
                return tuple(text(row.get(column)) for column in grouping_columns)

            explicit_sga_groups = {
                aggregate_group_key(row)
                for row in frame[frame["concept_key"].eq("sg_and_a_expense")].to_dict(orient="records")
            }
            for _, component_group in component_frame.groupby(grouping_columns, dropna=False, sort=False):
                if aggregate_group_key(component_group.iloc[0].to_dict()) in explicit_sga_groups:
                    continue
                by_concept = {}
                for component in component_group.to_dict(orient="records"):
                    value = number(component.get("numeric_value"))
                    key = text(component.get("concept_key"))
                    if value is not None and key not in by_concept:
                        by_concept[key] = component
                if not component_keys.issubset(by_concept):
                    continue
                selling = by_concept["marketing_and_distribution_expenses"]
                administration = by_concept["administrative_expenses"]
                aggregate = dict(administration)
                aggregate.update({
                    "concept_key": "sg_and_a_expense",
                    "field_label": "SG&A expense",
                    "row_label": "SG&A expense",
                    "canonical_label": "SG&A expense",
                    "numeric_value": abs(number(selling.get("numeric_value")))
                                     + abs(number(administration.get("numeric_value"))),
                    "raw_value": None,
                    "resolution_method": "DIRECT_COMPONENT_SUM",
                    "selection_method": "GOVERNED_SGA_COMPONENT_SUM",
                    "value_status": "DERIVED_FROM_DISCLOSED_COMPONENTS",
                    "derivation_formula": (
                        "ABS(selling/distribution expense) + "
                        "ABS(general and administrative expense)"
                    ),
                    "derivation_evidence": (
                        text(selling.get("field_label")) + " + "
                        + text(administration.get("field_label"))
                    ),
                })
                aggregate_rows.append(aggregate)
        if aggregate_rows:
            frame = pd.concat([frame, pd.DataFrame(aggregate_rows)], ignore_index=True, sort=False)
    frame["value_status"] = frame.get("value_status", "REPORTED")
    if "selection_method" not in frame.columns:
        frame["selection_method"] = "VALIDATED_STANDARDIZED_TABLE"
    else:
        frame["selection_method"] = frame["selection_method"].fillna("VALIDATED_STANDARDIZED_TABLE")

    # The webapp never derives financial values.  Any component aggregation
    # (for example SG&A, D&A, EBIT or long-term debt) is executed only by the
    # governed database rule layer and appears in FRI_SECTOR_TEMPLATE_VALUES.
    # This keeps the display layer report-neutral and prevents a source row
    # such as a lease liability from being silently reclassified as debt.
    return frame


def apply_disclosed_cash_flow_directions(frame: pd.DataFrame) -> pd.DataFrame:
    """Restore signs lost by extractors for labelled cash-flow subtotals."""
    if frame.empty or "concept_key" not in frame.columns:
        return frame
    directional_concepts = {
        "operating_cash_flow", "investing_cash_flow", "financing_cash_flow",
        "net_change_cash", "ending_cash",
    }
    result = frame.copy()
    for index, row in result.iterrows():
        if text(row.get("concept_key")) not in directional_concepts:
            continue
        for role in ("current", "prior"):
            value_column = role + "_value"
            if value_column not in result.columns:
                continue
            value = number(row.get(value_column))
            if value is None:
                continue
            label = text(
                row.get(role + "_source_label") or row.get("source_row_label")
                or row.get("row_label") or row.get("field_label")
                or row.get("canonical_label")
            ).lower()
            if re.search(r"\b(?:used in|used for|decrease in|net decrease|cash outflow)\b", label):
                result.at[index, value_column] = -abs(value)
            elif re.search(r"\b(?:generated from|generated by|provided by|net increase)\b", label):
                result.at[index, value_column] = abs(value)
    return result


def resolved_values():
    try:
        variables = dataiku.get_custom_variables()
    except Exception:
        variables = {}
    use_tables = str(variables.get("fsre_webapp_use_table_values", "true")).lower() in {
        "1", "true", "yes", "on",
    }
    frames = []
    sources = []

    def finalized(frame: pd.DataFrame, source: str):
        governed = apply_approved_fact_overrides_to_frame(frame)
        governed = isolate_note_shifted_value_pairs(governed)
        return apply_disclosed_cash_flow_directions(governed), source

    def overlay_missing_concepts(
        primary: pd.DataFrame,
        fallback: pd.DataFrame,
        method: str,
        allow_new_concepts: bool = False,
    ) -> pd.DataFrame:
        """Repair configured 04F fields without expanding the UI template.

        Matching is document/run/statement/concept aware so values from another
        filing can never fill the active filing. Existing 04F rows always win.
        """
        if fallback.empty:
            return primary
        fallback = normalize_resolved_shape(fallback.copy())
        if fallback.empty or "concept_key" not in fallback.columns:
            return primary
        if "statement_type" not in fallback.columns:
            income_keys = {
                "revenue", "cost_of_goods_sold", "sg_and_a_expense",
                "depreciation_amortization", "operating_income_ebit",
                "interest_expense", "net_profit",
            }
            cash_keys = {
                "operating_cash_flow", "investing_cash_flow",
                "financing_cash_flow", "net_change_cash", "ending_cash",
            }
            fallback["statement_type"] = fallback["concept_key"].map(
                lambda key: (
                    "CASH_FLOW_STATEMENT" if text(key) in cash_keys
                    else "INCOME_STATEMENT" if text(key) in income_keys
                    else "BALANCE_SHEET"
                )
            )
        else:
            fallback["statement_type"] = fallback["statement_type"].map(canonical_statement)
        if "resolution_method" not in fallback.columns:
            fallback["resolution_method"] = method
        else:
            fallback["resolution_method"] = fallback["resolution_method"].fillna(method)
        if "selection_method" not in fallback.columns:
            fallback["selection_method"] = method
        fallback["value_status"] = "SOURCE_FALLBACK"
        key_columns = [column for column in [
            "tenant_id", "entity_id", "assessment_run_id", "source_document_id",
            "statement_type", "concept_key",
        ] if column in primary.columns and column in fallback.columns]
        if not key_columns:
            return primary
        primary = primary.copy()
        existing_indexes = {
            tuple(text(row.get(column)) for column in key_columns): index
            for index, row in primary.iterrows()
        }
        existing = set(existing_indexes)
        # Repair the characteristic Note-column shift (for example Revenue=4
        # or Finance costs=6) when a validated source-table fallback contains
        # the actual two reported amounts.
        for fallback_row in fallback.to_dict(orient="records"):
            fallback_key = tuple(text(fallback_row.get(column)) for column in key_columns)
            primary_index = existing_indexes.get(fallback_key)
            if primary_index is None:
                continue
            primary_current = number(primary.at[primary_index, "current_value"]) if "current_value" in primary.columns else None
            fallback_current = number(fallback_row.get("current_value"))
            fallback_prior = number(fallback_row.get("prior_value"))
            primary_prior = number(primary.at[primary_index, "prior_value"]) if "prior_value" in primary.columns else None
            looks_like_note_shift = (
                primary_current is not None
                and abs(primary_current) <= 999
                and abs(primary_current - round(primary_current)) < 0.000001
                and fallback_current is not None
                and abs(fallback_current) >= 1000
                and fallback_prior is not None
            )
            corrects_accounting_sign = (
                primary_current is not None and fallback_current is not None
                and primary_current * fallback_current < 0
                and abs(abs(primary_current) - abs(fallback_current)) <= max(0.01, abs(fallback_current) * 0.000001)
                and (
                    primary_prior is None or fallback_prior is None
                    or abs(abs(primary_prior) - abs(fallback_prior)) <= max(0.01, abs(fallback_prior) * 0.000001)
                )
            )
            concept_key = text(fallback_row.get("concept_key"))
            fallback_source = text(
                fallback_row.get("current_source_label")
                or fallback_row.get("prior_source_label")
                or fallback_row.get("canonical_label")
            )
            source_backed = bool(fallback_source) and fallback_source not in {"-", "–", "—"}
            primary_missing = primary_current is None or primary_prior is None
            # A fallback may fill a missing configured period or repair an
            # unmistakable note/sign defect. It must never overwrite a
            # complete governed pair merely because it is canonical: the
            # canonical row can itself carry a shifted Note column.
            if (
                (source_backed and primary_missing)
                or looks_like_note_shift
                or corrects_accounting_sign
            ):
                # Merge field-by-field; never erase a populated period with
                # an empty value from a weaker fallback layer.
                for column, value in fallback_row.items():
                    if column not in primary.columns and column not in {"current_value", "prior_value"}:
                        continue
                    if column in {"current_value", "prior_value"}:
                        if number(value) is None:
                            continue
                    elif text(value) == "":
                        continue
                    primary.at[primary_index, column] = value
                repair_type = (
                    "NOTE_COLUMN_REPAIR" if looks_like_note_shift
                    else "ACCOUNTING_SIGN_REPAIR" if corrects_accounting_sign
                    else "DISCLOSED_COMPONENT_DERIVATION"
                )
                primary.at[primary_index, "resolution_method"] = method + "_" + repair_type
        if not allow_new_concepts:
            return primary
        additions = [
            row for row in fallback.to_dict(orient="records")
            if tuple(text(row.get(column)) for column in key_columns) not in existing
        ]
        if not additions:
            return primary
        return pd.concat([primary, pd.DataFrame(additions)], ignore_index=True, sort=False)

    # Database-rule-derived rows remain authoritative. Missing concepts are
    # supplemented by source-validated canonical facts, then by standardized
    # table cells. This affects display only and never writes a derived fact.
    sector_values = read_optional(SECTOR_TEMPLATE_VALUES_DATASET)
    if not sector_values.empty:
        sector_values = normalize_resolved_shape(sector_values)
        sector_values["statement_type"] = sector_values["statement_type"].map(
            canonical_statement
        )
        canonical = read_optional(CANONICAL_FACTS_DATASET)
        sector_values = overlay_missing_concepts(
            sector_values,
            canonical,
            "CANONICAL_SOURCE_FALLBACK",
            allow_new_concepts=False,
        )
        if use_tables:
            sector_values = overlay_missing_concepts(
                sector_values,
                standardized_table_values(),
                "VALIDATED_STANDARDIZED_TABLE_FALLBACK",
                allow_new_concepts=False,
            )
        return finalized(sector_values, "SECTOR_TEMPLATE_DB_RULES_WITH_CONFIGURED_REPAIRS")

    balance = read_optional(BALANCE_INPUTS_DATASET)

    if not balance.empty:
        frames.append(balance)
        sources.append("BALANCE_SHEET_RESOLVED")

    income = read_optional(INCOME_INPUTS_DATASET)

    if not income.empty:
        frames.append(income)
        sources.append("INCOME_STATEMENT_RESOLVED")

    if not frames:
        # Only fall back to row-per-cell values when no fixed resolver output
        # exists. These rows retain Note columns, so the UI must select year
        # columns structurally and never treat the first numeric column as the
        # current period.
        if use_tables:
            standardized = standardized_table_values()
            if not standardized.empty:
                return finalized(standardized, "VALIDATED_STANDARDIZED_TABLE_VALUES_FALLBACK")
        canonical = read_optional(CANONICAL_FACTS_DATASET)
        if canonical.empty:
            return finalized(pd.DataFrame(), "NO_DATA")
        canonical = normalize_resolved_shape(canonical)
        canonical["statement_type"] = canonical["statement_type"].map(
            canonical_statement
        )
        if "field_label" not in canonical.columns:
            canonical["field_label"] = canonical[
                "canonical_label"
                if "canonical_label" in canonical.columns
                else "concept_key"
            ]
        return finalized(canonical, "CANONICAL_FACTS_FALLBACK")

    values = pd.concat(
        frames,
        ignore_index=True,
        sort=False,
    )

    if "statement_type" in values.columns:
        values["statement_type"] = values["statement_type"].map(
            canonical_statement
        )

    return finalized(values, "+".join(sources))


def registration_lookup() -> Dict[str, Dict[str, str]]:
    result = {}

    registrations = read_optional(REGISTRATIONS_DATASET)

    if not registrations.empty:
        for row in registrations.to_dict(orient="records"):
            document_id = text(row.get("source_document_id"))

            if document_id:
                result[document_id] = {
                    "file_name": text(row.get("file_name")),
                    "entity_key": text(row.get("entity_key")),
                    "tenant_key": text(row.get("tenant_key")),
                    "registered_at": text(row.get("registered_at") or row.get("created_at")),
                }

    # Upload history is the durable filename source for completed/legacy runs.
    # Without this merge, a report can appear in Load sample via PostgreSQL but
    # the selected-PDF verifier receives no filename and cannot reopen it.
    try:
        with postgres_connection() as connection:
            with connection.cursor() as cursor:
                cursor.execute("""SELECT source_document_id, file_name
                                     FROM financial_risk_intelligence.uploaded_reports
                                    WHERE source_document_id IS NOT NULL""")
                upload_names_by_document = collections.defaultdict(set)
                for document_id, file_name in cursor.fetchall():
                    key = text(document_id)
                    if key and text(file_name):
                        upload_names_by_document[key].add(text(file_name))
                for key, file_names in upload_names_by_document.items():
                    if len(file_names) != 1:
                        print(f"AMBIGUOUS UPLOAD BINDING: source_document_id={key} files={sorted(file_names)}", flush=True)
                        continue
                    file_name = next(iter(file_names))
                    registration = result.setdefault(key, {
                        "file_name": "", "entity_key": "", "tenant_key": "", "registered_at": "",
                    })
                    if not text(registration.get("file_name")):
                        registration["file_name"] = text(file_name)
    except Exception as exc:
        print(f"Uploaded-report registration lookup unavailable: {type(exc).__name__}: {exc}")

    return result


def report_display_filename_lookup() -> Dict[str, Dict[Any, str]]:
    """Resolve dropdown labels without changing the selected document binding.

    Legacy runs can contain a resolver-generated document UUID while the
    durable upload row retains the original upload UUID. A unique assessment
    run is safe for display metadata only; evidence APIs continue to use the
    selected source_document_id.
    """
    by_pair = collections.defaultdict(set)
    by_document = collections.defaultdict(set)
    by_run = collections.defaultdict(set)
    try:
        with postgres_connection() as connection:
            with connection.cursor() as cursor:
                sources = []
                try:
                    cursor.execute("""SELECT assessment_run_id, source_document_id, file_name
                                         FROM financial_risk_intelligence.uploaded_reports
                                        WHERE file_name IS NOT NULL AND file_name <> ''""")
                    sources.extend(cursor.fetchall())
                except Exception:
                    connection.rollback()
                try:
                    cursor.execute("""SELECT assessment_run_id, source_document_id, file_name
                                         FROM financial_risk_intelligence.financial_input_validation_runs
                                        WHERE file_name IS NOT NULL AND file_name <> ''""")
                    sources.extend(cursor.fetchall())
                except Exception:
                    connection.rollback()
                try:
                    cursor.execute("""SELECT assessment_run_id, source_document_id,
                                              context_json ->> 'file_name' AS file_name
                                         FROM financial_risk_intelligence.webapp_analysis_history
                                        WHERE COALESCE(context_json ->> 'file_name', '') <> ''""")
                    sources.extend(cursor.fetchall())
                except Exception:
                    connection.rollback()
                # Hydrated historical PDFs retain the exact original filename
                # even when an older uploaded_reports row was accidentally
                # populated with a document UUID as its file_name.
                try:
                    cursor.execute("""SELECT DISTINCT assessment_run_id, source_document_id, file_name
                                         FROM financial_risk_intelligence.webapp_report_evidence
                                        WHERE file_name IS NOT NULL AND file_name <> ''""")
                    sources.extend(cursor.fetchall())
                except Exception:
                    connection.rollback()
        for run_id, document_id, file_name in sources:
            run_key, document_key, name = text(run_id), text(document_id), Path(text(file_name)).name
            if not name or re.fullmatch(r"[0-9a-f-]{32,36}", name, re.IGNORECASE):
                continue
            if run_key and document_key:
                by_pair[(run_key, document_key)].add(name)
            if document_key:
                by_document[document_key].add(name)
            if run_key:
                by_run[run_key].add(name)
    except Exception as exc:
        print(f"Report display-name lookup unavailable: {type(exc).__name__}: {exc}")

    def unique(source):
        return {key: next(iter(names)) for key, names in source.items() if len(names) == 1}

    return {"by_pair": unique(by_pair), "by_document": unique(by_document), "by_run": unique(by_run)}


def run_scoped_evidence_document_ids(run_id: str, document_id: str) -> List[str]:
    """Return the selected ID plus one unambiguous legacy upload binding.

    Some historical resolver rows were assigned a derived document UUID while
    the durable upload/evidence tables retained the original UUID. A run-scoped
    bridge is safe only when that assessment run identifies exactly one uploaded
    document. Ambiguous runs deliberately retain exact-ID-only behaviour.
    """
    selected_id, run_key = text(document_id), text(run_id)
    result = [selected_id] if selected_id else []
    display_names = report_display_filename_lookup()
    expected_name = Path(text(
        display_names.get("by_pair", {}).get((run_key, selected_id))
        or display_names.get("by_document", {}).get(selected_id)
        or display_names.get("by_run", {}).get(run_key)
    )).name
    try:
        with postgres_connection() as connection:
            with connection.cursor() as cursor:
                candidates = set()
                for table_name in (("uploaded_reports", "assessment_run_id") if run_key else (),
                                   ("financial_input_validation_runs", "assessment_run_id") if run_key else ()):
                    if not table_name:
                        continue
                    table_name, run_column = table_name
                    try:
                        cursor.execute(f"""
                            SELECT DISTINCT source_document_id
                              FROM financial_risk_intelligence.{table_name}
                             WHERE {run_column} = %s
                               AND source_document_id IS NOT NULL
                        """, (run_key,))
                        table_candidates = {text(row[0]) for row in cursor.fetchall() if text(row[0])}
                        if table_candidates:
                            candidates = table_candidates
                            break
                    except Exception:
                        connection.rollback()
                # Some earliest runs were re-keyed after upload and therefore
                # cannot join by assessment_run_id. An exact historical filename
                # is still safe when it maps to exactly one uploaded document.
                if not candidates and expected_name:
                    try:
                        cursor.execute("""
                            SELECT DISTINCT source_document_id
                              FROM financial_risk_intelligence.uploaded_reports
                             WHERE LOWER(file_name) = LOWER(%s)
                               AND source_document_id IS NOT NULL
                        """, (expected_name,))
                        filename_candidates = {text(row[0]) for row in cursor.fetchall() if text(row[0])}
                        if len(filename_candidates) == 1:
                            candidates = filename_candidates
                        elif len(filename_candidates) > 1:
                            print(f"AMBIGUOUS FILENAME EVIDENCE BINDING: file_name={expected_name} "
                                  f"documents={sorted(filename_candidates)}", flush=True)
                    except Exception:
                        connection.rollback()
        if len(candidates) == 1:
            legacy_id = next(iter(candidates))
            if legacy_id not in result:
                result.append(legacy_id)
        elif len(candidates) > 1:
            print(f"AMBIGUOUS LEGACY EVIDENCE BINDING: assessment_run_id={run_key} "
                  f"documents={sorted(candidates)}", flush=True)
    except Exception as exc:
        print(f"Legacy evidence binding unavailable for run {run_key}: "
              f"{type(exc).__name__}: {exc}", flush=True)
    return result


def infer_sector(rows: List[Dict[str, Any]]) -> Dict[str, str]:
    """Choose the filing template from governed metadata and fact structure.

    Mixed fallback frames can contain stale template rows plus newer canonical
    facts. Multiple bank-specific concepts are stronger evidence than a stale
    manufacturing tag; a single interest-related caption is not sufficient.
    """
    def canonical_sector_key(value: Any) -> str:
        key = re.sub(r"[^a-z0-9]+", "_", text(value).lower().replace("&", " and ")).strip("_")
        aliases = {
            "bank": "banking", "banks": "banking", "financial_institution": "banking",
            "financial_institutions": "banking", "banking_financial_institutions": "banking",
            "banking_and_financial_institutions": "banking",
            "banks_and_financial_institutions": "banking",
            "non_banking_financial_company": "nbfc", "non_banking_financial_services": "nbfc",
            "real_estate": "realestate", "real_estate_infrastructure": "realestate",
            "real_estate_and_infrastructure": "realestate", "property_development": "realestate",
        }
        return aliases.get(key, key)

    concepts = {
        re.sub(r"[^a-z0-9]+", "_", text(row.get("concept_key") or row.get("field_key")).lower()).strip("_")
        for row in rows
        if text(row.get("concept_key") or row.get("field_key"))
    }
    bank_anchors = {
        "net_interest_income", "gross_loans_advances", "customer_deposits",
        "stage3_npa", "ecl_balance", "cet1_ratio",
    }
    bank_hits = concepts.intersection(bank_anchors)
    if len(bank_hits) >= 2:
        return {"sector_key": "banking", "sector_name": "Banking & Financial Institutions"}

    configured = [
        text(row.get("sector_key")) for row in rows if text(row.get("sector_key"))
    ]
    if configured:
        configured_raw_key = collections.Counter(configured).most_common(1)[0][0]
        configured_key = canonical_sector_key(configured_raw_key)
        configured_name = next((
            text(row.get("sector_name")) for row in rows
            if text(row.get("sector_key")) == configured_raw_key and text(row.get("sector_name"))
        ), "")
        return {"sector_key": configured_key, "sector_name": configured_name or configured_key.replace("_", " ").title()}
    supplied = " ".join(
        text(row.get("sector_name") or row.get("sector") or row.get("industry"))
        for row in rows
    ).strip()
    if supplied:
        return {"sector_key": canonical_sector_key(supplied), "sector_name": supplied}

    evidence = " ".join(
        text(row.get("concept_key") or row.get("field_label") or row.get("canonical_label") or row.get("source_row_label"))
        for row in rows
    ).lower()
    if any(token in evidence for token in (
        "net_interest_income", "net interest income", "loans and advances",
        "customer deposits", "stage 3", "cet 1", "gnpa",
    )):
        return {"sector_key": "banking", "sector_name": "Banking & Financial Institutions"}
    return {"sector_key": "manufacturing", "sector_name": "Manufacturing & Industrials"}


def rows_for_inferred_sector(rows: List[Dict[str, Any]], sector_key: str) -> List[Dict[str, Any]]:
    """Remove explicit rows belonging to a stale conflicting template."""
    matching = [row for row in rows if text(row.get("sector_key")) == sector_key]
    unscoped = [row for row in rows if not text(row.get("sector_key"))]
    return matching + unscoped if matching else rows


def runtime_configuration_values() -> Dict[str, str]:
    """Read database-published runtime settings, then compatibility variables."""
    configured: Dict[str, str] = {}
    frame = read_optional(RUNTIME_SETTINGS_DATASET)
    if not frame.empty and {"setting_key", "setting_value"}.issubset(frame.columns):
        for row in frame.to_dict(orient="records"):
            if "active" in row and text(row.get("active")).lower() not in {"true", "1", "yes"}:
                continue
            key = text(row.get("setting_key"))
            value = text(row.get("setting_value"))
            if key and value:
                configured[key] = value
    try:
        variables = dataiku.get_custom_variables()
    except Exception:
        variables = {}
    for key, value in variables.items():
        if key not in configured and text(value):
            configured[str(key)] = text(value)
    return configured


def postgres_connection():
    """Open the same PostgreSQL configured for the Dataiku project."""
    import psycopg2
    from financial_risk_intelligence.database import DatabaseSettings
    settings = DatabaseSettings.from_runtime()
    return psycopg2.connect(
        host=settings.host, port=settings.port, dbname=settings.database,
        user=settings.user, password=settings.password,
        application_name="fri-financial-input-validation-webapp",
        connect_timeout=15,
    )


def ensure_analysis_history_table(connection) -> None:
    with connection.cursor() as cursor:
        cursor.execute("""
            CREATE SCHEMA IF NOT EXISTS financial_risk_intelligence;
            CREATE TABLE IF NOT EXISTS financial_risk_intelligence.webapp_analysis_history (
                assessment_run_id TEXT NOT NULL,
                source_document_id TEXT NOT NULL,
                context_json JSONB NOT NULL,
                values_json JSONB NOT NULL,
                scores_json JSONB NOT NULL DEFAULT '[]'::jsonb,
                exceptions_json JSONB NOT NULL DEFAULT '[]'::jsonb,
                captured_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                PRIMARY KEY (assessment_run_id, source_document_id)
            );
            CREATE INDEX IF NOT EXISTS webapp_analysis_history_captured_idx
                ON financial_risk_intelligence.webapp_analysis_history (captured_at DESC);
            ALTER TABLE financial_risk_intelligence.webapp_analysis_history
                ADD COLUMN IF NOT EXISTS forensic_result_json JSONB;
            ALTER TABLE financial_risk_intelligence.webapp_analysis_history
                ADD COLUMN IF NOT EXISTS input_fingerprint TEXT;
            ALTER TABLE financial_risk_intelligence.webapp_analysis_history
                ADD COLUMN IF NOT EXISTS derived_inputs_at TIMESTAMPTZ;
        """)


def history_json_value(value: Any):
    if missing(value):
        return None
    if hasattr(value, "item"):
        try:
            value = value.item()
        except Exception:
            pass
    if isinstance(value, dict):
        return {str(key): history_json_value(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [history_json_value(item) for item in value]
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return str(value)


def history_frame_rows(frame: pd.DataFrame) -> List[Dict[str, Any]]:
    if frame.empty:
        return []
    return [{str(key): history_json_value(value) for key, value in row.items()}
            for row in frame.to_dict(orient="records")]


def capture_completed_analysis_runs() -> int:
    """Upsert immutable run-scoped inputs and score outputs after a successful pipeline."""
    values, source = resolved_values()
    if values.empty:
        raise RuntimeError("Analysis completed but no resolved values were available to persist")
    score_rows = history_frame_rows(read_optional(FORENSIC_SCORES_DATASET))
    exception_rows = history_frame_rows(read_optional(FORENSIC_EXCEPTIONS_DATASET))
    registrations = registration_lookup()
    grouped: Dict[tuple, List[Dict[str, Any]]] = collections.defaultdict(list)
    for row in history_frame_rows(values):
        run_id = text(row.get("assessment_run_id") or row.get("run_id"))
        document_id = text(row.get("source_document_id"))
        if run_id and document_id:
            grouped[(run_id, document_id)].append(row)
    captured = 0
    with postgres_connection() as connection:
        ensure_analysis_history_table(connection)
        with connection.cursor() as cursor:
            for (run_id, document_id), rows in grouped.items():
                registration = registrations.get(document_id, {})
                sector = infer_sector(rows)
                run_scores = [row for row in score_rows
                              if text(row.get("assessment_run_id") or row.get("run_id")) == run_id
                              and text(row.get("source_document_id")) == document_id]
                run_exceptions = [row for row in exception_rows
                                  if text(row.get("assessment_run_id") or row.get("run_id")) == run_id
                                  and text(row.get("source_document_id")) == document_id]
                context = {
                    "context_id": f"{run_id}|{document_id}",
                    "assessment_run_id": run_id,
                    "source_document_id": document_id,
                    "entity_id": text(rows[0].get("entity_id")),
                    "entity_name": registration.get("entity_key") or text(rows[0].get("entity_id")) or "Unknown entity",
                    "file_name": registration.get("file_name") or text(rows[0].get("source_file_name")) or document_id,
                    "tenant_id": text(rows[0].get("tenant_id")),
                    "tenant_key": registration.get("tenant_key", ""),
                    "sector_key": sector["sector_key"],
                    "sector_name": sector["sector_name"],
                    "value_count": len(rows),
                    "data_source": source + "+POSTGRES_HISTORY",
                    "run_timestamp": text(rows[0].get("resolved_at") or rows[0].get("created_at") or rows[0].get("scored_at")) or registration.get("registered_at"),
                }
                cursor.execute("""
                    INSERT INTO financial_risk_intelligence.webapp_analysis_history
                        (assessment_run_id, source_document_id, context_json, values_json,
                         scores_json, exceptions_json, captured_at)
                    VALUES (%s, %s, %s::jsonb, %s::jsonb, %s::jsonb, %s::jsonb, NOW())
                    ON CONFLICT (assessment_run_id, source_document_id) DO UPDATE SET
                        context_json=EXCLUDED.context_json,
                        values_json=EXCLUDED.values_json,
                        scores_json=EXCLUDED.scores_json,
                        exceptions_json=EXCLUDED.exceptions_json
                """, (run_id, document_id, json.dumps(context, default=str), json.dumps(rows, default=str),
                      json.dumps(run_scores, default=str), json.dumps(run_exceptions, default=str)))
                captured += 1
    return captured


def load_analysis_history_contexts() -> List[Dict[str, Any]]:
    try:
        with postgres_connection() as connection:
            ensure_analysis_history_table(connection)
            with connection.cursor() as cursor:
                cursor.execute("""
                    SELECT context_json, captured_at
                      FROM financial_risk_intelligence.webapp_analysis_history
                     ORDER BY captured_at DESC
                """)
                rows = cursor.fetchall()
        # Historical context_json may contain a filename captured before the
        # document binding was corrected. Rebind display metadata using only
        # the exact source_document_id; never infer a filename from a run ID.
        registrations = registration_lookup()
        display_names = report_display_filename_lookup()
        contexts = []
        for context, captured_at in rows:
            item = dict(context or {})
            document_id = text(item.get("source_document_id"))
            run_id = text(item.get("assessment_run_id"))
            exact_registration = registrations.get(document_id, {})
            if text(exact_registration.get("file_name")):
                item["file_name"] = text(exact_registration.get("file_name"))
                item["display_name_binding"] = "EXACT_SOURCE_DOCUMENT_ID"
            else:
                resolved_name = (
                    display_names["by_pair"].get((run_id, document_id))
                    or display_names["by_document"].get(document_id)
                    or display_names["by_run"].get(run_id)
                )
                if resolved_name:
                    item["file_name"] = resolved_name
                    item["display_name_binding"] = (
                        "EXACT_RUN_DOCUMENT" if (run_id, document_id) in display_names["by_pair"]
                        else "EXACT_SOURCE_DOCUMENT_ID" if document_id in display_names["by_document"]
                        else "UNIQUE_ASSESSMENT_RUN_ID_DISPLAY_ONLY"
                    )
                elif not text(item.get("file_name")) or re.fullmatch(
                        r"[0-9a-f-]{32,36}", Path(text(item.get("file_name"))).name, re.IGNORECASE):
                    item["file_name"] = document_id
            item["run_timestamp"] = item.get("run_timestamp") or (captured_at.isoformat() if captured_at else "")
            item["history_source"] = "POSTGRESQL"
            item["document_binding"] = "EXACT_SOURCE_DOCUMENT_ID"
            contexts.append(item)
        return contexts
    except Exception as exc:
        print(f"Analysis history context load failed: {type(exc).__name__}: {exc}")
        return []


def retained_analysis_history_contexts() -> List[Dict[str, Any]]:
    """Return history only for reports with a retained upload/evidence record."""
    history = load_analysis_history_contexts()
    try:
        with postgres_connection() as connection:
            with connection.cursor() as cursor:
                cursor.execute("""
                    SELECT source_document_id, assessment_run_id, file_name
                      FROM financial_risk_intelligence.uploaded_reports
                """)
                rows = cursor.fetchall()
                try:
                    cursor.execute("""
                        SELECT DISTINCT source_document_id, assessment_run_id, file_name
                          FROM financial_risk_intelligence.webapp_report_evidence
                    """)
                    rows.extend(cursor.fetchall())
                except Exception:
                    connection.rollback()
                try:
                    cursor.execute("""
                        SELECT source_document_id, assessment_run_id,
                               context_json ->> 'file_name' AS file_name
                          FROM financial_risk_intelligence.webapp_analysis_history
                         WHERE COALESCE(context_json ->> 'file_name', '') <> ''
                    """)
                    rows.extend(cursor.fetchall())
                except Exception:
                    connection.rollback()
        documents = {text(row[0]) for row in rows if text(row[0])}
        runs = {text(row[1]) for row in rows if text(row[1])}
        return [item for item in history if (
            text(item.get("source_document_id")) in documents
            or text(item.get("assessment_run_id")) in runs
        )]
    except Exception as exc:
        print(f"History/upload inventory filter unavailable: {type(exc).__name__}: {exc}", flush=True)
        return history


def load_analysis_history_snapshot(run_id: str, document_id: str) -> Dict[str, Any]:
    try:
        with postgres_connection() as connection:
            ensure_analysis_history_table(connection)
            with connection.cursor() as cursor:
                cursor.execute("""
                    SELECT context_json, values_json, scores_json, exceptions_json, captured_at,
                           forensic_result_json, input_fingerprint, derived_inputs_at
                      FROM financial_risk_intelligence.webapp_analysis_history
                     WHERE assessment_run_id=%s AND source_document_id=%s
                """, (run_id, document_id))
                row = cursor.fetchone()
        if not row:
            return {}
        return {"context": row[0] or {}, "values": row[1] or [], "scores": row[2] or [],
                "exceptions": row[3] or [], "captured_at": row[4].isoformat() if row[4] else "",
                "forensic_result": row[5] or {}, "input_fingerprint": text(row[6]),
                "derived_inputs_at": row[7].isoformat() if row[7] else ""}
    except Exception as exc:
        print(f"Analysis history snapshot load failed: {type(exc).__name__}: {exc}")
        return {}


def forensic_input_fingerprint(rows: List[Dict[str, Any]]) -> str:
    """Stable hash of only score-bearing financial inputs for cache invalidation."""
    contract = sorted([{
        "concept_key": text(row.get("concept_key")),
        "current_value": number(row.get("current_value")),
        "prior_value": number(row.get("prior_value")),
        "current_period": text(row.get("current_period")),
        "prior_period": text(row.get("prior_period")),
    } for row in rows if text(row.get("concept_key"))], key=lambda item: item["concept_key"])
    return hashlib.sha256(json.dumps(contract, sort_keys=True, default=str).encode("utf-8")).hexdigest()


def persist_resolved_financial_inputs(run_id: str, document_id: str,
                                      fallback_tables: Optional[List[Dict[str, Any]]] = None) -> int:
    """Persist the latest resolved/approved values and invalidate stale scoring cache."""
    values, source = resolved_values()
    rows = [row for row in history_frame_rows(values)
            if text(row.get("assessment_run_id") or row.get("run_id")) == run_id
            and text(row.get("source_document_id")) == document_id]
    # Recipe-owned datasets can contain only the latest pipeline output.  Older
    # selected reports still have a complete statement skeleton in PostgreSQL.
    # Rebuild that snapshot with active overrides instead of returning zero and
    # leaving the UI on stale values after a successful approval.
    if not rows:
        historical = list(load_analysis_history_snapshot(run_id, document_id).get("values") or [])
        if historical:
            historical_frame = pd.DataFrame(historical)
            historical_frame = apply_approved_fact_overrides_to_frame(historical_frame)
            historical_frame = isolate_note_shifted_value_pairs(historical_frame)
            historical_frame = apply_disclosed_cash_flow_directions(historical_frame)
            rows = history_frame_rows(historical_frame)
            source = "POSTGRES_HISTORY+APPROVED_OVERRIDES"
    if not rows and fallback_tables:
        reconstructed = []
        for table in fallback_tables:
            statement_type = canonical_statement(table.get("statement_type"))
            for statement_row in table.get("rows") or []:
                values = statement_row.get("values") or {}
                current = values.get("current") or {}
                prior = values.get("prior") or {}
                # Compact batch tables already expose period/value fields at
                # row level; full UI tables expose them beneath values.
                current_period = text(current.get("period") or statement_row.get("current_period"))
                prior_period = text(prior.get("period") or statement_row.get("prior_period"))
                reconstructed.append({
                    "assessment_run_id": run_id,
                    "source_document_id": document_id,
                    "statement_type": statement_type,
                    "concept_key": text(statement_row.get("concept_key")),
                    "field_label": text(statement_row.get("row_label") or statement_row.get("label")
                                        or statement_row.get("concept_key")),
                    "canonical_label": text(statement_row.get("canonical_label")),
                    "current_period": current_period,
                    "prior_period": prior_period,
                    "current_value": number(current.get("numeric_value")
                                            if current else statement_row.get("current_value")),
                    "prior_value": number(prior.get("numeric_value")
                                          if prior else statement_row.get("prior_value")),
                    "resolution_method": text(statement_row.get("resolution_method")) or "STATEMENT_SNAPSHOT",
                })
        if reconstructed:
            reconstructed_frame = apply_approved_fact_overrides_to_frame(pd.DataFrame(reconstructed))
            reconstructed_frame = isolate_note_shifted_value_pairs(reconstructed_frame)
            reconstructed_frame = apply_disclosed_cash_flow_directions(reconstructed_frame)
            rows = history_frame_rows(reconstructed_frame)
            source = "RESOLVED_STATEMENT_TABLES+APPROVED_OVERRIDES"
    if not rows:
        return 0
    existing = load_analysis_history_snapshot(run_id, document_id)
    context = dict(existing.get("context") or {})
    sector = infer_sector(rows)
    context.update({
        "context_id": f"{run_id}|{document_id}", "assessment_run_id": run_id,
        "source_document_id": document_id, "sector_key": sector["sector_key"],
        "sector_name": sector["sector_name"], "value_count": len(rows),
        "data_source": source + "+POSTGRES_HISTORY",
    })
    with postgres_connection() as connection:
        ensure_analysis_history_table(connection)
        with connection.cursor() as cursor:
            cursor.execute("""INSERT INTO financial_risk_intelligence.webapp_analysis_history
                (assessment_run_id,source_document_id,context_json,values_json,scores_json,exceptions_json,
                 captured_at,derived_inputs_at,forensic_result_json,input_fingerprint)
                VALUES (%s,%s,%s::jsonb,%s::jsonb,'[]'::jsonb,'[]'::jsonb,NOW(),NOW(),NULL,NULL)
                ON CONFLICT (assessment_run_id,source_document_id) DO UPDATE SET
                 context_json=EXCLUDED.context_json,values_json=EXCLUDED.values_json,
                 derived_inputs_at=NOW(),forensic_result_json=NULL,input_fingerprint=NULL""",
                (run_id, document_id, json.dumps(context, default=str), json.dumps(rows, default=str)))
    return len(rows)


def persist_forensic_result(run_id: str, document_id: str, fingerprint: str, result: Dict[str, Any]) -> None:
    with postgres_connection() as connection:
        ensure_analysis_history_table(connection)
        with connection.cursor() as cursor:
            cursor.execute("""UPDATE financial_risk_intelligence.webapp_analysis_history
                                  SET forensic_result_json=%s::jsonb,input_fingerprint=%s,captured_at=NOW()
                                WHERE assessment_run_id=%s AND source_document_id=%s""",
                           (json.dumps(result, default=str), fingerprint, run_id, document_id))


def database_secret(setting_key: str) -> str:
    """Read a backend-only secret; secret values are never published to the UI dataset."""
    with postgres_connection() as connection:
        with connection.cursor() as cursor:
            cursor.execute(
                """SELECT setting_value
                     FROM financial_risk_intelligence.runtime_settings
                    WHERE setting_key = %s AND active = TRUE
                    LIMIT 1""",
                (setting_key,),
            )
            row = cursor.fetchone()
    return text(row[0]) if row else ""


def score_fingerprint(scores: List[Dict[str, Any]]) -> str:
    """Hash only governed score state so a score change creates a new narrative version."""
    contract = sorted([{
        "model_key": text(row.get("model_key")),
        "status": text(row.get("status")),
        "score": number(row.get("score")),
        "risk_band": text(row.get("risk_band")),
        "components": row.get("components_json"),
        "configuration_version": text(row.get("configuration_version")),
    } for row in scores], key=lambda item: item["model_key"])
    raw = json.dumps(contract, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def load_saved_narrative(document_id: str, fingerprint: str = "") -> Dict[str, Any]:
    try:
        with postgres_connection() as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    """SELECT narrative_json, authoritative_scores_json, company_context_json,
                              evidence_pages_json, provenance_json, score_fingerprint, created_at
                         FROM financial_risk_intelligence.forensic_narrative_versions
                        WHERE source_document_id = %s
                          AND (%s = '' OR score_fingerprint = %s)
                        ORDER BY created_at DESC LIMIT 1""",
                    (document_id, fingerprint, fingerprint),
                )
                row = cursor.fetchone()
        if not row:
            return {}
        return {
            "narrative": row[0], "authoritative_scores": row[1],
            "company_context": row[2], "evidence_pages": row[3],
            "provenance": {**(row[4] or {}), "persistence": "POSTGRESQL", "cached": True},
            "score_fingerprint": row[5], "saved_at": row[6].isoformat() if row[6] else "",
        }
    except Exception as exc:
        print("NARRATIVE CACHE READ FAILED:", type(exc).__name__, exc)
        return {}


def save_narrative(run_id: str, document_id: str, fingerprint: str, payload: Dict[str, Any]) -> None:
    try:
        with postgres_connection() as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    """INSERT INTO financial_risk_intelligence.forensic_narrative_versions
                           (assessment_run_id, source_document_id, score_fingerprint,
                            narrative_json, authoritative_scores_json, company_context_json,
                            evidence_pages_json, provenance_json)
                       VALUES (%s,%s,%s,%s::jsonb,%s::jsonb,%s::jsonb,%s::jsonb,%s::jsonb)
                       ON CONFLICT (source_document_id, score_fingerprint) DO UPDATE SET
                            assessment_run_id=EXCLUDED.assessment_run_id,
                            narrative_json=EXCLUDED.narrative_json,
                            authoritative_scores_json=EXCLUDED.authoritative_scores_json,
                            company_context_json=EXCLUDED.company_context_json,
                            evidence_pages_json=EXCLUDED.evidence_pages_json,
                            provenance_json=EXCLUDED.provenance_json""",
                    (run_id, document_id, fingerprint,
                     json.dumps(payload.get("narrative"), default=str),
                     json.dumps(payload.get("authoritative_scores"), default=str),
                     json.dumps(payload.get("company_context"), default=str),
                     json.dumps(payload.get("evidence_pages"), default=str),
                     json.dumps(payload.get("provenance"), default=str)),
                )
    except Exception as exc:
        print("NARRATIVE CACHE WRITE FAILED:", type(exc).__name__, exc)


def ollama_status(probe: bool = False) -> Dict[str, Any]:
    variables = runtime_configuration_values()

    base_url = (
        text(variables.get("fri_ollama_base_url"))
        or "http://localhost:11434"
    )

    configured_model = text(
        variables.get("fri_ollama_model")
    )

    # Rendering statement values must never wait for the model server. The
    # health endpoint may explicitly request a short connectivity probe.
    if not probe:
        return {
            "reachable": False,
            "base_url": base_url,
            "configured_model": configured_model,
            "available_models": [],
            "message": "Model connectivity is not probed during page loading.",
        }

    try:
        request_obj = urllib.request.Request(
            base_url.rstrip("/") + "/api/tags"
        )

        with urllib.request.urlopen(
            request_obj,
            timeout=2,
        ) as response:
            payload = json.loads(
                response.read().decode("utf-8")
            )

        models = [
            text(item.get("name"))
            for item in payload.get("models", [])
            if text(item.get("name"))
        ]

        return {
            "reachable": True,
            "base_url": base_url,
            "configured_model": configured_model,
            "available_models": models,
        }

    except Exception as exc:
        return {
            "reachable": False,
            "base_url": base_url,
            "configured_model": configured_model,
            "available_models": [],
            "message": f"{type(exc).__name__}: {exc}",
        }


def ollama_configuration() -> Dict[str, Any]:
    """Return the deployable Ollama settings documented by the FSRE runbook."""
    variables = runtime_configuration_values()
    return {
        "base_url": text(variables.get("fri_ollama_base_url")) or "http://localhost:11434",
        "model": text(variables.get("fri_ollama_model")) or "llama3.2:3b",
        "timeout_seconds": max(10, integer(variables.get("fri_ollama_narrative_timeout_seconds"), 600)),
        "max_fragments": max(4, min(20, integer(variables.get("fri_narrative_max_fragments"), 12))),
        "max_fragment_characters": max(500, min(5000, integer(variables.get("fri_narrative_max_fragment_characters"), 2500))),
    }


def secret_runtime_setting(setting_key: str) -> str:
    """Read one approved secret directly from PostgreSQL without publishing it."""
    if setting_key not in {"fri_bedrock_api_key", "fri_gemini_api_key"}:
        raise ValueError("Unsupported secret runtime setting")
    with postgres_connection() as connection:
        with connection.cursor() as cursor:
            cursor.execute(
                """SELECT setting_value
                     FROM financial_risk_intelligence.runtime_settings
                    WHERE setting_key = %s
                      AND active = TRUE
                      AND is_secret = TRUE
                    LIMIT 1""",
                (setting_key,),
            )
            row = cursor.fetchone()
    return text(row[0]) if row else ""


def financial_resolution_llm_configuration() -> Dict[str, Any]:
    """Return the selected LLM settings without publishing API credentials."""
    variables = runtime_configuration_values()
    # Active PostgreSQL settings are authoritative. The published Dataiku
    # dataset can lag behind a database update until its recipe rebuilds.
    try:
        database_provider = database_secret("fri_llm_provider")
        database_model = ""
        database_base_url = ""
    except Exception:
        database_provider = database_model = database_base_url = ""
    provider = text(database_provider or variables.get("fri_llm_provider") or "ollama").lower()
    if provider == "gemini":
        try:
            database_api_key = secret_runtime_setting("fri_gemini_api_key")
        except Exception as exc:
            raise RuntimeError(f"Unable to read the Gemini API key from PostgreSQL: {type(exc).__name__}") from exc
        environment_api_key = text(os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY"))
        variable_api_key = text(variables.get("fri_gemini_api_key"))
        api_key = text(database_api_key or environment_api_key or variable_api_key)
        credential_source = ("POSTGRES_RUNTIME_SETTINGS" if database_api_key else
                             "GEMINI_API_KEY" if environment_api_key else
                             "DATAIKU_CUSTOM_VARIABLE")
        if not api_key:
            raise RuntimeError(
                "Gemini is selected but fri_gemini_api_key, GEMINI_API_KEY, or GOOGLE_API_KEY is not configured"
            )
        try:
            database_model = database_secret("fri_gemini_model")
            database_base_url = database_secret("fri_gemini_base_url")
            database_timeout = database_secret("fri_gemini_timeout_seconds")
            database_fallback_models = database_secret("fri_gemini_fallback_models")
            database_max_output_tokens = database_secret("fri_gemini_max_output_tokens")
        except Exception:
            database_model = database_base_url = database_timeout = database_fallback_models = database_max_output_tokens = ""
        primary_model = text(database_model or variables.get("fri_gemini_model")) or "gemini-3.5-flash"
        fallback_text = text(database_fallback_models or variables.get("fri_gemini_fallback_models"))
        fallback_models = []
        for candidate in fallback_text.split(","):
            candidate = candidate.strip()
            if candidate and candidate != primary_model and candidate not in fallback_models:
                fallback_models.append(candidate)
        return {
            "provider": "gemini",
            "base_url": text(database_base_url or variables.get("fri_gemini_base_url"))
                        or "https://generativelanguage.googleapis.com/v1beta/openai",
            "model": primary_model,
            "fallback_models": fallback_models[:3],
            "max_output_tokens": max(4096, min(16384, integer(
                database_max_output_tokens or variables.get("fri_gemini_max_output_tokens"), 8192
            ))),
            "api_key": api_key,
            "credential_source": credential_source,
            # Financial-resolution responses can legitimately exceed one
            # minute when a compact request contains several missing cells.
            # Do not allow an older 60-second database setting to terminate
            # the request before Gemini returns its JSON decision packet.
            "timeout_seconds": max(180, integer(
                database_timeout or variables.get("fri_gemini_timeout_seconds"), 180
            )),
        }
    if provider == "bedrock":
        try:
            database_model = database_secret("fri_bedrock_model")
            database_base_url = database_secret("fri_bedrock_base_url")
        except Exception:
            database_model = database_base_url = ""
        try:
            database_api_key = secret_runtime_setting("fri_bedrock_api_key")
        except Exception as exc:
            raise RuntimeError(f"Unable to read the Bedrock API key from PostgreSQL: {type(exc).__name__}") from exc
        # The active database secret is authoritative for this Dataiku webapp.
        # This prevents a stale host environment token from silently overriding
        # a newly rotated short-term key saved by the administrator.
        environment_api_key = text(os.getenv("AWS_BEARER_TOKEN_BEDROCK"))
        variable_api_key = text(variables.get("fri_bedrock_api_key"))
        api_key = text(database_api_key or environment_api_key or variable_api_key)
        credential_source = ("POSTGRES_RUNTIME_SETTINGS" if database_api_key else
                             "AWS_BEARER_TOKEN_BEDROCK" if environment_api_key else
                             "DATAIKU_CUSTOM_VARIABLE")
        if not api_key:
            raise RuntimeError("Bedrock is selected but AWS_BEARER_TOKEN_BEDROCK or fri_bedrock_api_key is not configured")
        region = text(database_secret("fri_bedrock_region") or variables.get("fri_bedrock_region")) or "ap-southeast-2"
        base_url = text(database_base_url or variables.get("fri_bedrock_base_url")) or f"https://bedrock-runtime.{region}.amazonaws.com/openai/v1"
        base_url = base_url.rstrip("/")
        return {
            "provider": "bedrock",
            "base_url": base_url,
            "model": text(database_model or variables.get("fri_bedrock_model")) or "openai.gpt-oss-20b",
            "api_key": api_key,
            "credential_source": credential_source,
            "timeout_seconds": max(10, integer(variables.get("fri_bedrock_timeout_seconds"), 120)),
        }
    settings = ollama_configuration()
    return {"provider": "ollama", **settings}


def llm_feature_enabled(setting_key: str, default: bool = False) -> bool:
    """Read a database-controlled LLM consumer switch without exposing secrets."""
    try:
        configured = database_secret(setting_key)
    except Exception:
        configured = ""
    if not configured:
        configured = runtime_configuration_values().get(setting_key, "")
    if not text(configured):
        return default
    return text(configured).lower() in {"1", "true", "yes", "on", "enabled"}


def post_cloud_llm_json(settings: Dict[str, Any], endpoint: str,
                        payload: Dict[str, Any], timeout: Any):
    """Send one cloud-model request; callers handle each returned target independently."""
    read_timeout = max(180, integer(timeout, 180))
    try:
        return requests.post(
            endpoint, json=payload,
            headers={"Authorization": "Bearer " + settings["api_key"],
                     "Content-Type": "application/json"},
            # Fail a broken connection quickly while allowing model inference
            # enough time to complete. This does not retry or duplicate calls.
            timeout=(15, read_timeout),
        )
    except requests.ReadTimeout as exc:
        raise RuntimeError(
            f"{text(settings.get('provider')).title()} did not return the financial-resolution "
            f"response within {read_timeout} seconds. No value was changed."
        ) from exc


def financial_resolution_llm_request(settings: Dict[str, Any], messages: List[Dict[str, str]]) -> Dict[str, Any]:
    """Call an OpenAI-compatible provider or Ollama and normalize its response."""
    if settings["provider"] in {"bedrock", "gemini"}:
        endpoint = settings["base_url"].rstrip("/") + "/chat/completions"
        decision_schema = {
            "type": "object",
            "properties": {
                "can_resolve": {"type": "boolean"},
                "proposed_value": {"type": ["number", "null"]},
                "resolution_method": {"type": "string", "enum": ["DIRECT_EXTRACTION", "FORMULA_DERIVATION", "UNRESOLVED"]},
                "formula": {"type": "string"},
                "calculation": {
                    "type": "object",
                    "properties": {
                        "operation": {"type": "string", "enum": ["ADD", "SUM", "SUBTRACT", "NONE"]},
                        "operands": {"type": "array", "items": {"type": "object", "properties": {
                            "name": {"type": "string"}, "value": {"type": "number"}},
                            "required": ["name", "value"], "additionalProperties": False}},
                    },
                    "required": ["operation", "operands"], "additionalProperties": False,
                },
                "evidence": {"type": "array", "items": {"type": "object", "properties": {
                    "page_number": {"type": "integer"}, "quote": {"type": "string"}},
                    "required": ["page_number", "quote"], "additionalProperties": False}},
                "explanation": {"type": "string"},
                "confidence": {"type": "number"},
                "extracted_value_is_correct": {"type": "boolean"},
            },
            "required": ["can_resolve", "proposed_value", "resolution_method", "formula", "calculation",
                         "evidence", "explanation", "confidence", "extracted_value_is_correct"],
            "additionalProperties": False,
        }
        request_payload = {"model": settings["model"], "stream": False,
                           "messages": messages, "temperature": 0}
        if settings["provider"] == "bedrock":
            request_payload.update({
                "max_completion_tokens": 3000,
                "response_format": {"type": "json_schema", "json_schema": {
                    "name": "financial_fact_resolution", "strict": True,
                    "schema": decision_schema}},
            })
        else:
            request_payload.update({"max_tokens": integer(settings.get("max_output_tokens"), 8192),
                                    "response_format": {"type": "json_object"}})
        headers = {"Authorization": "Bearer " + settings["api_key"], "Content-Type": "application/json"}
    else:
        endpoint = settings["base_url"].rstrip("/") + "/api/chat"
        request_payload = {
            "model": settings["model"], "stream": False, "format": "json",
            "options": {"temperature": 0, "num_predict": 700}, "messages": messages,
        }
        headers = None
    started = dt.datetime.now(dt.timezone.utc)
    if settings["provider"] in {"bedrock", "gemini"}:
        response = post_cloud_llm_json(
            settings, endpoint, request_payload, settings["timeout_seconds"]
        )
    else:
        response = requests.post(endpoint, json=request_payload, headers=headers,
                                 timeout=settings["timeout_seconds"])
    elapsed = round((dt.datetime.now(dt.timezone.utc) - started).total_seconds(), 3)
    if settings["provider"] == "bedrock" and response.status_code == 401:
        request_id = text(response.headers.get("x-amzn-requestid") or response.headers.get("x-amz-request-id"))
        raise RuntimeError(
            "Amazon Bedrock rejected the bearer token (HTTP 401). The short-term key is expired, "
            "invalid, or belongs to a different regional session. Rotate fri_bedrock_api_key, "
            f"confirm region ap-southeast-2, restart the webapp, and retry. Credential source: "
            f"{settings.get('credential_source', 'UNKNOWN')}; AWS request ID: {request_id or 'not returned'}."
        )
    if settings["provider"] == "gemini" and response.status_code in {401, 403}:
        raise RuntimeError(
            "Google Gemini rejected the API key. Replace fri_gemini_api_key, confirm that the "
            "Gemini API is enabled for the key's Google project, restart the webapp, and retry. "
            f"Credential source: {settings.get('credential_source', 'UNKNOWN')}."
        )
    response.raise_for_status()
    body = response.json()
    if settings["provider"] in {"bedrock", "gemini"}:
        choices = body.get("choices") or []
        content = text(((choices[0].get("message") or {}).get("content")) if choices else "")
        finish_reason = text(choices[0].get("finish_reason") if choices else "").lower()
        if finish_reason in {"length", "max_tokens"}:
            raise ValueError(
                f"{settings['provider'].title()} response was truncated before completing its JSON. "
                "Increase the completion-token budget or reduce supplied evidence."
            )
    else:
        content = text((body.get("message") or {}).get("content"))
    if not content:
        raise ValueError(f"{settings['provider']} returned empty message content")
    return {"endpoint": endpoint, "request_payload": request_payload, "response_body": body,
            "response_contract": ("STRICT_JSON_SCHEMA" if settings.get("provider") == "bedrock"
                                  else "JSON_OBJECT" if settings.get("provider") == "gemini"
                                  else "OLLAMA_JSON"),
            "raw_content": content, "http_status": response.status_code, "elapsed_seconds": elapsed}


def ensure_fact_resolution_tables(connection) -> None:
    """Create a review/approval store separate from recipe-owned facts."""
    with connection.cursor() as cursor:
        cursor.execute("""
            CREATE SCHEMA IF NOT EXISTS financial_risk_intelligence;
            CREATE TABLE IF NOT EXISTS financial_risk_intelligence.financial_fact_resolution_proposals (
                proposal_id TEXT PRIMARY KEY, assessment_run_id TEXT NOT NULL,
                source_document_id TEXT NOT NULL, statement_type TEXT NOT NULL,
                concept_key TEXT NOT NULL, concept_label TEXT NOT NULL,
                period_role TEXT NOT NULL, period_label TEXT NOT NULL,
                proposed_value NUMERIC NOT NULL, currency TEXT, unit TEXT,
                resolution_method TEXT NOT NULL, formula TEXT,
                operands_json JSONB NOT NULL DEFAULT '[]'::jsonb,
                candidate_rows_json JSONB NOT NULL DEFAULT '[]'::jsonb,
                evidence_json JSONB NOT NULL DEFAULT '[]'::jsonb,
                explanation TEXT NOT NULL, confidence NUMERIC NOT NULL,
                validation_status TEXT NOT NULL, validation_message TEXT NOT NULL,
                model_name TEXT NOT NULL, prompt_json JSONB NOT NULL,
                response_json JSONB NOT NULL, status TEXT NOT NULL DEFAULT 'PENDING',
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), reviewed_at TIMESTAMPTZ,
                reviewed_by TEXT
            );
            CREATE TABLE IF NOT EXISTS financial_risk_intelligence.approved_financial_fact_overrides (
                override_id TEXT PRIMARY KEY, proposal_id TEXT NOT NULL UNIQUE,
                assessment_run_id TEXT NOT NULL, source_document_id TEXT NOT NULL,
                statement_type TEXT NOT NULL, concept_key TEXT NOT NULL,
                period_role TEXT NOT NULL, period_label TEXT NOT NULL,
                numeric_value NUMERIC NOT NULL, currency TEXT, unit TEXT,
                resolution_method TEXT NOT NULL, confidence NUMERIC NOT NULL,
                evidence_json JSONB NOT NULL DEFAULT '[]'::jsonb,
                approved_by TEXT NOT NULL, approved_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                active BOOLEAN NOT NULL DEFAULT TRUE,
                UNIQUE (assessment_run_id, source_document_id, concept_key, period_role)
            );
            ALTER TABLE financial_risk_intelligence.approved_financial_fact_overrides
                ADD COLUMN IF NOT EXISTS validated_rule_version TEXT;
            CREATE TABLE IF NOT EXISTS financial_risk_intelligence.financial_fact_resolution_jobs (
                job_key TEXT PRIMARY KEY, assessment_run_id TEXT NOT NULL,
                source_document_id TEXT NOT NULL, resolution_scope TEXT NOT NULL,
                status TEXT NOT NULL, requested_count INTEGER NOT NULL DEFAULT 0,
                saved_count INTEGER NOT NULL DEFAULT 0, unresolved_count INTEGER NOT NULL DEFAULT 0,
                result_json JSONB NOT NULL DEFAULT '{}'::jsonb,
                error_message TEXT, started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                completed_at TIMESTAMPTZ, updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                UNIQUE (assessment_run_id, source_document_id, resolution_scope)
            );
            CREATE TABLE IF NOT EXISTS financial_risk_intelligence.financial_input_validation_runs (
                validation_id TEXT PRIMARY KEY,
                assessment_run_id TEXT NOT NULL,
                source_document_id TEXT NOT NULL,
                file_name TEXT NOT NULL,
                validation_mode TEXT NOT NULL,
                status TEXT NOT NULL,
                requested_count INTEGER NOT NULL DEFAULT 0,
                saved_count INTEGER NOT NULL DEFAULT 0,
                unresolved_count INTEGER NOT NULL DEFAULT 0,
                values_json JSONB NOT NULL DEFAULT '[]'::jsonb,
                score_json JSONB NOT NULL DEFAULT '{}'::jsonb,
                details_json JSONB NOT NULL DEFAULT '{}'::jsonb,
                backend_build TEXT NOT NULL,
                saved_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                UNIQUE (assessment_run_id, source_document_id, validation_id)
            );
            ALTER TABLE financial_risk_intelligence.financial_fact_resolution_proposals
                ADD COLUMN IF NOT EXISTS candidate_rows_json JSONB NOT NULL DEFAULT '[]'::jsonb;
        """)


def save_financial_input_validation_run(validation_id: str, run_id: str, document_id: str,
                                        mode: str, status: str, requested_count: int,
                                        saved_count: int, unresolved_count: int,
                                        score: Dict[str, Any], details: Dict[str, Any]) -> Dict[str, Any]:
    """Persist one report-bound validation result before the UI is refreshed."""
    snapshot = load_analysis_history_snapshot(run_id, document_id)
    values = list(snapshot.get("values") or [])
    registration = registration_lookup().get(document_id, {})
    file_name = text(registration.get("file_name")) or document_id
    with postgres_connection() as connection:
        ensure_fact_resolution_tables(connection)
        with connection.cursor() as cursor:
            cursor.execute("""INSERT INTO financial_risk_intelligence.financial_input_validation_runs
                (validation_id,assessment_run_id,source_document_id,file_name,validation_mode,status,
                 requested_count,saved_count,unresolved_count,values_json,score_json,details_json,backend_build,saved_at)
                VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s::jsonb,%s::jsonb,%s::jsonb,%s,NOW())
                ON CONFLICT (validation_id) DO UPDATE SET
                 file_name=EXCLUDED.file_name,validation_mode=EXCLUDED.validation_mode,status=EXCLUDED.status,
                 requested_count=EXCLUDED.requested_count,saved_count=EXCLUDED.saved_count,
                 unresolved_count=EXCLUDED.unresolved_count,values_json=EXCLUDED.values_json,
                 score_json=EXCLUDED.score_json,details_json=EXCLUDED.details_json,
                 backend_build=EXCLUDED.backend_build,saved_at=NOW()""",
                (validation_id,run_id,document_id,file_name,mode,status,
                 integer(requested_count,0),integer(saved_count,0),integer(unresolved_count,0),
                 json.dumps(values,default=str),json.dumps(score or {},default=str),
                 json.dumps(details or {},default=str),BACKEND_BUILD_ID))
    return {"validation_id": validation_id, "file_name": file_name,
            "persisted_value_count": len(values), "saved_at": dt.datetime.now(dt.timezone.utc).isoformat()}


def resolution_job_identity(run_id: str, document_id: str, target_concepts: Any) -> Tuple[str, str]:
    concepts = sorted({text(item) for item in (target_concepts or []) if text(item)})
    scope = "ALL_MISSING_VALUES" if not concepts else "CONCEPTS:" + ",".join(concepts)
    # v2 invalidates the earlier job guard that could incorrectly cache a
    # terminal result while score-critical concepts were still unresolved.
    return hashlib.sha256(f"resolution-v2|{run_id}|{document_id}|{scope}".encode("utf-8")).hexdigest(), scope


def begin_resolution_job(run_id: str, document_id: str, target_concepts: Any) -> Dict[str, Any]:
    job_key, scope = resolution_job_identity(run_id, document_id, target_concepts)
    with postgres_connection() as connection:
        ensure_fact_resolution_tables(connection)
        with connection.cursor() as cursor:
            # Never leave the UI waiting on a duplicate verification request.
            # A non-blocking lock lets the caller receive a clear RUNNING
            # response while the first selected-report job completes.
            cursor.execute("SELECT pg_try_advisory_xact_lock(hashtext(%s))",
                           (f"{run_id}|{document_id}|{scope}",))
            lock_row = cursor.fetchone()
            if not lock_row or not bool(lock_row[0]):
                return {"job_key": job_key, "scope": scope, "running": True}
            # Scope is the durable identity. Looking it up directly also lets
            # newer backend versions safely adopt rows created with an older
            # hash without violating the table's run/document/scope unique key.
            cursor.execute("""SELECT job_key,status,result_json,error_message,started_at
                                 FROM financial_risk_intelligence.financial_fact_resolution_jobs
                                WHERE assessment_run_id=%s AND source_document_id=%s
                                  AND resolution_scope=%s FOR UPDATE""",
                           (run_id, document_id, scope))
            row = cursor.fetchone()
            if row:
                job_key = text(row[0])
            saved_result = (row[2] or {}) if row else {}
            completed_is_valid = (
                row and row[1] == "COMPLETED"
                and (saved_result.get("status") == "NO_MISSING_VALUES"
                     or saved_result.get("critical_unresolved_count") == 0)
            )
            if completed_is_valid:
                return {"job_key": job_key, "scope": scope, "reuse": True, "result": saved_result}
            # A live duplicate request is skipped. A worker interrupted by a
            # restart may be reclaimed after 30 minutes instead of remaining
            # permanently stuck in RUNNING.
            running_age = ((dt.datetime.now(dt.timezone.utc) - row[4]).total_seconds()
                           if row and row[4] else None)
            if row and row[1] == "RUNNING" and running_age is not None and running_age < 1800:
                return {"job_key": job_key, "scope": scope, "running": True}
            if row:
                cursor.execute("""UPDATE financial_risk_intelligence.financial_fact_resolution_jobs
                                      SET status='RUNNING',error_message=NULL,result_json='{}'::jsonb,
                                          started_at=NOW(),completed_at=NULL,updated_at=NOW()
                                    WHERE job_key=%s""", (job_key,))
            else:
                cursor.execute("""INSERT INTO financial_risk_intelligence.financial_fact_resolution_jobs
                                      (job_key,assessment_run_id,source_document_id,resolution_scope,status,started_at,updated_at)
                                   VALUES (%s,%s,%s,%s,'RUNNING',NOW(),NOW())""",
                               (job_key, run_id, document_id, scope))
    return {"job_key": job_key, "scope": scope, "reuse": False}


def finish_resolution_job(job_key: str, status: str, payload: Dict[str, Any], error: str = "") -> None:
    with postgres_connection() as connection:
        ensure_fact_resolution_tables(connection)
        with connection.cursor() as cursor:
            cursor.execute("""UPDATE financial_risk_intelligence.financial_fact_resolution_jobs
                                  SET status=%s,requested_count=%s,saved_count=%s,unresolved_count=%s,
                                      result_json=%s::jsonb,error_message=%s,completed_at=CASE WHEN %s='COMPLETED' THEN NOW() ELSE NULL END,
                                      updated_at=NOW() WHERE job_key=%s""",
                           (status, integer(payload.get("requested_count"), 0), integer(payload.get("saved_count"), 0),
                            integer(payload.get("unresolved_count"), 0), json.dumps(payload, default=str),
                            error or None, status, job_key))


def approved_fact_overrides(run_id: str, document_id: str) -> List[Dict[str, Any]]:
    try:
        with postgres_connection() as connection:
            ensure_fact_resolution_tables(connection)
            with connection.cursor() as cursor:
                cursor.execute("""SELECT concept_key,period_role,period_label,numeric_value,
                                          resolution_method,confidence,approved_by,approved_at,
                                          validated_rule_version
                                     FROM financial_risk_intelligence.approved_financial_fact_overrides
                                    WHERE assessment_run_id=%s AND source_document_id=%s AND active=TRUE""",
                               (run_id, document_id))
                rows = cursor.fetchall()
        return [{"concept_key": r[0], "period_role": r[1], "period_label": r[2],
                 "numeric_value": float(r[3]), "resolution_method": r[4], "confidence": float(r[5]),
                 "approved_by": r[6], "approved_at": r[7].isoformat() if r[7] else "",
                 "validated_rule_version": text(r[8]),
                 "mapping_version_current": active_financial_validation_version(r[0]),
                 "requires_revalidation": text(r[8]) != active_financial_validation_version(r[0])}
                for r in rows]
    except Exception as exc:
        print("FACT OVERRIDE READ FAILED:", type(exc).__name__, exc)
        return []


def apply_approved_fact_overrides_to_frame(frame: pd.DataFrame) -> pd.DataFrame:
    """Overlay every active governed value before any report consumer reads facts."""
    if frame.empty or "concept_key" not in frame.columns:
        return frame
    try:
        with postgres_connection() as connection:
            ensure_fact_resolution_tables(connection)
            with connection.cursor() as cursor:
                cursor.execute("""SELECT assessment_run_id,source_document_id,concept_key,period_role,
                                          period_label,numeric_value,resolution_method,confidence,approved_by,approved_at,
                                          validated_rule_version
                                     FROM financial_risk_intelligence.approved_financial_fact_overrides
                                    WHERE active=TRUE""")
                overrides = cursor.fetchall()
    except Exception as exc:
        print("GLOBAL FACT OVERRIDE READ FAILED:", type(exc).__name__, exc)
        return frame
    if not overrides:
        return frame
    result = frame.copy()
    run_column = "assessment_run_id" if "assessment_run_id" in result.columns else "run_id" if "run_id" in result.columns else ""
    if not run_column or "source_document_id" not in result.columns:
        return result
    for run_id, document_id, concept_key, role, period_label, numeric_value, method, confidence, approved_by, approved_at, validated_rule_version in overrides:
        active_rule_version = active_financial_validation_version(concept_key)
        if not validated_rule_version or text(validated_rule_version) != active_rule_version:
            # Preserve the row for audit, but never let a stale mapping-version
            # override replace newly extracted facts. The validation pipeline
            # will re-evaluate and supersede only this concept/period.
            continue
        role = text(role).lower()
        value_column = role + "_value"
        period_column = role + "_period"
        if role not in {"current", "prior"} or value_column not in result.columns:
            continue
        mask = (result[run_column].astype(str) == text(run_id))
        mask &= (result["source_document_id"].astype(str) == text(document_id))
        mask &= (result["concept_key"].astype(str) == text(concept_key))
        if not mask.any():
            continue
        result.loc[mask, value_column] = float(numeric_value)
        if period_column in result.columns and text(period_label):
            result.loc[mask, period_column] = text(period_label)
        if "resolution_method" in result.columns:
            result.loc[mask, "resolution_method"] = text(method)
        if "value_status" in result.columns:
            result.loc[mask, "value_status"] = "AI_APPROVED"
        if "confidence" in result.columns:
            result.loc[mask, "confidence"] = float(confidence)
        if "approved_by" in result.columns:
            result.loc[mask, "approved_by"] = text(approved_by)
        if "approved_at" in result.columns:
            result.loc[mask, "approved_at"] = approved_at.isoformat() if approved_at else ""
    return result


def apply_fact_overrides(tables: List[Dict[str, Any]], overrides: List[Dict[str, Any]]) -> None:
    lookup = {(text(x["concept_key"]), text(x["period_role"])): x for x in overrides}
    for table in tables:
        for row in table.get("rows", []):
            for role in ("current", "prior"):
                override = lookup.get((text(row.get("concept_key")), role))
                if not override:
                    continue
                value = row.setdefault("values", {}).setdefault(role, {})
                value.update({"period": override["period_label"] or value.get("period", ""),
                              "numeric_value": override["numeric_value"], "raw_text": str(override["numeric_value"]),
                              "value_status": "AI_APPROVED", "resolution_method": override["resolution_method"],
                              "confidence": override["confidence"], "approved_by": override["approved_by"],
                              "approved_at": override["approved_at"]})
                row["resolution_method"] = override["resolution_method"]
                row["confidence"] = override["confidence"]


def period_from(row: Dict[str, Any]) -> str:
    configured = text(
        row.get("period_label")
        or row.get("period_end")
        or row.get("current_period")
        or row.get("prior_period")
    )

    years = re.findall(
        r"\b(?:19|20)\d{2}\b",
        configured,
    )

    return years[-1] if years else configured


def scope_from(row: Dict[str, Any]) -> str:
    scope = text(
        row.get("entity_scope")
        or row.get("scope")
        or row.get("group_scope")
    ).upper()

    return scope or "GROUP"


def is_total(label: str) -> bool:
    return bool(
        re.search(
            r"(^total\b|^net\b|profit before tax|net profit)",
            label.lower().strip(),
        )
    )


def build_tables(
    rows: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    grouped = collections.defaultdict(list)

    for row in rows:
        statement = canonical_statement(
            row.get("statement_type")
        )

        if statement not in PRIMARY_STATEMENTS:
            continue

        numeric_value = number(
            row.get("numeric_value")
        )

        value_status = text(
            row.get("value_status")
        ).upper()

        if numeric_value is None and value_status not in {
            "NOT_REPORTED",
            "DERIVED",
        }:
            continue

        key = text(
            row.get("table_artifact_id")
            or row.get("source_table_id")
            or row.get("table_id")
        )

        if key:
            grouped[key].append(row)

    tables = []

    for key, values in grouped.items():
        first = values[0]

        statement_type = canonical_statement(
            first.get("statement_type")
        )

        columns_by_key = {}
        rows_by_index = {}

        for value in values:
            column_index = integer(
                value.get("column_index"),
                -1,
            )

            period = period_from(value)
            scope = scope_from(value)

            column_key = (
                f"{column_index}|{scope}|{period}"
            )

            columns_by_key.setdefault(
                column_key,
                {
                    "column_key": column_key,
                    "column_index": column_index,
                    "scope": scope,
                    "period": period,
                    "display_scope": (
                        "Group"
                        if scope == "GROUP"
                        else scope.title()
                    ),
                    "display_period": (
                        period
                        or f"Column {column_index}"
                    ),
                },
            )

            row_index = integer(
                value.get("row_index"),
                -1,
            )

            if row_index < 0:
                continue

            label = text(
                value.get("row_label")
                or value.get("field_label")
                or value.get("concept_label")
            )

            item = rows_by_index.setdefault(
                row_index,
                {
                    "row_index": row_index,
                    "row_label": label,
                    "statement_section": text(
                        value.get("statement_section")
                    ),
                    "is_total": bool(
                        value.get("is_total")
                    ) or is_total(label),
                    "values": {},
                    "confidence": 0.0,
                },
            )

            item["values"][column_key] = {
                "raw_text": text(
                    value.get("raw_value")
                    or value.get("raw_text")
                ),
                "numeric_value": number(
                    value.get("numeric_value")
                ),
                "value_status": text(
                    value.get("value_status")
                ),
                "selection_method": text(
                    value.get("selection_method")
                ),
                "source_row_label": text(
                    value.get("source_row_label")
                ),
                "column_index": column_index,
                "scope": scope,
                "period": period,
            }

            confidence = number(
                value.get("extraction_confidence")
                or value.get("confidence")
            )

            if confidence is not None:
                item["confidence"] = max(
                    item["confidence"],
                    confidence,
                )

        tables.append(
            {
                "table_artifact_id": key,
                "source_table_id": text(
                    first.get("source_table_id")
                ),
                "statement_type": statement_type,
                "table_title": text(
                    first.get("statement_title")
                    or first.get("table_title")
                ),
                "page_number": integer(
                    first.get("page_number"),
                    0,
                ),
                "validation_status": text(
                    first.get("normalization_status")
                    or first.get("validation_status")
                ),
                "classification_method": text(
                    first.get("classification_method")
                ),
                "model_name": text(
                    first.get("model_name")
                ),
                "currency": text(
                    first.get("currency")
                ),
                "unit": text(
                    first.get("unit")
                ),
                "columns": sorted(
                    columns_by_key.values(),
                    key=lambda item: (
                        item["column_index"],
                        item["scope"],
                        item["period"],
                    ),
                ),
                "rows": sorted(
                    rows_by_index.values(),
                    key=lambda item: item["row_index"],
                ),
            }
        )

    return tables


def build_resolved_tables(
    rows: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """Convert resolver outputs (current_value/prior_value) into UI tables."""
    income_keys = {
        "revenue", "total_income", "cost_of_goods_sold", "sg_and_a_expense",
        "depreciation_amortization", "operating_income_ebit", "interest_expense",
        "net_profit", "profit_before_tax", "net_interest_income", "non_interest_income",
        "operating_expenses", "provisions_impairment",
    }
    cash_keys = {"operating_cash_flow", "investing_cash_flow", "financing_cash_flow",
                 "net_change_cash", "ending_cash"}
    grouped = collections.defaultdict(list)
    for row in rows:
        statement_type = canonical_statement(row.get("statement_type"))
        if statement_type not in {"BALANCE_SHEET", "INCOME_STATEMENT", "CASH_FLOW_STATEMENT"}:
            concept_key = text(row.get("concept_key"))
            statement_type = ("CASH_FLOW_STATEMENT" if concept_key in cash_keys
                              else "INCOME_STATEMENT" if concept_key in income_keys
                              else "BALANCE_SHEET")
        if statement_type in {"BALANCE_SHEET", "INCOME_STATEMENT", "CASH_FLOW_STATEMENT"}:
            grouped[statement_type].append(row)

    tables = []
    for statement_type, statement_rows in grouped.items():
        first = statement_rows[0]
        current_period = text(first.get("current_period")) or "Current period"
        prior_period = text(first.get("prior_period")) or "Prior period"
        output_rows = []

        for index, row in enumerate(statement_rows):
            label = text(
                row.get("field_label")
                or row.get("concept_label")
                or row.get("concept_key")
            )
            output_rows.append({
                "row_index": index,
                "row_label": label,
                "concept_key": text(row.get("concept_key")),
                "canonical_label": text(row.get("canonical_label")),
                "resolution_method": text(row.get("resolution_method")),
                "confidence": number(row.get("confidence") or row.get("extraction_confidence")),
                "statement_section": statement_type,
                "is_total": bool(re.search(
                    r"(^total\b|^net\b|profit before tax|net profit)",
                    label.lower(),
                )),
                "values": {
                    "current": {
                        "column_index": 0,
                        "scope": "GROUP",
                        "period": current_period,
                        "numeric_value": number(row.get("current_value")),
                        "raw_text": text(row.get("current_value")),
                        "value_status": text(row.get("resolution_method")),
                    },
                    "prior": {
                        "column_index": 1,
                        "scope": "GROUP",
                        "period": prior_period,
                        "numeric_value": number(row.get("prior_value")),
                        "raw_text": text(row.get("prior_value")),
                        "value_status": text(row.get("resolution_method")),
                    },
                },
            })

        tables.append({
            "table_artifact_id": statement_type.lower() + "_resolved",
            "source_table_id": "",
            "statement_type": statement_type,
            "table_title": (
                "Resolved Income Statement"
                if statement_type == "INCOME_STATEMENT"
                else "Resolved Balance Sheet"
                if statement_type == "BALANCE_SHEET"
                else "Resolved Cash-flow Statement"
            ),
            "page_number": 0,
            "currency": text(first.get("currency")),
            "unit": text(first.get("unit")),
            "columns": [
                {
                    "column_key": "current",
                    "column_index": 0,
                    "scope": "GROUP",
                    "period": current_period,
                    "display_scope": "Group",
                    "display_period": current_period,
                },
                {
                    "column_key": "prior",
                    "column_index": 1,
                    "scope": "GROUP",
                    "period": prior_period,
                    "display_scope": "Group",
                    "display_period": prior_period,
                },
            ],
            "rows": output_rows,
        })

    return tables


@app.route("/api/export-dataset", methods=["GET"])
def export_dataset():
    """Download one allowlisted Dataiku dataset as CSV."""
    name = text(request.args.get("name"))
    if name not in DATASETS_TO_EXPORT:
        return jsonify({"error": "Dataset is not allowlisted", "dataset": name}), 400
    try:
        frame = dataiku.Dataset(name).get_dataframe(infer_with_pandas=True)
        payload = io.BytesIO(frame.to_csv(index=False).encode("utf-8-sig"))
        return send_file(payload, mimetype="text/csv; charset=utf-8", as_attachment=True,
                         download_name=name + ".csv")
    except Exception as exc:
        return jsonify({"error": type(exc).__name__ + ": " + str(exc), "dataset": name}), 500


@app.route("/api/export-dataset-list", methods=["GET"])
def export_dataset_list():
    return jsonify({"datasets": DATASETS_TO_EXPORT})


@app.route("/api/health", methods=["GET"])
def health():
    values, source = resolved_values()

    statement_counts = {}

    if not values.empty and "statement_type" in values.columns:
        statement_counts = {
            str(key): int(value)
            for key, value in values["statement_type"]
            .map(canonical_statement)
            .value_counts()
            .to_dict()
            .items()
        }

    return jsonify(
        {
            "status": "ok",
            "backend_build": BACKEND_BUILD_ID,
            "data_source": source,
            "row_count": int(len(values)),
            "statement_counts": statement_counts,
            "ollama": ollama_status(probe=True),
        }
    )


@app.route("/api/report-session/reset", methods=["POST"])
@json_api_errors
def reset_report_session():
    """Clear transient report caches without deleting governed database facts."""
    payload = request.get_json(silent=True) or {}
    run_id = text(payload.get("assessment_run_id"))
    document_id = text(payload.get("source_document_id"))
    if not document_id:
        return jsonify({"error": "source_document_id is required"}), 400
    removed_pdf_cache = 0
    with SELECTED_PDF_TEXT_CACHE_LOCK:
        for cache_key in list(SELECTED_PDF_TEXT_CACHE):
            if cache_key.startswith(document_id + "|"):
                SELECTED_PDF_TEXT_CACHE.pop(cache_key, None)
                removed_pdf_cache += 1
    removed_jobs = 0
    with AUTO_RESOLUTION_LOCK:
        for job_id, state in list(AUTO_RESOLUTION_STATE.items()):
            if (text(state.get("source_document_id")) == document_id
                    and (not run_id or text(state.get("assessment_run_id")) == run_id)
                    and text(state.get("status")) not in {"QUEUED", "RUNNING"}):
                AUTO_RESOLUTION_STATE.pop(job_id, None)
                removed_jobs += 1
    return jsonify({
        "status": "TRANSIENT_REPORT_STATE_CLEARED",
        "assessment_run_id": run_id, "source_document_id": document_id,
        "removed_pdf_cache_entries": removed_pdf_cache,
        "removed_completed_jobs": removed_jobs,
        "database_records_preserved": True,
        "backend_build": BACKEND_BUILD_ID,
    })


@app.route("/api/contexts", methods=["GET"])
@json_api_errors
def contexts():
    try:
        values, source = resolved_values()
    except Exception as exc:
        # The UI expects JSON even when an optional/stale dataset has a
        # schema/path problem. Keep the diagnostic visible in the response
        # instead of returning Flask's HTML 500 page.
        print(f"/api/contexts failed: {type(exc).__name__}: {exc}")
        return jsonify({
            "contexts": [],
            "data_source": "ERROR",
            "error": f"{type(exc).__name__}: {exc}",
        }), 200

    # A template build may be empty while canonical facts are already
    # available. Use canonical/standardized rows to keep the context selector
    # usable and expose the real upstream state instead of a false "no live
    # data" message.
    if values.empty:
        fallback = read_optional(CANONICAL_FACTS_DATASET)
        if fallback.empty:
            fallback = read_optional(STANDARDIZED_VALUES_DATASET)
        if not fallback.empty:
            values = normalize_resolved_shape(fallback.copy())
            source = source + "+CONTEXT_FALLBACK"

    if values.empty:
        # Database-saved analyses remain valid selector entries even when the
        # transient uploaded_reports registration has been cleared. This is
        # the durable history behaviour used by the earlier application.
        history_contexts = retained_analysis_history_contexts()
        return jsonify(
            {
                "contexts": history_contexts,
                "data_source": source + ("+POSTGRES_HISTORY" if history_contexts else ""),
                "message": (
                    "No live resolved statement values are available."
                ),
            }
        )

    # Backfill any completed runs already present in Dataiku before this
    # persistent-history version was deployed. Failure does not hide live runs.
    try:
        capture_completed_analysis_runs()
    except Exception as exc:
        print(f"Analysis history backfill failed: {type(exc).__name__}: {exc}")

    registrations = registration_lookup()
    uploaded_names = {}
    uploaded_names_by_run = {}
    uploaded_document_ids = set()
    upload_inventory_available = False
    display_names = report_display_filename_lookup()
    try:
        with postgres_connection() as connection:
            with connection.cursor() as cursor:
                cursor.execute("SELECT source_document_id, assessment_run_id, file_name FROM financial_risk_intelligence.uploaded_reports")
                upload_rows = list(cursor.fetchall())
                try:
                    cursor.execute("""SELECT DISTINCT source_document_id, assessment_run_id, file_name
                                         FROM financial_risk_intelligence.webapp_report_evidence""")
                    upload_rows.extend(cursor.fetchall())
                except Exception:
                    connection.rollback()
                try:
                    cursor.execute("""SELECT source_document_id, assessment_run_id,
                                                context_json ->> 'file_name' AS file_name
                                           FROM financial_risk_intelligence.webapp_analysis_history
                                          WHERE COALESCE(context_json ->> 'file_name', '') <> ''""")
                    upload_rows.extend(cursor.fetchall())
                except Exception:
                    connection.rollback()
                uploaded_name_sets = collections.defaultdict(set)
                uploaded_run_name_sets = collections.defaultdict(set)
                for source_id, upload_run, filename in upload_rows:
                    source_key, run_key = text(source_id), text(upload_run)
                    clean_name = Path(text(filename)).name
                    if source_key:
                        uploaded_document_ids.add(source_key)
                    if source_key and clean_name:
                        uploaded_name_sets[source_key].add(clean_name)
                    if run_key and clean_name:
                        uploaded_run_name_sets[run_key].add(clean_name)
                uploaded_names = {
                    source_id: next(iter(file_names))
                    for source_id, file_names in uploaded_name_sets.items()
                    if len(file_names) == 1
                }
                uploaded_names_by_run = {
                    run_id: next(iter(file_names))
                    for run_id, file_names in uploaded_run_name_sets.items()
                    if len(file_names) == 1
                }
                upload_inventory_available = True
    except Exception as exc:
        print(f"Uploaded-report inventory unavailable: {type(exc).__name__}: {exc}", flush=True)
        uploaded_names = {}
        uploaded_names_by_run = {}
        uploaded_document_ids = set()
        upload_inventory_available = False
    contexts_by_key = {}

    def usable_report_name(value: Any) -> str:
        candidate = Path(text(value)).name
        if not candidate or re.fullmatch(r"[0-9a-f-]{32,36}", candidate, re.IGNORECASE):
            return ""
        return candidate

    for row in values.to_dict(orient="records"):
        run_id = text(
            row.get("assessment_run_id")
            or row.get("run_id")
        )

        document_id = text(
            row.get("source_document_id")
        )

        if not run_id or not document_id:
            continue

        registration = registrations.get(
            document_id,
            {},
        )

        # uploaded_reports is the report-selector inventory. Resolved-value
        # datasets and webapp history can outlive a deleted upload and must not
        # resurrect it in the dropdown. A legacy derived document id remains
        # valid only when its run maps unambiguously to a retained upload.
        retained_upload_name = (
            uploaded_names.get(document_id)
            or uploaded_names_by_run.get(run_id)
        )
        if upload_inventory_available and not retained_upload_name:
            # Resolved Dataiku datasets can outlive a deliberately deleted
            # report. They are calculation sources, not dropdown inventory,
            # and must not resurrect deleted entries.
            continue
        if not upload_inventory_available:
            retained_upload_name = usable_report_name(registration.get("file_name"))

        key = f"{run_id}|{document_id}"
        context = contexts_by_key.setdefault(
            key,
            {
                "context_id": key,
                "tenant_id": text(
                    row.get("tenant_id")
                ),
                "entity_id": text(
                    row.get("entity_id")
                ),
                "entity_name": (
                    registration.get("entity_key")
                    or text(row.get("entity_id"))
                    or "Unknown entity"
                ),
                "assessment_run_id": run_id,
                "source_document_id": document_id,
                "file_name": (
                    usable_report_name(retained_upload_name)
                    or usable_report_name(registration.get("file_name"))
                    or usable_report_name(row.get("source_file_name"))
                    or usable_report_name(display_names["by_pair"].get((run_id, document_id)))
                    or usable_report_name(display_names["by_document"].get(document_id))
                    or usable_report_name(display_names["by_run"].get(run_id))
                    or document_id
                ),
                "tenant_key": registration.get(
                    "tenant_key",
                    "",
                ),
                "sector_key": "",
                "sector_name": "",
                "value_count": 0,
                "data_source": source,
                "document_binding": "EXACT_SOURCE_DOCUMENT_ID",
                "run_timestamp": (
                    text(row.get("resolved_at") or row.get("created_at") or row.get("scored_at"))
                    or registration.get("registered_at")
                ),
                "_sector_rows": [],
            },
        )
        context["_sector_rows"].append(row)
        context["value_count"] += 1

    for context in contexts_by_key.values():
        try:
            sector = infer_sector(context.pop("_sector_rows", []))
        except Exception as exc:
            print(f"/api/contexts sector inference failed: {type(exc).__name__}: {exc}")
            sector = {"sector_key": "manufacturing", "sector_name": "Manufacturing & Industrials"}
        context["sector_key"] = sector["sector_key"]
        context["sector_name"] = sector["sector_name"]

    for historical in retained_analysis_history_contexts():
        key = text(historical.get("context_id")) or f"{text(historical.get('assessment_run_id'))}|{text(historical.get('source_document_id'))}"
        historical_document_id = text(historical.get("source_document_id"))
        historical_run_id = text(historical.get("assessment_run_id"))
        retained_upload_name = (
            uploaded_names.get(historical_document_id)
            or uploaded_names_by_run.get(historical_run_id)
        )
        if upload_inventory_available and not retained_upload_name:
            continue
        if key:
            if retained_upload_name:
                historical["file_name"] = usable_report_name(retained_upload_name) or historical_document_id
                historical["display_name_binding"] = (
                    "EXACT_SOURCE_DOCUMENT_ID"
                    if historical_document_id in uploaded_names
                    else "UNIQUE_ASSESSMENT_RUN_ID_DISPLAY_ONLY"
                )
            contexts_by_key.setdefault(key, historical)

    return jsonify(
        {
            "contexts": sorted(
                contexts_by_key.values(),
                key=lambda item: (
                    item.get("run_timestamp", ""),
                    item["assessment_run_id"],
                ),
                reverse=True,
            ),
            "data_source": source,
        }
    )


@app.route("/api/reports/<source_document_id>", methods=["DELETE"])
@json_api_errors
def delete_report_records(source_document_id: str):
    """Delete only database rows bound to one uploaded report.

    The frontend has always called this route from its Clear records control.
    Discovering tables by the governed source_document_id column keeps the
    handler compatible with optional schema additions and prevents unrelated
    runtime/configuration rows from being removed.
    """
    import psycopg2.sql

    document_id = text(source_document_id)
    if not document_id:
        return jsonify({"error": "source_document_id is required"}), 400

    deleted_rows: Dict[str, int] = {}
    skipped_tables: Dict[str, str] = {}
    with postgres_connection() as connection:
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT DISTINCT table_name
                  FROM information_schema.columns
                 WHERE table_schema = 'financial_risk_intelligence'
                   AND column_name = 'source_document_id'
            """)
            discovered = {text(row[0]) for row in cursor.fetchall() if text(row[0])}

            # Child/review records are removed before report registration and
            # evidence records. Optional tables follow deterministically.
            preferred_order = [
                "approved_financial_fact_overrides",
                "financial_fact_resolution_proposals",
                "financial_fact_resolution_jobs",
                "financial_input_validation_runs",
                "forensic_narrative_versions",
                "webapp_analysis_history",
                "report_evidence",
                "uploaded_reports",
            ]
            ordered_tables = [name for name in preferred_order if name in discovered]
            ordered_tables.extend(sorted(discovered.difference(ordered_tables)))

            for index, table_name in enumerate(ordered_tables):
                savepoint = f"delete_report_{index}"
                cursor.execute(psycopg2.sql.SQL("SAVEPOINT {}").format(
                    psycopg2.sql.Identifier(savepoint)
                ))
                try:
                    cursor.execute(
                        psycopg2.sql.SQL(
                            "DELETE FROM financial_risk_intelligence.{} "
                            "WHERE source_document_id = %s"
                        ).format(psycopg2.sql.Identifier(table_name)),
                        (document_id,),
                    )
                    deleted_rows[table_name] = int(cursor.rowcount or 0)
                    cursor.execute(psycopg2.sql.SQL("RELEASE SAVEPOINT {}").format(
                        psycopg2.sql.Identifier(savepoint)
                    ))
                except Exception as exc:
                    cursor.execute(psycopg2.sql.SQL("ROLLBACK TO SAVEPOINT {}").format(
                        psycopg2.sql.Identifier(savepoint)
                    ))
                    skipped_tables[table_name] = f"{type(exc).__name__}: {exc}"
                    cursor.execute(psycopg2.sql.SQL("RELEASE SAVEPOINT {}").format(
                        psycopg2.sql.Identifier(savepoint)
                    ))

    with SELECTED_PDF_TEXT_CACHE_LOCK:
        for cache_key in list(SELECTED_PDF_TEXT_CACHE):
            if cache_key.startswith(document_id + "|"):
                SELECTED_PDF_TEXT_CACHE.pop(cache_key, None)

    return jsonify({
        "status": "REPORT_RECORDS_CLEARED",
        "source_document_id": document_id,
        "deleted_rows": deleted_rows,
        "deleted_count": sum(deleted_rows.values()),
        "skipped_tables": skipped_tables,
        "runtime_settings_preserved": True,
        "backend_build": BACKEND_BUILD_ID,
    })


@app.route("/api/statements", methods=["GET"])
def statements():
    run_id = text(
        request.args.get("assessment_run_id")
    )

    document_id = text(
        request.args.get("source_document_id")
    )

    if not run_id or not document_id:
        return jsonify(
            {
                "error": (
                    "assessment_run_id and "
                    "source_document_id are required"
                ),
            }
        ), 400

    values, source = resolved_values()
    table_validation = validated_table_lookup(document_id)
    raw_tables = raw_validated_tables(document_id)

    selected = [
        row
        for row in values.to_dict(orient="records")
        if text(
            row.get("assessment_run_id")
            or row.get("run_id")
        ) == run_id
        and text(
            row.get("source_document_id")
        ) == document_id
    ]

    if not selected:
        snapshot = load_analysis_history_snapshot(run_id, document_id)
        selected = list(snapshot.get("values") or [])
        if selected:
            source = "POSTGRES_ANALYSIS_HISTORY"

    inferred = infer_sector(selected)
    selected = rows_for_inferred_sector(selected, inferred["sector_key"])

    if table_validation["available"] and not source.startswith("SECTOR_TEMPLATE_DB_RULES"):
        valid_ids = table_validation["valid_table_ids"]
        validated_selected = [
            row for row in selected
            if text(row.get("table_artifact_id") or row.get("source_table_id")) in valid_ids
        ]
        # Resolver/template and PostgreSQL-history rows frequently have no raw
        # table ID. Do not erase a valid run-scoped statement merely because
        # the raw-table validation layer cannot join to those derived rows.
        if validated_selected:
            selected = validated_selected
        elif selected:
            source += "+RUN_SCOPED_HISTORY_FALLBACK"

    if any(
        number(row.get("current_value")) is not None
        or number(row.get("prior_value")) is not None
        for row in selected
    ):
        tables = build_resolved_tables(selected)
    else:
        tables = build_tables(selected)

    overrides = approved_fact_overrides(run_id, document_id)
    apply_fact_overrides(tables, overrides)

    display_order = {
        "BALANCE_SHEET": 1,
        "INCOME_STATEMENT": 2,
        "CASH_FLOW_STATEMENT": 3,
    }

    tables.sort(
        key=lambda item: (
            display_order.get(
                item["statement_type"],
                9,
            ),
            item["page_number"],
            item["table_artifact_id"],
        )
    )

    statement_counts = collections.Counter(
        table["statement_type"]
        for table in tables
    )

    return jsonify(
        {
            "tables": tables,
            "table_count": int(len(tables)),
            "row_count": int(
                sum(len(table["rows"]) for table in tables)
            ),
            "statement_counts": {
                str(key): int(value)
                for key, value in statement_counts.items()
            },
            "data_source": source,
            "approved_override_count": len(overrides),
            "raw_tables": raw_tables,
            "table_validation": {
                key: value for key, value in table_validation.items()
                if key != "valid_table_ids"
            },
            "ollama": ollama_status(),
        }
    )


@app.route("/api/financial-fact-resolution/propose", methods=["POST"])
@json_api_errors
def propose_financial_fact_resolution():
    request_started = dt.datetime.now(dt.timezone.utc)
    payload = request.get_json(silent=True) or {}
    run_id, document_id = text(payload.get("assessment_run_id")), text(payload.get("source_document_id"))
    concept_key, role = text(payload.get("concept_key")), text(payload.get("period_role")).lower()
    validation_mode = bool(payload.get("validation_mode"))
    if not run_id or not document_id or not concept_key or role not in {"current", "prior"}:
        return jsonify({"error": "assessment_run_id, source_document_id, concept_key and current/prior period_role are required"}), 400
    values, _ = resolved_values()
    selected = [r for r in values.to_dict(orient="records")
                if text(r.get("assessment_run_id") or r.get("run_id")) == run_id
                and text(r.get("source_document_id")) == document_id]
    # A user can open a completed report after recipe datasets have rotated.
    # In that case the authoritative run snapshot remains eligible for a
    # single-cell "Not reported" resolution.
    if not selected:
        selected = list(load_analysis_history_snapshot(run_id, document_id).get("values") or [])
    tables = build_resolved_tables(selected)
    # Historical extraction snapshots predate later LLM approvals. Overlay the
    # active governed values explicitly so this review agrees with Financial
    # Inputs and the scoring engine even when PostgreSQL history is the source.
    overrides = approved_fact_overrides(run_id, document_id)
    apply_fact_overrides(tables, overrides)
    target_table = target_row = target_value = None

    def normalized_identifier(value: Any) -> str:
        return re.sub(r"[^a-z0-9]+", "_", text(value).lower()).strip("_")

    requested_identifier = normalized_identifier(concept_key)
    concept_equivalents = {
        "revenue": {"total_income", "operating_revenue", "revenue_from_operations",
                    "property_development_revenue", "property_sales", "sale_of_properties",
                    "rental_revenue", "rental_income", "construction_revenue", "turnover"},
        "total_assets": {"assets", "total_asset", "group_total_assets", "consolidated_total_assets",
                         "total_current_and_non_current_assets"},
        "trade_receivables_net": {"trade_receivables", "accounts_receivable", "contract_assets"},
        "retained_earnings": {"retained_profits", "accumulated_losses", "accumulated_deficit",
                              "accumulated_profit_or_losses", "revenue_reserve"},
        "total_shareholders_equity": {"shareholders_equity", "total_equity", "equity"},
        "operating_cash_flow": {"net_cash_from_operating_activities", "cash_flow_from_operations"},
    }
    requested_identifiers = {requested_identifier}
    for canonical, aliases in concept_equivalents.items():
        if requested_identifier == canonical or requested_identifier in aliases:
            requested_identifiers.update({canonical, *aliases})
    for table in tables:
        for row in table.get("rows", []):
            row_identifiers = {
                normalized_identifier(row.get("concept_key")),
                normalized_identifier(row.get("canonical_label")),
                normalized_identifier(row.get("row_label")),
            }
            if requested_identifiers & row_identifiers:
                target_table, target_row, target_value = table, row, row.get("values", {}).get(role, {})
                break
        if target_row:
            break
    # Some legacy statement screens send a canonical/field alias that was not
    # materialised as a table row. Resolve it against the run-scoped fact row
    # rather than rejecting a valid selected report.
    if not target_row:
        for fact in selected:
            fact_identifiers = {
                normalized_identifier(fact.get("concept_key")),
                normalized_identifier(fact.get("field_key")),
                normalized_identifier(fact.get("canonical_key")),
                normalized_identifier(fact.get("canonical_label")),
                normalized_identifier(fact.get("field_label")),
                normalized_identifier(fact.get("source_row_label")),
                normalized_identifier(fact.get("row_label")),
            }
            if not (requested_identifiers & fact_identifiers):
                continue
            statement_type = canonical_statement(fact.get("statement_type"))
            if statement_type not in {"BALANCE_SHEET", "INCOME_STATEMENT", "CASH_FLOW_STATEMENT"}:
                statement_type = "CASH_FLOW_STATEMENT" if requested_identifier in {
                    "operating_cash_flow", "investing_cash_flow", "financing_cash_flow"
                } else "INCOME_STATEMENT"
            canonical_key = text(fact.get("concept_key")) or concept_key
            label = (text(fact.get("field_label")) or text(fact.get("canonical_label"))
                     or text(fact.get("row_label")) or canonical_key)
            target_table = {"statement_type": statement_type, "currency": text(fact.get("currency")),
                            "unit": text(fact.get("unit"))}
            target_row = {"concept_key": canonical_key, "row_label": label,
                          "values": {"current": {"numeric_value": number(fact.get("current_value")),
                                                   "period": text(fact.get("current_period")) or "Current period"},
                                     "prior": {"numeric_value": number(fact.get("prior_value")),
                                               "period": text(fact.get("prior_period")) or "Prior period"}}}
            target_value = target_row["values"][role]
            concept_key = canonical_key
            break
    if not target_row:
        return jsonify({"error": "The requested concept is not available for the selected report.",
                        "requested_concept": concept_key,
                        "available_concepts": sorted({text(row.get("concept_key")) for row in selected
                                                      if text(row.get("concept_key"))})[:80]}), 404
    extracted_value = number((target_value or {}).get("numeric_value"))
    if extracted_value is not None and not validation_mode:
        return jsonify({"error": "AI resolution is available only for a missing value"}), 409
    try:
        settings = financial_resolution_llm_configuration()
    except RuntimeError as exc:
        return jsonify({"error": str(exc), "stage": "MODEL_CONFIGURATION"}), 503
    indexed_evidence = statement_resolution_evidence(
        document_id, target_table.get("statement_type"), concept_key,
        target_row.get("row_label"), {**settings, "max_fragments": 8, "max_fragment_characters": 2400},
        run_id=run_id,
    )
    selected_pdf_evidence = managed_pdf_evidence_fallback(
        document_id, target_table.get("statement_type"), concept_key,
        target_row.get("row_label"), max_fragments=8, run_id=run_id,
    )
    evidence, seen_evidence = [], set()
    for item in [*selected_pdf_evidence, *indexed_evidence]:
        signature = (integer(item.get("page_number"), 0),
                     hashlib.sha256(text(item.get("content")).encode("utf-8")).hexdigest())
        if signature in seen_evidence:
            continue
        seen_evidence.add(signature)
        evidence.append(item)
    evidence = compact_statement_resolution_evidence(
        evidence, concept_key, target_row.get("row_label"), 8,
    )
    candidate_table = build_resolution_candidate_table(evidence, concept_key, target_row.get("row_label"))
    # The canonical pipeline may already contain the exact audited row under
    # an equivalent concept (for example accumulated_losses while the screen
    # requests retained_earnings). Promote that run/document-scoped row into
    # the candidate table before attempting an external model call.
    candidate_fact_rows = list(selected)
    try:
        standardized_support = normalize_resolved_shape(standardized_table_values())
        candidate_fact_rows.extend([
            fact for fact in standardized_support.to_dict(orient="records")
            if text(fact.get("assessment_run_id") or fact.get("run_id")) == run_id
            and text(fact.get("source_document_id")) == document_id
        ])
    except Exception as support_error:
        print(f"PROPOSE STANDARDIZED SUPPORT UNAVAILABLE: {type(support_error).__name__}: {support_error}", flush=True)
    fact_candidates = []
    for fact in candidate_fact_rows:
        fact_identifiers = {
            normalized_identifier(fact.get("concept_key")),
            normalized_identifier(fact.get("field_key")),
            normalized_identifier(fact.get("canonical_key")),
            normalized_identifier(fact.get("canonical_label")),
            normalized_identifier(fact.get("field_label")),
            normalized_identifier(fact.get("source_row_label")),
            normalized_identifier(fact.get("row_label")),
        }
        if not (requested_identifiers & fact_identifiers):
            continue
        current_value, prior_value = number(fact.get("current_value")), number(fact.get("prior_value"))
        if current_value is None and prior_value is None:
            continue
        fact_candidates.append({
            "candidate_id": "RUN_SCOPED_FACT_" + str(len(fact_candidates) + 1),
            "page_number": integer(fact.get("source_page_number") or fact.get("page_number"), 0),
            "description": (text(fact.get("current_source_label")) or text(fact.get("source_row_label"))
                            or text(fact.get("canonical_label")) or text(fact.get("concept_key"))),
            "current_value": current_value, "prior_value": prior_value,
            "source_line": (text(fact.get("current_source_label")) or text(fact.get("source_row_label"))
                            or text(fact.get("canonical_label")) or text(fact.get("concept_key"))),
            "derivation_method": "RUN_SCOPED_CANONICAL_FACT",
        })
    existing_candidate_pairs = {
        (number(item.get("current_value")), number(item.get("prior_value")))
        for item in candidate_table
    }
    candidate_table = [item for item in fact_candidates
                       if (number(item.get("current_value")), number(item.get("prior_value")))
                       not in existing_candidate_pairs] + candidate_table
    registration = registration_lookup().get(document_id, {})
    resolved_display_name = (text(registration.get("file_name"))
        or text(report_display_filename_lookup().get("by_document", {}).get(document_id)))
    company_context = {"entity_id": text(selected[0].get("entity_id")) if selected else "",
                       "company_name": registration.get("entity_key") or text(selected[0].get("entity_id")) if selected else "",
                       "file_name": resolved_display_name or document_id,
                       "source_document_id": document_id}
    if not evidence:
        return jsonify({"error": "No annual-report evidence is available for this document",
                        "stage": "EVIDENCE_LOADING",
                        "debug": {"target": {"concept_key": concept_key, "period_role": role},
                                  "assessment_run_id": run_id, "source_document_id": document_id,
                                  "evidence_document_ids_checked": run_scoped_evidence_document_ids(run_id, document_id),
                                  "resolved_file_name": resolved_display_name,
                                  "sources_checked": ["POSTGRES_REPORT_EVIDENCE",
                                                      "POSTGRES_WEBAPP_REPORT_EVIDENCE",
                                                      DOCUMENT_FRAGMENTS_DATASET,
                                                      "EXACT_PDF_DATABASE_HYDRATION",
                                                      "SELECTED_MANAGED_PDF",
                                                      "SELECTED_LOCAL_PDF"]}}), 422
    known = []
    for table in tables:
        if table.get("statement_type") != target_table.get("statement_type"):
            continue
        for row in table.get("rows", []):
            for period_role in ("current", "prior"):
                value = row.get("values", {}).get(period_role, {})
                if number(value.get("numeric_value")) is not None:
                    known.append({"concept_key": row.get("concept_key"), "label": row.get("row_label"),
                                  "period_role": period_role, "period": value.get("period"), "value": value.get("numeric_value")})
    validation_formulas = {
        "revenue": "DIRECT_DISCLOSED_VALUE from the consolidated income statement; reject narrative shorthand and note references",
        "cost_of_goods_sold": "DIRECT_DISCLOSED_VALUE from cost of sales/revenue on the consolidated income statement",
        "sg_and_a_expense": "selling_or_marketing_and_distribution_expenses + general_and_administrative_expenses; exclude research_and_development unless the issuer explicitly presents it within SG&A",
        "operating_income_ebit": "profit_or_loss_before_income_tax + absolute(finance_costs) - absolute(finance_income); prefer a directly disclosed operating profit/loss subtotal",
        "interest_expense": "DIRECT_DISCLOSED_VALUE from total finance costs/finance expenses on the income statement; do not use interest paid or one loan component",
        "long_term_debt": "non_current_borrowings + non_current_lease_liabilities",
        "trade_receivables_net": "current_trade_receivables + non_current_trade_receivables; use the Group columns only",
        "shares_outstanding": "issued_ordinary_shares - treasury_shares_count",
        "operating_cash_flow": "DIRECT_DISCLOSED_VALUE from net cash generated from/used in operating activities",
        "investing_cash_flow": "DIRECT_DISCLOSED_VALUE from net cash generated from/used in investing activities",
        "financing_cash_flow": "DIRECT_DISCLOSED_VALUE from net cash generated from/used in financing activities",
        "net_change_cash": "operating_cash_flow + investing_cash_flow + financing_cash_flow",
        "depreciation_amortization": "sum(asset_class_depreciation_charges) + separately_disclosed_finite_life_intangible_amortisation; do not double-count right-of-use depreciation included in PPE",
        "total_assets": "total_non_current_assets + total_current_assets",
        "total_liabilities": "total_non_current_liabilities + total_current_liabilities",
        "total_shareholders_equity": "share_capital + treasury_shares + accumulated_profit_or_losses + other_reserves",
    }
    mapping_rule = financial_mapping_rule(concept_key)
    governed_formula = configured_governed_formula(
        concept_key,
        validation_formulas.get(concept_key, "DIRECT_DISCLOSED_VALUE: compare the extracted value with the same labelled row and period in raw evidence"),
    )
    prompt = {"task": "Validate exactly one extracted financial statement value against raw annual-report evidence. Never estimate or invent.",
              "company_context": company_context,
              "target": {"statement_type": target_table.get("statement_type"), "concept_key": concept_key,
                         "concept_label": target_row.get("row_label"), "period_role": role,
                         "period_label": (target_value or {}).get("period"), "currency": target_table.get("currency"),
                         "unit": target_table.get("unit"), "extracted_value": extracted_value,
                         "validation_mode": validation_mode},
              "governed_formula": governed_formula,
              "database_mapping_rule": {
                  "rule_version": mapping_rule.get("rule_version"),
                  "component_concepts": mapping_rule.get("component_concepts", []),
                  "exclusions": mapping_rule.get("exclusions", []),
                  "validation": mapping_rule.get("validation", {}),
                  "output_unit_rule": mapping_rule.get("output_unit_rule", ""),
              },
              "rules": ["DIRECT_EXTRACTION requires an exact value in evidence.",
                        "FORMULA_DERIVATION requires ADD, SUM or SUBTRACT and named operands from known facts.",
                        "Cite supplied page numbers. Set can_resolve false if unsupported.",
                        "Use candidate_value_table first; its values are mapped to current and prior periods.",
                        "For one matching row, copy the requested period value using DIRECT_EXTRACTION.",
                        "For multiple required component rows, use FORMULA_DERIVATION with SUM and list each operand.",
                        "Primary consolidated financial-table rows outrank notes and narrative summaries.",
                        "Never use a note number, page number, year, percentage, EPS weighted-average share count, or monetary share-capital amount as the target value.",
                        "Do not modify a populated value unless same-report evidence proves the replacement for the same scope, period, currency and unit.",
                        "Do not repeat or echo an evidence object. Return only the decision object in json_contract."],
              "json_contract": {"can_resolve": True, "proposed_value": 0, "resolution_method": "DIRECT_EXTRACTION",
                                "formula": "", "calculation": {"operation": "SUM", "operands": [{"name": "", "value": 0}]},
                                "evidence": [{"page_number": 1, "quote": "short quote"}],
                                "explanation": "short explanation", "confidence": 0.0,
                                "extracted_value_is_correct": True},
              "statement_context": target_table.get("statement_type"),
              "period_columns": {"current": (target_value or {}).get("period"),
                                 "prior": target_row.get("values", {}).get("prior", {}).get("period")},
              "candidate_value_table": candidate_table,
              # Only formula-relevant operands are disclosed to the model. The
              # complete statement remains local and is never copied into an LLM prompt.
              "known_financial_facts": [fact for fact in known if fact.get("concept_key") in {
                  "marketing_and_distribution_expenses", "administrative_expenses",
                  "profit_or_loss_before_income_tax", "finance_costs", "non_current_borrowings",
                  "non_current_lease_liabilities", "issued_ordinary_shares", "treasury_shares_count",
                  "depreciation_expense", "depreciation_of_property_plant_equipment",
                  "amortisation_expense", "amortization_expense",
                  "current_trade_receivables", "non_current_trade_receivables",
                  "operating_cash_flow", "investing_cash_flow", "financing_cash_flow",
                  "total_current_assets", "total_non_current_assets", "total_current_liabilities",
                  "total_non_current_liabilities", "share_capital", "treasury_shares",
                  "accumulated_profit_or_losses", "other_reserves"
              }][:12], "annual_report_evidence": (
                  evidence[:5] if concept_key == "shares_outstanding" else evidence[:3]
              ),
              "final_instruction": "Return exactly one JSON object matching json_contract. Do not return a page object or markdown."}
    messages = [{"role": "system", "content": (
                    "Conservative financial extraction assistant. Return exactly one compact JSON object only. "
                    "Include at most two evidence items; keep every quote under 300 characters and the explanation "
                    "under 500 characters. Do not repeat the supplied tables or prompt."
                )},
                {"role": "user", "content": json.dumps(prompt, default=str)}]
    debug = {"provider": settings["provider"], "model": settings["model"], "target": prompt["target"],
             "known_fact_count": len(prompt["known_financial_facts"]), "candidate_value_table": candidate_table,
             "evidence_pages": [x.get("page_number") for x in (
                 evidence[:5] if concept_key == "shares_outstanding" else evidence[:3]
             )],
             "prompt_text": messages[1]["content"]}
    print("FACT RESOLUTION LLM REQUEST:", json.dumps(debug, default=str))
    # Do not spend an LLM request on an exact, report-scoped statement row.
    # A candidate is safe to apply automatically when it comes from a governed
    # extraction method and every populated candidate from that method agrees
    # for the requested period.  This also makes an explicit audited value
    # resilient to provider throttling and malformed model responses.
    governed_direct_methods = {
        "VALIDATED_TABLE_DIRECT_EXTRACTION", "RUN_SCOPED_CANONICAL_FACT",
        "PRIMARY_STATEMENT_SECTION_SUBTOTAL", "ISSUED_LESS_TREASURY_SHARES",
        "PRIMARY_STATEMENT_CONFIRMED_ZERO",
    }
    governed_direct_candidates = [
        candidate for candidate in candidate_table
        if text(candidate.get("derivation_method")) in governed_direct_methods
        and number(candidate.get(role + "_value")) is not None
    ]
    governed_values = {
        number(candidate.get(role + "_value"))
        for candidate in governed_direct_candidates
    }
    deterministic_candidate = (
        governed_direct_candidates[0]
        if governed_direct_candidates and len(governed_values) == 1 else None
    )
    llm_response = None
    if deterministic_candidate is not None:
        deterministic_value = number(deterministic_candidate.get(role + "_value"))
        deterministic_decision = {
            "can_resolve": True,
            "proposed_value": deterministic_value,
            "resolution_method": "DIRECT_EXTRACTION",
            "formula": "DIRECT_DISCLOSED_VALUE",
            "calculation": {"operation": "NONE", "operands": []},
            "evidence": [{
                "page_number": integer(deterministic_candidate.get("page_number"), 0),
                "quote": text(deterministic_candidate.get("source_line")),
            }],
            "explanation": "Applied an unambiguous period-aligned value from the selected report; no language-model call was required.",
            "confidence": 1.0,
            "extracted_value_is_correct": (
                extracted_value is not None
                and abs(deterministic_value - extracted_value)
                    <= max(.01, abs(extracted_value) * .0001)
            ),
            "deterministic_pre_llm": True,
        }
        llm_response = {
            "raw_content": json.dumps(deterministic_decision),
            "response_body": {"deterministic_pre_llm": True},
            "http_status": 200,
            "elapsed_seconds": 0,
            "provider": "backend",
            "model": "DETERMINISTIC_STATEMENT_MAPPING",
        }
        debug["deterministic_pre_llm_candidate"] = deterministic_candidate
    try:
        try:
            if llm_response is None:
                llm_response = financial_resolution_llm_request(settings, messages)
        except requests.HTTPError as provider_error:
            status_code = integer(getattr(provider_error.response, "status_code", 0), 0)
            # Authentication and malformed-request failures must be fixed, not
            # multiplied across models. Only fail over for transient capacity,
            # throttling and gateway errors.
            if status_code not in {429, 500, 502, 503, 504}:
                raise
            retry_after = text(getattr(provider_error.response, "headers", {}).get("retry-after"))
            fallback_llm_response = None
            fallback_errors = {}
            primary_model = text(settings.get("model"))
            attempted_models = [primary_model]
            for fallback_model in settings.get("fallback_models", []):
                if fallback_model in attempted_models:
                    continue
                attempted_models.append(fallback_model)
                fallback_settings = {**settings, "model": fallback_model}
                try:
                    fallback_llm_response = financial_resolution_llm_request(
                        fallback_settings, messages,
                    )
                except Exception as fallback_exc:
                    fallback_detail = f"{type(fallback_exc).__name__}: {fallback_exc}"
                    fallback_response = getattr(fallback_exc, "response", None)
                    if fallback_response is not None:
                        try:
                            fallback_detail += " | " + json.dumps(fallback_response.json(), default=str)[:1200]
                        except Exception:
                            fallback_detail += " | " + text(getattr(fallback_response, "text", ""))[:1200]
                    fallback_errors[fallback_model] = fallback_detail
                    continue
                else:
                    settings = fallback_settings
                    debug.update(fallback_llm_response)
                    debug.update({"primary_model_rate_limited": status_code == 429,
                                  "primary_model_temporarily_unavailable": status_code in {500, 502, 503, 504},
                                  "primary_provider_status": status_code,
                                  "primary_model": primary_model,
                                  "fallback_model": settings["model"],
                                  "attempted_models": attempted_models,
                                  "fallback_errors": fallback_errors,
                                  "retry_after_seconds": retry_after})
                    raw_model_content = fallback_llm_response["raw_content"]
                    debug["raw_model_content"] = raw_model_content
                    result = parse_ollama_json(raw_model_content)
                    debug["model_response"] = result
                    break
            governed_methods = {
                "DIRECT_COMPONENT_SUM", "PRIMARY_STATEMENT_SECTION_SUBTOTAL",
                "VALIDATED_TABLE_DIRECT_EXTRACTION", "ISSUED_LESS_TREASURY_SHARES",
                "RUN_SCOPED_CANONICAL_FACT",
            }
            exact_labels = {
                "retained_earnings": r"^(?:retained earnings|accumulated losses|accumulated deficit)\b",
                "interest_expense": r"^(?:financial|finance) (?:expense|expenses|cost|costs)\b",
                "ending_cash": r"^cash and (?:cash equivalents|bank balances) at (?:the )?end\b",
            }
            fallback_candidate = next((candidate for candidate in candidate_table
                                       if text(candidate.get("derivation_method")) in governed_methods), None)
            label_pattern = exact_labels.get(concept_key)
            if fallback_candidate is None and label_pattern:
                fallback_candidate = next((candidate for candidate in candidate_table
                                           if re.match(label_pattern, text(candidate.get("description")).lower())), None)
            if fallback_candidate is None and len(candidate_table) == 1:
                fallback_candidate = candidate_table[0]
            fallback_value = number((fallback_candidate or {}).get(role + "_value"))
            if fallback_llm_response is None and (fallback_candidate is None or fallback_value is None):
                return jsonify({
                    "status": "RATE_LIMITED" if status_code == 429 else "PROVIDER_UNAVAILABLE",
                    "stage": "LLM_PROVIDER_RATE_LIMIT" if status_code == 429 else "LLM_PROVIDER_CAPACITY",
                    "error": ("The configured language models are temporarily rate-limited."
                              if status_code == 429 else
                              "The configured language models are temporarily unavailable.")
                             + " No value was changed; retry this report later.",
                    "retry_after_seconds": retry_after, "concept_key": concept_key,
                    "period_role": role, "attempted_models": attempted_models,
                    "fallback_errors": fallback_errors,
                    "debug": debug,
                }), status_code
            if fallback_llm_response is None:
                result = {
                    "can_resolve": True, "proposed_value": fallback_value,
                    "resolution_method": "DIRECT_EXTRACTION", "formula": governed_formula,
                    "calculation": {"operation": "NONE", "operands": []},
                    "evidence": [{"page_number": integer(fallback_candidate.get("page_number"), 0),
                                  "quote": text(fallback_candidate.get("source_line"))}],
                    "explanation": "The language-model service was unavailable; the backend used an unambiguous governed annual-report candidate.",
                    "confidence": 0.99, "extracted_value_is_correct": (
                        extracted_value is not None and abs(fallback_value - extracted_value)
                        <= max(.01, abs(extracted_value) * .0001)
                    ), "rate_limit_fallback": True,
                }
                debug.update({"provider_status": status_code, "rate_limited": status_code == 429,
                              "provider_unavailable": status_code in {500, 502, 503, 504},
                              "retry_after_seconds": retry_after,
                              "attempted_models": attempted_models,
                              "fallback_errors": fallback_errors,
                              "governed_fallback_candidate": fallback_candidate,
                              "model_response": result})
        else:
            debug.update(llm_response)
            response_body = llm_response["response_body"]
            raw_model_content = llm_response["raw_content"]
            debug["raw_model_content"] = raw_model_content
            print("FACT RESOLUTION LLM RESPONSE:", json.dumps({
                "provider": settings["provider"], "http_status": debug["http_status"], "elapsed_seconds": debug["elapsed_seconds"],
                "raw_model_content": raw_model_content, "response_body": response_body,
            }, default=str))
            result = parse_ollama_json(raw_model_content)
            debug["model_response"] = result
        if (not result.get("can_resolve") or number(result.get("proposed_value")) in (None, 0)) and len(candidate_table) == 1:
            candidate = candidate_table[0]
            deterministic_value = number(candidate.get(role + "_value"))
            if deterministic_value is not None:
                result = {"can_resolve": True, "proposed_value": deterministic_value,
                          "resolution_method": "DIRECT_EXTRACTION", "formula": "",
                          "calculation": {"operation": "SUM", "operands": []},
                          "evidence": [{"page_number": candidate["page_number"], "quote": candidate["source_line"]}],
                          "explanation": "Deterministically mapped the single target-bearing table row to the requested period.",
                          "confidence": 0.98, "model_contract_fallback": True,
                          "raw_model_decision": debug.get("model_response")}
                debug["deterministic_fallback"] = result
        if not result.get("can_resolve"):
            return jsonify({"error": text(result.get("explanation")) or "Ollama could not resolve the value from governed evidence.",
                            "status": "UNRESOLVED", "stage": "MODEL_DECISION", "model_response": result,
                            "debug": debug}), 422
        proposed, confidence = number(result.get("proposed_value")), number(result.get("confidence"))
        method = text(result.get("resolution_method")).upper()
        citations = result.get("evidence") if isinstance(result.get("evidence"), list) else []
        allowed_pages = ({integer(x.get("page_number"), -1) for x in evidence}
                         | {integer(x.get("page_number"), -1) for x in candidate_table})
        cited_pages = {integer(x.get("page_number"), -1) for x in citations if isinstance(x, dict)}
        if proposed is None or confidence is None or not 0 <= confidence <= 1:
            raise ValueError("Model did not return a valid proposed value and confidence")
        if method not in {"DIRECT_EXTRACTION", "FORMULA_DERIVATION"} or not (allowed_pages & cited_pages):
            raise ValueError("Proposal lacks an allowed method or valid annual-report citation")
        validation_message = "Annual-report citation validated; analyst review is required."
        operands = (result.get("calculation") or {}).get("operands", [])
        if method == "FORMULA_DERIVATION":
            operation = text((result.get("calculation") or {}).get("operation")).upper()
            operand_values = [number(x.get("value")) for x in operands if isinstance(x, dict)]
            if not operand_values or any(x is None for x in operand_values):
                raise ValueError("Formula derivation requires numeric operands")
            calculated = sum(operand_values) if operation in {"ADD", "SUM"} else (operand_values[0] - sum(operand_values[1:]) if operation == "SUBTRACT" else None)
            if calculated is None or abs(calculated - proposed) > max(.01, abs(proposed) * .0001):
                raise ValueError("Backend recalculation does not match the proposed value")
            validation_message = "Formula was recalculated by the backend; analyst review is required."
        if validation_mode and extracted_value is not None and abs(proposed - extracted_value) <= max(.01, abs(extracted_value) * .0001):
            return jsonify({"status": "VALIDATED_CORRECT", "proposal_id": "", "model": settings["model"],
                            "concept_key": concept_key, "concept_label": target_row.get("row_label"),
                            "period_role": role, "period_label": (target_value or {}).get("period"),
                            "extracted_value": extracted_value, "proposed_value": proposed,
                            "resolution_method": method, "evidence": citations,
                            "explanation": text(result.get("explanation")), "confidence": confidence,
                            "validation_message": "The extracted value matches the governed annual-report evidence.",
                            "debug": debug})
        proposal_id = str(uuid.uuid4())
        with postgres_connection() as connection:
            ensure_fact_resolution_tables(connection)
            with connection.cursor() as cursor:
                cursor.execute("""INSERT INTO financial_risk_intelligence.financial_fact_resolution_proposals
                    (proposal_id,assessment_run_id,source_document_id,statement_type,concept_key,concept_label,period_role,period_label,
                     proposed_value,currency,unit,resolution_method,formula,operands_json,evidence_json,explanation,confidence,
                     validation_status,validation_message,model_name,prompt_json,response_json)
                    VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s::jsonb,%s::jsonb,%s,%s,%s,%s,%s,%s::jsonb,%s::jsonb)""",
                    (proposal_id,run_id,document_id,target_table.get("statement_type"),concept_key,target_row.get("row_label"),role,
                     (target_value or {}).get("period") or role,proposed,target_table.get("currency"),target_table.get("unit"),method,
                     text(result.get("formula")),json.dumps(operands),json.dumps(citations),text(result.get("explanation")),confidence,
                     "VALIDATED_FOR_REVIEW",validation_message,settings["model"],json.dumps(prompt,default=str),json.dumps(result,default=str)))
        return jsonify({"proposal_id": proposal_id,
                        "status": "CORRECTION_PENDING_REVIEW" if validation_mode and extracted_value is not None else "PENDING_REVIEW",
                        "model": settings["model"], "concept_key": concept_key,
                        "concept_label": target_row.get("row_label"), "period_role": role,
                        "period_label": (target_value or {}).get("period"), "extracted_value": extracted_value,
                        "proposed_value": proposed, "resolution_method": method,
                        "formula": text(result.get("formula")) or governed_formula,
                        "operands": operands, "evidence": citations, "explanation": text(result.get("explanation")),
                        "confidence": confidence, "validation_message": validation_message, "debug": debug})
    except Exception as exc:
        debug.setdefault("elapsed_seconds", round((dt.datetime.now(dt.timezone.utc) - request_started).total_seconds(), 3))
        debug["exception_type"] = type(exc).__name__
        debug["exception_message"] = str(exc)
        print("FACT RESOLUTION FAILED:", type(exc).__name__, exc)
        return jsonify({"error": f"{type(exc).__name__}: {exc}", "stage": "LLM_FACT_RESOLUTION",
                        "debug": debug}), 502


@app.route("/api/statement-derivation-context", methods=["GET"])
def statement_derivation_context():
    """Return Python output, governed formula and annual-report evidence without an LLM call."""
    run_id = text(request.args.get("assessment_run_id"))
    document_id = text(request.args.get("source_document_id"))
    concept_key = text(request.args.get("concept_key"))
    role = text(request.args.get("period_role")).lower()
    if not run_id or not document_id or not concept_key or role not in {"current", "prior"}:
        return jsonify({"error": "assessment_run_id, source_document_id, concept_key and period_role are required"}), 400
    values, source = resolved_values()
    selected = [row for row in values.to_dict(orient="records")
                if text(row.get("assessment_run_id") or row.get("run_id")) == run_id
                and text(row.get("source_document_id")) == document_id]
    if not selected:
        snapshot = load_analysis_history_snapshot(run_id, document_id)
        selected = list(snapshot.get("values") or [])
        if selected:
            source = "POSTGRES_ANALYSIS_HISTORY"
    tables = build_resolved_tables(selected)
    # Keep the read-only derivation view synchronized with values approved and
    # saved after the immutable extraction snapshot was created.
    overrides = approved_fact_overrides(run_id, document_id)
    apply_fact_overrides(tables, overrides)
    target_table = target_row = None
    for table in tables:
        for row in table.get("rows", []):
            if text(row.get("concept_key")) == concept_key:
                target_table, target_row = table, row
                break
        if target_row:
            break
    if not target_row:
        return jsonify({"error": "Requested concept is not present in the Python output"}), 404
    formulas = {
        "total_assets": "current_assets + non_current_assets",
        "total_liabilities": "current_liabilities + non_current_liabilities",
        "total_shareholders_equity": "share_capital + treasury_shares + accumulated_profit_or_losses + other_reserves",
        "working_capital": "current_assets - current_liabilities",
        "net_debt": "short_term_debt + long_term_debt - cash_and_equivalents",
        "ebitda": "operating_income_ebit + depreciation_amortization",
        "gross_profit": "revenue - cost_of_goods_sold",
        "operating_cash_flow": "net_change_cash - investing_cash_flow - financing_cash_flow",
        "ending_cash": "beginning_cash + operating_cash_flow + investing_cash_flow + financing_cash_flow + fx_effect_on_cash",
        "shares_outstanding": "closing issued ordinary shares - treasury shares",
    }
    settings = ollama_configuration()
    evidence = statement_resolution_evidence(
        document_id, target_table.get("statement_type"), concept_key,
        target_row.get("row_label"), settings, run_id=run_id,
    )
    compact_evidence = compact_statement_resolution_evidence(
        evidence, concept_key, target_row.get("row_label"), limit=4,
    )
    candidate_table = build_resolution_candidate_table(
        compact_evidence, concept_key, target_row.get("row_label"),
    )
    known = [{"concept_key": text(row.get("concept_key")),
              "label": text(row.get("row_label")),
              "current_value": number((row.get("values") or {}).get("current", {}).get("numeric_value")),
              "prior_value": number((row.get("values") or {}).get("prior", {}).get("numeric_value"))}
             for table in tables for row in table.get("rows", [])
             if text(row.get("concept_key"))]
    value = target_row.get("values", {}).get(role, {})
    return jsonify({
        "data_source": source,
        "target": {"statement_type": target_table.get("statement_type"),
                   "concept_key": concept_key, "concept_label": target_row.get("row_label"),
                   "period_role": role, "period_label": value.get("period"),
                   "python_value": value.get("numeric_value"),
                   "currency": target_table.get("currency"), "unit": target_table.get("unit")},
        "governed_formula": configured_governed_formula(
            concept_key, formulas.get(concept_key, "DIRECT_DISCLOSED_VALUE")
        ),
        "known_financial_facts": known,
        "candidate_value_table": candidate_table,
        "annual_report_evidence": [{"page_number": item.get("page_number"),
                                    "matched_terms": item.get("matched_terms", []),
                                    "content": item.get("content", "")}
                                   for item in compact_evidence],
        "external_model_calls": 0,
        "next_action": "Call propose only when the analyst selects Analyze this value.",
    })


@app.route("/api/financial-fact-resolution/batch-preview", methods=["POST"])
def batch_financial_fact_resolution_preview():
    """Derive or source-verify selected-report statement values and persist them."""
    request_started = dt.datetime.now(dt.timezone.utc)
    payload = request.get_json(silent=True) or {}
    run_id = text(payload.get("assessment_run_id"))
    document_id = text(payload.get("source_document_id"))
    if not run_id or not document_id:
        return jsonify({"error": "assessment_run_id and source_document_id are required"}), 400
    print(json.dumps({"event": "SOURCE_VERIFICATION_START", "backend_build": BACKEND_BUILD_ID,
                      "assessment_run_id": run_id, "source_document_id": document_id,
                      "verify_source": payload.get("verify_source")}), flush=True)
    force_source_refresh = text(payload.get("verify_source") or payload.get("force_source_refresh")).lower() in {"1", "true", "yes", "on"}
    llm_validate_all = text(payload.get("llm_validate_all")).lower() in {"1", "true", "yes", "on"}
    force_llm_revalidation = text(payload.get("force_llm_revalidation")).lower() in {"1", "true", "yes", "on"}
    requested_target_concepts = payload.get("target_concepts")
    job_targets = list(requested_target_concepts) if isinstance(requested_target_concepts, list) else []
    # Invalidate jobs completed before durable PostgreSQL/history evidence and
    # calendar-date share-closing rows were supported.
    job_targets.append("__DATABASE_FIRST_HISTORICAL_EVIDENCE_V11_ALL_TABLE_CATALOG__")
    validation_request_id = text(payload.get("validation_request_id"))
    # Keep source-verification jobs separate from earlier missing-only jobs so
    # an old completed job cannot prevent a selected PDF from correcting stale
    # populated figures. V2 also invalidates the earlier verifier, which did
    # not yet protect same-label current/non-current rows or component sums.
    if force_source_refresh:
        job_targets.append("__SOURCE_VERIFICATION_V16__")
    if llm_validate_all:
        job_targets.append("__LLM_VALIDATE_ALL_SCORE_INPUTS_V10_ALL_TABLE_CATALOG__")
    if validation_request_id:
        job_targets.append("__VALIDATION_REQUEST__" + validation_request_id)
    job = begin_resolution_job(run_id, document_id, job_targets)
    if job.get("reuse"):
        reused = dict(job.get("result") or {})
        reused.update({"status": "ALREADY_COMPLETED", "resolution_job_key": job["job_key"],
                       "execution_skipped": True,
                       "message": "Missing-value resolution was already completed and saved; backend execution was skipped."})
        return jsonify(reused)
    if job.get("running"):
        return jsonify({"status": "ALREADY_RUNNING", "resolution_job_key": job["job_key"],
                        "execution_skipped": True,
                        "message": "The backend missing-value job is already running for this report."}), 202
    resolution_job_key = job["job_key"]
    llm_configuration_error = ""
    if force_source_refresh and not llm_validate_all:
        # Source verification is deterministic: it never needs an LLM key,
        # model configuration, or a network call.
        settings = {"provider": "selected_pdf", "model": "SELECTED_PDF_DETERMINISTIC"}
    else:
        try:
            settings = financial_resolution_llm_configuration()
        except RuntimeError as exc:
            if not llm_validate_all:
                finish_resolution_job(resolution_job_key, "FAILED", {}, f"MODEL_CONFIGURATION: {exc}")
                return jsonify({"error": str(exc), "stage": "MODEL_CONFIGURATION"}), 503
            llm_configuration_error = str(exc)
            settings = {"provider": "selected_pdf", "model": "SELECTED_PDF_DETERMINISTIC"}
        if settings["provider"] not in {"bedrock", "gemini"}:
            if llm_validate_all:
                llm_configuration_error = llm_configuration_error or "A configured cloud LLM is not available; deterministic selected-report validation was used."
                settings = {"provider": "selected_pdf", "model": "SELECTED_PDF_DETERMINISTIC"}
            else:
                finish_resolution_job(resolution_job_key, "FAILED", {}, "Batch preview requires fri_llm_provider=bedrock or gemini")
                return jsonify({"error": "Batch preview requires fri_llm_provider=bedrock or gemini"}), 409
    values, source = resolved_values()
    print(json.dumps({"event": "SOURCE_VERIFICATION_VALUES_LOADED", "rows": len(values),
                      "elapsed_seconds": round((dt.datetime.now(dt.timezone.utc) - request_started).total_seconds(), 3)}), flush=True)
    selected = [row for row in values.to_dict(orient="records")
                if text(row.get("assessment_run_id") or row.get("run_id")) == run_id
                and text(row.get("source_document_id")) == document_id]
    if not selected:
        snapshot = load_analysis_history_snapshot(run_id, document_id)
        selected = list(snapshot.get("values") or [])
        if selected:
            source = "POSTGRES_ANALYSIS_HISTORY"
    tables = build_resolved_tables(selected)
    formula_map = {
        "total_current_assets": "SUM(all disclosed current-asset component rows for the requested period)",
        "total_current_liabilities": "SUM(all disclosed current-liability component rows for the requested period)",
        "total_assets": "current_assets + non_current_assets",
        "total_liabilities": "current_liabilities + non_current_liabilities",
        "total_shareholders_equity": "share_capital + treasury_shares + accumulated_profit_or_losses + other_reserves",
        "working_capital": "current_assets - current_liabilities",
        "net_debt": "short_term_debt + long_term_debt - cash_and_equivalents",
        "ebitda": "operating_income_ebit + depreciation_amortization",
        "gross_profit": "revenue - cost_of_goods_sold",
        "sg_and_a_expense": "selling/marketing/distribution expense + general and administrative expense",
        "operating_income_ebit": "profit_or_loss_before_tax + finance_costs - finance_income",
        "trade_receivables_net": "current_trade_receivables + non_current_trade_receivables, or gross_trade_receivables - loss_allowance",
        "long_term_debt": "non_current_borrowings + non_current_lease_liabilities",
        "operating_cash_flow": "net_change_cash - investing_cash_flow - financing_cash_flow",
        "investing_cash_flow": "net_change_cash - operating_cash_flow - financing_cash_flow",
        "financing_cash_flow": "net_change_cash - operating_cash_flow - investing_cash_flow",
        "net_change_cash": "operating_cash_flow + investing_cash_flow + financing_cash_flow",
        "ending_cash": "beginning_cash + operating_cash_flow + investing_cash_flow + financing_cash_flow + fx_effect_on_cash",
        "shares_outstanding": "closing issued ordinary shares - treasury shares; do not use monetary share capital or weighted-average EPS shares",
    }
    requested_concepts = {text(item) for item in requested_target_concepts or [] if text(item)}
    requested_aliases = {
        "revenue": {"total_income", "operating_revenue", "revenue_from_operations",
                    "property_development_revenue", "property_sales", "sale_of_properties",
                    "revenue_from_contracts_with_customers", "turnover", "gross_revenue",
                    "rental_revenue", "rental_income", "construction_revenue",
                    "income_from_properties"},
        "total_assets": {"assets", "total_asset", "group_total_assets",
                         "consolidated_total_assets", "total_current_and_non_current_assets"},
    }
    requested_concepts |= set().union(*(requested_aliases.get(concept, set()) for concept in tuple(requested_concepts)))
    missing = []
    source_candidate_cache: Dict[Tuple[str, str], Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]] = {}
    evidence_settings = ({"max_fragments": 8, "max_fragment_characters": 2400}
                         if force_source_refresh else ollama_configuration())
    for table in tables:
        for row in table.get("rows", []):
            concept_key = text(row.get("concept_key"))
            cache_key = (text(table.get("statement_type")), concept_key)
            if cache_key not in source_candidate_cache:
                share_pair = disclosed_share_pair_from_validated_tables(document_id) \
                    if concept_key == "shares_outstanding" else {}
                if share_pair:
                    source_candidate_cache[cache_key] = ([], [{
                        "candidate_id": "VALIDATED_SHARE_CLOSING_BALANCE",
                        "page_number": share_pair.get("page_number"),
                        "description": share_pair.get("description") or
                                       "Issued ordinary shares before treasury-share adjustment",
                        "current_value": share_pair.get("current_value"),
                        "prior_value": share_pair.get("prior_value"),
                        "source_line": share_pair.get("source_line"),
                        "derivation_method": share_pair.get("derivation_method") or
                                             "ISSUED_SHARES_PROXY",
                    }])
                else:
                    # This route is deliberately scoped to the selected report.
                    # Bypass repeated whole-dataset fragment reads; the PDF text is
                    # parsed once then served from SELECTED_PDF_TEXT_CACHE.
                    evidence = statement_resolution_evidence(
                        document_id, table.get("statement_type"), concept_key,
                        row.get("row_label"), evidence_settings, run_id=run_id,
                    )
                    # A document-fragment dataset can contain a registration row
                    # but no usable narrative/table text for the selected report.
                    # Recover from the exact registered PDF before declaring that
                    # annual-report evidence is unavailable. This never scans or
                    # combines other reports.
                    if not any(text(item.get("content")).strip() for item in evidence):
                        evidence = managed_pdf_evidence_fallback(
                            document_id, table.get("statement_type"), concept_key,
                            row.get("row_label"), max_fragments=8, run_id=run_id,
                        )
                    compact = compact_statement_resolution_evidence(
                        evidence, concept_key, row.get("row_label"), limit=8,
                    )
                    # Share-capital movement tables commonly place the decisive
                    # ending-balance row several lines below a merged "No. of
                    # ordinary shares" header. Keep the full selected evidence
                    # page for this one concept so compaction cannot remove it.
                    full_evidence_concepts = {
                        "trade_receivables_net", "total_current_assets", "total_current_liabilities",
                        "total_assets", "total_liabilities", "retained_earnings",
                        "total_shareholders_equity", "shares_outstanding", "long_term_debt",
                        "operating_cash_flow", "investing_cash_flow", "financing_cash_flow",
                        "net_change_cash", "ending_cash",
                    }
                    # Parse candidates from complete selected-report pages so
                    # a nearby note reference or subtotal cannot replace the
                    # exact audited row. The external-model prompt below still
                    # receives compact evidence to stay within rate limits.
                    candidate_evidence = evidence if concept_key in full_evidence_concepts else compact
                    source_candidate_cache[cache_key] = (
                        compact,
                        build_resolution_candidate_table(
                            candidate_evidence, concept_key, row.get("row_label")
                        )[:12],
                    )
            for role in ("current", "prior"):
                value = row.get("values", {}).get(role, {})
                verify_this_concept = (force_source_refresh or llm_validate_all) and (
                    not requested_concepts or concept_key in requested_concepts
                )
                if value.get("numeric_value") is not None and not verify_this_concept:
                    continue
                compact, candidates = source_candidate_cache[cache_key]
                missing.append({
                    "target_id": f"{row.get('concept_key')}::{role}",
                    "statement_type": table.get("statement_type"),
                    "concept_key": row.get("concept_key"), "concept_label": row.get("row_label"),
                    "period_role": role, "period_label": value.get("period"),
                    "existing_value": value.get("numeric_value"),
                    "currency": table.get("currency"), "unit": table.get("unit"),
                    "governed_formula": formula_map.get(row.get("concept_key"), "DIRECT_DISCLOSED_VALUE"),
                    "candidate_rows": candidates,
                    "evidence": [{"page_number": item.get("page_number"),
                                  "matched_terms": item.get("matched_terms", []),
                                  "evidence_source": item.get("evidence_source") or "DOCUMENT_FRAGMENTS",
                                  "content": text(item.get("content"))[:1400]}
                                 for item in compact],
                })
    print(json.dumps({"event": "SOURCE_VERIFICATION_CANDIDATES_READY", "targets": len(missing),
                      "elapsed_seconds": round((dt.datetime.now(dt.timezone.utc) - request_started).total_seconds(), 3)}), flush=True)
    if isinstance(requested_target_concepts, list) and requested_target_concepts:
        missing = [item for item in missing if text(item.get("concept_key")) in requested_concepts]
    # Multiple extraction layers can materialize the same canonical row. Send
    # and save each concept/period once while merging its report evidence.
    unique_missing = {}
    for target in missing:
        target_id = text(target.get("target_id"))
        if target_id not in unique_missing:
            unique_missing[target_id] = target
            continue
        existing = unique_missing[target_id]
        existing["candidate_rows"] = list({
            (integer(candidate.get("page_number"), 0), text(candidate.get("source_line"))): candidate
            for candidate in [*(existing.get("candidate_rows") or []), *(target.get("candidate_rows") or [])]
        }.values())
        existing["evidence"] = list({
            (integer(item.get("page_number"), 0), text(item.get("content"))): item
            for item in [*(existing.get("evidence") or []), *(target.get("evidence") or [])]
        }.values())
    missing = list(unique_missing.values())
    # An active override validated under the current concept-rule version is a
    # durable database flag. Do not spend another LLM call on that cell unless
    # the caller explicitly requests revalidation or its mapping rule changes.
    validated_target_ids = set()
    if llm_validate_all and not force_llm_revalidation:
        for override in approved_fact_overrides(run_id, document_id):
            if override.get("requires_revalidation"):
                continue
            concept_key = text(override.get("concept_key"))
            period_role = text(override.get("period_role")).lower()
            if concept_key and period_role in {"current", "prior"}:
                validated_target_ids.add(f"{concept_key}::{period_role}")
        missing = [target for target in missing
                   if text(target.get("target_id")) not in validated_target_ids]
    if not missing:
        response_payload = {"status": "ALREADY_VALIDATED" if validated_target_ids else "NO_MISSING_VALUES",
                            "results": [], "model_calls": 0,
                            "requested_count": 0, "saved_count": 0, "unresolved_count": 0,
                            "critical_unresolved_count": 0,
                            "validated_skip_count": len(validated_target_ids),
                            "resolution_job_key": resolution_job_key,
                            "message": ("Every requested cell is already validated for the active mapping-rule version; no LLM call was made."
                                        if validated_target_ids else
                                        "All Python statement values are populated.")}
        finish_resolution_job(resolution_job_key, "COMPLETED", response_payload)
        return jsonify(response_payload)
    # Resolve score-critical concepts first and keep each Bedrock request small.
    # Saved results disappear from the missing set on the next automatic pass.
    score_priority = {concept: index for index, concept in enumerate((
        "revenue", "total_assets", "net_profit", "operating_cash_flow",
        "total_current_assets", "total_current_liabilities", "total_liabilities",
        "total_shareholders_equity", "cost_of_goods_sold", "trade_receivables_net",
        "inventory", "net_ppe", "operating_income_ebit", "interest_expense",
        "long_term_debt", "retained_earnings", "shares_outstanding",
        "depreciation_amortization", "sg_and_a_expense",
    ))}
    missing.sort(key=lambda item: (
        score_priority.get(text(item.get("concept_key")), 999),
        0 if item.get("period_role") == "current" else 1,
    ))
    # Source verification is deterministic for exact statement rows and does
    # not send those values to the LLM. Permit a full deterministic report-input
    # pass while retaining a smaller cap for model-backed derivation.
    # Keep a conservative Bedrock token/request envelope.
    # Give each unresolved concept enough audited context, but process only six
    # concepts per model call. The existing background runner continues the
    # deferred concepts in subsequent passes.
    # One compact report-level request can carry all unresolved cells because
    # statement evidence is included once in shared_statement_evidence rather
    # than repeated for every target.
    maximum_allowed = 60
    maximum_targets = max(1, min(maximum_allowed, integer(payload.get("maximum_targets"), maximum_allowed)))
    queued, deferred = missing[:maximum_targets], missing[maximum_targets:]
    authoritative_methods = {
        "DIRECT_COMPONENT_SUM", "ISSUED_LESS_TREASURY_SHARES",
        "PRIMARY_STATEMENT_CONFIRMED_ZERO", "GOVERNED_EBIT_RECONCILIATION",
        "PRIMARY_STATEMENT_SECTION_SUBTOTAL", "VALIDATED_TABLE_DIRECT_EXTRACTION",
        "PRIMARY_STATEMENT_FINAL_RESULT",
    }
    exact_statement_patterns = {
        "revenue": r"^(?:net |operating |total )?(?:revenue|sales|turnover)\b",
        "cost_of_goods_sold": r"^(?:cost of (?:goods sold|sales|revenue)|cost of services)\b",
        "sg_and_a_expense": r"^(?:selling(?:,? general and administrative)?|general and administrative|total operating) expenses?\b",
        "depreciation_amortization": r"^(?:depreciation(?: and amorti[sz]ation)?|depreciation and amorti[sz]ation)\b",
        "operating_income_ebit": r"^(?:operating (?:income|profit|loss)|profit from operations)\b",
        "interest_expense": r"^(?:financial|finance|interest) (?:expense|expenses|cost|costs)\b",
        "net_profit": r"^(?:net (?:income|profit|loss)|profit/?\(loss\) for the (?:year|period)|(?:profit|loss) for the (?:year|period|year/period))\b",
        "total_current_assets": r"^total current assets\b",
        "trade_receivables_net": r"^(?:net )?trade receivables\b",
        "inventory": r"^(?:inventories|inventory)\b",
        "net_ppe": r"^(?:net )?property,? plant and equipment\b",
        "total_assets": r"^total assets\b",
        "total_current_liabilities": r"^total current liabilities\b",
        "long_term_debt": r"^(?:non-current|long-term) (?:borrowings|debt|loans)(?: and lease liabilities)?\b",
        "total_liabilities": r"^total liabilities\b(?!\s+and\s+equity)",
        "retained_earnings": r"^(?:retained earnings|accumulated (?:losses|deficit))\b",
        "total_shareholders_equity": r"^(?:total shareholders['’]? equity|total stockholders['’]? equity|total equity)\b",
        "shares_outstanding": r"^(?:at end of|as at|balance (?:at|as at)|closing issued ordinary shares|issued ordinary shares less treasury shares|ordinary shares in issue|shares in issue|number of issued ordinary shares)\b",
        "operating_cash_flow": r"^net cash flows? (?:(?:\(used in\)|used in)/generated from|from/\(used in\)|generated from|used in|from) operating activities\b",
        "investing_cash_flow": r"^net cash flows? (?:(?:\(used in\)|used in)/generated from|from/\(used in\)|generated from|used in|from) investing activities\b",
        "financing_cash_flow": r"^net cash flows? (?:(?:\(used in\)|used in)/generated from|from/\(used in\)|generated from|used in|from) financing activities\b",
        "net_change_cash": r"^net (?:increase/\(decrease\)|\(increase\)/decrease|increase|decrease|change) in cash and cash equivalents\b",
        "ending_cash": r"^cash and (?:cash equivalents|bank balances) at (?:the )?end of (?:the )?(?:financial )?(?:year|period)\b",
    }

    def authoritative_candidate_for_target(target):
        """Return only a candidate strong enough to become a fact or LLM operand."""
        role_key = text(target.get("period_role")) + "_value"
        candidates = [(candidate, number(candidate.get(role_key)))
                      for candidate in target.get("candidate_rows", [])]
        candidates = [entry for entry in candidates if entry[1] is not None]
        if not candidates:
            return None
        concept_key = text(target.get("concept_key"))
        preferred = [entry for entry in candidates
                     if text(entry[0].get("derivation_method")).upper() in authoritative_methods]
        pattern = exact_statement_patterns.get(concept_key)
        exact = [entry for entry in candidates
                 if pattern and re.match(pattern, re.sub(
                     r"^\[page\s+\d+\]\s*", "",
                     text(entry[0].get("description")).strip().lower(), flags=re.I))]
        pool = preferred or exact
        if not pool:
            return None
        # Aggregate concepts must prefer the governed component calculation
        # over an individual component carrying an otherwise-valid row label.
        # This priority is concept based, not issuer/page based.
        aggregate_methods = {
            "sg_and_a_expense": "DIRECT_COMPONENT_SUM",
            "depreciation_amortization": "DIRECT_COMPONENT_SUM",
            "depreciation_amortisation": "DIRECT_COMPONENT_SUM",
            "trade_receivables_net": "DIRECT_COMPONENT_SUM",
            "net_ppe": "DIRECT_COMPONENT_SUM",
            "long_term_debt": "DIRECT_COMPONENT_SUM",
            "operating_income_ebit": "GOVERNED_EBIT_RECONCILIATION",
            "shares_outstanding": "ISSUED_LESS_TREASURY_SHARES",
        }
        mapping_validation = financial_mapping_rule(concept_key).get("validation") or {}
        required_method = (
            text(mapping_validation.get("preferred_resolution_method")).upper()
            or aggregate_methods.get(concept_key)
        )
        governed_pool = [entry for entry in pool
                         if text(entry[0].get("derivation_method")).upper() == required_method]
        if governed_pool:
            pool = governed_pool
        # Conflicting values under equally strong labels are ambiguous. They
        # must be reviewed; choosing the first is how note headers leaked into
        # earlier LLM prompts and saved facts.
        unique_values = {round(entry[1], 8) for entry in pool}
        if len(unique_values) != 1:
            return None
        selected_candidate, selected_value = pool[0]
        if concept_key in {
            "cost_of_goods_sold", "sg_and_a_expense",
            "depreciation_amortization", "depreciation_amortisation",
            "interest_expense",
        }:
            selected_value = abs(selected_value)
        return selected_candidate, selected_value

    for target in queued:
        target["reported_existing_value"] = target.get("existing_value")
        authoritative = authoritative_candidate_for_target(target)
        target["trusted_existing_value"] = authoritative[1] if authoritative else None
        target["existing_value_trust"] = "SELECTED_REPORT_GOVERNED" if authoritative else "UNTRUSTED_OMITTED_FROM_LLM"
        if (authoritative and number(target.get("existing_value")) is not None
                and abs(number(target.get("existing_value")) - authoritative[1]) > max(.01, abs(authoritative[1]) * .0001)):
            target["rejected_extracted_value"] = number(target.get("existing_value"))
            target["rejection_reason"] = "CONFLICTS_WITH_SELECTED_REPORT_EVIDENCE"
    queued_statement_types = {item["statement_type"] for item in queued}
    complete_statement_tables = []
    for table in tables:
        if table.get("statement_type") not in queued_statement_types:
            continue
        complete_statement_tables.append({
            "statement_type": table.get("statement_type"),
            "table_title": table.get("table_title"),
            "page_number": table.get("page_number"),
            "currency": table.get("currency"), "unit": table.get("unit"),
            "rows": [{
                "concept_key": row.get("concept_key"), "label": row.get("row_label"),
                "current_period": row.get("values", {}).get("current", {}).get("period"),
                "current_value": row.get("values", {}).get("current", {}).get("numeric_value"),
                "prior_period": row.get("values", {}).get("prior", {}).get("period"),
                "prior_value": row.get("values", {}).get("prior", {}).get("numeric_value"),
            } for row in table.get("rows", [])],
        })
    def operand_token(value):
        return re.sub(r"[^a-z0-9]+", "", text(value).lower())

    statement_operand_values = {}
    for table in complete_statement_tables:
        statement_type = table.get("statement_type")
        for role in ("current", "prior"):
            available = {}
            for row in table.get("rows", []):
                cache_key = (text(statement_type), text(row.get("concept_key")))
                candidate_rows = source_candidate_cache.get(cache_key, ([], []))[1]
                governed = authoritative_candidate_for_target({
                    "concept_key": row.get("concept_key"), "period_role": role,
                    "candidate_rows": candidate_rows,
                })
                supplied_value = governed[1] if governed else None
                # A prior deterministic/source-validation pass may already
                # have persisted the operand even when the compact candidate
                # table has no direct row. Reuse that validated statement
                # value for arithmetic identities; never ask the LLM to add
                # three cash-flow figures that are already on screen.
                if supplied_value is None:
                    row_values = row.get("values") or {}
                    role_value = row_values.get(role) if isinstance(row_values, dict) else None
                    if isinstance(role_value, dict):
                        supplied_value = number(role_value.get("numeric_value"))
                    if supplied_value is None:
                        supplied_value = number(row.get(role + "_value"))
                if supplied_value is None:
                    continue
                for identifier in (row.get("concept_key"), row.get("label")):
                    token = operand_token(identifier)
                    if token:
                        available[token] = supplied_value
            statement_operand_values[(statement_type, role)] = available

    # Resolve algebraically complete cash-flow identities locally. This avoids
    # an LLM call and provides the cash-flow inputs required for reconciliation.
    local_derivations = {}
    for target in queued:
        concept_key = text(target.get("concept_key"))
        cash_formula = {
            "operating_cash_flow": ("SUBTRACT", "net_change_cash", "investing_cash_flow", "financing_cash_flow"),
            "investing_cash_flow": ("SUBTRACT", "net_change_cash", "operating_cash_flow", "financing_cash_flow"),
            "financing_cash_flow": ("SUBTRACT", "net_change_cash", "operating_cash_flow", "investing_cash_flow"),
            "net_change_cash": ("SUM", "operating_cash_flow", "investing_cash_flow", "financing_cash_flow"),
        }.get(concept_key)
        if not cash_formula:
            continue
        available = statement_operand_values.get(
            (target.get("statement_type"), target.get("period_role")), {}
        )
        operation, *operand_names = cash_formula
        operand_values = [available.get(operand_token(name)) for name in operand_names]
        if any(value is None for value in operand_values):
            continue
        proposed_value = (sum(operand_values) if operation == "SUM"
                          else operand_values[0] - sum(operand_values[1:]))
        local_derivations[target["target_id"]] = {
            "target_id": target["target_id"], "can_resolve": True,
            "proposed_value": proposed_value,
            "resolution_method": "FORMULA_DERIVATION",
            "formula": formula_map.get(concept_key),
            "operation": operation,
            "operands": [{"name": name, "value": value}
                         for name, value in zip(operand_names, operand_values)],
            "evidence": [],
            "explanation": "Calculated by the backend from the cash-flow reconciliation identity.",
            "confidence": 1.0, "deterministic_formula": True,
        }

    # Historical reports often have their best statement text in the saved
    # database digest rather than in the per-concept fragment lookup. Parse
    # that digest before deciding which cells require Bedrock. This makes exact
    # audited rows available to the same deterministic validator used for a
    # newly uploaded PDF and keeps rate limiting from blocking direct values.
    digest_by_statement = report_statement_evidence_digest(document_id, run_id)
    for target in queued:
        digest = digest_by_statement.get(text(target.get("statement_type")))
        if not digest or not text(digest.get("content")):
            continue
        page_lines = collections.defaultdict(list)
        fallback_page = integer((digest.get("page_numbers") or [0])[0], 0)
        for digest_line in text(digest.get("content")).splitlines():
            page_match = re.match(r"^\[page\s+(\d+)\]\s*(.*)$", digest_line.strip(), re.I)
            if page_match:
                page_lines[integer(page_match.group(1), fallback_page)].append(page_match.group(2))
            elif digest_line.strip():
                page_lines[fallback_page].append(digest_line)
        digest_evidence = [
            {"page_number": page_number, "content": "\n".join(lines),
             "evidence_source": digest.get("evidence_source") or "DATABASE_STATEMENT_DIGEST"}
            for page_number, lines in page_lines.items() if lines
        ]
        digest_candidates = build_resolution_candidate_table(
            digest_evidence, text(target.get("concept_key")), text(target.get("concept_label"))
        )
        if digest_candidates:
            merged = {
                (integer(candidate.get("page_number"), 0), text(candidate.get("source_line"))): candidate
                for candidate in [*(target.get("candidate_rows") or []), *digest_candidates]
            }
            target["candidate_rows"] = list(merged.values())[:24]
            existing_pages = {
                (integer(item.get("page_number"), 0), text(item.get("content")))
                for item in target.get("evidence", [])
            }
            for item in digest_evidence:
                signature = (integer(item.get("page_number"), 0), text(item.get("content")))
                if signature not in existing_pages:
                    target.setdefault("evidence", []).append(item)
                    existing_pages.add(signature)
    # Governed selected-report rows are resolved locally. The model receives
    # only genuinely unresolved targets and never receives a conflicting raw
    # database value as if it were a trusted fact.
    llm_targets = ([] if force_source_refresh else [
        target for target in queued
        if target["target_id"] not in local_derivations
        and authoritative_candidate_for_target(target) is None
    ])
    dependency_keys = {
        "total_assets": {"total_current_assets", "total_non_current_assets"},
        "total_liabilities": {"total_current_liabilities", "total_non_current_liabilities"},
        "total_shareholders_equity": {"share_capital", "treasury_shares", "accumulated_profit_or_losses", "other_reserves"},
        "working_capital": {"total_current_assets", "total_current_liabilities"},
        "net_debt": {"short_term_debt", "long_term_debt", "cash_and_equivalents"},
        "ebitda": {"operating_income_ebit", "depreciation_amortization"},
        "gross_profit": {"revenue", "cost_of_goods_sold"},
        "sg_and_a_expense": {"selling_expenses", "marketing_and_distribution_expenses", "administrative_expenses"},
        "operating_income_ebit": {"profit_before_tax", "loss_before_income_tax", "finance_costs", "finance_income"},
        "long_term_debt": {"non_current_borrowings", "non_current_lease_liabilities"},
        "shares_outstanding": {"issued_ordinary_shares", "treasury_shares"},
        "ending_cash": {"beginning_cash", "operating_cash_flow", "investing_cash_flow", "financing_cash_flow", "fx_effect_on_cash"},
    }
    required_dependencies = set().union(*(dependency_keys.get(item["concept_key"], set()) for item in llm_targets)) if llm_targets else set()
    formula_operand_context = []
    for table in complete_statement_tables:
        statement_type = text(table.get("statement_type"))
        for row in table.get("rows", []):
            concept_key = text(row.get("concept_key"))
            if concept_key not in required_dependencies:
                continue
            candidate_rows = source_candidate_cache.get((statement_type, concept_key), ([], []))[1]
            trusted_row = {"concept_key": concept_key}
            for role in ("current", "prior"):
                governed = authoritative_candidate_for_target({
                    "concept_key": concept_key, "period_role": role,
                    "candidate_rows": candidate_rows,
                })
                if governed:
                    trusted_row[role + "_value"] = governed[1]
            if len(trusted_row) > 1:
                formula_operand_context.append(trusted_row)
    def compact_llm_target(target):
        """Reference shared statement evidence instead of repeating it per cell."""
        return {
            **{key: target.get(key) for key in (
                "target_id", "statement_type", "concept_key", "concept_label",
                "period_role", "period_label", "trusted_existing_value", "currency", "unit",
                "governed_formula",
            )},
            # Ambiguous parser candidates are deliberately excluded. The LLM
            # sees the compact audited source text, never pre-labelled note
            # numbers or stale database values masquerading as financial facts.
            "candidate_rows": [],
            "allowed_evidence_pages": sorted({
                integer(item.get("page_number"), 0)
                for item in target.get("evidence", []) if integer(item.get("page_number"), 0) > 0
            }),
        }

    # Reuse the digest already loaded for deterministic historical-report
    # matching; it is also the single compact evidence packet sent to Bedrock.
    required_statement_types = {text(item.get("statement_type")) for item in llm_targets}
    shared_statement_evidence = []

    def targeted_digest_content(statement_type: str, digest: Dict[str, Any], targets: List[Dict[str, Any]]) -> str:
        """Keep only rows needed to resolve this request, plus minimal table context."""
        raw_lines = [line.strip() for line in text(digest.get("content")).splitlines() if line.strip()]
        relevant_concepts = set()
        relevant_labels = []
        for target in targets:
            if text(target.get("statement_type")) != statement_type:
                continue
            concept = text(target.get("concept_key"))
            relevant_concepts.add(concept)
            relevant_concepts.update(dependency_keys.get(concept, set()))
            relevant_labels.append(text(target.get("concept_label")).lower())
        terms = set()
        for concept in relevant_concepts:
            terms.update(concept_evidence_aliases(concept))
            terms.update(token for token in re.findall(r"[a-z]{4,}", concept.replace("_", " "))
                         if token not in {"total", "current", "prior"})
        for label in relevant_labels:
            terms.update(token for token in re.findall(r"[a-z]{4,}", label)
                         if token not in {"total", "current", "prior", "from"})
        selected_indexes = set()
        for index, line in enumerate(raw_lines):
            normalized = re.sub(r"^\[page\s+\d+\]\s*", "", line.lower())
            if any(term in normalized for term in terms):
                # Retain one neighbouring line because PDF extraction can put
                # the label and numeric cells on adjacent lines.
                selected_indexes.update(range(max(0, index - 1), min(len(raw_lines), index + 2)))
            elif (re.search(r"\b20\d{2}\b", normalized)
                  and any(marker in normalized for marker in (
                      "statement", "group", "company", "currency", "expressed", "in thousands", "in millions"))):
                selected_indexes.add(index)
        selected, seen = [], set()
        for index in sorted(selected_indexes):
            line = raw_lines[index]
            signature = re.sub(r"\s+", " ", line).casefold()
            if signature in seen:
                continue
            seen.add(signature)
            selected.append(line)
            if len(selected) >= 50 or len("\n".join(selected)) >= 4200:
                break
        return "\n".join(selected)[:4200]

    for statement_type in sorted(required_statement_types):
        digest = digest_by_statement.get(statement_type)
        if digest:
            compact_content = targeted_digest_content(statement_type, digest, llm_targets)
            if not compact_content:
                # Use already-targeted fragments below instead of sending an
                # unrelated full statement or report section.
                digest = None
        if digest:
            shared_statement_evidence.append({
                "statement_type": statement_type,
                "page_numbers": digest.get("page_numbers", []),
                "evidence_hash": digest.get("evidence_hash"),
                "evidence_source": digest.get("evidence_source"),
                "content": compact_content,
            })
            continue
        # If a legacy report cannot yet produce a complete digest, deduplicate
        # the already selected target evidence into one statement packet.
        rows, seen_rows, pages = [], set(), set()
        for target in llm_targets:
            if text(target.get("statement_type")) != statement_type:
                continue
            for item in target.get("evidence", []):
                page_number, content = integer(item.get("page_number"), 0), text(item.get("content"))
                signature = (page_number, content)
                if not content or signature in seen_rows:
                    continue
                seen_rows.add(signature)
                pages.add(page_number)
                # Per-target evidence is already compacted. Cap each excerpt
                # again so one malformed fragment cannot dominate the batch.
                rows.append(f"[page {page_number}] {content[:900]}")
        if rows:
            shared_statement_evidence.append({
                "statement_type": statement_type, "page_numbers": sorted(pages),
                "evidence_source": "DEDUPLICATED_TARGET_EVIDENCE",
                "content": "\n".join(rows)[:4200],
            })
    shared_pages_by_statement = {
        text(item.get("statement_type")): {
            integer(page, 0) for page in (item.get("page_numbers") or []) if integer(page, 0) > 0
        }
        for item in shared_statement_evidence
    }

    llm_resolution_contract = {
        "revenue": "Use the exact consolidated income-statement Revenue/Net sales/Turnover row. Reject narrative shorthand such as 7.5 million and reject note numbers.",
        "cost_of_goods_sold": "Use the exact consolidated Cost of sales/Cost of revenue row; return the expense magnitude.",
        "sg_and_a_expense": "First use an explicit audited SG&A or selling/general/administrative subtotal for the matching Group period. Only when no subtotal exists, calculate selling/marketing/distribution expense + general and administrative expense. Exclude R&D, depreciation, finance costs and other operating expenses unless the issuer explicitly includes them in its labelled SG&A subtotal.",
        "depreciation_amortization": "First use an explicit audited combined depreciation-and-amortisation expense total for the matching period. Otherwise add current-period depreciation charges by asset class plus separately disclosed finite-life intangible amortisation exactly once. Exclude accumulated depreciation/amortisation, asset cost, carrying amount, impairment, disposals, useful-life years, rates and cash-flow add-backs when they duplicate note expense totals.",
        "operating_income_ebit": "Use a directly disclosed audited operating profit/income/loss subtotal whenever present and preserve its sign. Only if that subtotal is absent, calculate profit/loss before tax + absolute finance costs - absolute finance income using same-period Group rows. Never calculate EBIT as revenue minus the UI fields COGS, SG&A and D&A because depreciation or other operating costs may already be embedded in those classifications.",
        "interest_expense": "Use total finance costs/finance expenses from the income statement. Do not substitute interest paid or an individual borrowing component.",
        "net_profit": "Use final profit/loss attributable to owners for the period, preserving its accounting sign.",
        "total_current_assets": "Use the Group consolidated current-assets subtotal, or sum all disclosed current-asset components once.",
        "trade_receivables_net": "Use net Group trade receivables; if required, gross trade receivables less ECL allowance. Do not use trade-and-other receivables when a separate trade row exists.",
        "inventory": "Use the consolidated closing inventory/inventories balance, not write-offs, purchases or an allowance movement.",
        "net_ppe": "Use closing net PPE carrying amount; add right-of-use assets only when the configured scoring definition requires and the issuer presents it separately.",
        "total_assets": "Use consolidated TOTAL ASSETS; otherwise total current assets + total non-current assets.",
        "total_current_liabilities": "Use the consolidated current-liabilities subtotal, not non-current liabilities.",
        "long_term_debt": "Non-current borrowings + non-current lease liabilities. Exclude current borrowings and note references.",
        "total_liabilities": "Use consolidated TOTAL LIABILITIES; otherwise current liabilities + all non-current liabilities including deferred tax.",
        "retained_earnings": "Use retained earnings, accumulated profits, accumulated losses or accumulated deficit, preserving the sign.",
        "total_shareholders_equity": "Use consolidated TOTAL EQUITY; otherwise total assets - total liabilities.",
        "shares_outstanding": "Closing issued ordinary-share count - treasury-share count. Use count columns only; never monetary share capital or weighted-average EPS shares.",
        "operating_cash_flow": "Use net cash generated from/used in operating activities, preserving sign.",
        "investing_cash_flow": "Use net cash generated from/used in investing activities, preserving sign.",
        "financing_cash_flow": "Use net cash generated from/used in financing activities, preserving sign.",
        "net_change_cash": "Use direct net increase/decrease in cash; otherwise operating + investing + financing cash flows, preserving sign.",
        "ending_cash": "Use cash and cash equivalents at end of period, not beginning cash or a note number.",
    }
    relevant_resolution_contract = {
        key: value for key, value in llm_resolution_contract.items()
        if key in {text(target.get("concept_key")) for target in llm_targets}
    }

    batch_prompt = {
        "task": ("In one response, validate every supplied financial input across the Income Statement, Balance Sheet and Cash Flow Statement against only its selected-report evidence. "
                 "Return the correct value even when an existing value is populated; never estimate or invent."
                 if llm_validate_all else
                 "Resolve only the supplied missing financial inputs from compact evidence or governed formula operands. Never estimate or invent."),
        "rules": ["Return exactly one result per target_id in this single report-level response.", "Use the requested current/prior period.",
                  "A missing trusted_existing_value means the database value was intentionally withheld because it was not verified; do not infer it.",
                  "DIRECT_EXTRACTION requires an exact candidate/evidence value.",
                  "FORMULA_DERIVATION requires named numeric operands and ADD, SUM or SUBTRACT.",
                  "For formula derivations, use only formula_operand_context and list every operand.",
                  "Use UNRESOLVED when evidence is insufficient.",
                  "Ignore note-reference columns, page numbers, percentages and monetary share-capital amounts unless the requested concept requires them.",
                  "Prefer Group or Consolidated columns and preserve the disclosed current/prior year order and accounting signs.",
                  "Do not replace an existing populated value unless the same-report evidence proves the replacement for the same statement, scope, period, currency and unit.",
                  "When an exact audited subtotal exists, return DIRECT_EXTRACTION and do not recalculate it from components.",
                  "Use FORMULA_DERIVATION only when the required direct subtotal is absent and every named operand is present in formula_operand_context for the same period and scope.",
                  "Do not use one financial input as an operand for another unless the applicable concept_resolution_contract explicitly permits that formula.",
                  "Apply only the rule for each target's concept_key from concept_resolution_contract."],
        "source_priority": ["CONSOLIDATED_PRIMARY_STATEMENT", "AUDITED_SUBTOTAL",
                            "GOVERNED_COMPONENT_FORMULA", "SUPPORTING_NOTE", "NARRATIVE_ONLY_IF_NO_TABLE"],
        "concept_resolution_contract": relevant_resolution_contract,
        "formula_operand_context": formula_operand_context,
        "shared_statement_evidence": shared_statement_evidence,
        "missing_targets": [compact_llm_target(target) for target in llm_targets],
        # Gemini JSON-object mode does not receive the Bedrock API-level JSON
        # schema, so the required response shape must travel in the prompt.
        "response_contract": {
            "results": [{
                "target_id": "copy exactly from missing_targets.target_id",
                "can_resolve": False,
                "proposed_value": None,
                "resolution_method": "UNRESOLVED",
                "formula": "",
                "operation": "NONE",
                "operands": [],
                "evidence": [{"page_number": 0, "quote": "exact supplied evidence excerpt"}],
                "explanation": "concise evidence-based decision",
                "confidence": 0.0,
            }],
            "existing_value_exceptions": [],
        },
        "final_instruction": (
            "Return one JSON object only. Its top-level keys must be results and "
            "existing_value_exceptions. Return exactly one results item for every "
            "missing_targets item and copy each target_id without alteration."
        ),
    }
    result_item = {
        "type": "object", "properties": {
            "target_id": {"type": "string"}, "can_resolve": {"type": "boolean"},
            "proposed_value": {"type": ["number", "null"]},
            "resolution_method": {"type": "string", "enum": ["DIRECT_EXTRACTION", "FORMULA_DERIVATION", "UNRESOLVED"]},
            "formula": {"type": "string"},
            "operation": {"type": "string", "enum": ["ADD", "SUM", "SUBTRACT", "NONE"]},
            "operands": {"type": "array", "items": {"type": "object", "properties": {
                "name": {"type": "string"}, "value": {"type": "number"}},
                "required": ["name", "value"], "additionalProperties": False}},
            "evidence": {"type": "array", "items": {"type": "object", "properties": {
                "page_number": {"type": "integer"}, "quote": {"type": "string"}},
                "required": ["page_number", "quote"], "additionalProperties": False}},
            "explanation": {"type": "string"}, "confidence": {"type": "number"},
        },
        "required": ["target_id", "can_resolve", "proposed_value", "resolution_method", "formula",
                     "operation", "operands", "evidence", "explanation", "confidence"],
        "additionalProperties": False,
    }
    # Gemini uses Google's OpenAI-compatible JSON-object contract. Bedrock can
    # use the stricter json_schema response envelope below.
    batch_compound_mode = settings.get("provider") == "gemini"
    strict_batch_response_format = {"type": "json_schema", "json_schema": {
            "name": "batch_financial_fact_resolution", "strict": True,
            "schema": {"type": "object", "properties": {
                "results": {"type": "array", "items": result_item},
                "existing_value_exceptions": {"type": "array", "items": {"type": "object", "properties": {
                    "statement_type": {"type": "string"}, "concept_key": {"type": "string"},
                    "period_role": {"type": "string", "enum": ["current", "prior"]},
                    "existing_value": {"type": "number"}, "expected_value": {"type": "number"},
                    "formula": {"type": "string"}, "explanation": {"type": "string"}},
                    "required": ["statement_type", "concept_key", "period_role", "existing_value", "expected_value", "formula", "explanation"],
                    "additionalProperties": False}},
            }, "required": ["results", "existing_value_exceptions"], "additionalProperties": False}}}
    request_payload = {
        "model": settings["model"], "stream": False, "temperature": 0,
        "messages": [{"role": "system", "content": "Conservative financial extraction assistant. JSON only."},
                     {"role": "user", "content": json.dumps(batch_prompt, default=str)}],
        "response_format": ({"type": "json_object"} if batch_compound_mode
                            else strict_batch_response_format),
    }
    if settings.get("provider") == "gemini":
        # Financial batches can contain many targets. A larger output allowance
        # prevents Gemini from stopping in the middle of a JSON string.
        request_payload["max_tokens"] = 8192
    else:
        request_payload["max_completion_tokens"] = 4000 if llm_validate_all else 3000
    started = dt.datetime.now(dt.timezone.utc)
    try:
        rate_limited, retry_after, provider_error = False, "", {}
        provider_unavailable = False
        malformed_model_response = False
        model_used = settings["model"]
        attempted_models = [model_used]
        compound_fallback_used = False
        if not llm_targets:
            parsed = {"results": [], "existing_value_exceptions": []}
        else:
            try:
                response = post_cloud_llm_json(
                    settings,
                    settings["base_url"].rstrip("/") + "/chat/completions",
                    request_payload,
                    (5, min(settings["timeout_seconds"], 60)),
                )
            except RuntimeError as request_error:
                # A provider timeout is not a transaction failure. Continue
                # through the deterministic candidate/formula validator below,
                # save every independently verified cell, and leave only the
                # genuinely model-dependent targets for a later attempt.
                provider_unavailable = True
                provider_error = {
                    "message": str(request_error),
                    "exception_type": type(request_error).__name__,
                    "timed_out": True,
                }
                parsed = {"results": [], "existing_value_exceptions": []}
            else:
                if response.status_code in {403, 413, 429, 500, 502, 503, 504}:
                    rate_limited = response.status_code == 429
                    provider_unavailable = response.status_code in {500, 502, 503, 504}
                    retry_after = text(response.headers.get("retry-after"))
                    try:
                        provider_error = response.json()
                    except Exception:
                        provider_error = {"message": response.text[:500]}
                    # Continue: exact candidate rows can still be validated and
                    # persisted without an LLM response.
                    parsed = {"results": [], "existing_value_exceptions": []}
                else:
                    response.raise_for_status()
                    body = response.json()
                    choices = body.get("choices") or []
                    content = text(((choices[0].get("message") or {}).get("content")) if choices else "")
                    try:
                        parsed = parse_ollama_json(content)
                    except (json.JSONDecodeError, ValueError) as parse_error:
                        # Never fail the complete automatic pipeline because a
                        # provider stopped midway through JSON. Exact governed
                        # candidates below remain eligible for deterministic save;
                        # other targets are returned as review items.
                        malformed_model_response = True
                        provider_error = {
                            "message": "Gemini returned incomplete or malformed JSON; unresolved targets require review.",
                            "exception_type": type(parse_error).__name__,
                            "exception_message": str(parse_error),
                            "finish_reason": text(choices[0].get("finish_reason") if choices else ""),
                            "response_characters": len(content),
                        }
                        parsed = parse_partial_batch_results(content)
                        provider_error["recovered_result_count"] = len(parsed.get("results") or [])
        # Tolerate common JSON-object variations while retaining strict target
        # matching. This is compatibility normalization, not financial logic.
        if not isinstance(parsed.get("results"), list):
            alternate_results = next((parsed.get(key) for key in (
                "decisions", "resolutions", "financial_facts", "resolved_values"
            ) if isinstance(parsed.get(key), list)), None)
            if alternate_results is not None:
                parsed["results"] = alternate_results
            elif all(key in parsed for key in ("can_resolve", "proposed_value")):
                parsed["results"] = [parsed]
            else:
                parsed["results"] = []
        normalized_results = []
        expected_by_concept_role = {
            (text(target.get("concept_key")), text(target.get("period_role"))): target["target_id"]
            for target in llm_targets
        }
        for index, item in enumerate(parsed.get("results") or []):
            if not isinstance(item, dict):
                continue
            normalized = dict(item)
            target_id = text(normalized.get("target_id") or normalized.get("id"))
            if not target_id:
                target_id = expected_by_concept_role.get((
                    text(normalized.get("concept_key")),
                    text(normalized.get("period_role") or normalized.get("period")),
                ), "")
            # Positional recovery is safe only when the model returned exactly
            # one item per requested target in the supplied order.
            if (not target_id and len(parsed.get("results") or []) == len(llm_targets)
                    and index < len(llm_targets)):
                target_id = llm_targets[index]["target_id"]
            normalized["target_id"] = target_id
            normalized_results.append(normalized)
        parsed["results"] = normalized_results

        existing_value_exceptions = parsed.get("existing_value_exceptions")
        if not isinstance(existing_value_exceptions, list):
            existing_value_exceptions = []
        allowed = {item["target_id"]: item for item in queued}
        model_results = {text(item.get("target_id")): item for item in parsed.get("results", [])
                         if isinstance(item, dict) and text(item.get("target_id"))}
        results = []
        for target_id, target in allowed.items():
            # Python-governed calculations always take precedence. The model
            # is consulted only for a target that has neither an authoritative
            # statement candidate nor a complete deterministic formula.
            preferred_result = local_derivations.get(target_id) or model_results.get(target_id)
            item = dict(preferred_result or {
                "target_id": target_id, "can_resolve": False, "proposed_value": None,
                "resolution_method": "UNRESOLVED", "formula": target.get("governed_formula") or "",
                "operation": "NONE", "operands": [], "evidence": [],
                "explanation": "The model did not return a decision for this target.", "confidence": 0,
            })
            direct_candidates = []
            for candidate in target.get("candidate_rows", []):
                candidate_value = number(candidate.get(target["period_role"] + "_value"))
                if candidate_value is not None:
                    direct_candidates.append((candidate, candidate_value))
            # Governed rows outrank a model choice when a statement contains
            # several numerically plausible alternatives. Typical examples
            # are cash-flow reconciliation interest versus P&L finance costs,
            # borrowings versus borrowings-plus-leases, and share counts beside
            # monetary share capital. The LLM still validates the statement,
            # but cannot replace a stronger, mechanically verified candidate.
            authoritative = authoritative_candidate_for_target(target)
            if authoritative:
                candidate, candidate_value = authoritative
                item.update({
                    "can_resolve": True, "proposed_value": candidate_value,
                    "resolution_method": candidate.get("derivation_method") or "DIRECT_EXTRACTION",
                    "formula": target.get("governed_formula") or "DIRECT_DISCLOSED_VALUE",
                    "operation": "NONE", "operands": [],
                    "evidence": [{"page_number": integer(candidate.get("page_number"), 0),
                                  "quote": text(candidate.get("source_line"))}],
                    "explanation": "Backend applied the governed annual-statement candidate after LLM validation.",
                    "confidence": 1.0, "governed_candidate_override": True,
                })
            # An exact target-bearing annual-statement row is stronger than an
            # omitted/unresolved model response. Promote it deterministically;
            # the normal citation and candidate-value validators still run.
            if (not item.get("can_resolve") or number(item.get("proposed_value")) is None) and authoritative:
                candidate, candidate_value = authoritative
                item.update({
                    "can_resolve": True, "proposed_value": candidate_value,
                    "resolution_method": "DIRECT_EXTRACTION", "formula": "DIRECT_DISCLOSED_VALUE",
                    "operation": "NONE", "operands": [],
                    "evidence": [{"page_number": integer(candidate.get("page_number"), 0),
                                  "quote": text(candidate.get("source_line"))}],
                    "explanation": "Backend selected the exact target-labelled annual-statement candidate row after the model returned no usable value.",
                    "confidence": 0.99, "deterministic_candidate_fallback": True,
                })
            proposed = number(item.get("proposed_value"))
            confidence = number(item.get("confidence"))
            method = text(item.get("resolution_method")).upper()
            operands = item.get("operands") if isinstance(item.get("operands"), list) else []
            citations = item.get("evidence") if isinstance(item.get("evidence"), list) else []
            cited_pages = {integer(citation.get("page_number"), -1) for citation in citations if isinstance(citation, dict)}
            allowed_pages = ({integer(evidence.get("page_number"), -1) for evidence in target.get("evidence", [])}
                             | shared_pages_by_statement.get(text(target.get("statement_type")), set()))
            if item.get("can_resolve") and method == "DIRECT_EXTRACTION" and not (cited_pages & allowed_pages):
                item["can_resolve"], item["proposed_value"] = False, None
                item["resolution_method"] = "UNRESOLVED"
                item["explanation"] = "The proposed value did not cite a supplied annual-report page."
                proposed = None
                method = "UNRESOLVED"
            if item.get("can_resolve") and proposed is not None and method == "DIRECT_EXTRACTION":
                expected = [number(candidate.get(target["period_role"] + "_value"))
                            for candidate in target.get("candidate_rows", [])]
                expected = [value for value in expected if value is not None]
                # Some PDF extractors preserve a combined cash-flow caption
                # that the canonical candidate parser did not previously
                # recognize. Accept it only after proving that the model's
                # cited quote occurs on the supplied page, then parse the
                # current/prior pair from that exact line in Python.
                if not any(abs(value - proposed) <= max(.01, abs(proposed) * .0001)
                           for value in expected):
                    supplied_page_text = collections.defaultdict(list)
                    for evidence_item in target.get("evidence", []):
                        supplied_page_text[integer(evidence_item.get("page_number"), -1)].append(
                            text(evidence_item.get("content")))
                    for shared_item in shared_statement_evidence:
                        if text(shared_item.get("statement_type")) != text(target.get("statement_type")):
                            continue
                        for shared_line in text(shared_item.get("content")).splitlines():
                            page_match = re.match(r"^\[page\s+(\d+)\]\s*(.*)$", shared_line.strip(), re.I)
                            if page_match:
                                supplied_page_text[integer(page_match.group(1), -1)].append(page_match.group(2))
                    for citation in citations:
                        if not isinstance(citation, dict):
                            continue
                        page_number = integer(citation.get("page_number"), -1)
                        quote = re.sub(r"\s+", " ", text(citation.get("quote"))).strip()
                        page_content = re.sub(r"\s+", " ", "\n".join(supplied_page_text.get(page_number, []))).strip()
                        if not quote or quote.casefold() not in page_content.casefold():
                            continue
                        cited_candidates = build_resolution_candidate_table(
                            [{"page_number": page_number, "content": quote}],
                            text(target.get("concept_key")), text(target.get("concept_label")),
                        )
                        expected.extend(
                            number(candidate.get(target["period_role"] + "_value"))
                            for candidate in cited_candidates
                            if number(candidate.get(target["period_role"] + "_value")) is not None
                        )
                if not expected or not any(abs(value - proposed) <= max(.01, abs(proposed) * .0001) for value in expected):
                    item["can_resolve"], item["proposed_value"] = False, None
                    item["resolution_method"] = "UNRESOLVED"
                    item["explanation"] = "The proposed direct value did not match a supplied candidate row."
                    proposed = None
                    method = "UNRESOLVED"
            if item.get("can_resolve") and proposed is not None and method == "FORMULA_DERIVATION":
                values_to_calculate = [number(op.get("value")) for op in operands if isinstance(op, dict)]
                operation = text(item.get("operation")).upper()
                available_operands = statement_operand_values.get(
                    (target.get("statement_type"), target.get("period_role")), {}
                )
                operands_match_statement = bool(values_to_calculate) and len(values_to_calculate) == len(operands)
                for operand in operands:
                    supplied = number(operand.get("value")) if isinstance(operand, dict) else None
                    token = operand_token(operand.get("name")) if isinstance(operand, dict) else ""
                    matched_values = [value for name, value in available_operands.items()
                                      if token == name or (len(token) >= 5 and (token in name or name in token))]
                    if supplied is None or not any(abs(value - supplied) <= max(.01, abs(supplied) * .0001)
                                                   for value in matched_values):
                        operands_match_statement = False
                        break
                calculated = (sum(values_to_calculate) if values_to_calculate and operation in {"ADD", "SUM"}
                              else values_to_calculate[0] - sum(values_to_calculate[1:])
                              if values_to_calculate and operation == "SUBTRACT" else None)
                if (not operands_match_statement or calculated is None
                        or abs(calculated - proposed) > max(.01, abs(proposed) * .0001)):
                    item["can_resolve"], item["resolution_method"] = False, "UNRESOLVED"
                    item["explanation"] = "Formula operands did not match populated rows in the complete statement, or backend recalculation did not match the proposed value."
                    item["proposed_value"] = None
                elif not citations:
                    source_table = next((table for table in complete_statement_tables
                                         if table.get("statement_type") == target.get("statement_type")), {})
                    operand_summary = "; ".join(
                        f"{text(op.get('name'))} = {number(op.get('value'))}"
                        for op in operands if isinstance(op, dict)
                    )
                    item["evidence"] = [{
                        "page_number": integer(source_table.get("page_number"), 0),
                        "quote": "Calculated from populated annual-statement rows: " + operand_summary,
                    }]
            if confidence is None or not 0 <= confidence <= 1:
                item["can_resolve"], item["proposed_value"] = False, None
            # Never leave a known-bad populated value in place merely because
            # the model omitted or rejected a row. The fallback is still
            # selected-report evidence, not a heuristic or another document.
            if (not item.get("can_resolve") or number(item.get("proposed_value")) is None) and authoritative:
                rejected_llm = dict(item) if target_id in model_results else {}
                candidate, candidate_value = authoritative
                item.update({
                    "can_resolve": True, "proposed_value": candidate_value,
                    "resolution_method": (candidate.get("derivation_method") or "DIRECT_EXTRACTION"),
                    "formula": target.get("governed_formula") or "DIRECT_DISCLOSED_VALUE",
                    "operation": "NONE", "operands": [],
                    "evidence": [{"page_number": integer(candidate.get("page_number"), 0),
                                  "quote": text(candidate.get("source_line"))}],
                    "explanation": "Selected-report candidate applied after the LLM result was unavailable or failed evidence validation.",
                    "confidence": 0.99, "deterministic_candidate_fallback": True,
                    "llm_rejected_result": rejected_llm,
                })
            results.append({**target, **item})
        saved_count = 0
        with postgres_connection() as connection:
            ensure_fact_resolution_tables(connection)
            with connection.cursor() as cursor:
                for result in results:
                    proposed = number(result.get("proposed_value"))
                    confidence = number(result.get("confidence"))
                    if not result.get("can_resolve") or proposed is None or confidence is None or confidence < 0.80:
                        result["saved_to_report"] = False
                        continue
                    role = text(result.get("period_role")).lower()
                    opposite_role = "prior" if role == "current" else "current"
                    adjacent_values = [
                        number(candidate.get(opposite_role + "_value"))
                        for candidate in (result.get("candidate_rows") or [])
                        if isinstance(candidate, dict)
                    ]
                    if any(looks_like_note_identifier(proposed, adjacent)
                           for adjacent in adjacent_values if adjacent is not None):
                        result.update({
                            "can_resolve": False, "proposed_value": None,
                            "saved_to_report": False,
                            "resolution_method": "NOTE_COLUMN_REJECTED",
                            "explanation": (
                                "Rejected before database save because the proposed small integer "
                                "is the Note-column identifier beside a materially larger amount."
                            ),
                        })
                        continue
                    proposal_id, override_id = str(uuid.uuid4()), str(uuid.uuid4())
                    citations = result.get("evidence") if isinstance(result.get("evidence"), list) else []
                    operands = result.get("operands") if isinstance(result.get("operands"), list) else []
                    candidate_rows = result.get("candidate_rows") if isinstance(result.get("candidate_rows"), list) else []
                    validation_message = "Batch result validated against governed evidence and saved to the report override layer."
                    cursor.execute("""INSERT INTO financial_risk_intelligence.financial_fact_resolution_proposals
                        (proposal_id,assessment_run_id,source_document_id,statement_type,concept_key,concept_label,period_role,period_label,
                         proposed_value,currency,unit,resolution_method,formula,operands_json,candidate_rows_json,evidence_json,explanation,confidence,
                         validation_status,validation_message,model_name,prompt_json,response_json,status,reviewed_at,reviewed_by)
                        VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s::jsonb,%s::jsonb,%s::jsonb,%s,%s,%s,%s,%s,%s::jsonb,%s::jsonb,
                                'APPROVED',NOW(),'BATCH_BEDROCK_VALIDATED')""",
                        (proposal_id,run_id,document_id,result.get("statement_type"),result.get("concept_key"),result.get("concept_label"),
                         result.get("period_role"),result.get("period_label") or result.get("period_role"),proposed,
                         result.get("currency"),result.get("unit"),result.get("resolution_method"),result.get("formula"),
                         json.dumps(operands),json.dumps(candidate_rows),json.dumps(citations),text(result.get("explanation")),confidence,
                          "VALIDATED_FOR_REPORT",validation_message,model_used,json.dumps(batch_prompt,default=str),
                         json.dumps(result,default=str)))
                    cursor.execute("""INSERT INTO financial_risk_intelligence.approved_financial_fact_overrides
                        (override_id,proposal_id,assessment_run_id,source_document_id,statement_type,concept_key,period_role,period_label,
                         numeric_value,currency,unit,resolution_method,confidence,evidence_json,approved_by,validated_rule_version)
                        VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s::jsonb,'BATCH_BEDROCK_VALIDATED',%s)
                        ON CONFLICT (assessment_run_id,source_document_id,concept_key,period_role) DO UPDATE SET
                         proposal_id=EXCLUDED.proposal_id,numeric_value=EXCLUDED.numeric_value,currency=EXCLUDED.currency,
                         unit=EXCLUDED.unit,resolution_method=EXCLUDED.resolution_method,confidence=EXCLUDED.confidence,
                         evidence_json=EXCLUDED.evidence_json,approved_by=EXCLUDED.approved_by,
                         validated_rule_version=EXCLUDED.validated_rule_version,approved_at=NOW(),active=TRUE""",
                        (override_id,proposal_id,run_id,document_id,result.get("statement_type"),result.get("concept_key"),
                         result.get("period_role"),result.get("period_label") or result.get("period_role"),proposed,
                         result.get("currency"),result.get("unit"),result.get("resolution_method"),confidence,json.dumps(citations),
                         active_financial_validation_version(result.get("concept_key"))))
                    result["proposal_id"], result["saved_to_report"] = proposal_id, True
                    saved_count += 1
        response_message = f"Saved {saved_count} backend-validated value(s) to the report override layer."
        persisted_input_count = 0
        if saved_count:
            persisted_input_count = persist_resolved_financial_inputs(
                run_id, document_id, complete_statement_tables,
            )
        if rate_limited:
            response_message += f" {settings['provider'].title()} was throttled; exact annual-statement candidates were still processed without the model."
        elif provider_unavailable:
            response_message += f" {settings['provider'].title()} remained temporarily unavailable after bounded retries; exact annual-statement candidates were processed and other values remain for review."
        elif malformed_model_response:
            response_message += " Gemini returned incomplete JSON; exact annual-statement candidates were saved and remaining values were left for review."
        elif not llm_targets:
            response_message += " No model call was needed because all requested values had exact annual-statement candidates."
        critical_concepts = {
            "revenue", "total_income", "operating_revenue", "revenue_from_operations",
            "property_development_revenue", "property_sales", "sale_of_properties",
            "revenue_from_contracts_with_customers", "turnover", "gross_revenue",
            "rental_revenue", "rental_income", "construction_revenue", "income_from_properties",
            "total_assets", "assets", "total_asset", "group_total_assets",
            "consolidated_total_assets", "total_current_and_non_current_assets",
        }
        critical_unresolved_count = sum(
            1 for item in results
            if text(item.get("concept_key")) in critical_concepts and not item.get("saved_to_report")
        )
        llm_validation_complete = bool(llm_validate_all and llm_targets and not rate_limited
                                       and not provider_unavailable
                                       and not malformed_model_response
                                       and len(model_results) >= len(llm_targets))
        replaced_count = sum(
            1 for item in results
            if item.get("saved_to_report")
            and number(item.get("extracted_value")) is not None
            and number(item.get("proposed_value")) is not None
            and abs(number(item.get("proposed_value")) - number(item.get("extracted_value")))
                > max(.01, abs(number(item.get("extracted_value"))) * .0001)
        )
        response_payload = {"status": "RESOLVED_VALUES_SAVED", "provider": settings.get("provider"), "model": model_used,
                        "data_source": source, "model_calls": 1 if llm_targets else 0,
                        "elapsed_seconds": round((dt.datetime.now(dt.timezone.utc) - started).total_seconds(), 3),
                        "requested_count": len(queued), "deferred_count": len(deferred),
                        "validated_skip_count": len(validated_target_ids),
                        "llm_target_count": len(llm_targets), "rate_limited": rate_limited,
                        "provider_unavailable": provider_unavailable,
                        "malformed_model_response": malformed_model_response,
                        "llm_validate_all": llm_validate_all,
                        "llm_validation_complete": llm_validation_complete,
                        "llm_configuration_error": llm_configuration_error,
                        "retry_after_seconds": retry_after,
                        "provider_error": provider_error if (rate_limited or provider_unavailable or malformed_model_response) else {},
                        "attempted_models": attempted_models,
                        "compound_fallback_used": compound_fallback_used,
                        "saved_count": saved_count, "replaced_count": replaced_count, "results": results,
                        "persisted_input_count": persisted_input_count,
                        "existing_value_exceptions": existing_value_exceptions,
                        "unresolved_count": sum(1 for item in results if not item.get("saved_to_report")),
                        "critical_unresolved_count": critical_unresolved_count,
                        "resolution_job_key": resolution_job_key,
                        "message": response_message}
        # A capped batch remains resumable. The job becomes final only after
        # every deferred target has been attempted and the score-gating revenue
        # and total-assets values are saved. Other evidence-unavailable optional
        # fields remain documented but do not trigger repeated model calls.
        finish_resolution_job(
            resolution_job_key,
            "COMPLETED" if (not deferred and critical_unresolved_count == 0
                            and (not llm_validate_all or llm_validation_complete)) else "PARTIAL",
            response_payload,
        )
        return jsonify(response_payload)
    except Exception as exc:
        print("BATCH FACT RESOLUTION FAILED:", type(exc).__name__, exc)
        finish_resolution_job(resolution_job_key, "FAILED", {}, f"{type(exc).__name__}: {exc}")
        return jsonify({"error": f"{type(exc).__name__}: {exc}", "stage": "BATCH_LLM_PREVIEW"}), 502


VALIDATED_RUN_CONCEPTS = [
    "revenue", "cost_of_goods_sold", "sg_and_a_expense", "depreciation_amortization",
    "operating_income_ebit", "interest_expense", "net_profit", "total_current_assets",
    "trade_receivables_net", "inventory", "net_ppe", "total_assets",
    "total_current_liabilities", "long_term_debt", "total_liabilities", "retained_earnings",
    "total_shareholders_equity", "shares_outstanding", "operating_cash_flow",
    "investing_cash_flow", "financing_cash_flow", "net_change_cash", "ending_cash",
    "total_income", "net_interest_income", "non_interest_income", "operating_expenses",
    "provisions_impairment", "profit_before_tax", "gross_loans_advances", "stage3_npa",
    "ecl_balance", "investments", "customer_deposits", "borrowings", "cet1_ratio",
]


def persisted_missing_statement_cells(run_id: str, document_id: str,
                                      target_concepts: List[str]) -> List[Dict[str, str]]:
    """Recount missing cells from the final DB-governed statement snapshot."""
    values, _ = resolved_values()
    selected = [row for row in values.to_dict(orient="records")
                if text(row.get("assessment_run_id") or row.get("run_id")) == run_id
                and text(row.get("source_document_id")) == document_id]
    if not selected:
        selected = list(load_analysis_history_snapshot(run_id, document_id).get("values") or [])
    tables = build_resolved_tables(selected)
    apply_fact_overrides(tables, approved_fact_overrides(run_id, document_id))
    requested = {text(item) for item in target_concepts if text(item)}
    missing_cells, seen = [], set()
    for table in tables:
        for row in table.get("rows", []):
            concept_key = text(row.get("concept_key"))
            if requested and concept_key not in requested:
                continue
            for role in ("current", "prior"):
                key = (concept_key, role)
                if key in seen:
                    continue
                seen.add(key)
                value = (row.get("values") or {}).get(role) or {}
                if number(value.get("numeric_value")) is None:
                    missing_cells.append({"concept_key": concept_key, "period_role": role})
    return missing_cells


@app.route("/api/run-analysis-validated", methods=["POST"])
def run_analysis_validated():
    """Validate selected-report inputs, persist corrections, score, and snapshot atomically."""
    payload = request.get_json(silent=True) or {}
    run_id, document_id = text(payload.get("assessment_run_id")), text(payload.get("source_document_id"))
    if not run_id or not document_id:
        return jsonify({"error": "assessment_run_id and source_document_id are required"}), 400
    target_concepts = payload.get("target_concepts")
    target_concepts = ([text(item) for item in target_concepts if text(item)]
                       if isinstance(target_concepts, list) else VALIDATED_RUN_CONCEPTS)
    validate_all_statements = text(payload.get("llm_validate_all")).lower() in {"1", "true", "yes", "on"}
    started = dt.datetime.now(dt.timezone.utc)
    explicit_resolution_id = "run-analysis-" + str(uuid.uuid4())

    # Full-statement validation is an explicit user action. Keep each statement
    # in its own compact provider request so one slow/failed statement does not
    # discard successful Python validations or prevent the next statement from
    # being processed. Durable per-cell flags suppress completed cells.
    if validate_all_statements:
        income_concepts = {
            "revenue", "total_income", "cost_of_goods_sold", "sg_and_a_expense",
            "depreciation_amortization", "operating_income_ebit", "profit_before_tax",
            "interest_expense", "net_profit", "net_interest_income", "non_interest_income",
            "operating_expenses", "provisions_impairment",
        }
        balance_concepts = {
            "total_current_assets", "trade_receivables_net", "inventory", "net_ppe",
            "total_assets", "total_current_liabilities", "long_term_debt", "total_liabilities",
            "retained_earnings", "total_shareholders_equity", "shares_outstanding",
            "gross_loans_advances", "stage3_npa", "ecl_balance", "investments",
            "customer_deposits", "borrowings", "cet1_ratio",
        }
        cash_concepts = {
            "operating_cash_flow", "investing_cash_flow", "financing_cash_flow",
            "net_change_cash", "ending_cash",
        }
        statement_groups = [
            ("INCOME_STATEMENT", [item for item in target_concepts if item in income_concepts]),
            ("BALANCE_SHEET", [item for item in target_concepts if item in balance_concepts]),
            ("CASH_FLOW_STATEMENT", [item for item in target_concepts if item in cash_concepts]),
        ]
        statement_batches, batch_errors = [], []
        for statement_index, (statement_type, concepts) in enumerate(statement_groups, 1):
            if not concepts:
                continue
            validation_request = {
                "assessment_run_id": run_id,
                "source_document_id": document_id,
                "verify_source": False,
                "llm_validate_all": True,
                "maximum_targets": max(2, len(concepts) * 2),
                "target_concepts": concepts,
                "validation_request_id": explicit_resolution_id + f"-{statement_index}",
            }
            with app.test_request_context(
                    "/api/financial-fact-resolution/batch-preview",
                    method="POST", json=validation_request):
                outcome = batch_financial_fact_resolution_preview()
                response, status_code = ((outcome[0], outcome[1])
                                         if isinstance(outcome, tuple) else (outcome, 200))
                statement_validation = response.get_json() if hasattr(response, "get_json") else {}
            statement_validation["statement_type"] = statement_type
            statement_validation["http_status"] = status_code
            statement_batches.append(statement_validation)
            if status_code >= 400:
                batch_errors.append({
                    "statement_type": statement_type,
                    "status": status_code,
                    "error": text(statement_validation.get("error")) or "Statement validation failed.",
                })
            # A provider failure in one group must not prevent deterministic
            # processing of later groups. A true in-progress collision is the
            # only condition returned immediately to avoid duplicate work.
            if status_code == 202:
                return jsonify({
                    "status": "VALIDATION_RUNNING", "validation": statement_validation,
                    "backend_build": BACKEND_BUILD_ID,
                }), 202

        validation = {
            "statement_batches": statement_batches,
            "batch_errors": batch_errors,
            "requested_count": sum(integer(item.get("requested_count"), 0) for item in statement_batches),
            "saved_count": sum(integer(item.get("saved_count"), 0) for item in statement_batches),
            "replaced_count": sum(integer(item.get("replaced_count"), 0) for item in statement_batches),
            "unresolved_count": sum(integer(item.get("unresolved_count"), 0) for item in statement_batches),
            "validated_skip_count": sum(integer(item.get("validated_skip_count"), 0) for item in statement_batches),
            "model_calls": sum(integer(item.get("model_calls"), 0) for item in statement_batches),
        }

        persisted_input_count = persist_resolved_financial_inputs(run_id, document_id)
        score = invoke_forensic_result_persistence(run_id, document_id)
        saved_count = integer(validation.get("saved_count"), 0)
        unresolved_count = integer(validation.get("unresolved_count"), 0)
        save_record = save_financial_input_validation_run(
            str(uuid.uuid4()), run_id, document_id, "llm_validate_all",
            "COMPLETED" if unresolved_count == 0 else "PARTIAL",
            len(target_concepts), saved_count, unresolved_count, score, validation,
        )
        return jsonify({
            "status": "FULL_STATEMENT_VALIDATION_SAVED",
            "backend_build": BACKEND_BUILD_ID,
            "assessment_run_id": run_id,
            "source_document_id": document_id,
            "elapsed_seconds": round((dt.datetime.now(dt.timezone.utc) - started).total_seconds(), 3),
            "validation": validation,
            "saved_count": saved_count,
            "replaced_count": integer(validation.get("replaced_count"), 0),
            "validated_skip_count": integer(validation.get("validated_skip_count"), 0),
            "unresolved_count": unresolved_count,
            "persisted_input_count": persisted_input_count,
            "score": score,
            "save_record": save_record,
            "message": "All three financial statements were validated; accepted corrections and scores were saved.",
        })
    source_validation_request = {
        "assessment_run_id": run_id, "source_document_id": document_id,
        "verify_source": True, "llm_validate_all": False,
        "maximum_targets": 60, "target_concepts": target_concepts,
        "validation_request_id": explicit_resolution_id + "-source",
    }
    with app.test_request_context("/api/financial-fact-resolution/batch-preview", method="POST", json=source_validation_request):
        outcome = batch_financial_fact_resolution_preview()
        source_response, source_status = ((outcome[0], outcome[1])
                                          if isinstance(outcome, tuple) else (outcome, 200))
        source_validation = source_response.get_json() if hasattr(source_response, "get_json") else {}
    if source_status >= 400:
        return jsonify({"error": text(source_validation.get("error")) or "Selected-report validation failed.",
                        "stage": "SOURCE_VALIDATION", "validation": source_validation,
                        "backend_build": BACKEND_BUILD_ID}), source_status
    if source_status == 202:
        return jsonify({"status": "VALIDATION_RUNNING", "validation": source_validation,
                        "backend_build": BACKEND_BUILD_ID}), 202

    # A separate job now resolves only values that remain absent after the
    # deterministic source pass. This keeps Bedrock requests compact and prevents
    # valid populated rows from consuming tokens or hitting rate limits.
    missing_request = {
        "assessment_run_id": run_id, "source_document_id": document_id,
        "verify_source": False, "llm_validate_all": False,
        "maximum_targets": 60, "target_concepts": target_concepts,
        "validation_request_id": explicit_resolution_id + "-missing",
    }
    with app.test_request_context("/api/financial-fact-resolution/batch-preview", method="POST", json=missing_request):
        outcome = batch_financial_fact_resolution_preview()
        missing_response, missing_status = ((outcome[0], outcome[1])
                                            if isinstance(outcome, tuple) else (outcome, 200))
        missing_resolution = missing_response.get_json() if hasattr(missing_response, "get_json") else {}
    if missing_status >= 400:
        return jsonify({"error": text(missing_resolution.get("error")) or "Missing-value resolution failed.",
                        "stage": "LLM_MISSING_VALUE_RESOLUTION",
                        "validation": {"source_validation": source_validation,
                                       "missing_resolution": missing_resolution},
                        "backend_build": BACKEND_BUILD_ID}), missing_status
    if missing_status == 202:
        return jsonify({"status": "VALIDATION_RUNNING",
                        "validation": {"source_validation": source_validation,
                                       "missing_resolution": missing_resolution},
                        "backend_build": BACKEND_BUILD_ID}), 202

    # The compact report-level model response can omit a small number of cells
    # even though the per-cell governed resolver has enough evidence. Because
    # this endpoint is invoked only by the user's explicit Resolve Missing
    # Values action, finish those genuinely blank cells through the same
    # propose -> validate -> approve path used by Statement Derivation Review.
    # Populated review-only values are intentionally excluded so this fallback
    # cannot overwrite a reported figure merely because the batch omitted it.
    sequential_results = []
    unresolved_targets = []
    seen_targets = set()
    for item in missing_resolution.get("results") or []:
        if not isinstance(item, dict) or item.get("saved_to_report"):
            continue
        concept_key = text(item.get("concept_key"))
        period_role = text(item.get("period_role"))
        target_key = (concept_key, period_role)
        existing_value = number(item.get("reported_existing_value"))
        if existing_value is None:
            existing_value = number(item.get("existing_value"))
        if (not concept_key or period_role not in {"current", "prior"}
                or existing_value is not None or target_key in seen_targets):
            continue
        seen_targets.add(target_key)
        unresolved_targets.append(item)

    # The residual path is the same governed Analyze -> Approve flow exposed in
    # Statement Derivation Review. It is bounded by the financial-input schema
    # and uses only two workers to improve latency without flooding the model.
    maximum_residual_targets = min(len(VALIDATED_RUN_CONCEPTS) * 2, 60)
    residual_targets = unresolved_targets[:maximum_residual_targets]

    def resolve_explicit_residual(target: Dict[str, Any]) -> Dict[str, Any]:
        proposal_body = {
            "assessment_run_id": run_id,
            "source_document_id": document_id,
            "concept_key": text(target.get("concept_key")),
            "period_role": text(target.get("period_role")),
            "validation_mode": False,
        }
        try:
            with app.test_request_context(
                    "/api/financial-fact-resolution/propose", method="POST", json=proposal_body):
                proposal_outcome = propose_financial_fact_resolution()
                proposal_response, proposal_status = ((proposal_outcome[0], proposal_outcome[1])
                                                       if isinstance(proposal_outcome, tuple)
                                                       else (proposal_outcome, 200))
                proposal_payload = (proposal_response.get_json()
                                    if hasattr(proposal_response, "get_json") else {})
            entry = {"concept_key": proposal_body["concept_key"],
                     "period_role": proposal_body["period_role"],
                     "proposal_status": proposal_status, "proposal": proposal_payload,
                     "saved": False}
            proposal_id = text(proposal_payload.get("proposal_id"))
            if proposal_status < 400 and proposal_id:
                with app.test_request_context(
                        "/api/financial-fact-resolution/approve", method="POST", json={
                            "proposal_id": proposal_id,
                            "approved_by": "FSRE explicit missing-value resolver",
                        }):
                    approval_outcome = approve_financial_fact_resolution()
                    approval_response, approval_status = ((approval_outcome[0], approval_outcome[1])
                                                           if isinstance(approval_outcome, tuple)
                                                           else (approval_outcome, 200))
                    approval_payload = (approval_response.get_json()
                                        if hasattr(approval_response, "get_json") else {})
                entry.update({"approval_status": approval_status,
                              "approval": approval_payload,
                              "saved": approval_status < 400})
            return entry
        except Exception as residual_error:
            return {"concept_key": proposal_body["concept_key"],
                    "period_role": proposal_body["period_role"],
                    "proposal_status": 500, "saved": False,
                    "error": f"{type(residual_error).__name__}: {residual_error}"}

    # Resolve one cell at a time. This avoids provider bursts and preserves the
    # successful manual Analyze -> Approve ordering for every remaining cell.
    for residual_target in residual_targets:
        sequential_results.append(resolve_explicit_residual(residual_target))

    sequential_saved = sum(1 for item in sequential_results if item.get("saved"))
    sequential_persisted_count = 0
    if sequential_saved:
        sequential_persisted_count = persist_resolved_financial_inputs(run_id, document_id)
    missing_resolution["sequential_cell_resolution"] = sequential_results
    missing_resolution["sequential_saved_count"] = sequential_saved
    missing_resolution["persisted_input_count"] = max(
        integer(missing_resolution.get("persisted_input_count"), 0),
        sequential_persisted_count,
    )
    missing_resolution["saved_count"] = integer(missing_resolution.get("saved_count"), 0) + sequential_saved
    # Report the final unique missing cells, not the model's raw count (which
    # may contain duplicate aliases or repeated candidate decisions).
    resolved_residual_keys = {
        (text(item.get("concept_key")), text(item.get("period_role")))
        for item in sequential_results if item.get("saved")
    }
    final_missing_cells = persisted_missing_statement_cells(
        run_id, document_id, target_concepts,
    )
    missing_resolution["unresolved_count"] = len(final_missing_cells)
    missing_resolution["final_missing_cells"] = final_missing_cells
    missing_resolution["final_count_source"] = "POSTGRES_GOVERNED_STATEMENT_SNAPSHOT"

    validation = {
        "source_validation": source_validation,
        "missing_resolution": missing_resolution,
        "saved_count": integer(source_validation.get("saved_count"), 0)
                       + integer(missing_resolution.get("saved_count"), 0),
        "unresolved_count": integer(missing_resolution.get("unresolved_count"), 0),
        "model_calls": integer(missing_resolution.get("model_calls"), 0),
        "llm_validation_complete": not bool(missing_resolution.get("deferred_count")),
    }
    score = invoke_forensic_result_persistence(run_id, document_id)
    save_record = save_financial_input_validation_run(
        str(uuid.uuid4()), run_id, document_id, "run_analysis_validated",
        "COMPLETED" if validation["unresolved_count"] == 0 else "PARTIAL",
        len(target_concepts), validation["saved_count"], validation["unresolved_count"],
        score, validation,
    )
    completed = validation["unresolved_count"] == 0
    return jsonify({
        "status": "VALIDATED_SCORES_SAVED" if completed else "PARTIAL_VALIDATION_SAVED",
        "backend_build": BACKEND_BUILD_ID,
        "assessment_run_id": run_id, "source_document_id": document_id,
        "elapsed_seconds": round((dt.datetime.now(dt.timezone.utc) - started).total_seconds(), 3),
        "validation": validation, "score": score, "save_record": save_record,
        "message": (
            "Selected-report inputs were validated, final scores calculated, and the snapshot saved."
            if completed else
            f"Validated values and the current score snapshot were saved; {validation['unresolved_count']} financial input(s) still require evidence."
        ),
    })


def bedrock_retry_delay_seconds(value: Any, attempt: int = 1) -> int:
    """Normalize Bedrock Retry-After values and apply bounded backoff."""
    raw = text(value).strip().lower()
    seconds = None
    if raw:
        match = re.match(r"^([0-9]+(?:\.[0-9]+)?)\s*(ms|s|sec|secs|seconds?|m|min|mins|minutes?)?$", raw)
        if match:
            amount = float(match.group(1))
            unit = match.group(2) or "s"
            seconds = amount / 1000 if unit == "ms" else amount * 60 if unit.startswith("m") else amount
    if seconds is None:
        seconds = 30 * (2 ** max(0, attempt - 1))
    # A little spacing avoids retrying on the exact provider reset boundary.
    return max(5, min(3600, int(math.ceil(seconds)) + 2))


def auto_statement_resolution_worker(job_id: str, run_id: str, document_id: str,
                                     target_concepts: List[str],
                                     missing_concepts: List[str],
                                     mode: str = "automatic") -> None:
    """Validate statement rows locally, then LLM-resolve only remaining blanks."""
    combined_saved = 0
    combined_replaced = 0
    combined_requested = 0
    last_payload: Dict[str, Any] = {}
    try:
        if mode == "llm_validate_all":
            statement_groups = [
                [concept for concept in target_concepts if concept in {
                    "revenue", "total_income", "cost_of_goods_sold", "sg_and_a_expense",
                    "depreciation_amortization", "operating_income_ebit", "profit_before_tax",
                    "interest_expense", "net_profit", "net_interest_income", "non_interest_income",
                    "operating_expenses", "provisions_impairment",
                }],
                [concept for concept in target_concepts if concept in {
                    "total_current_assets", "trade_receivables_net", "inventory", "net_ppe",
                    "total_assets", "total_current_liabilities", "long_term_debt", "total_liabilities",
                    "retained_earnings", "total_shareholders_equity", "shares_outstanding",
                    "gross_loans_advances", "stage3_npa", "ecl_balance", "investments",
                    "customer_deposits", "borrowings", "cet1_ratio",
                }],
                [concept for concept in target_concepts if concept in {
                    "operating_cash_flow", "investing_cash_flow", "financing_cash_flow",
                    "net_change_cash", "ending_cash",
                }],
            ]
            results = []
            for statement_index, concepts in enumerate((group for group in statement_groups if group), 1):
                with AUTO_RESOLUTION_LOCK:
                    AUTO_RESOLUTION_STATE[job_id].update({
                        "status": "RUNNING", "pass": statement_index,
                        "message": f"LLM validating financial statement {statement_index} of 3…",
                    })
                request_body = {
                    "assessment_run_id": run_id, "source_document_id": document_id,
                    "target_concepts": concepts, "maximum_targets": 60,
                    "verify_source": False, "llm_validate_all": True,
                    "validation_request_id": job_id,
                }
                with app.test_request_context(
                        "/api/financial-fact-resolution/batch-preview",
                        method="POST", json=request_body):
                    outcome = batch_financial_fact_resolution_preview()
                    response, status_code = ((outcome[0], outcome[1])
                                             if isinstance(outcome, tuple) else (outcome, 200))
                    statement_payload = response.get_json() if hasattr(response, "get_json") else {}
                if status_code >= 400:
                    raise RuntimeError(text(statement_payload.get("error")) or
                                       f"LLM statement validation failed ({status_code})")
                if status_code == 202:
                    raise RuntimeError(text(statement_payload.get("message")) or
                                       "An LLM statement validation job is already running.")
                combined_saved += integer(statement_payload.get("saved_count"), 0)
                combined_replaced += integer(statement_payload.get("replaced_count"), 0)
                combined_requested += integer(statement_payload.get("requested_count"), 0)
                results.append(statement_payload)
                last_payload = statement_payload
                if statement_payload.get("rate_limited"):
                    break
            # Consolidate every approved override into the report history only
            # after all statement groups have finished. This also invalidates
            # the previous score fingerprint before scores are recalculated.
            persisted_input_count = persist_resolved_financial_inputs(run_id, document_id)
            score = invoke_forensic_result_persistence(run_id, document_id)
            unresolved = sum(integer(item.get("unresolved_count"), 0) for item in results)
            rate_limited = any(bool(item.get("rate_limited")) for item in results)
            final_status = "PARTIAL" if unresolved or rate_limited else "COMPLETED"
            save_record = save_financial_input_validation_run(
                job_id, run_id, document_id, mode, final_status,
                combined_requested, combined_saved, unresolved,
                score, {"statements": results, "rate_limited": rate_limited},
            )
            with AUTO_RESOLUTION_LOCK:
                AUTO_RESOLUTION_STATE[job_id].update({
                    "status": final_status,
                    "message": ("LLM financial-statement validation completed and replacements were saved."
                                if final_status == "COMPLETED" else
                                "LLM validation completed with values requiring review."),
                    "saved_count": combined_saved, "requested_count": combined_requested,
                    "replaced_count": combined_replaced,
                    "unresolved_count": unresolved, "result": {"statements": results},
                    "persisted_input_count": persisted_input_count,
                    "save_record": save_record,
                    "score_saved": bool(score), "refresh_required": True,
                    "data_revision": dt.datetime.now(dt.timezone.utc).isoformat(),
                    "completed_at": dt.datetime.now(dt.timezone.utc).isoformat(),
                })
            return

        # Pass 1 is deterministic and sends nothing to the LLM. It repairs
        # populated note-number and Group/Company-column mismatches from exact
        # audited statement rows and is guarded by a durable versioned job.
        with AUTO_RESOLUTION_LOCK:
            AUTO_RESOLUTION_STATE[job_id].update({
                "status": "RUNNING", "pass": 0,
                "message": "Validating saved values against audited statement rows…",
            })
        source_request = {
            "assessment_run_id": run_id, "source_document_id": document_id,
            "target_concepts": target_concepts, "maximum_targets": 60,
            "verify_source": True, "llm_validate_all": False,
            "validation_request_id": job_id,
        }
        with app.test_request_context(
                "/api/financial-fact-resolution/batch-preview",
                method="POST", json=source_request):
            outcome = batch_financial_fact_resolution_preview()
            response, status_code = ((outcome[0], outcome[1])
                                     if isinstance(outcome, tuple) else (outcome, 200))
            source_payload = response.get_json() if hasattr(response, "get_json") else {}
        if status_code >= 400:
            raise RuntimeError(text(source_payload.get("error")) or
                               f"Statement source validation failed ({status_code})")
        if status_code == 202:
            with AUTO_RESOLUTION_LOCK:
                AUTO_RESOLUTION_STATE[job_id].update({
                    "status": "RUNNING", "message": text(source_payload.get("message")) or
                    "Statement source validation is already running.", "result": source_payload,
                })
            return
        combined_saved += integer(source_payload.get("saved_count"), 0)
        combined_requested += integer(source_payload.get("requested_count"), 0)
        last_payload = source_payload

        # Automatic missing-value resolution is independently controlled. It
        # sends every remaining missing statement cell in one compact request
        # and persists each valid result independently.
        automatic_llm_enabled = llm_feature_enabled(
            "fri_llm_financial_resolution_enabled", True
        )
        if mode == "automatic" and not automatic_llm_enabled:
            missing_concepts = []
            last_payload["automatic_llm_skipped"] = True
            last_payload["message"] = (
                "Automatic selected-report validation completed without an LLM call because "
                "fri_llm_financial_resolution_enabled is disabled."
            )

        # All remaining blanks are resolved in one compact report-level call.
        # The three statement digests are shared once across every target.
        # One report selection produces one model call. Individual valid
        # results continue through persistence even when another target fails.
        max_rate_limit_retries = 0
        pass_number = 0
        while missing_concepts and pass_number <= max_rate_limit_retries:
            pass_number += 1
            with AUTO_RESOLUTION_LOCK:
                AUTO_RESOLUTION_STATE[job_id].update({
                    "status": "RUNNING", "pass": pass_number,
                    "message": ("Resolving the compact annual-statement evidence batch…"
                                if pass_number == 1 else
                                f"Retrying compact statement resolution · attempt {pass_number}…"),
                })
            request_body = {
                "assessment_run_id": run_id,
                "source_document_id": document_id,
                "target_concepts": missing_concepts,
                "maximum_targets": 60,
                "verify_source": False,
                "llm_validate_all": False,
                # Do not reuse an earlier incomplete batch response for this
                # report. Durable per-cell validation flags still prevent
                # already approved values from being submitted again.
                "validation_request_id": f"{job_id}-pass-{pass_number}-v154",
            }
            with app.test_request_context(
                    "/api/financial-fact-resolution/batch-preview",
                    method="POST", json=request_body):
                outcome = batch_financial_fact_resolution_preview()
                response, status_code = ((outcome[0], outcome[1])
                                         if isinstance(outcome, tuple) else (outcome, 200))
                last_payload = response.get_json() if hasattr(response, "get_json") else {}
            if status_code >= 400:
                raise RuntimeError(text(last_payload.get("error")) or
                                   f"Statement resolution failed ({status_code})")
            if status_code == 202:
                # A durable job for this exact report/scope is already active.
                with AUTO_RESOLUTION_LOCK:
                    AUTO_RESOLUTION_STATE[job_id].update({
                        "status": "RUNNING", "message": text(last_payload.get("message")) or
                        "Statement resolution is already running.", "result": last_payload,
                    })
                return
            combined_saved += integer(last_payload.get("saved_count"), 0)
            combined_requested += integer(last_payload.get("requested_count"), 0)
            if text(last_payload.get("status")) in {"NO_MISSING_VALUES", "ALREADY_COMPLETED"}:
                break
            if last_payload.get("rate_limited"):
                if pass_number > max_rate_limit_retries:
                    break
                delay_seconds = bedrock_retry_delay_seconds(
                    last_payload.get("retry_after_seconds"), pass_number
                )
                retry_at = dt.datetime.now(dt.timezone.utc) + dt.timedelta(seconds=delay_seconds)
                with AUTO_RESOLUTION_LOCK:
                    AUTO_RESOLUTION_STATE[job_id].update({
                        # Keep RUNNING so the existing UI poller continues.
                        "status": "RUNNING",
                        "message": (f"Bedrock request limit reached. The backend will retry automatically "
                                    f"in {delay_seconds} seconds."),
                        "rate_limited": True,
                        "retry_attempt": pass_number,
                        "maximum_retry_attempts": max_rate_limit_retries,
                        "retry_after_seconds": delay_seconds,
                        "next_retry_at": retry_at.isoformat(),
                        "result": last_payload,
                    })
                time.sleep(delay_seconds)
                continue
            # One report-level request contains every unresolved statement
            # target; without throttling there is no reason to call it again.
            break

        # A compact batch can conservatively leave ambiguous cells for review.
        # For an automatically opened report, retry only those still-missing
        # cells through the existing single-value Statement Analysis &
        # Derivation contract. Each proposal remains subject to page citation,
        # candidate-row, period and arithmetic validation before it is saved.
        sequential_results = []
        batch_unresolved_targets = [
            item for item in (last_payload.get("results") or [])
            if isinstance(item, dict) and not item.get("saved_to_report")
            and text(item.get("concept_key")) and text(item.get("period_role")) in {"current", "prior"}
        ]
        # De-duplicate targets before invoking the per-value resolver.  This was
        # previously hard-disabled (``unresolved_targets = []``), which is why
        # the manual Analyze/Approve flow succeeded while this button stopped
        # after the compact batch.
        unresolved_targets = []
        unresolved_target_keys = set()
        for item in batch_unresolved_targets:
            target_key = (text(item.get("concept_key")), text(item.get("period_role")))
            if target_key not in unresolved_target_keys:
                unresolved_target_keys.add(target_key)
                unresolved_targets.append(item)
        last_payload["review_targets"] = batch_unresolved_targets

        def resolve_and_approve_residual(target: Dict[str, Any]) -> Dict[str, Any]:
            """Use the proven manual contract for one residual statement cell."""
            proposal_body = {
                "assessment_run_id": run_id,
                "source_document_id": document_id,
                "concept_key": text(target.get("concept_key")),
                "period_role": text(target.get("period_role")),
                "validation_mode": False,
            }
            try:
                with app.test_request_context(
                        "/api/financial-fact-resolution/propose",
                        method="POST", json=proposal_body):
                    proposal_outcome = propose_financial_fact_resolution()
                    proposal_response, proposal_status = ((proposal_outcome[0], proposal_outcome[1])
                                                           if isinstance(proposal_outcome, tuple)
                                                           else (proposal_outcome, 200))
                    proposal_payload = (proposal_response.get_json()
                                        if hasattr(proposal_response, "get_json") else {})
                entry = {
                    "concept_key": proposal_body["concept_key"],
                    "period_role": proposal_body["period_role"],
                    "proposal_status": proposal_status,
                    "proposal": proposal_payload,
                    "saved": False,
                }
                proposal_id = text(proposal_payload.get("proposal_id"))
                if proposal_status < 400 and proposal_id:
                    with app.test_request_context(
                            "/api/financial-fact-resolution/approve",
                            method="POST", json={
                                "proposal_id": proposal_id,
                                "approved_by": "FSRE automatic missing-value resolver",
                            }):
                        approval_outcome = approve_financial_fact_resolution()
                        approval_response, approval_status = ((approval_outcome[0], approval_outcome[1])
                                                               if isinstance(approval_outcome, tuple)
                                                               else (approval_outcome, 200))
                        approval_payload = (approval_response.get_json()
                                            if hasattr(approval_response, "get_json") else {})
                    entry.update({"approval_status": approval_status,
                                  "approval": approval_payload,
                                  "saved": approval_status < 400})
                return entry
            except Exception as residual_error:
                return {
                    "concept_key": proposal_body["concept_key"],
                    "period_role": proposal_body["period_role"],
                    "proposal_status": 500,
                    "saved": False,
                    "error": f"{type(residual_error).__name__}: {residual_error}",
                }

        # Sequential residual calls mirror the working manual flow and avoid
        # consuming multiple provider request buckets at the same instant.
        residual_workers = 1
        completed_residuals = 0
        if unresolved_targets:
            with AUTO_RESOLUTION_LOCK:
                AUTO_RESOLUTION_STATE[job_id].update({
                    "status": "RUNNING", "pass": "residual-cells",
                    "message": (f"Resolving {len(unresolved_targets)} residual missing values "
                                f"with {residual_workers} governed workers…"),
                })
            for target in unresolved_targets:
                entry = resolve_and_approve_residual(target)
                sequential_results.append(entry)
                completed_residuals += 1
                if entry.get("saved"):
                    combined_saved += 1
                with AUTO_RESOLUTION_LOCK:
                    AUTO_RESOLUTION_STATE[job_id].update({
                        "status": "RUNNING", "pass": "residual-cells",
                        "message": (f"Resolved {completed_residuals} of "
                                    f"{len(unresolved_targets)} residual values…"),
                    })

        if any(item.get("saved") for item in sequential_results):
            persist_resolved_financial_inputs(run_id, document_id)
        last_payload["sequential_cell_resolution"] = sequential_results
        last_payload["sequential_saved_count"] = sum(
            1 for item in sequential_results if item.get("saved")
        )

        score = invoke_forensic_result_persistence(run_id, document_id)
        # Count unique cells that are still unsaved after the governed
        # per-value approvals. Raw batch counts can include duplicate aliases.
        resolved_residual_keys = {
            (text(item.get("concept_key")), text(item.get("period_role")))
            for item in sequential_results if item.get("saved")
        }
        final_missing_cells = persisted_missing_statement_cells(
            run_id, document_id, target_concepts,
        )
        unresolved = len(final_missing_cells)
        last_payload["final_missing_cells"] = final_missing_cells
        last_payload["final_count_source"] = "POSTGRES_GOVERNED_STATEMENT_SNAPSHOT"
        final_status = "PARTIAL" if unresolved or last_payload.get("rate_limited") else "COMPLETED"
        save_record = save_financial_input_validation_run(
            job_id, run_id, document_id, mode, final_status,
            combined_requested, combined_saved, unresolved,
            score, {"batch_result": last_payload,
                    "sequential_cell_resolution": sequential_results},
        )
        with AUTO_RESOLUTION_LOCK:
            AUTO_RESOLUTION_STATE[job_id].update({
                "status": final_status,
                "message": ("Statement derivation completed and saved."
                            if final_status == "COMPLETED"
                            else "Statement derivation completed with values requiring review."),
                "saved_count": combined_saved,
                "requested_count": combined_requested,
                "unresolved_count": unresolved,
                "result": last_payload,
                "score_saved": bool(score),
                "save_record": save_record,
                "refresh_required": combined_saved > 0,
                "data_revision": dt.datetime.now(dt.timezone.utc).isoformat(),
                "completed_at": dt.datetime.now(dt.timezone.utc).isoformat(),
            })
    except Exception as exc:
        with AUTO_RESOLUTION_LOCK:
            AUTO_RESOLUTION_STATE[job_id].update({
                "status": "FAILED", "message": f"{type(exc).__name__}: {exc}",
                "completed_at": dt.datetime.now(dt.timezone.utc).isoformat(),
            })


@app.route("/api/financial-fact-resolution/auto", methods=["POST"])
@json_api_errors
def start_auto_statement_resolution():
    payload = request.get_json(silent=True) or {}
    run_id = text(payload.get("assessment_run_id"))
    document_id = text(payload.get("source_document_id"))
    target_concepts = sorted({text(item) for item in (payload.get("target_concepts") or []) if text(item)})
    missing_concepts = sorted({text(item) for item in (payload.get("missing_concepts") or []) if text(item)})
    mode = "llm_validate_all" if text(payload.get("mode")).lower() == "llm_validate_all" else "automatic"
    validation_request_id = text(payload.get("validation_request_id"))
    if not run_id or not document_id:
        return jsonify({"error": "assessment_run_id and source_document_id are required"}), 400
    if not target_concepts:
        return jsonify({"status": "COMPLETED", "message": "No statement values require derivation.",
                        "saved_count": 0, "unresolved_count": 0})
    job_id = hashlib.sha256(
        f"statement-job-v12-sequential-db-recount|{mode}|{run_id}|{document_id}|{','.join(target_concepts)}|{validation_request_id}".encode("utf-8")
    ).hexdigest()
    with AUTO_RESOLUTION_LOCK:
        existing = dict(AUTO_RESOLUTION_STATE.get(job_id) or {})
        if existing.get("status") in {"RUNNING", "COMPLETED"}:
            return jsonify(existing), 202 if existing.get("status") == "RUNNING" else 200
        state = {
            "job_id": job_id, "assessment_run_id": run_id, "source_document_id": document_id,
            "status": "QUEUED", "message": "Statement derivation queued.",
            "target_concepts": target_concepts, "missing_concepts": missing_concepts,
            "mode": mode,
            "validation_request_id": validation_request_id,
            "requested_at": dt.datetime.now(dt.timezone.utc).isoformat(),
        }
        AUTO_RESOLUTION_STATE[job_id] = state
    threading.Thread(
        target=auto_statement_resolution_worker,
        args=(job_id, run_id, document_id, target_concepts, missing_concepts, mode),
        daemon=True, name=f"fsre-auto-resolution-{job_id[:8]}",
    ).start()
    return jsonify(state), 202


@app.route("/api/financial-fact-resolution/auto", methods=["GET"])
@json_api_errors
def auto_statement_resolution_status():
    job_id = text(request.args.get("job_id"))
    if not job_id:
        return jsonify({"error": "job_id is required"}), 400
    with AUTO_RESOLUTION_LOCK:
        state = dict(AUTO_RESOLUTION_STATE.get(job_id) or {})
    return jsonify(state or {"job_id": job_id, "status": "NOT_FOUND",
                             "message": "The background job is no longer active."}), 200


@app.route("/api/financial-statement-validation-stream", methods=["POST"])
def financial_statement_validation_stream():
    """Stream row-level PDF/LLM validation for the selected report only."""
    payload = request.get_json(silent=True) or {}
    run_id, document_id = text(payload.get("assessment_run_id")), text(payload.get("source_document_id"))
    # Sequential validation is the safe default for hosted LLM rate limits.
    concurrency = max(1, min(2, integer(payload.get("concurrency"), 1)))
    include_populated = text(payload.get("include_populated")).lower() in {"1", "true", "yes", "on"}
    requested_concepts = {text(item) for item in (payload.get("target_concepts") or []) if text(item)}
    maximum_targets = max(1, min(60, integer(payload.get("maximum_targets"), 60)))
    if not run_id or not document_id:
        return jsonify({"error": "assessment_run_id and source_document_id are required"}), 400
    if not llm_feature_enabled("fri_llm_debug_validation_enabled", False):
        return Response(json.dumps({"event": "completed", "status": "LLM_FEATURE_DISABLED",
                                    "llm_skipped": True, "completed": 0, "total": 0,
                                    "message": "Debug LLM validation is temporarily disabled to reserve provider capacity for missing financial values."}) + "\n",
                        mimetype="application/x-ndjson",
                        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})
    values, source = resolved_values()
    selected = [row for row in values.to_dict(orient="records")
                if text(row.get("assessment_run_id") or row.get("run_id")) == run_id
                and text(row.get("source_document_id")) == document_id]
    tables = build_resolved_tables(selected)
    targets = []
    seen_targets = set()
    for table in tables:
        for row in table.get("rows", []):
            concept_key = text(row.get("concept_key"))
            if requested_concepts and concept_key not in requested_concepts:
                continue
            for role in ("current", "prior"):
                value = row.get("values", {}).get(role, {})
                extracted_value = number(value.get("numeric_value"))
                if extracted_value is not None and not include_populated:
                    continue
                target_key = (concept_key, role)
                if target_key in seen_targets:
                    continue
                seen_targets.add(target_key)
                targets.append({
                    "concept_key": concept_key, "concept_label": row.get("row_label"),
                    "statement_type": table.get("statement_type"), "period_role": role,
                    "period_label": value.get("period"), "extracted_value": extracted_value,
                })
    targets = targets[:maximum_targets]
    registration = registration_lookup().get(document_id, {})
    company = registration.get("entity_key") or (text(selected[0].get("entity_id")) if selected else "Unknown company")

    def line(event: str, **data) -> str:
        return json.dumps({"event": event, **data}, default=str) + "\n"

    def validate_target(target: Dict[str, Any]) -> Dict[str, Any]:
        body = {"assessment_run_id": run_id, "source_document_id": document_id,
                "concept_key": target["concept_key"], "period_role": target["period_role"],
                "validation_mode": True}
        with app.test_request_context("/api/financial-fact-resolution/propose", method="POST", json=body):
            outcome = propose_financial_fact_resolution()
            status_code = 200
            response = outcome
            if isinstance(outcome, tuple):
                response, status_code = outcome[0], outcome[1]
            result = response.get_json() if hasattr(response, "get_json") else outcome
            return {"target": target, "http_status": status_code, "result": result}

    @stream_with_context
    def generate():
        yield line("started", company=company, assessment_run_id=run_id,
                   source_document_id=document_id, data_source=source,
                   total=len(targets), concurrency=concurrency,
                   include_populated=include_populated)
        completed = 0
        with concurrent.futures.ThreadPoolExecutor(max_workers=concurrency,
                                                   thread_name_prefix="fri-statement-validator") as executor:
            futures = {executor.submit(validate_target, target): target for target in targets}
            for future in concurrent.futures.as_completed(futures):
                target = futures[future]
                try:
                    item = future.result()
                except Exception as exc:
                    item = {"target": target, "http_status": 500,
                            "result": {"error": f"{type(exc).__name__}: {exc}", "stage": "BACKEND_WORKER"}}
                completed += 1
                yield line("cell_result", completed=completed, total=len(targets), **item)
        yield line("completed", company=company, completed=completed, total=len(targets),
                   message="Validation finished. Review corrections before saving.")

    return Response(generate(), mimetype="application/x-ndjson",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


@app.route("/api/financial-fact-resolution/approve", methods=["POST"])
def approve_financial_fact_resolution():
    payload = request.get_json(silent=True) or {}
    proposal_id, reviewer = text(payload.get("proposal_id")), text(payload.get("approved_by")) or "FSRE analyst"
    if not proposal_id:
        return jsonify({"error": "proposal_id is required"}), 400
    try:
        with postgres_connection() as connection:
            ensure_fact_resolution_tables(connection)
            with connection.cursor() as cursor:
                cursor.execute("""SELECT assessment_run_id,source_document_id,statement_type,concept_key,period_role,period_label,
                                         proposed_value,currency,unit,resolution_method,confidence,evidence_json,status,validation_status
                                    FROM financial_risk_intelligence.financial_fact_resolution_proposals
                                   WHERE proposal_id=%s FOR UPDATE""", (proposal_id,))
                row = cursor.fetchone()
                if not row: return jsonify({"error": "Proposal not found"}), 404
                if row[12] != "PENDING" or row[13] != "VALIDATED_FOR_REVIEW":
                    return jsonify({"error": "Only a validated pending proposal can be approved"}), 409
                cursor.execute("""INSERT INTO financial_risk_intelligence.approved_financial_fact_overrides
                    (override_id,proposal_id,assessment_run_id,source_document_id,statement_type,concept_key,period_role,period_label,
                     numeric_value,currency,unit,resolution_method,confidence,evidence_json,approved_by,validated_rule_version)
                    VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s::jsonb,%s,%s)
                    ON CONFLICT (assessment_run_id,source_document_id,concept_key,period_role) DO UPDATE SET
                     proposal_id=EXCLUDED.proposal_id,numeric_value=EXCLUDED.numeric_value,currency=EXCLUDED.currency,unit=EXCLUDED.unit,
                     resolution_method=EXCLUDED.resolution_method,confidence=EXCLUDED.confidence,evidence_json=EXCLUDED.evidence_json,
                     approved_by=EXCLUDED.approved_by,validated_rule_version=EXCLUDED.validated_rule_version,
                     approved_at=NOW(),active=TRUE""",
                    (str(uuid.uuid4()),proposal_id,row[0],row[1],row[2],row[3],row[4],row[5],row[6],row[7],row[8],row[9],row[10],
                     json.dumps(row[11] or []),reviewer,
                     active_financial_validation_version(row[3])))
                cursor.execute("""UPDATE financial_risk_intelligence.financial_fact_resolution_proposals
                                      SET status='APPROVED',reviewed_at=NOW(),reviewed_by=%s WHERE proposal_id=%s""", (reviewer,proposal_id))
        persisted_input_count = persist_resolved_financial_inputs(text(row[0]), text(row[1]))
        return jsonify({"status": "APPROVED", "proposal_id": proposal_id,
                        "persisted_input_count": persisted_input_count,
                        "rescore_required": True,
                        "message": ("Approved value was saved and the selected report snapshot was refreshed. "
                                    "Re-run downstream scoring to recalculate forensic scores.")})
    except Exception as exc:
        print("FACT APPROVAL FAILED:", type(exc).__name__, exc)
        return jsonify({"error": f"{type(exc).__name__}: {exc}"}), 500


@app.route("/api/financial-fact-resolution/saved", methods=["GET"])
def saved_financial_fact_resolutions():
    """Return the persistent evidence and calculation trail for applied values."""
    run_id = text(request.args.get("assessment_run_id"))
    document_id = text(request.args.get("source_document_id"))
    if not run_id or not document_id:
        return jsonify({"error": "assessment_run_id and source_document_id are required"}), 400
    try:
        with postgres_connection() as connection:
            ensure_fact_resolution_tables(connection)
            with connection.cursor() as cursor:
                cursor.execute("""SELECT p.proposal_id,p.statement_type,p.concept_key,p.concept_label,
                                          p.period_role,p.period_label,o.numeric_value,o.currency,o.unit,
                                          p.resolution_method,p.formula,p.operands_json,p.candidate_rows_json,
                                          p.evidence_json,p.explanation,p.confidence,o.approved_by,o.approved_at,
                                          p.validation_status,p.validation_message,p.model_name
                                     FROM financial_risk_intelligence.approved_financial_fact_overrides o
                                     JOIN financial_risk_intelligence.financial_fact_resolution_proposals p
                                       ON p.proposal_id=o.proposal_id
                                    WHERE o.assessment_run_id=%s AND o.source_document_id=%s AND o.active=TRUE
                                    ORDER BY o.approved_at DESC,p.statement_type,p.concept_key,p.period_role""",
                               (run_id, document_id))
                rows = cursor.fetchall()
        items = [{
            "proposal_id": row[0], "statement_type": row[1], "concept_key": row[2],
            "concept_label": row[3], "period_role": row[4], "period_label": row[5],
            "proposed_value": float(row[6]), "currency": row[7], "unit": row[8],
            "resolution_method": row[9], "formula": row[10],
            "operands": row[11] if isinstance(row[11], list) else [],
            "candidate_rows": row[12] if isinstance(row[12], list) else [],
            "evidence": row[13] if isinstance(row[13], list) else [],
            "explanation": row[14], "confidence": float(row[15]),
            "approved_by": row[16], "approved_at": row[17].isoformat() if row[17] else "",
            "validation_status": row[18], "validation_message": row[19], "model_name": row[20],
            "approval_status": "APPROVED_AND_APPLIED", "saved_to_report": True,
            "model_proposal": {"proposed_value": float(row[6]), "resolution_method": row[9],
                               "formula": row[10], "explanation": row[14], "confidence": float(row[15])},
        } for row in rows]
        return jsonify({"status": "OK", "count": len(items), "results": items})
    except Exception as exc:
        print("SAVED FACT RESOLUTION READ FAILED:", type(exc).__name__, exc)
        return jsonify({"error": f"{type(exc).__name__}: {exc}"}), 500


@app.route("/api/resolution-trace", methods=["GET"])
def resolution_trace():
    """Diagnostic view comparing raw, canonical, and template values."""
    run_id = text(request.args.get("assessment_run_id"))
    document_id = text(request.args.get("source_document_id"))
    if not run_id or not document_id:
        return jsonify({"error": "assessment_run_id and source_document_id are required"}), 400
    concepts = request.args.getlist("concept_key")
    if not concepts:
        concepts = ["revenue", "cost_of_goods_sold", "sg_and_a_expense", "depreciation_amortization",
                    "operating_income_ebit", "net_profit", "total_current_assets", "trade_receivables_net",
                    "inventory", "net_ppe", "total_assets", "total_current_liabilities", "long_term_debt",
                    "total_liabilities", "retained_earnings", "total_shareholders_equity", "shares_outstanding",
                    "operating_cash_flow"]
    def scoped(name):
        frame = read_optional(name)
        if frame.empty:
            return []
        return [row for row in frame.to_dict(orient="records")
                if text(row.get("assessment_run_id") or row.get("run_id")) == run_id
                and text(row.get("source_document_id")) == document_id
                and (not concepts or text(row.get("concept_key")) in concepts)]
    return jsonify({
        "assessment_run_id": run_id,
        "source_document_id": document_id,
        "diagnosis": "Compare numeric_value/raw_value -> canonical current/prior -> template current/prior",
        "raw_standardized": scoped(STANDARDIZED_VALUES_DATASET),
        "canonical_facts": scoped(CANONICAL_FACTS_DATASET),
        "sector_template": scoped(SECTOR_TEMPLATE_VALUES_DATASET),
    })


def resolve_reporting_units(run_id: str, document_id: str,
                            snapshot: Optional[Dict[str, Any]] = None) -> str:
    """Resolve and persist the selected report's currency and presentation scale.

    Statement headings are deterministic and authoritative. The configured LLM
    receives only short header excerpts when those headings are ambiguous.
    Saved metadata prevents repeated provider calls on subsequent screen loads.
    """
    snapshot = snapshot or load_analysis_history_snapshot(run_id, document_id)
    context = dict(snapshot.get("context") or {})
    resolver_version = "statement-table-units-v2"
    cached = text(context.get("reporting_units") or context.get("units"))
    if cached and text(context.get("reporting_units_version")) == resolver_version:
        return cached

    evidence = []
    seen = set()
    validated_header_parts = []
    try:
        for table in raw_validated_tables(document_id):
            statement_type = canonical_statement(table.get("statement_type"))
            if statement_type not in PRIMARY_STATEMENTS:
                continue
            currency_value, unit_value = text(table.get("currency")), text(table.get("unit"))
            if currency_value:
                validated_header_parts.append(currency_value)
            if unit_value:
                validated_header_parts.append(unit_value)
            # Include only the table title/column headers and never narrative
            # report prose or numeric body rows.
            validated_header_parts.append(text(table.get("table_title")))
            for column in table.get("columns") or []:
                validated_header_parts.extend([
                    text(column.get("raw_text")), text(column.get("display_scope")),
                    text(column.get("display_period")),
                ])
    except Exception as exc:
        print(f"Validated statement-unit lookup unavailable: {type(exc).__name__}: {exc}", flush=True)
    for statement_type, concept_key, label in (
        ("INCOME_STATEMENT", "revenue", "Net revenue / sales"),
        ("BALANCE_SHEET", "total_assets", "Total assets"),
        ("CASH_FLOW_STATEMENT", "operating_cash_flow", "Cash flow from operations"),
    ):
        try:
            rows = managed_pdf_evidence_fallback(
                document_id, statement_type, concept_key, label,
                max_fragments=3, run_id=run_id,
            )
        except Exception:
            rows = []
        for row in rows:
            page = integer(row.get("page_number"), 0)
            content = text(row.get("content"))
            signature = (page, hashlib.sha256(content.encode("utf-8")).hexdigest())
            if not content or signature in seen:
                continue
            seen.add(signature)
            header_lines = [line.strip() for line in content.splitlines() if line.strip()]
            is_primary_statement_page = bool(re.search(
                r"(?:statements? of financial position|balance sheets?|"
                r"statements? of (?:profit or loss|comprehensive income)|income statements?|"
                r"statements? of cash flows?|cash flow statements?)",
                content, re.I,
            ))
            if not is_primary_statement_page:
                continue
            relevant = [line for line in header_lines if re.search(
                r"(?:expressed|presented|amounts? in|currency|US\$|S\$|SGD|USD|EUR|GBP|INR|"
                r"RM|RMB|HK\$|thousand|million|crore|lakh|['’]000)", line, re.I
            )]
            evidence.append({"page_number": page, "content": "\n".join(relevant[:10])[:1600]})

    header_text = "\n".join(
        [part for part in validated_header_parts if part]
        + [item["content"] for item in evidence]
    )
    currency_patterns = (
        (r"\bUS\$|\bUSD\b|United States dollars?", "US$"),
        (r"\bS\$|\bSGD\b|Singapore dollars?", "S$"),
        (r"\bEUR\b|€|euros?", "EUR"),
        (r"\bGBP\b|£|pounds? sterling", "GBP"),
        (r"\bINR\b|₹|Indian rupees?", "INR"),
        (r"\bHK\$|\bHKD\b|Hong Kong dollars?", "HK$"),
        (r"\bRMB\b|\bCNY\b|Renminbi", "RMB"),
        (r"\bRM\b|\bMYR\b|Malaysian ringgit", "RM"),
    )
    currency = next((label for pattern, label in currency_patterns
                     if re.search(pattern, header_text, re.I)), "")
    scale = (
        "crore" if re.search(r"\bcrores?\b", header_text, re.I) else
        "million" if re.search(r"\bmillions?\b", header_text, re.I) else
        "thousand" if re.search(r"\bthousands?\b|['’]000\b", header_text, re.I) else
        "lakh" if re.search(r"\blakhs?\b", header_text, re.I) else ""
    )

    resolution_source = "STATEMENT_HEADER"
    if not currency or not header_text:
        try:
            settings = financial_resolution_llm_configuration()
            prompt_evidence = "\n\n".join(
                f"Page {item['page_number']}:\n{item['content']}" for item in evidence if item["content"]
            )[:5000]
            if prompt_evidence:
                result = financial_resolution_llm_request(settings, [
                    {"role": "system", "content": (
                        "Identify only the presentation currency and scale used by the consolidated "
                        "financial statements. Return JSON with currency, scale, reporting_units and "
                        "evidence. Do not infer from company domicile."
                    )},
                    {"role": "user", "content": prompt_evidence},
                ])
                parsed = parse_ollama_json(result["raw_content"])
                currency = text(parsed.get("currency")) or currency
                scale = text(parsed.get("scale")) or scale
                llm_units = text(parsed.get("reporting_units"))
                if llm_units:
                    reporting_units = llm_units
                else:
                    reporting_units = " ".join(value for value in (currency, scale) if value)
                resolution_source = "LLM_STATEMENT_HEADER"
            else:
                reporting_units = ""
        except Exception as exc:
            print(f"Reporting-unit LLM fallback unavailable: {type(exc).__name__}: {exc}", flush=True)
            reporting_units = " ".join(value for value in (currency, scale) if value)
    else:
        reporting_units = " ".join(value for value in (currency, scale) if value)

    reporting_units = text(reporting_units)
    if not reporting_units:
        return ""
    try:
        patch = {"reporting_units": reporting_units, "units": reporting_units,
                 "reporting_units_source": resolution_source,
                 "reporting_units_version": resolver_version}
        with postgres_connection() as connection:
            ensure_analysis_history_table(connection)
            with connection.cursor() as cursor:
                cursor.execute("""
                    UPDATE financial_risk_intelligence.webapp_analysis_history
                       SET context_json = COALESCE(context_json, '{}'::jsonb) || %s::jsonb,
                           captured_at = captured_at
                     WHERE assessment_run_id = %s AND source_document_id = %s
                """, (json.dumps(patch), run_id, document_id))
            connection.commit()
    except Exception as exc:
        print(f"Reporting-unit persistence unavailable: {type(exc).__name__}: {exc}", flush=True)
    return reporting_units


@app.route("/api/forensic-scores", methods=["GET"])
@json_api_errors
def forensic_scores():
    """Return database/recipe-owned forensic results for one filing."""
    run_id = text(request.args.get("assessment_run_id"))
    document_id = text(request.args.get("source_document_id"))
    if not run_id or not document_id:
        return jsonify({"error": "assessment_run_id and source_document_id are required"}), 400

    scores = read_optional(FORENSIC_SCORES_DATASET)
    exceptions = read_optional(FORENSIC_EXCEPTIONS_DATASET)

    def selected(frame: pd.DataFrame) -> List[Dict[str, Any]]:
        if frame.empty:
            return []
        rows = []
        for row in frame.to_dict(orient="records"):
            if text(row.get("assessment_run_id") or row.get("run_id")) != run_id:
                continue
            if text(row.get("source_document_id")) != document_id:
                continue
            cleaned = {str(key): (None if missing(value) else value) for key, value in row.items()}
            for json_column in ("components_json", "parameters_json"):
                raw = cleaned.get(json_column)
                if isinstance(raw, str):
                    try:
                        cleaned[json_column] = json.loads(raw)
                    except json.JSONDecodeError:
                        pass
            rows.append(cleaned)
        return rows

    score_rows = selected(scores)
    exception_rows = selected(exceptions)
    snapshot = load_analysis_history_snapshot(run_id, document_id)
    reporting_units = resolve_reporting_units(run_id, document_id, snapshot)
    try:
        all_values, value_source = resolved_values()
        context_values = selected(all_values)
    except Exception as exc:
        print(f"Live forensic values unavailable; trying history: {type(exc).__name__}: {exc}")
        context_values, value_source = [], "LIVE_VALUES_UNAVAILABLE"
    if not context_values:
        context_values = list(snapshot.get("values") or [])
        score_rows = score_rows or list(snapshot.get("scores") or [])
        exception_rows = exception_rows or list(snapshot.get("exceptions") or [])
        if context_values:
            value_source = "POSTGRES_ANALYSIS_HISTORY"
    if not context_values:
        return jsonify({"error": "No run-scoped financial inputs were found in Dataiku or PostgreSQL history.",
                        "assessment_run_id": run_id, "source_document_id": document_id,
                        "backend_build": BACKEND_BUILD_ID}), 404

    # Add run-scoped standardized rows as supporting components. Resolved rows
    # stay first/authoritative; these rows supply details omitted by the sector
    # template (for example marketing expense, tax and issued share counts).
    try:
        # standardized_table_values() is row-per-cell. Convert it to the same
        # current/prior shape used by resolved_values before the mapper reads
        # it; otherwise numeric_value is silently ignored here.
        standardized_support_frame = normalize_resolved_shape(standardized_table_values())
        standardized_support = selected(standardized_support_frame)
        if standardized_support:
            context_values = context_values + standardized_support
            value_source = value_source + "+STANDARDIZED_COMPONENT_SUPPORT"
    except Exception as exc:
        print(f"Standardized component support unavailable: {type(exc).__name__}: {exc}")

    input_fingerprint = forensic_input_fingerprint(context_values)
    cached_result = snapshot.get("forensic_result") or {}
    if (snapshot.get("input_fingerprint") == input_fingerprint
            and cached_result.get("cache_version") == BACKEND_BUILD_ID):
        cached_result = dict(cached_result)
        cached_result["cache_status"] = "POSTGRES_CACHE_HIT"
        return jsonify(cached_result)

    concept_values = {}
    for fact in context_values:
        candidate = {
            "current": number(fact.get("current_value")),
            "prior": number(fact.get("prior_value")),
        }
        identifiers = {
            re.sub(r"[^a-z0-9]+", "_", text(value).lower()).strip("_")
            for value in (
                fact.get("concept_key"), fact.get("field_key"), fact.get("canonical_key"),
                fact.get("canonical_label"), fact.get("field_label"),
                fact.get("source_row_label"), fact.get("row_label"),
            ) if text(value)
        }
        for concept in identifiers:
            existing = concept_values.get(concept)
            if existing is None or sum(value is not None for value in candidate.values()) > sum(
                    value is not None for value in existing.values()):
                concept_values[concept] = candidate

    def concept_number(period: str, *concepts: str):
        for concept in concepts:
            normalized_concept = re.sub(r"[^a-z0-9]+", "_", text(concept).lower()).strip("_")
            value = (concept_values.get(normalized_concept) or {}).get(period)
            if value is not None:
                return value
        # Safely accept common qualified captions such as group_total_revenue
        # and consolidated_total_assets without confusing component rows.
        normalized_aliases = {
            re.sub(r"[^a-z0-9]+", "_", text(concept).lower()).strip("_")
            for concept in concepts
        }
        for available_key, period_values in concept_values.items():
            if any(available_key in {"group_" + alias, "consolidated_" + alias,
                                     alias + "_group", alias + "_consolidated"}
                   for alias in normalized_aliases):
                value = (period_values or {}).get(period)
                if value is not None:
                    return value
        return None

    def largest_concept_pair(*concepts: str) -> Dict[str, Optional[float]]:
        """Return the largest exact disclosed pair for scale-sensitive facts.

        This is intentionally used only for issued shares. Annual-report share
        notes can expose note numbers, EPS denominators and values stated in
        thousands alongside the actual issued-share count. The largest exact
        issued-share-labelled pair is the defensible outstanding-share input.
        """
        normalized_aliases = {
            re.sub(r"[^a-z0-9]+", "_", text(concept).lower()).strip("_")
            for concept in concepts
        }
        candidates = []
        for fact in context_values:
            identifiers = {
                re.sub(r"[^a-z0-9]+", "_", text(value).lower()).strip("_")
                for value in (
                    fact.get("concept_key"), fact.get("field_key"), fact.get("canonical_key"),
                    fact.get("canonical_label"), fact.get("field_label"),
                    fact.get("source_row_label"), fact.get("row_label"),
                ) if text(value)
            }
            if not identifiers.intersection(normalized_aliases):
                continue
            pair = {
                "current": number(fact.get("current_value")),
                "prior": number(fact.get("prior_value")),
            }
            magnitudes = [abs(value) for value in pair.values() if value is not None]
            if magnitudes:
                candidates.append((max(magnitudes), pair))
        return max(candidates, key=lambda item: item[0])[1] if candidates else {
            "current": None, "prior": None,
        }

    def largest_ending_balance_pair() -> Dict[str, Optional[float]]:
        """Recover issued shares from a share-capital movement table.

        Extractors often label the decisive row only as "At end of the
        financial year/period" because "No. of ordinary shares" is a merged
        column header. This fallback is accepted only later when it is at
        least 100 times the candidate already mapped as shares, preventing an
        ordinary monetary closing balance from replacing a valid share count.
        """
        candidates = []
        for fact in context_values:
            row_label = text(
                fact.get("source_row_label") or fact.get("row_label")
                or fact.get("field_label") or fact.get("canonical_label")
            ).lower()
            if not re.search(r"\bat end of (?:the )?(?:financial )?(?:year|period)", row_label):
                continue
            pair = {
                "current": number(fact.get("current_value")),
                "prior": number(fact.get("prior_value")),
            }
            values = [abs(value) for value in pair.values() if value is not None]
            if len(values) == 2 and all(abs(value - round(value)) < .000001 for value in values):
                candidates.append((max(values), pair))
        return max(candidates, key=lambda item: item[0])[1] if candidates else {
            "current": None, "prior": None,
        }

    def reported_period_label(column: str) -> str:
        labels = [text(row.get(column)) for row in context_values if text(row.get(column))]
        return collections.Counter(labels).most_common(1)[0][0] if labels else ""

    def parse_report_date(value: str):
        cleaned = re.sub(r"\s+", " ", text(value).strip().replace(",", ""))
        for date_format in ("%d/%m/%Y", "%d-%m-%Y", "%d %B %Y", "%d %b %Y",
                            "%B %d %Y", "%b %d %Y"):
            try:
                return dt.datetime.strptime(cleaned, date_format).date()
            except ValueError:
                continue
        return None

    def period_months(label: str):
        """Return the disclosed period duration without guessing from a year."""
        value = re.sub(r"\s+", " ", text(label))
        date_pattern = (r"(?:\d{1,2}[/-]\d{1,2}[/-]\d{4}|"
                        r"\d{1,2}\s+[A-Za-z]+\s+\d{4}|"
                        r"[A-Za-z]+\s+\d{1,2},?\s+\d{4})")
        dates = [parse_report_date(item) for item in re.findall(date_pattern, value)]
        dates = [item for item in dates if item is not None]
        if len(dates) >= 2:
            start, end = dates[0], dates[1]
            days = (end - start).days + 1
            raw_months = days / 30.4375 if days > 0 else None
            return (float(round(raw_months)) if raw_months is not None
                    and abs(raw_months - round(raw_months)) < .12 else raw_months)
        explicit_months = re.search(r"\b(\d{1,2})\s+months?\s+ended\b", value, re.I)
        if explicit_months:
            return float(explicit_months.group(1))
        if re.search(r"\b(?:financial\s+)?year\s+ended\b", value, re.I):
            return 12.0
        return None

    def report_period_metadata() -> Dict[str, Any]:
        """Recover unequal comparative durations from the selected report.

        The financial fact table often retains only the column year (for
        example 2026/2025). In that case, inspect the persisted text for this
        document only. This is deterministic and does not make an LLM call.
        """
        metadata: Dict[str, Any] = {
            "current_months": period_months(reported_period_label("current_period")),
            "prior_months": period_months(reported_period_label("prior_period")),
            "source": "FINANCIAL_FACT_PERIOD_LABELS",
            "evidence": [],
        }
        if metadata["current_months"] and metadata["prior_months"]:
            return metadata
        try:
            with postgres_connection() as connection:
                with connection.cursor() as cursor:
                    cursor.execute("""
                        SELECT page_number, content_text
                        FROM financial_risk_intelligence.report_evidence
                        WHERE source_document_id = %s
                          AND (content_text ILIKE '%%months ended%%'
                               OR content_text ILIKE '%%year ended%%')
                        ORDER BY page_number
                        LIMIT 30
                    """, (document_id,))
                    evidence_rows = cursor.fetchall()
        except Exception as exc:
            print(f"Period evidence lookup unavailable: {type(exc).__name__}: {exc}", flush=True)
            evidence_rows = []

        # A completed legacy run may have resolved financial facts but no
        # report_evidence rows. Read only its registered PDF as a deterministic
        # fallback; this does not call an LLM and never scans unrelated reports.
        try:
            pdf_period_evidence = managed_pdf_evidence_fallback(
                document_id, "INCOME_STATEMENT", "revenue",
                "Net revenue / sales", max_fragments=5,
            )
            evidence_rows.extend([
                (item.get("page_number"), item.get("content"))
                for item in pdf_period_evidence if text(item.get("content"))
            ])
        except Exception as exc:
            print(f"Selected-PDF period fallback unavailable: {type(exc).__name__}: {exc}", flush=True)

        current_year = period_year(reported_period_label("current_period"))
        prior_year = period_year(reported_period_label("prior_period"))
        date_pattern = (r"(?:\d{1,2}[/-]\d{1,2}[/-]\d{4}|"
                        r"\d{1,2}\s+[A-Za-z]+\s+\d{4}|"
                        r"[A-Za-z]+\s+\d{1,2},?\s+\d{4})")
        duration_pattern = re.compile(
            rf"(?P<label>(?:(?P<months>\d{{1,2}})\s+months?|(?:financial\s+)?year)\s+ended"
            rf"(?:\s+on)?\s+(?P<end>{date_pattern}))", re.I,
        )
        range_pattern = re.compile(
            rf"(?P<label>(?:from\s+)?(?P<start>{date_pattern})\s+"
            rf"(?:to|until|[-–—])\s+(?P<end>{date_pattern}))", re.I,
        )
        # PDF text extraction often emits side-by-side statement headers in
        # reading order: current-start, prior-start, current-end, prior-end.
        # Recognise that generic two-column layout without relying on issuer,
        # page number, currency or financial year.
        dual_column_range_pattern = re.compile(
            rf"(?P<start_current>{date_pattern})\s+to\s+"
            rf"(?P<start_prior>{date_pattern})\s+to\s+"
            rf"(?:note\s+)?(?P<end_current>{date_pattern})\s+"
            rf"(?P<end_prior>{date_pattern})", re.I,
        )
        discovered: Dict[int, float] = {}
        for page_number, content_text in evidence_rows:
            content = re.sub(r"\s+", " ", text(content_text))
            for match in dual_column_range_pattern.finditer(content):
                for role in ("current", "prior"):
                    start_date = parse_report_date(match.group("start_" + role))
                    end_date = parse_report_date(match.group("end_" + role))
                    if not start_date or not end_date or end_date < start_date:
                        continue
                    raw_months = ((end_date - start_date).days + 1) / 30.4375
                    months = float(round(raw_months)) if abs(raw_months - round(raw_months)) < .12 else raw_months
                    discovered[end_date.year] = months
                    if len(metadata["evidence"]) < 6:
                        metadata["evidence"].append({
                            "page_number": integer(page_number, 0), "period_role": role,
                            "period_start": start_date.isoformat(), "period_end": end_date.isoformat(),
                            "months": months, "text": match.group(0)[:200],
                        })
            # Exact statement-column ranges take precedence. They preserve
            # leap years and non-standard periods (for example 456 days).
            for match in range_pattern.finditer(content):
                start_date = parse_report_date(match.group("start"))
                end_date = parse_report_date(match.group("end"))
                if not start_date or not end_date or end_date < start_date:
                    continue
                raw_months = ((end_date - start_date).days + 1) / 30.4375
                months = float(round(raw_months)) if abs(raw_months - round(raw_months)) < .12 else raw_months
                discovered[end_date.year] = months
                if len(metadata["evidence"]) < 6:
                    metadata["evidence"].append({
                        "page_number": integer(page_number, 0),
                        "period_start": start_date.isoformat(),
                        "period_end": end_date.isoformat(),
                        "months": months,
                        "text": match.group("label")[:160],
                    })
            for match in duration_pattern.finditer(content):
                end_date = parse_report_date(match.group("end"))
                if not end_date:
                    continue
                months = float(match.group("months") or 12)
                # Prefer the first explicit statement heading for each year.
                discovered.setdefault(end_date.year, months)
                if len(metadata["evidence"]) < 6:
                    metadata["evidence"].append({
                        "page_number": integer(page_number, 0),
                        "period_end": end_date.isoformat(),
                        "months": months,
                        "text": match.group("label")[:160],
                    })
        if not metadata["current_months"] and current_year in discovered:
            metadata["current_months"] = discovered[current_year]
        if not metadata["prior_months"] and prior_year in discovered:
            metadata["prior_months"] = discovered[prior_year]
        if metadata["evidence"]:
            metadata["source"] = "SELECTED_REPORT_EVIDENCE"
        return metadata

    model_input_aliases = {
        "sales": ("revenue", "total_income", "operating_revenue", "revenue_from_operations",
                  "property_development_revenue", "property_sales", "sale_of_properties",
                  "revenue_from_contracts_with_customers", "revenue_from_contract_with_customers",
                  "turnover", "gross_revenue", "rental_revenue", "rental_income",
                  "construction_revenue", "income_from_properties"),
        "cogs": ("cost_of_goods_sold", "cost_of_sales", "cost_of_revenue"),
        "sga": ("sg_and_a_expense", "selling_general_administrative_expense", "administrative_expenses"),
        "depreciation": ("depreciation_amortization", "depreciation_amortisation"),
        "ebit": ("operating_income_ebit", "operating_profit", "profit_from_operations"),
        "interest_expense": ("interest_expense", "finance_costs", "finance_cost"),
        "net_income": ("net_profit", "profit_loss", "profit_for_year"),
        "current_assets": ("total_current_assets", "current_assets"),
        "receivables": ("trade_receivables_net", "trade_receivables", "contract_assets"),
        "inventory": ("inventory", "inventories", "development_properties"),
        "net_ppe": ("net_ppe", "property_plant_equipment"),
        "total_assets": ("total_assets", "assets", "total_asset", "group_total_assets",
                         "consolidated_total_assets", "total_current_and_non_current_assets"),
        "current_liabilities": ("total_current_liabilities", "current_liabilities"),
        "long_term_debt": ("long_term_debt", "non_current_borrowings"),
        "total_liabilities": ("total_liabilities",),
        "retained_earnings": ("retained_earnings", "accumulated_profits", "revenue_reserve"),
        "equity": ("total_shareholders_equity", "shareholders_equity", "total_equity"),
        "shares": ("shares_outstanding", "issued_ordinary_shares"),
        "cfo": ("operating_cash_flow", "net_cash_from_operating_activities"),
        "investing_cash_flow": ("investing_cash_flow", "net_cash_from_investing_activities"),
        "financing_cash_flow": ("financing_cash_flow", "net_cash_from_financing_activities"),
        "net_change_cash": ("net_change_cash", "net_change_in_cash"),
        "ending_cash": ("ending_cash", "cash_and_cash_equivalents_at_end_of_period"),
    }
    current = {name: concept_number("current", *aliases) for name, aliases in model_input_aliases.items()}
    prior = {name: concept_number("prior", *aliases) for name, aliases in model_input_aliases.items()}

    # Prefer governed component arithmetic over ambiguous aggregate aliases.
    # This prevents note numbers or a single administrative-expense row from
    # being presented as EBIT/SG&A, and prevents scaled note values from being
    # used as the issued-share count.
    for period, values in (("current", current), ("prior", prior)):
        marketing = concept_number(period, "marketing_and_distribution_expenses",
                                   "marketing_and_distribution_expense",
                                   "marketing_and_distribution_costs",
                                   "selling_and_distribution_expenses",
                                   "distribution_expenses", "selling_expenses",
                                   "marketing_expenses")
        administration = concept_number(period, "administrative_expenses",
                                        "administrative_expense",
                                        "general_and_administrative_expenses",
                                        "general_and_administrative_expense")
        if marketing is not None and administration is not None:
            values["sga"] = abs(marketing) + abs(administration)

        before_tax = concept_number(period, "profit_before_tax", "loss_before_income_tax",
                                    "profit_loss_before_tax", "loss_before_tax")
        finance_cost = concept_number(period, "interest_expense", "finance_costs", "finance_cost")
        derived_ebit = before_tax + abs(finance_cost) if before_tax is not None and finance_cost is not None else None
        reported_ebit = values.get("ebit")
        revenue = values.get("sales")
        # A tiny integer relative to revenue is normally a Note-column value.
        suspicious_ebit = (reported_ebit is not None and revenue
                           and abs(reported_ebit) < max(100, abs(revenue) * 0.0001))
        if derived_ebit is not None and (reported_ebit is None or suspicious_ebit):
            values["ebit"] = derived_ebit

        issued_pair = largest_concept_pair(
            "issued_ordinary_shares", "number_of_ordinary_shares",
            "number_of_issued_shares", "issued_shares", "shares_in_issue",
            "shares_outstanding", "issued_and_fully_paid_ordinary_shares",
        )
        issued_shares = issued_pair.get(period)
        reported_shares = values.get("shares")
        ending_pair = largest_ending_balance_pair()
        ending_shares = ending_pair.get(period)
        if (reported_shares is not None and ending_shares is not None
                and abs(ending_shares) >= abs(reported_shares) * 100):
            issued_shares = ending_shares
        suspicious_shares = (issued_shares is not None and reported_shares is not None
                             and abs(reported_shares) < abs(issued_shares) * 0.01)
        if issued_shares is not None and (reported_shares is None or suspicious_shares):
            values["shares"] = issued_shares

    # Final deterministic share-note validation. This does not call an LLM.
    # It reads only the selected report and prefers the explicit closing row
    # beneath a No. of ordinary shares header. This also repairs older runs
    # whose standardized table dataset omitted the supporting share note.
    share_source_validation: Dict[str, Any] = {"status": "NOT_RUN"}
    try:
        validated_share_pair = disclosed_share_pair_from_validated_tables(document_id)
        selected_share_candidate = ({
            "description": "At end of the financial year/period",
            **validated_share_pair,
        } if validated_share_pair else None)
        if not selected_share_candidate:
            share_evidence = statement_resolution_evidence(
                document_id, "BALANCE_SHEET", "shares_outstanding",
                "Shares outstanding", ollama_configuration(),
            )
            share_candidates = build_resolution_candidate_table(
                share_evidence, "shares_outstanding", "Shares outstanding",
            )
            closing_candidate = next((candidate for candidate in share_candidates
                if re.match(r"^at end of (?:the )?(?:financial )?(?:year|period)",
                            text(candidate.get("description")).lower())), None)
            selected_share_candidate = closing_candidate or next((candidate for candidate in share_candidates
                if number(candidate.get("current_value")) is not None
                and number(candidate.get("prior_value")) is not None), None)
        if not selected_share_candidate:
            # The fragment dataset may contain only the primary statements and
            # omit the later share-capital note. Recover from the exact PDF
            # registered for this document; never scan or combine old reports.
            selected_pdf_evidence = managed_pdf_evidence_fallback(
                document_id, "BALANCE_SHEET", "shares_outstanding",
                "Shares outstanding", max_fragments=8,
            )
            selected_pdf_candidates = build_resolution_candidate_table(
                selected_pdf_evidence, "shares_outstanding", "Shares outstanding",
            )
            selected_share_candidate = next((candidate for candidate in selected_pdf_candidates
                if re.match(r"^at end of (?:the )?(?:financial )?(?:year|period)",
                            text(candidate.get("description")).lower())), None)
        if selected_share_candidate:
            disclosed_current = number(selected_share_candidate.get("current_value"))
            disclosed_prior = number(selected_share_candidate.get("prior_value"))
            if disclosed_current is not None and disclosed_prior is not None:
                current["shares"], prior["shares"] = disclosed_current, disclosed_prior
                share_source_validation = {
                    "status": "DIRECT_DISCLOSED_CLOSING_BALANCE",
                    "page_number": integer(selected_share_candidate.get("page_number"), 0),
                    "source_line": text(selected_share_candidate.get("source_line")),
                    "current_value": disclosed_current, "prior_value": disclosed_prior,
                }
            else:
                share_source_validation = {"status": "CANDIDATE_PERIOD_INCOMPLETE"}
        else:
            share_source_validation = {"status": "NO_EXACT_SHARE_NOTE_CANDIDATE"}
    except Exception as exc:
        share_source_validation = {
            "status": "SOURCE_VALIDATION_UNAVAILABLE",
            "error": f"{type(exc).__name__}: {exc}",
        }
        print("Share-note source validation unavailable:", share_source_validation["error"], flush=True)
    # Total assets is an exact accounting identity and can be recovered without
    # an LLM when both disclosed subtotals are available.
    for period, values in (("current", current), ("prior", prior)):
        if values.get("total_assets") is None:
            current_assets = concept_number(period, "total_current_assets", "current_assets")
            non_current_assets = concept_number(period, "total_non_current_assets", "non_current_assets")
            if current_assets is not None and non_current_assets is not None:
                values["total_assets"] = current_assets + non_current_assets

    bank_input_aliases = {
        "sales": ("total_income", "revenue"),
        "nii": ("net_interest_income",),
        "noninterest": ("non_interest_income",),
        "opex": ("operating_expenses", "operating_expense"),
        "provisions": ("provisions_impairment", "impairment_charge", "ecl_charge"),
        "ebit": ("profit_before_tax", "profit_loss_before_tax", "loss_before_tax"),
        "net_income": ("net_profit", "profit_loss"),
        "gross_loans": ("gross_loans_advances", "gross_loans_and_advances"),
        "stage3": ("stage3_npa", "stage_3_npa", "non_performing_loans"),
        "ecl_balance": ("ecl_balance", "loan_loss_provision", "loan_loss_allowance"),
        "investments": ("investments", "investment_securities"),
        "total_assets": ("total_assets",),
        "deposits": ("customer_deposits", "deposits"),
        "borrowings": ("borrowings", "total_borrowings"),
        "total_liabilities": ("total_liabilities",),
        "equity": ("total_shareholders_equity", "shareholders_equity"),
        "cet1": ("cet1_ratio", "common_equity_tier_1_ratio", "capital_adequacy_ratio"),
        "cfo": ("operating_cash_flow",),
    }
    bank_current = {name: concept_number("current", *aliases) for name, aliases in bank_input_aliases.items()}
    bank_prior = {name: concept_number("prior", *aliases) for name, aliases in bank_input_aliases.items()}
    for values in (bank_current, bank_prior):
        for expense_key in ("opex", "provisions"):
            if values.get(expense_key) is not None:
                values[expense_key] = abs(values[expense_key])
        capital_ratio = values.get("cet1")
        if capital_ratio is not None:
            magnitude = abs(capital_ratio)
            # DBS-style source tables can render a percentage with an implied
            # three-decimal scale (25,471 means 25.471%). The selected concept
            # is explicitly a ratio, so normalize this representation instead
            # of treating it as a monetary capital amount or showing 0%.
            values["cet1"] = (capital_ratio * 100 if magnitude <= 1
                              else capital_ratio / 1000 if 1000 <= magnitude <= 100000
                              else None if magnitude > 100
                              else capital_ratio)

    # Expense lines may be presented in parentheses, but model denominators
    # require their magnitude. Profit/loss, retained earnings, EBIT and cash
    # flow retain their disclosed accounting signs.
    for values in (current, prior):
        for expense_key in ("cogs", "sga", "depreciation", "interest_expense"):
            if values.get(expense_key) is not None:
                values[expense_key] = abs(values[expense_key])

    # EBIT is not always published as a separate row. Derive operating result
    # from signed profit/loss before tax plus the positive finance-cost amount.
    for period, values in (("current", current), ("prior", prior)):
        if values.get("ebit") in {None, 0}:
            before_tax = concept_number(period, "profit_before_tax", "loss_before_income_tax",
                                        "profit_loss_before_tax", "loss_before_tax")
            interest = values.get("interest_expense")
            if before_tax is None and values.get("net_income") is not None:
                tax_expense = concept_number(period, "income_tax_expense", "tax_expense", "income_tax")
                if tax_expense is not None:
                    before_tax = values["net_income"] + abs(tax_expense)
            if before_tax is not None and interest is not None:
                values["ebit"] = before_tax + interest

    # Final selected-PDF reconciliation for high-risk rows that are commonly
    # shifted across Group/Company, note/count, or current/prior columns. The
    # first candidate is either an exact primary-statement row or a governed
    # component sum created by build_resolution_candidate_table(). No LLM is
    # involved, and evidence is restricted to this document's registered PDF.
    sector_key = infer_sector(context_values)["sector_key"] if context_values else ""
    primary_statement_validation: Dict[str, Any] = {}
    def broken_balance_identity(values: Dict[str, Any]) -> bool:
        assets = number(values.get("total_assets"))
        liabilities = number(values.get("total_liabilities"))
        equity = number(values.get("equity"))
        if None in {assets, liabilities, equity}:
            return False
        return abs(assets - liabilities - equity) > max(1.0, abs(assets) * 0.02)

    explicit_source_validation = text(request.args.get("verify_source")).lower() in {
        "1", "true", "yes", "on"
    }
    # Automatically reconcile only clearly contaminated runs. Correct reports
    # keep the existing fast path. Typical corruption signatures are a failed
    # balance-sheet identity or a note/cash amount placed in the share field.
    duplicate_share_cash = any(
        values.get("shares") is not None
        and values.get("ending_cash") is not None
        and abs(number(values.get("shares")) - number(values.get("ending_cash")))
            <= max(0.01, abs(number(values.get("ending_cash"))) * 0.000001)
        for values in (current, prior)
    )
    implausible_statement_scale = any(
        values.get("sales") not in {None, 0}
        and values.get("cogs") is not None
        and abs(number(values.get("cogs"))) > abs(number(values.get("sales"))) * 1000
        for values in (current, prior)
    )
    automatic_source_validation = (
        broken_balance_identity(current)
        or broken_balance_identity(prior)
        or duplicate_share_cash
        or implausible_statement_scale
    )
    verify_primary_statements = explicit_source_validation or automatic_source_validation
    if automatic_source_validation:
        primary_statement_validation["trigger"] = {
            "status": "AUTOMATIC_SOURCE_RECONCILIATION",
            "reason": (
                "NARRATIVE_SCALE_CONTAMINATION" if implausible_statement_scale
                else "BALANCE_IDENTITY_OR_SHARE_CASH_COLLISION"
            ),
        }
    if sector_key not in {"banking", "nbfc"} and verify_primary_statements:
        source_specs = {
            "sales": ("INCOME_STATEMENT", "revenue", "Net revenue / sales"),
            "cogs": ("INCOME_STATEMENT", "cost_of_goods_sold", "Cost of goods sold"),
            "sga": ("INCOME_STATEMENT", "sg_and_a_expense", "SG&A expense"),
            "depreciation": ("INCOME_STATEMENT", "depreciation_amortization", "Depreciation & amortisation"),
            "ebit": ("INCOME_STATEMENT", "operating_income_ebit", "Operating income (EBIT)"),
            "interest_expense": ("INCOME_STATEMENT", "interest_expense", "Interest expense"),
            "net_income": ("INCOME_STATEMENT", "net_profit", "Net income"),
            "current_assets": ("BALANCE_SHEET", "total_current_assets", "Total current assets"),
            "receivables": ("BALANCE_SHEET", "trade_receivables_net", "Trade receivables (net)"),
            "inventory": ("BALANCE_SHEET", "inventory", "Inventory"),
            "net_ppe": ("BALANCE_SHEET", "net_ppe", "Net PP&E (fixed assets)"),
            "total_assets": ("BALANCE_SHEET", "total_assets", "Total assets"),
            "current_liabilities": ("BALANCE_SHEET", "total_current_liabilities", "Total current liabilities"),
            "long_term_debt": ("BALANCE_SHEET", "long_term_debt", "Long-term debt"),
            "total_liabilities": ("BALANCE_SHEET", "total_liabilities", "Total liabilities"),
            "retained_earnings": ("BALANCE_SHEET", "retained_earnings", "Retained earnings"),
            "equity": ("BALANCE_SHEET", "total_shareholders_equity", "Total shareholders' equity"),
            "shares": ("BALANCE_SHEET", "shares_outstanding", "Shares outstanding"),
            "cfo": ("CASH_FLOW_STATEMENT", "operating_cash_flow", "Cash flow from operations"),
            "investing_cash_flow": ("CASH_FLOW_STATEMENT", "investing_cash_flow", "Cash flow from investing activities"),
            "financing_cash_flow": ("CASH_FLOW_STATEMENT", "financing_cash_flow", "Cash flow from financing activities"),
            "net_change_cash": ("CASH_FLOW_STATEMENT", "net_change_cash", "Net change in cash"),
            "ending_cash": ("CASH_FLOW_STATEMENT", "ending_cash", "Cash and cash equivalents at end of period"),
        }
        for model_key, (statement_type, concept_key, label) in source_specs.items():
            try:
                evidence = managed_pdf_evidence_fallback(
                    document_id, statement_type, concept_key, label, max_fragments=8,
                )
                candidates = build_resolution_candidate_table(evidence, concept_key, label)
                complete_candidates = [candidate for candidate in candidates
                    if number(candidate.get("current_value")) is not None
                    and number(candidate.get("prior_value")) is not None]
                governed_method_order = (
                    "ISSUED_LESS_TREASURY_SHARES", "PRIMARY_STATEMENT_FINAL_RESULT",
                    "VALIDATED_TABLE_DIRECT_EXTRACTION",
                    "DIRECT_COMPONENT_SUM", "GOVERNED_EBIT_RECONCILIATION",
                    "PRIMARY_STATEMENT_CONFIRMED_ZERO", "PRIMARY_STATEMENT_SECTION_SUBTOTAL",
                )
                selected_candidate = next((candidate for method in governed_method_order
                    for candidate in complete_candidates
                    if text(candidate.get("derivation_method")).upper() == method), None)
                if not selected_candidate:
                    selected_candidate = complete_candidates[0] if complete_candidates else None
                if (model_key == "shares" and selected_candidate
                        and text(selected_candidate.get("derivation_method")).upper() == "ISSUED_SHARES_PROXY"):
                    # Issued share capital is not shares outstanding when a
                    # treasury balance may exist. Preserve the existing value
                    # until the same-report treasury reconciliation succeeds.
                    selected_candidate = None
                if model_key == "interest_expense":
                    # Notes may list individual loan/lease interest rows before
                    # the audited total. Select the largest exact finance-cost
                    # total, not a component or segment column.
                    finance_totals = [candidate for candidate in complete_candidates
                        if re.match(r"^(?:financial|finance) (?:expense|expenses|cost|costs)\b",
                                    text(candidate.get("description")).lower())]
                    if finance_totals:
                        selected_candidate = max(finance_totals, key=lambda candidate:
                            abs(number(candidate.get("current_value")) or 0)
                            + abs(number(candidate.get("prior_value")) or 0))
                share_capital_current = concept_number("current", "share_capital", "issued_share_capital")
                share_capital_prior = concept_number("prior", "share_capital", "issued_share_capital")
                unchanged_share_capital = (
                    share_capital_current is not None and share_capital_prior is not None
                    and abs(share_capital_current - share_capital_prior) <= max(.01, abs(share_capital_current) * .000001)
                )
                treasury_status_explicit = any(re.search(
                    r"excluding treasury shares|no treasury shares|treasury shares\s+(?:nil|none|[-–—])",
                    text(item.get("content")), re.I,
                ) for item in evidence)
                if (not selected_candidate and model_key == "shares"
                        and unchanged_share_capital and treasury_status_explicit):
                    # Some issuers disclose only the current issued count in
                    # shareholder statistics. Where monetary share capital is
                    # unchanged across both reporting dates, use that disclosed
                    # count for both dates instead of a note/page number.
                    share_count = None
                    for item in evidence:
                        match = re.search(
                            r"\bnumber of shares\s*:?\s*(\d{1,3}(?:,\d{3})+|\d{6,})\b",
                            text(item.get("content")), re.I,
                        )
                        if match:
                            share_count = number(match.group(1))
                            if share_count is not None:
                                selected_candidate = {
                                    "current_value": share_count, "prior_value": share_count,
                                    "page_number": item.get("page_number"),
                                    "source_line": match.group(0),
                                    "derivation_method": "DISCLOSED_COUNT_UNCHANGED_SHARE_CAPITAL",
                                }
                                break
                if not selected_candidate:
                    primary_statement_validation[model_key] = {"status": "NO_EXACT_CANDIDATE"}
                    continue
                disclosed_current = number(selected_candidate.get("current_value"))
                disclosed_prior = number(selected_candidate.get("prior_value"))
                if model_key in {"cogs", "sga", "depreciation", "interest_expense"}:
                    disclosed_current = abs(disclosed_current) if disclosed_current is not None else None
                    disclosed_prior = abs(disclosed_prior) if disclosed_prior is not None else None
                current[model_key], prior[model_key] = disclosed_current, disclosed_prior
                primary_statement_validation[model_key] = {
                    "status": "SELECTED_PDF_APPLIED",
                    "concept_key": concept_key,
                    "current_value": disclosed_current, "prior_value": disclosed_prior,
                    "page_number": integer(selected_candidate.get("page_number"), 0),
                    "method": text(selected_candidate.get("derivation_method")) or "DIRECT_DISCLOSED_VALUE",
                    "source_line": text(selected_candidate.get("source_line"))[:500],
                }
            except Exception as exc:
                primary_statement_validation[model_key] = {
                    "status": "SOURCE_VALIDATION_UNAVAILABLE",
                    "error": f"{type(exc).__name__}: {exc}",
                }
                print(f"Primary-statement validation unavailable for {model_key}: {type(exc).__name__}: {exc}", flush=True)

    current_label = reported_period_label("current_period")
    prior_label = reported_period_label("prior_period")
    period_metadata = report_period_metadata()
    current_months = period_metadata.get("current_months")
    prior_months = period_metadata.get("prior_months")
    prior_flow_factor = (
        current_months / prior_months
        if current_months and prior_months and abs(current_months - prior_months) > .25
        else 1.0
    )
    # Preserve the disclosed values for the UI and audit trail. Only the model
    # working copy is duration-normalized below.
    reported_prior = dict(prior)
    # Normalize only duration-based comparatives. Balance-sheet and share
    # values are point-in-time amounts and must never be annualized.
    flow_keys = {"sales", "cogs", "sga", "depreciation", "ebit", "interest_expense", "net_income", "cfo"}
    if prior_flow_factor != 1.0:
        for key in flow_keys:
            if prior.get(key) is not None:
                prior[key] *= prior_flow_factor

    def safe_div(numerator, denominator):
        return None if numerator is None or denominator in {None, 0} else numerator / denominator

    def missing_for(names, periods=("current", "prior")):
        result = []
        for name in names:
            concept = model_input_aliases[name][0]
            for period in periods:
                values = current if period == "current" else prior
                if values.get(name) is None:
                    result.append(f"{concept}:{period}")
        return result

    live_scores, live_debug = [], []

    def add_live_model(key, name, score, band, formula, components, missing_inputs,
                       component_formulas=None):
        status = "DATA_MISSING" if missing_inputs else "CALCULATED"
        live_scores.append({"model_key": key, "model_name": name, "status": status,
                            "score": score, "risk_band": band, "components_json": components,
                            "component_formulas": component_formulas or {},
                            "calculation_source": "DETERMINISTIC_WEBAPP_FORMULA"})
        live_debug.append({"model_key": key, "model_name": name, "diagnostic_status": status,
                           "formula": formula, "missing_inputs": missing_inputs,
                           "inputs": [{"concept_key": item.split(":")[0], "period_requirement": item.split(":")[1].upper(),
                                       "required": True, "input_status": "MISSING"} for item in missing_inputs],
                           "calculation_components": components,
                           "component_formulas": component_formulas or {}, "exception_code": "",
                           "exception_message": "Required statement values must be resolved before calculation." if missing_inputs else ""})

    beneish_required = ["sales", "cogs", "sga", "depreciation", "net_income", "current_assets",
                        "receivables", "net_ppe", "total_assets", "current_liabilities", "long_term_debt", "cfo"]
    beneish_missing = missing_for(beneish_required)
    beneish_components, beneish_score = {}, None
    if not beneish_missing:
        gm_c = safe_div(current["sales"] - current["cogs"], current["sales"])
        gm_p = safe_div(prior["sales"] - prior["cogs"], prior["sales"])
        asset_quality_c = safe_div(current["current_assets"] + current["net_ppe"], current["total_assets"])
        asset_quality_p = safe_div(prior["current_assets"] + prior["net_ppe"], prior["total_assets"])
        aq_c = None if asset_quality_c is None else 1 - asset_quality_c
        aq_p = None if asset_quality_p is None else 1 - asset_quality_p
        dep_c = safe_div(current["depreciation"], current["depreciation"] + current["net_ppe"])
        dep_p = safe_div(prior["depreciation"], prior["depreciation"] + prior["net_ppe"])
        lev_c = safe_div(current["current_liabilities"] + current["long_term_debt"], current["total_assets"])
        lev_p = safe_div(prior["current_liabilities"] + prior["long_term_debt"], prior["total_assets"])
        beneish_components = {
            "DSRI": safe_div(safe_div(current["receivables"], current["sales"]), safe_div(prior["receivables"], prior["sales"])),
            "GMI": safe_div(gm_p, gm_c), "AQI": safe_div(aq_c, aq_p),
            "SGI": safe_div(current["sales"], prior["sales"]), "DEPI": safe_div(dep_p, dep_c),
            "SGAI": safe_div(safe_div(current["sga"], current["sales"]), safe_div(prior["sga"], prior["sales"])),
            "TATA": safe_div(current["net_income"] - current["cfo"], current["total_assets"]),
            "LVGI": safe_div(lev_c, lev_p),
        }
        if all(value is not None and math.isfinite(value) for value in beneish_components.values()):
            b = beneish_components
            beneish_score = (-4.84 + .92*b["DSRI"] + .528*b["GMI"] + .404*b["AQI"] +
                             .892*b["SGI"] + .115*b["DEPI"] - .172*b["SGAI"] +
                             4.679*b["TATA"] - .327*b["LVGI"])
    add_live_model("beneish", "Beneish M-Score", beneish_score,
                   "MANIPULATION_RISK" if beneish_score is not None and beneish_score > -1.78 else "BELOW_THRESHOLD" if beneish_score is not None else "DATA_MISSING",
                   "-4.84 + 0.92×DSRI + 0.528×GMI + 0.404×AQI + 0.892×SGI + 0.115×DEPI − 0.172×SGAI + 4.679×TATA − 0.327×LVGI",
                   beneish_components, beneish_missing, {
                       "DSRI": "(Receivables_c / Sales_c) / (Receivables_p / Sales_p)",
                       "GMI": "GrossMargin_p / GrossMargin_c; GrossMargin = (Sales − COGS) / Sales",
                       "AQI": "AssetQuality_c / AssetQuality_p; AssetQuality = 1 − (CurrentAssets + NetPPE) / TotalAssets",
                       "SGI": "Sales_c / Sales_p",
                       "DEPI": "DepRate_p / DepRate_c; DepRate = Depreciation / (Depreciation + NetPPE)",
                       "SGAI": "(SGA_c / Sales_c) / (SGA_p / Sales_p)",
                       "LVGI": "Leverage_c / Leverage_p; Leverage = (CurrentLiabilities + LongTermDebt) / TotalAssets",
                       "TATA": "(NetIncome_c − CFO_c) / TotalAssets_c",
                   })

    altman_names = ["current_assets", "current_liabilities", "total_assets", "retained_earnings",
                     "ebit", "equity", "total_liabilities"]
    altman_missing = missing_for(altman_names, ("current",))
    altman_parts, altman_score = {}, None
    if not altman_missing:
        altman_parts = {"X1": safe_div(current["current_assets"]-current["current_liabilities"], current["total_assets"]),
                         "X2": safe_div(current["retained_earnings"], current["total_assets"]),
                         "X3": safe_div(current["ebit"], current["total_assets"]),
                         "X4": safe_div(current["equity"], current["total_liabilities"])}
        if all(value is not None and math.isfinite(value) for value in altman_parts.values()):
            altman_score = 6.56*altman_parts["X1"] + 3.26*altman_parts["X2"] + 6.72*altman_parts["X3"] + 1.05*altman_parts["X4"]
    altman_band = "SAFE" if altman_score is not None and altman_score > 2.6 else "GREY" if altman_score is not None and altman_score >= 1.1 else "DISTRESS" if altman_score is not None else "DATA_MISSING"
    add_live_model("altman", "Altman Z double-prime", altman_score, altman_band,
                   "6.56×X1 + 3.26×X2 + 6.72×X3 + 1.05×X4", altman_parts, altman_missing, {
                       "X1": "(CurrentAssets − CurrentLiabilities) / TotalAssets",
                       "X2": "RetainedEarnings / TotalAssets",
                       "X3": "EBIT / TotalAssets",
                       "X4": "Equity / TotalLiabilities",
                   })

    sloan_missing = missing_for(["net_income", "cfo", "total_assets"])
    sloan_components, sloan_score = {}, None
    if not sloan_missing:
        average_assets = (current["total_assets"] + prior["total_assets"]) / 2
        sloan_score = safe_div(current["net_income"] - current["cfo"], average_assets)
        sloan_components = {"net_income": current["net_income"], "operating_cash_flow": current["cfo"], "average_total_assets": average_assets}
    sloan_band = "HIGH" if sloan_score is not None and sloan_score > .10 else "ELEVATED" if sloan_score is not None and sloan_score >= .05 else "CASH_EXCEEDS_PROFIT" if sloan_score is not None and sloan_score < -.10 else "NORMAL" if sloan_score is not None else "DATA_MISSING"
    add_live_model("sloan", "Sloan Accruals Ratio", sloan_score, sloan_band,
                   "(Net income − operating cash flow) ÷ average total assets", sloan_components, sloan_missing, {
                       "net_income": "NetIncome_c",
                       "operating_cash_flow": "CFO_c",
                       "average_total_assets": "(TotalAssets_c + TotalAssets_p) / 2",
                   })

    montier_names = ["sales", "cogs", "depreciation", "net_income", "current_assets", "receivables",
                     "inventory", "net_ppe", "total_assets", "cfo"]
    montier_missing = missing_for(montier_names)
    montier_tests, montier_score = {}, None
    if not montier_missing:
        dso_c, dso_p = safe_div(current["receivables"], current["sales"]), safe_div(prior["receivables"], prior["sales"])
        dsi_c, dsi_p = safe_div(current["inventory"], current["cogs"]), safe_div(prior["inventory"], prior["cogs"])
        oca_c = safe_div(current["current_assets"]-current["receivables"]-current["inventory"], current["sales"])
        oca_p = safe_div(prior["current_assets"]-prior["receivables"]-prior["inventory"], prior["sales"])
        depr_c = safe_div(current["depreciation"], current["depreciation"]+current["net_ppe"])
        depr_p = safe_div(prior["depreciation"], prior["depreciation"]+prior["net_ppe"])
        asset_growth = safe_div(current["total_assets"], prior["total_assets"])
        montier_tests = {"income_exceeds_cfo": current["net_income"] > current["cfo"],
                         "dso_rising": dso_c is not None and dso_p is not None and dso_c > dso_p,
                         "inventory_days_rising": dsi_c is not None and dsi_p is not None and dsi_c > dsi_p,
                         "other_current_assets_rising": oca_c is not None and oca_p is not None and oca_c > oca_p,
                         "depreciation_rate_declining": depr_c is not None and depr_p is not None and depr_c < depr_p,
                         "asset_growth_above_20pct": asset_growth is not None and asset_growth - 1 > .20}
        montier_score = sum(bool(value) for value in montier_tests.values())
    add_live_model("montier", "Montier C-Score", montier_score,
                   "HIGH" if montier_score is not None and montier_score >= 4 else "ELEVATED" if montier_score is not None and montier_score >= 2 else "LOW" if montier_score is not None else "DATA_MISSING",
                   "Sum of six TRUE conditions; each TRUE condition scores 1 point (0–6)", montier_tests, montier_missing, {
                       "income_exceeds_cfo": "NetIncome_c > CFO_c",
                       "dso_rising": "DSO_c > DSO_p; DSO = (Receivables / Sales) × 365",
                       "inventory_days_rising": "DSI_c > DSI_p; DSI = (Inventory / COGS) × 365",
                       "other_current_assets_rising": "OtherCA_c > OtherCA_p; OtherCA = (CurrentAssets − Receivables − Inventory) / Sales",
                       "depreciation_rate_declining": "DepRate_c < DepRate_p; DepRate = Depreciation / (Depreciation + NetPPE)",
                       "asset_growth_above_20pct": "(TotalAssets_c / TotalAssets_p) − 1 > 20%",
                   })

    piotroski_names = ["sales", "cogs", "net_income", "current_assets", "total_assets",
                       "current_liabilities", "long_term_debt", "shares", "cfo"]
    piotroski_missing = missing_for(piotroski_names)
    piotroski_tests, piotroski_score = {}, None
    if not piotroski_missing:
        roa_c, roa_p = safe_div(current["net_income"], current["total_assets"]), safe_div(prior["net_income"], prior["total_assets"])
        current_ratio_c, current_ratio_p = safe_div(current["current_assets"], current["current_liabilities"]), safe_div(prior["current_assets"], prior["current_liabilities"])
        leverage_c, leverage_p = safe_div(current["long_term_debt"], current["total_assets"]), safe_div(prior["long_term_debt"], prior["total_assets"])
        margin_c, margin_p = safe_div(current["sales"]-current["cogs"], current["sales"]), safe_div(prior["sales"]-prior["cogs"], prior["sales"])
        turnover_c, turnover_p = safe_div(current["sales"], current["total_assets"]), safe_div(prior["sales"], prior["total_assets"])
        cfo_assets = safe_div(current["cfo"], current["total_assets"])
        ratios = [roa_c, roa_p, current_ratio_c, current_ratio_p, leverage_c, leverage_p,
                  margin_c, margin_p, turnover_c, turnover_p, cfo_assets]
        if all(value is not None and math.isfinite(value) for value in ratios):
            piotroski_tests = {"positive_roa": roa_c > 0, "positive_cfo": current["cfo"] > 0,
                                "improving_roa": roa_c > roa_p, "low_accruals": cfo_assets > roa_c,
                                "falling_leverage": leverage_c < leverage_p, "improving_liquidity": current_ratio_c > current_ratio_p,
                                "no_dilution": current["shares"] <= prior["shares"], "improving_margin": margin_c > margin_p,
                                "improving_turnover": turnover_c > turnover_p}
            piotroski_score = sum(bool(value) for value in piotroski_tests.values())
    add_live_model("piotroski", "Piotroski F-Score", piotroski_score,
                   "STRONG" if piotroski_score is not None and piotroski_score >= 7 else "WEAK" if piotroski_score is not None and piotroski_score <= 3 else "MODERATE" if piotroski_score is not None else "DATA_MISSING",
                   "Sum of nine TRUE conditions; each TRUE condition scores 1 point (0–9)", piotroski_tests, piotroski_missing, {
                       "positive_roa": "NetIncome_c / TotalAssets_c > 0",
                       "positive_cfo": "CFO_c > 0",
                       "improving_roa": "ROA_c > ROA_p",
                       "low_accruals": "CFO_c / TotalAssets_c > ROA_c",
                       "falling_leverage": "LongTermDebt_c / TotalAssets_c < LongTermDebt_p / TotalAssets_p",
                       "improving_liquidity": "CurrentAssets_c / CurrentLiabilities_c > CurrentAssets_p / CurrentLiabilities_p",
                       "no_dilution": "Shares_c ≤ Shares_p",
                       "improving_margin": "GrossMargin_c > GrossMargin_p; GrossMargin = (Sales − COGS) / Sales",
                       "improving_turnover": "Sales_c / TotalAssets_c > Sales_p / TotalAssets_p",
                   })

    # The five reference models are deterministic and take precedence over
    # stale recipe output while retaining any additional sector models.
    live_keys = {item["model_key"] for item in live_scores}
    score_rows = [row for row in score_rows if text(row.get("model_key")) not in live_keys
                  and text(row.get("model_key")).lower() != "bank_metrics"
                  and "bank asset-quality" not in text(row.get("model_name")).lower()] + live_scores
    values_by_concept: Dict[str, Dict[str, Any]] = {}
    for row in context_values:
        concept = text(row.get("concept_key"))
        if not concept:
            continue
        candidate = {
            "concept_key": concept,
            "current_period": text(row.get("current_period")),
            "prior_period": text(row.get("prior_period")),
            "current_value": number(row.get("current_value")),
            "prior_value": number(row.get("prior_value")),
            "resolution_method": text(row.get("resolution_method") or row.get("selection_method")),
            "current_rule_key": text(row.get("current_rule_key")),
            "prior_rule_key": text(row.get("prior_rule_key")),
            "current_lineage_json": row.get("current_lineage_json"),
            "prior_lineage_json": row.get("prior_lineage_json"),
        }
        existing = values_by_concept.get(concept)
        completeness = int(candidate["current_value"] is not None) + int(candidate["prior_value"] is not None)
        existing_completeness = -1 if existing is None else int(existing["current_value"] is not None) + int(existing["prior_value"] is not None)
        if completeness > existing_completeness:
            values_by_concept[concept] = candidate

    formula_descriptions = {
        "beneish": "-4.84 + 0.92×DSRI + 0.528×GMI + 0.404×AQI + 0.892×SGI + 0.115×DEPI − 0.172×SGAI + 4.679×TATA − 0.327×LVGI",
        "altman": "6.56×X1 + 3.26×X2 + 6.72×X3 + 1.05×X4",
        "montier": "Sum of configured accounting-quality warning signals, normalized to a 0–6 scale",
        "piotroski": "Sum of nine binary profitability, leverage/liquidity and operating-efficiency signals",
        "sloan": "(Net income − operating cash flow) ÷ average total assets",
        "bank_metrics": "Bank asset quality, ECL coverage, loan growth, net-interest yield and CET1 capital metrics",
    }
    scoring_config = read_optional(SECTOR_SCORING_CONFIG_DATASET)
    if not scoring_config.empty and sector_key and "sector_key" in scoring_config.columns:
        scoring_config = scoring_config[scoring_config["sector_key"].astype(str).eq(sector_key)]
    score_by_model = {text(row.get("model_key")): row for row in score_rows}
    exception_by_model = {text(row.get("model_key")): row for row in exception_rows}
    model_debug = []
    if not scoring_config.empty and "model_key" in scoring_config.columns:
        for model_key, model_rows in scoring_config.groupby("model_key", sort=False):
            key = text(model_key)
            first_config = model_rows.iloc[0]
            enabled = text(first_config.get("enabled")).lower() in {"true", "1", "yes"}
            disabled_reason = text(first_config.get("disabled_reason"))
            if not enabled:
                model_debug.append({
                    "model_key": key,
                    "model_name": text(first_config.get("model_name")),
                    "diagnostic_status": "NOT_APPLICABLE",
                    "formula": formula_descriptions.get(key, "Configured scoring engine"),
                    "missing_inputs": [],
                    "inputs": [],
                    "calculation_components": {},
                    "exception_code": "",
                    "exception_message": disabled_reason or "Model is disabled for this sector profile",
                    "disabled_reason": disabled_reason,
                })
                continue
            requirements = []
            missing_inputs = []
            for config_row in model_rows.to_dict(orient="records"):
                concept = text(config_row.get("input_concept_key") or config_row.get("concept_key"))
                if not concept:
                    continue
                period_requirement = text(config_row.get("period_requirement")) or "CURRENT"
                is_required = text(config_row.get("input_required", config_row.get("required", True))).lower() in {"true", "1", "yes"}
                supplied = values_by_concept.get(concept, {"current_value": None, "prior_value": None})
                current_missing = supplied.get("current_value") is None
                prior_missing = period_requirement == "CURRENT_AND_PRIOR" and supplied.get("prior_value") is None
                if is_required and (current_missing or prior_missing):
                    missing_inputs.append(concept)
                requirements.append({
                    "concept_key": concept,
                    "period_requirement": period_requirement,
                    "required": is_required,
                    **supplied,
                    "input_status": "MISSING" if current_missing or prior_missing else "AVAILABLE",
                })
            scored = score_by_model.get(key)
            exception = exception_by_model.get(key)
            diagnostic_status = (
                "CALCULATED_WITH_ASSUMPTIONS"
                if scored and text(scored.get("status")) == "SCORED_WITH_ASSUMPTIONS"
                else "CALCULATED" if scored and text(scored.get("status")) == "SCORED"
                else "NOT_APPLICABLE" if scored and text(scored.get("status")) == "NOT_APPLICABLE"
                else "DATA_MISSING" if missing_inputs
                else "CALCULATION_ERROR" if exception
                else "NOT_RUN"
            )
            model_debug.append({
                "model_key": key,
                "model_name": text(model_rows.iloc[0].get("model_name")),
                "diagnostic_status": diagnostic_status,
                "formula": formula_descriptions.get(key, "Configured scoring engine"),
                "missing_inputs": sorted(set(missing_inputs)),
                "inputs": requirements,
                "calculation_components": (scored or {}).get("components_json", {}),
                "exception_code": text((exception or {}).get("exception_code")),
                "exception_message": text((exception or {}).get("message")),
            })
    model_debug = [item for item in model_debug if text(item.get("model_key")) not in live_keys
                   and text(item.get("model_key")).lower() != "bank_metrics"
                   and "bank asset-quality" not in text(item.get("model_name")).lower()] + live_debug

    # Ported from fsre-ui/src/App.jsx: use its weighted composite index, not
    # the earlier average-of-model-percentages approximation.
    available = {item["model_key"]: item for item in live_scores if item.get("score") is not None}
    sector_thresholds = {
        "trading": {"dso_tol": 1.25, "inventory_tol": 1.2},
        "technology": {"dso_tol": 1.15, "inventory_enabled": False},
        "realestate": {"dso_tol": 1.35, "leverage_tol": 1.25, "coverage_floor": 1.5, "coverage_critical": 1},
        "energy": {"leverage_tol": 1.2, "coverage_floor": 1.5},
        "consumer": {"dso_tol": 1.15, "inventory_tol": 1.10},
        "pharma": {"inventory_tol": 1.10},
    }
    thresholds = {"dso_tol": 1.2, "inventory_tol": 1.15, "leverage_tol": 1.1,
                  "coverage_floor": 2, "coverage_critical": 1, "inventory_enabled": True}
    thresholds.update(sector_thresholds.get(sector_key, {}))
    financial_indicators = []

    def add_indicator(hit, severity, title, detail, metric=None, threshold=None):
        if hit:
            financial_indicators.append({"severity": severity, "category": "Financial",
                                         "title": title, "detail": detail, "metric": metric,
                                         "threshold": threshold, "reference": "MAS 3.1(a)(b)"})

    def ratio(a, b):
        return safe_div(a, b)

    dso_c, dso_p = ratio(current["receivables"], current["sales"]), ratio(prior["receivables"], prior["sales"])
    leverage_c = ratio((current["current_liabilities"] or 0) + (current["long_term_debt"] or 0), current["total_assets"]) if current["current_liabilities"] is not None and current["long_term_debt"] is not None else None
    leverage_p = ratio((prior["current_liabilities"] or 0) + (prior["long_term_debt"] or 0), prior["total_assets"]) if prior["current_liabilities"] is not None and prior["long_term_debt"] is not None else None
    coverage = ratio(current["ebit"], current.get("interest_expense"))
    current_ratio = ratio(current["current_assets"], current["current_liabilities"])
    dso_detail = (f"Days sales outstanding rose from {dso_p:.0f} to {dso_c:.0f} days — possible channel stuffing."
                  if dso_c is not None and dso_p is not None
                  else "Days sales outstanding could not be compared because a required value is unavailable.")
    coverage_detail = (f"EBIT covers interest {coverage:.1f}× — below the sector floor."
                       if coverage is not None
                       else "Interest coverage could not be calculated because EBIT or interest expense is unavailable.")
    add_indicator(current["cfo"] is not None and current["cfo"] < 0, "high", "Negative operating cash flow", "Company reports profit dynamics while burning cash from operations.", current["cfo"], 0)
    add_indicator(all(v is not None for v in (current["cfo"], current["net_income"])) and current["cfo"] >= 0 and current["net_income"] > 0 and current["cfo"] < current["net_income"] * .6, "med", "Cash flow lags reported earnings", "Operating cash flow is well below net income — accrual-heavy earnings.", current["cfo"], current["net_income"] * .6 if current["net_income"] is not None else None)
    add_indicator(dso_c is not None and dso_p is not None and dso_c > dso_p * thresholds["dso_tol"], "high", "Receivables outpacing sales", dso_detail, dso_c, dso_p * thresholds["dso_tol"] if dso_p is not None else None)
    add_indicator(thresholds["inventory_enabled"] and all(v is not None for v in (current["inventory"], prior["inventory"], current["sales"], prior["sales"])) and prior["inventory"] != 0 and prior["sales"] != 0 and current["inventory"] > 0 and current["inventory"] / prior["inventory"] > current["sales"] / prior["sales"] * thresholds["inventory_tol"], "med", "Inventory building faster than sales", "Inventory growth is outrunning revenue — obsolescence or demand risk.")
    add_indicator(leverage_c is not None and leverage_p is not None and leverage_c > leverage_p * thresholds["leverage_tol"], "med", "Leverage rising", "Total-debt-to-assets increased beyond the sector tolerance.", leverage_c, leverage_p * thresholds["leverage_tol"] if leverage_p is not None else None)
    add_indicator(coverage is not None and coverage < thresholds["coverage_floor"], "high" if coverage is not None and coverage < thresholds["coverage_critical"] else "med", "Thin interest coverage", coverage_detail, coverage, thresholds["coverage_floor"])
    add_indicator(current_ratio is not None and current_ratio < 1, "high", "Current ratio below 1.0", "Short-term liabilities exceed short-term assets — liquidity strain.", current_ratio, 1)
    add_indicator(current["retained_earnings"] is not None and current["retained_earnings"] < 0, "med", "Negative retained earnings", "Accumulated deficit on the balance sheet.", current["retained_earnings"], 0)
    add_indicator(current["shares"] is not None and prior["shares"] is not None and current["shares"] > prior["shares"] * 1.03, "low", "Share dilution", "New shares were issued during the period.", current["shares"], prior["shares"] * 1.03 if prior["shares"] is not None else None)

    def clamp(value, low, high):
        return max(low, min(high, value))
    m = available.get("beneish", {}).get("score")
    mont = available.get("montier", {}).get("score")
    z = available.get("altman", {}).get("score")
    f_score = available.get("piotroski", {}).get("score")
    sl = available.get("sloan", {}).get("score")
    risk_points = {
        "Beneish M-Score": (18 + clamp((m + 1.78) / 2, 0, 1) * 8) if m is not None and m > -1.78 else clamp((m + 2.22) / .44, 0, 1) * 12 if m is not None else 0,
        "Montier C-Score": mont / 6 * 12 if mont is not None else 0,
        "Altman Z double-prime": clamp((2.6 - z) / 1.5, 0, 1) * 16 if z is not None else 0,
        "Piotroski F-Score": (9 - f_score) / 9 * 10 if f_score is not None else 0,
        "Sloan Accruals Ratio": clamp((sl - .02) / .12, 0, 1) * 8 if sl is not None else 0,
        "Financial indicators": min(15, sum({"high": 5, "med": 3, "low": 1}[item["severity"]] for item in financial_indicators)),
    }
    risk_index = round(clamp(sum(risk_points.values()), 0, 100)) if available else None
    risk_band = ("HIGH" if risk_index is not None and risk_index > 66 else
                 "ELEVATED" if risk_index is not None and risk_index > 42 else
                 "MODERATE" if risk_index is not None and risk_index > 22 else
                 "LOW" if risk_index is not None else "DATA_MISSING")
    response_payload = {
        "backend_build": BACKEND_BUILD_ID,
        "report_binding": {
            "assessment_run_id": run_id,
            "source_document_id": document_id,
            "file_name": text(registration_lookup().get(document_id, {}).get("file_name")) or document_id,
            "binding_method": "EXACT_SOURCE_DOCUMENT_ID",
        },
        "scores": score_rows,
        "exceptions": exception_rows,
        "score_count": len(score_rows),
        "exception_count": len(exception_rows),
        "data_source": FORENSIC_SCORES_DATASET,
        "input_data_source": value_source,
        "model_debug": model_debug,
        "share_source_validation": share_source_validation,
        "primary_statement_validation": primary_statement_validation,
        "risk_summary": {"index": risk_index, "band": risk_band,
                         "calculated_models": len(risk_points), "required_models": 5,
                         "components": risk_points,
                         "missing_inputs": sorted({value for item in live_debug for value in item.get("missing_inputs", [])})},
        # Read-only audit contract for the score-derivation screen.  These are
        # the same values, formulas and components used above; no score is
        # recomputed by the browser.
        "score_derivation": {
            "read_only": True,
            "display_precision": 3,
            "models": live_scores,
            "model_debug": live_debug,
            "reported_inputs": {
                "current": ({**current, **bank_current}
                            if sector_key in {"banking", "nbfc"} else current),
                "prior": ({**reported_prior, **bank_prior}
                          if sector_key in {"banking", "nbfc"} else reported_prior),
            },
            "calculation_inputs": {
                "current": ({**current, **bank_current}
                            if sector_key in {"banking", "nbfc"} else current),
                "prior": ({**prior, **bank_prior}
                          if sector_key in {"banking", "nbfc"} else prior),
            },
            "period_normalization": {
                "current_label": current_label,
                "prior_label": prior_label,
                "current_months": current_months,
                "prior_months": prior_months,
                "prior_flow_factor": prior_flow_factor,
                "normalized_flow_keys": sorted(flow_keys) if prior_flow_factor != 1.0 else [],
                "display_values_are_reported": True,
            },
            "composite_components": risk_points,
        },
        "financial_indicators": financial_indicators,
        # Adapter contract for the reference Forensic Scoring screen.  Values
        # are scoped to this run/document only and deliberately retain nulls:
        # the client must surface unavailable inputs rather than treating them
        # as zero.
        "reference_forensic_inputs": {
            "assessment_run_id": run_id,
            "source_document_id": document_id,
            "file_name": text(registration_lookup().get(document_id, {}).get("file_name")) or document_id,
            "sector": sector_key or "manufacturing",
            "entity": (registration_lookup().get(document_id, {}).get("entity_key")
                       or text((snapshot.get("context") or {}).get("entity_name"))),
            "units": reporting_units,
            "reporting_units": reporting_units,
            "current": {**current, **bank_current} if sector_key in {"banking", "nbfc"} else current,
            "prior": ({**reported_prior, **bank_prior}
                      if sector_key in {"banking", "nbfc"} else reported_prior),
            "derived_inputs": [{"concept_key": text(row.get("concept_key")), "period_role": role}
                               for row in context_values
                               for role in ("current", "prior")
                               if number(row.get(role + "_value")) is not None
                               and text(row.get("resolution_method")).upper()
                               not in {"", "DIRECT_DISCLOSED_VALUE", "PYTHON"}],
            "period_normalization": {
                "current_label": current_label,
                "prior_label": prior_label,
                "current_months": current_months,
                "prior_months": prior_months,
                "prior_flow_factor": prior_flow_factor,
                "source": period_metadata.get("source"),
                "evidence": period_metadata.get("evidence") or [],
                "normalized_flow_keys": sorted(flow_keys) if prior_flow_factor != 1.0 else [],
                "display_values_are_reported": True,
            },
        },
        "cache_version": BACKEND_BUILD_ID,
        "cache_status": "CALCULATED_AND_PERSISTED",
    }
    persist_forensic_result(run_id, document_id, input_fingerprint, response_payload)
    return jsonify(response_payload)


NARRATIVE_EVIDENCE_TERMS = {
    "audit", "auditor", "going concern", "restatement", "fraud", "investigation",
    "related party", "related-party", "revenue recognition", "receivable", "inventory",
    "impairment", "debt", "borrowings", "liquidity", "covenant", "default", "cash flow",
    "management", "director", "chief financial officer", "material uncertainty",
}


def rows_for_filing(frame: pd.DataFrame, run_id: str, document_id: str) -> List[Dict[str, Any]]:
    if frame.empty:
        return []
    rows = []
    for row in frame.to_dict(orient="records"):
        row_run = text(row.get("assessment_run_id") or row.get("run_id"))
        row_document = text(row.get("source_document_id"))
        if row_document != document_id or (row_run and row_run != run_id):
            continue
        rows.append({str(key): (None if missing(value) else value) for key, value in row.items()})
    return rows


def narrative_evidence(document_id: str, settings: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Select a bounded, page-cited evidence set from the uploaded annual report."""
    # Prefer persisted upload evidence so event extraction works for every
    # uploaded report, even when the Dataiku fragments dataset is not refreshed.
    try:
        with postgres_connection() as connection:
            with connection.cursor() as cursor:
                cursor.execute("""
                    SELECT page_number, content_text
                    FROM financial_risk_intelligence.report_evidence
                    WHERE source_document_id = %s
                    ORDER BY page_number
                """, (document_id,))
                rows = cursor.fetchall()
        if rows:
            fragments = [{"page_number": row[0], "content_text": row[1]} for row in rows]
        else:
            fragments = read_optional(DOCUMENT_FRAGMENTS_DATASET).to_dict("records")
    except Exception:
        fragments = read_optional(DOCUMENT_FRAGMENTS_DATASET).to_dict("records")
    if not fragments:
        return []
    candidates = []
    for row in fragments:
        if text(row.get("source_document_id")) != document_id:
            continue
        content = text(row.get("content_text"))
        if not content:
            continue
        normalized = content.lower()
        hits = sorted(term for term in NARRATIVE_EVIDENCE_TERMS if term in normalized)
        score = sum(normalized.count(term) for term in hits)
        # Financial-statement pages remain useful even without narrative keywords.
        if any(term in normalized for term in ("statement of financial position", "income statement", "cash flow statement")):
            score += 3
        candidates.append((score, integer(row.get("page_number"), 0), content, hits))
    candidates.sort(key=lambda item: (-item[0], item[1]))
    selected = []
    seen_pages = set()
    for score, page, content, hits in candidates:
        if page in seen_pages or (score <= 0 and selected):
            continue
        seen_pages.add(page)
        selected.append({
            "page_number": page,
            "matched_topics": hits,
            "content": content[:settings["max_fragment_characters"]],
        })
        if len(selected) >= settings["max_fragments"]:
            break
    return selected


EVENT_SIGNAL_TYPES = {
    "reg_order", "auditor_exit", "adverse_opinion", "default", "restatement",
    "trading_halt", "forensic_audit", "reg_investigation", "exec_exit", "raid",
    "auditor_downgrade", "qualified_opinion", "cfo_exit", "ceo_exit", "multi_exits",
    "late_filing", "control_weakness", "litigation", "address_churn",
    "audit_regulator", "rating_downgrade", "whistleblower", "exchange_query",
    "inv_closed", "order_overturned", "clean_reaudit", "gap_resolved", "rating_upgrade",
}
EVENT_SIGNAL_CACHE: Dict[str, List[Dict[str, Any]]] = {}
# Parsed pages are cached per selected document. This prevents a Derivation
# Review batch from reparsing a long annual report once for every missing cell.
SELECTED_PDF_TEXT_CACHE: Dict[str, Dict[str, Any]] = {}
SELECTED_PDF_TEXT_CACHE_LOCK = threading.Lock()
MAX_SELECTED_PDF_TEXT_CACHE = 8


@app.route("/api/event-signals", methods=["POST"])
def event_signals():
    """Extract rating-moving events from only the selected uploaded PDF using the configured LLM."""
    body = request.get_json(silent=True) or {}
    run_id = text(body.get("assessment_run_id"))
    document_id = text(body.get("source_document_id"))
    if not run_id or not document_id:
        return jsonify({"error": "assessment_run_id and source_document_id are required"}), 400
    cache_key = f"{run_id}:{document_id}"
    if cache_key in EVENT_SIGNAL_CACHE and not bool(body.get("refresh")):
        return jsonify({"events": EVENT_SIGNAL_CACHE[cache_key], "cached": True})
    if not llm_feature_enabled("fri_llm_governance_enabled", False):
        return jsonify({"events": [], "cached": False, "llm_skipped": True,
                        "status": "LLM_FEATURE_DISABLED",
                        "message": "Governance LLM extraction is temporarily disabled to reserve provider capacity for missing financial values."})
    try:
        settings = financial_resolution_llm_configuration()
        evidence = narrative_evidence(document_id, ollama_configuration())
        if not evidence:
            return jsonify({"events": [], "message": "No narrative evidence was found in the selected report."})
        # Keep governance extraction within provider request limits. Prefer
        # pages containing governance/audit/legal terms, then cap each page.
        terms = ("governance", "auditor", "audit opinion", "director", "litigation", "regulatory", "internal control", "related party", "restatement", "filing")
        ranked = sorted(evidence, key=lambda item: (0 if any(term in text(item.get("content") or item.get("text")).lower() for term in terms) else 1, integer(item.get("page_number"), 0)))
        # Send compact chunks to avoid provider payload limits. The selected
        # report is represented by several small, independently bounded pages.
        evidence = [{"page_number": integer(item.get("page_number"), 0), "text": text(item.get("content") or item.get("text"))[:600]} for item in ranked[:6]]
        allowed = sorted(EVENT_SIGNAL_TYPES)
        prompt = {
            "task": "Identify only explicit rating-moving governance, audit, regulatory, solvency or credit events disclosed in this annual report. Do not infer an event from financial ratios and do not use outside knowledge.",
            "allowed_type_ids": allowed,
            "rules": [
                "Return an empty events array when the report does not explicitly support an allowed event.",
                "Every event must cite one supplied page number and summarize the disclosure without inventing facts.",
                "Use confirmed only when the report states the event occurred; otherwise use reported.",
                "Deduplicate repeated references to the same event.",
            ],
            "report_evidence": evidence,
        }
        messages = [
            {"role": "system", "content": "You are the FSRE event-signal extraction layer. Output strict JSON grounded only in supplied annual-report evidence."},
            {"role": "user", "content": json.dumps(prompt, default=str)},
        ]
        if settings["provider"] in {"bedrock", "gemini"}:
            event_schema = {
                "type": "object",
                "properties": {"events": {"type": "array", "items": {
                    "type": "object",
                    "properties": {
                        "type_id": {"type": "string", "enum": allowed},
                        "date": {"type": "string"},
                        "status": {"type": "string", "enum": ["confirmed", "reported"]},
                        "note": {"type": "string"},
                        "evidence_page": {"type": "integer"},
                        "confidence": {"type": "number"},
                    },
                    "required": ["type_id", "date", "status", "note", "evidence_page", "confidence"],
                    "additionalProperties": False,
                }}},
                "required": ["events"], "additionalProperties": False,
            }
            response = requests.post(
                settings["base_url"].rstrip("/") + "/chat/completions",
                json=({"model": settings["model"], "stream": False, "messages": messages,
                       "temperature": 0, "max_completion_tokens": 3000,
                       "response_format": {"type": "json_schema", "json_schema": {
                           "name": "fsre_event_signals", "strict": True, "schema": event_schema}}}
                      if settings["provider"] == "bedrock" else
                      {"model": settings["model"], "stream": False, "messages": messages,
                       "temperature": 0, "max_tokens": 3000,
                       "response_format": {"type": "json_object"}}),
                headers={"Authorization": "Bearer " + settings["api_key"], "Content-Type": "application/json"},
                timeout=settings["timeout_seconds"],
            )
            response.raise_for_status()
            choices = response.json().get("choices") or []
            raw = text(((choices[0].get("message") or {}).get("content")) if choices else "")
        else:
            response = requests.post(
                settings["base_url"].rstrip("/") + "/api/chat",
                json={"model": settings["model"], "stream": False, "format": "json",
                      "options": {"temperature": 0, "num_predict": 1200}, "messages": messages},
                timeout=settings["timeout_seconds"],
            )
            response.raise_for_status()
            raw = text((response.json().get("message") or {}).get("content"))
        parsed = parse_ollama_json(raw)
        # Deterministic safety-net: preserve explicit governance disclosures
        # even when the model returns an empty/partial event array.
        evidence_text = " ".join(text(item.get("text")) for item in evidence).lower()
        heuristic_terms = {
            "qualified_opinion": ("qualified opinion", "adverse opinion", "disclaimer of opinion", "emphasis of matter"),
            "control_weakness": ("material weakness", "internal control deficiency", "icfr weakness", "internal control over financial reporting", "control weakness"),
            "litigation": ("material litigation", "regulatory investigation", "legal proceedings"),
            "restatement": ("prior period restatement", "restated financial statements", "restated", "restatement of comparative", "reclassified comparative"),
            "late_filing": ("late filing", "delayed filing", "filed late"),
            "auditor_exit": ("auditor resigned", "auditor resignation", "dismissed as auditor"),
        }
        parsed.setdefault("events", [])
        for type_id, terms in heuristic_terms.items():
            if any(term in evidence_text for term in terms) and not any(text(x.get("type_id")) == type_id for x in parsed["events"]):
                page = next((integer(item.get("page_number"), 0) for item in evidence if any(term in text(item.get("text")).lower() for term in terms)), 0)
                if page:
                    parsed["events"].append({"type_id": type_id, "date": "", "status": "confirmed", "note": "Explicit annual-report disclosure detected.", "evidence_page": page, "confidence": 0.9})
        allowed_pages = {integer(item.get("page_number"), 0) for item in evidence}
        events = []
        seen = set()
        for item in parsed.get("events", []):
            type_id = text(item.get("type_id"))
            page = integer(item.get("evidence_page"), 0)
            note = text(item.get("note"))[:500]
            if type_id not in EVENT_SIGNAL_TYPES or page not in allowed_pages or not note:
                continue
            signature = (type_id, note.lower())
            if signature in seen:
                continue
            seen.add(signature)
            confidence = max(0.0, min(1.0, number(item.get("confidence")) or 0.0))
            events.append({
                "typeId": type_id,
                "date": text(item.get("date")),
                "status": "confirmed" if text(item.get("status")) == "confirmed" and confidence >= .75 else "reported",
                "note": f"{note} (annual report p. {page}; LLM confidence {confidence:.0%})",
                "evidencePage": page,
                "confidence": confidence,
                "source": "UPLOADED_REPORT_LLM",
            })
        EVENT_SIGNAL_CACHE[cache_key] = events
        return jsonify({"events": events, "cached": False, "model": settings["model"],
                        "llm_request": {"evidence_count": len(evidence), "evidence": evidence, "allowed_type_ids": allowed},
                        "source_document_id": document_id, "assessment_run_id": run_id})
    except Exception as exc:
        if "429" in str(exc) or "Too Many Requests" in str(exc):
            return jsonify({"events": [], "cached": False, "rate_limited": True,
                            "message": "LLM rate limit reached; retry later.",
                            "source_document_id": document_id, "assessment_run_id": run_id}), 200
        return jsonify({"error": f"{type(exc).__name__}: {exc}", "stage": "LLM_EVENT_SIGNAL_EXTRACTION"}), 502


STATEMENT_EVIDENCE_ANCHORS = {
    "BALANCE_SHEET": ("statement of financial position", "balance sheet", "current assets",
        "non-current assets", "current liabilities", "non-current liabilities", "total assets",
        "total liabilities", "shareholders' equity", "equity attributable"),
    "INCOME_STATEMENT": ("statement of comprehensive income", "income statement", "profit or loss",
        "statement of profit", "revenue", "cost of sales", "gross profit", "operating profit",
        "profit before tax", "profit for the year"),
    "CASH_FLOW_STATEMENT": ("statement of cash flows", "cash flow statement", "cash flows from operating",
        "cash flows from investing", "cash flows from financing", "net cash", "cash and cash equivalents"),
}

CONCEPT_EVIDENCE_ALIASES = {
    # REIT/property issuers often use Gross Revenue rather than sales. It is
    # the top-line operating revenue needed by the sector forensic models.
    "revenue": ("revenue", "operating revenue", "gross revenue", "gross rental income", "rental income",
                "property revenue", "property development revenue", "construction revenue",
                "turnover", "income from properties"),
    "net_profit": ("net profit", "net income", "profit for the year", "loss for the year",
                   "loss for the year, attributable to owners"),
    "sg_and_a_expense": ("selling expenses", "selling and distribution expenses", "distribution costs",
                          "marketing expenses", "marketing and distribution expenses",
                          "selling, general and administrative expenses",
                          "general, administrative and selling expenses",
                          "general and administrative expenses", "administrative expenses"),
    "depreciation_amortization": ("depreciation expense", "amortisation expense", "amortization expense",
                                   "depreciation of property, plant and equipment",
                                   "depreciation of property plant and equipment",
                                   "amortisation of intangible assets", "amortization of intangible assets",
                                   "depreciation and amortisation", "depreciation and amortization"),
    "interest_expense": ("financial expenses", "finance expenses", "finance costs", "finance cost",
                         "interest expense", "interest expenses"),
    "cost_of_goods_sold": ("cost of sales", "cost of revenue", "cost of goods sold"),
    "operating_income_ebit": ("operating income", "operating profit", "profit from operations",
                               "profit before tax", "loss before tax", "loss before income tax",
                               "finance costs", "finance cost", "finance income", "interest income"),
    "total_current_assets": ("total current assets", "current assets"),
    "total_current_liabilities": ("total current liabilities", "current liabilities"),
    "total_assets": ("total assets",),
    "total_liabilities": ("total liabilities",),
    "total_shareholders_equity": ("total shareholders' equity", "total stockholders' equity",
                                    "total equity", "equity attributable to owners"),
    "shares_outstanding": ("shares outstanding", "shares in issue", "issued shares",
        "issued and paid up share capital", "excluding treasury shares comprised",
        "number of issued shares excluding treasury shares", "number of ordinary shares",
        "no. of ordinary shares", "ordinary shares in issue", "share capital",
        "treasury shares", "weighted average outstanding shares"),
    "operating_cash_flow": ("net cash generated from operating activities",
        "net cash used in operating activities", "net cash flows from operating activities",
        "net cash flows from/(used in) operating activities",
        "net cash (used in)/generated from operating activities",
        "net cash used in/generated from operating activities"),
    "ending_cash": ("cash and cash equivalents at end of year",
        "cash and cash equivalents at end of financial year",
        "cash and cash equivalents at end of period", "cash and cash equivalents",
        "cash and bank balances at end of financial year",
        "cash and bank balances at the end of the financial year",
        "cash and bank balances at end of year", "cash and bank balances at end of period"),
    "investing_cash_flow": ("net cash flows used in investing activities",
        "net cash flows from/(used in) investing activities",
        "net cash used in investing activities", "net cash generated from investing activities",
        "net cash (used in)/generated from investing activities",
        "net cash used in/generated from investing activities"),
    "financing_cash_flow": ("net cash flows used in financing activities",
        "net cash used in financing activities", "net cash generated from financing activities",
        "net cash (used in)/generated from financing activities",
        "net cash used in/generated from financing activities"),
    "net_change_cash": ("net increase in cash and cash equivalents",
        "net decrease in cash and cash equivalents", "net change in cash and cash equivalents",
        "net increase/(decrease) in cash and cash equivalents",
        "net (increase)/decrease in cash and cash equivalents"),
    "depreciation_amortization": ("depreciation expense", "amortisation expense", "amortization expense",
        "depreciation of property, plant and equipment", "depreciation of property plant and equipment",
        "amortisation of intangible assets", "amortization of intangible assets",
        "depreciation and amortisation", "depreciation and amortization"),
    "depreciation_amortisation": ("depreciation expense", "amortisation expense", "amortization expense",
        "depreciation of property, plant and equipment", "depreciation of property plant and equipment",
        "amortisation of intangible assets", "amortization of intangible assets",
        "depreciation and amortisation", "depreciation and amortization"),
    "net_ppe": ("property, plant and equipment", "accumulated depreciation", "carrying amount"),
    "inventory": ("inventories", "inventory", "cost of inventories", "write-down"),
    "trade_receivables_net": ("trade receivables", "trade and other receivables", "loss allowance", "expected credit losses"),
    "long_term_debt": ("loans and borrowings", "borrowings", "bank loans", "lease liabilities", "non-current liabilities"),
    "retained_earnings": ("retained earnings", "accumulated losses", "accumulated deficit", "revenue reserve"),
}

_FINANCIAL_MAPPING_CACHE: Dict[str, Any] = {"loaded_at": 0.0, "rules": {}}
_FINANCIAL_MAPPING_CACHE_LOCK = threading.Lock()


def financial_mapping_registry() -> Dict[str, Dict[str, Any]]:
    """Load administrator-approved mappings; preserve Python rules as fallback."""
    now = time.monotonic()
    with _FINANCIAL_MAPPING_CACHE_LOCK:
        if now - float(_FINANCIAL_MAPPING_CACHE.get("loaded_at") or 0) < 300:
            return dict(_FINANCIAL_MAPPING_CACHE.get("rules") or {})
    rules: Dict[str, Dict[str, Any]] = {}
    try:
        with postgres_connection() as connection, connection.cursor() as cursor:
            cursor.execute("""
                SELECT concept_key, statement_type, aliases_json, component_concepts_json,
                       governed_formula, exclusions_json, validation_json, output_unit_rule,
                       rule_version
                  FROM financial_risk_intelligence.financial_concept_mapping_rules
                 WHERE active = TRUE
                 ORDER BY priority, concept_key
            """)
            for row in cursor.fetchall():
                def json_value(value, default):
                    if isinstance(value, (dict, list)):
                        return value
                    try:
                        return json.loads(text(value)) if text(value) else default
                    except Exception:
                        return default
                rules[text(row[0])] = {
                    "concept_key": text(row[0]), "statement_type": canonical_statement(row[1]),
                    "aliases": json_value(row[2], []),
                    "component_concepts": json_value(row[3], []),
                    "governed_formula": text(row[4]),
                    "exclusions": json_value(row[5], []),
                    "validation": json_value(row[6], {}),
                    "output_unit_rule": text(row[7]), "rule_version": text(row[8]),
                }
    except Exception as exc:
        print(f"FINANCIAL MAPPING REGISTRY FALLBACK: {type(exc).__name__}: {exc}", flush=True)
    with _FINANCIAL_MAPPING_CACHE_LOCK:
        _FINANCIAL_MAPPING_CACHE.update({"loaded_at": now, "rules": rules})
    return dict(rules)


def financial_mapping_rule(concept_key: Any) -> Dict[str, Any]:
    return financial_mapping_registry().get(text(concept_key).lower(), {})


def active_financial_validation_version(concept_key: Any) -> str:
    """Version a saved value by both governed mapping and parser semantics."""
    mapping_version = text(financial_mapping_rule(concept_key).get("rule_version")) or "UNVERSIONED"
    return f"{mapping_version}|{FINANCIAL_VALIDATION_ALGORITHM_VERSION}"


def concept_evidence_aliases(concept_key: Any) -> Tuple[str, ...]:
    key = text(concept_key).lower()
    configured = financial_mapping_rule(key).get("aliases") or []
    return tuple(dict.fromkeys(
        text(value).lower() for value in [*CONCEPT_EVIDENCE_ALIASES.get(key, ()), *configured]
        if text(value)
    ))


def configured_governed_formula(concept_key: Any, fallback: str) -> str:
    return text(financial_mapping_rule(concept_key).get("governed_formula")) or fallback


def managed_pdf_evidence_fallback(document_id: str, statement_type: str,
                                  concept_key: str, concept_label: str,
                                  max_fragments: int = 8,
                                  run_id: str = "") -> List[Dict[str, Any]]:
    """Read only the selected managed PDF when its fragment index is absent.

    This is intentionally a narrow recovery path: it never scans a report
    folder and it never mixes evidence from an older upload. The registered
    filename must exactly match the document selected in the webapp.
    """
    registration = registration_lookup().get(document_id, {})
    display_names = report_display_filename_lookup()
    # Historical run/document metadata outranks the live registration dataset:
    # the latter is recipe-owned and commonly contains only the newest upload.
    # Every candidate is still an exact filename binding, never a folder-order
    # guess. Reject UUID placeholders because they cannot identify a PDF.
    filename_candidates = [
        display_names.get("by_pair", {}).get((text(run_id), text(document_id))) if text(run_id) else "",
        display_names.get("by_document", {}).get(text(document_id)),
        display_names.get("by_run", {}).get(text(run_id)) if text(run_id) else "",
        registration.get("file_name"),
    ]
    expected_name = ""
    for candidate_name in filename_candidates:
        candidate_name = Path(text(candidate_name)).name
        if (candidate_name and candidate_name.lower().endswith(".pdf")
                and not re.fullmatch(r"[0-9a-f-]{32,36}(?:\.pdf)?", candidate_name, re.IGNORECASE)):
            expected_name = candidate_name
            break
    if not expected_name:
        return []
    cache_key = f"{document_id}|{expected_name.casefold()}"
    with SELECTED_PDF_TEXT_CACHE_LOCK:
        cached = dict(SELECTED_PDF_TEXT_CACHE.get(cache_key) or {})
    try:
        page_texts = cached.get("pages") or []
        evidence_source = text(cached.get("evidence_source"))
        pdf_bytes = b""
        # First choice: the exact currently selected PDF in the managed folder.
        # The filename comparison prevents an old report from being considered.
        if not page_texts:
            try:
                folder = dataiku.Folder(reports_folder_id())
                paths = [text(path) for path in folder.list_paths_in_partition() if text(path)]
                matched_path = next((path for path in paths if Path(path).name.casefold() == expected_name.casefold()), "")
                if matched_path:
                    with folder.get_download_stream(matched_path) as source:
                        pdf_bytes = source.read()
                    evidence_source = "SELECTED_MANAGED_PDF_FALLBACK"
            except Exception as folder_error:
                print(f"Managed PDF lookup unavailable for {document_id}: {type(folder_error).__name__}: {folder_error}")

        # Recovery for legacy/completed runs whose managed-folder upload was
        # cleared after analysis. Configure fsre_local_pdf_fallback_roots as a
        # semicolon-separated list in Dataiku; the project data folder is the
        # local-desktop default. Only the registered filename is opened.
        if not page_texts and not pdf_bytes:
            try:
                variables = dataiku.get_custom_variables()
            except Exception:
                variables = {}
            configured_roots = text(variables.get("fsre_local_pdf_fallback_roots"))
            roots = [Path(item.strip()) for item in re.split(r"[;\n|]+", configured_roots) if item.strip()]
            if not roots and os.name == "nt":
                roots = [Path(r"C:\Sciente_Harsh\Project_C\data")]
            for root in roots:
                if not root.is_dir():
                    continue
                direct = root / expected_name
                matches = [direct] if direct.is_file() else list(root.rglob(expected_name))
                matched_file = next((item for item in matches if item.is_file() and item.name.casefold() == expected_name.casefold()), None)
                if matched_file:
                    pdf_bytes = matched_file.read_bytes()
                    evidence_source = "SELECTED_LOCAL_PDF_FALLBACK"
                    break
        if not page_texts:
            if not pdf_bytes.startswith(b"%PDF"):
                return []
            reader_class = None
            for module_name in ("pypdf", "PyPDF2"):
                try:
                    reader_class = importlib.import_module(module_name).PdfReader
                    break
                except Exception:
                    continue
            if reader_class is None:
                return []
            reader = reader_class(io.BytesIO(pdf_bytes))
            page_texts = []
            for page_index, page in enumerate(reader.pages):
                try:
                    content = text(page.extract_text() or "")
                except Exception:
                    content = ""
                if content:
                    page_texts.append((page_index + 1, content))
            with SELECTED_PDF_TEXT_CACHE_LOCK:
                SELECTED_PDF_TEXT_CACHE[cache_key] = {
                    "pages": page_texts, "evidence_source": evidence_source,
                }
                while len(SELECTED_PDF_TEXT_CACHE) > MAX_SELECTED_PDF_TEXT_CACHE:
                    SELECTED_PDF_TEXT_CACHE.pop(next(iter(SELECTED_PDF_TEXT_CACHE)))
        aliases = list(concept_evidence_aliases(concept_key))
        aliases.extend(re.findall(r"[a-z]{4,}", text(concept_label).lower()))
        aliases = sorted({alias.lower() for alias in aliases if len(alias) >= 4})
        anchors = STATEMENT_EVIDENCE_ANCHORS.get(text(statement_type).upper(), ())
        share_target = text(concept_key).lower() == "shares_outstanding"
        referenced_share_notes = set()
        if share_target:
            for _, page_content in page_texts:
                normalized_page = re.sub(r"\s+", " ", text(page_content)).lower()
                for pattern in (
                    r"(?:share capital|issued shares|ordinary shares).*?\bnote\s+(\d{1,3})\b",
                    r"\bnote\s+(\d{1,3})\b.*?(?:share capital|issued shares|ordinary shares)",
                ):
                    referenced_share_notes.update(re.findall(pattern, normalized_page, re.I))
        candidates = []
        for page_number, content in page_texts:
            normalized = content.lower()
            alias_hits = [alias for alias in aliases if alias in normalized]
            anchor_hits = [anchor for anchor in anchors if anchor in normalized]
            inventory_absence_evidence = (
                text(concept_key).lower() == "inventory"
                and re.search(r"^total assets\b", normalized, re.MULTILINE)
                and re.search(r"^total current liabilities\b", normalized, re.MULTILINE)
                and not re.search(r"^(?:inventory|inventories)\b", normalized, re.MULTILINE)
            )
            if inventory_absence_evidence:
                # A confirmed primary balance sheet with no inventory line is
                # governed evidence of a zero balance for the model input. It
                # must outrank narrative pages that merely mention inventory.
                candidates.append((1000, page_number, content,
                                   sorted(set(anchor_hits + ["inventory omitted from primary statement"]))))
                continue
            if not alias_hits:
                continue
            score = len(alias_hits) * 12 + len(anchor_hits) * 5
            if share_target:
                has_share_count_context = bool(re.search(
                    r"(?:number|no\.|issued|allotted|treasury|at end|closing).*?ordinary shares|"
                    r"ordinary shares.*?(?:number|issued|allotted|treasury|at end|closing)",
                    normalized, re.I | re.S,
                ))
                has_share_numbers = bool(re.search(r"\b\d{1,3}(?:,\d{3}){2,}\b", content))
                if "share capital" in normalized and has_share_count_context and has_share_numbers:
                    score += 300
                if "treasury shares" in normalized and has_share_numbers:
                    score += 220
                if any(re.search(rf"(?:^|\n)\s*(?:note\s+)?{re.escape(note)}\b", normalized, re.I)
                       for note in referenced_share_notes):
                    score += 180
            candidates.append((score, page_number, content, sorted(set(alias_hits + anchor_hits))))
        candidates.sort(key=lambda item: (-item[0], item[1]))
        return [{"page_number": page, "statement_type": statement_type,
                 "matched_terms": terms, "content": content[:12000],
                 "evidence_source": evidence_source}
                for _, page, content, terms in candidates[:max_fragments]]
    except Exception as exc:
        print(f"Selected-PDF evidence fallback unavailable for {document_id}: {type(exc).__name__}: {exc}")
        return []


def hydrate_report_evidence(document_id: str, run_id: str = "") -> List[Dict[str, Any]]:
    """Persist every text-bearing page for one exactly identified uploaded PDF.

    Historical Dataiku recipe datasets rotate.  This durable webapp-owned
    cache lets old runs resolve statement facts without retaining the report
    in the current recipe output.  A PDF is opened only when its registered
    filename is an exact match; the reports folder is never processed in bulk.
    """
    document_id, run_id = text(document_id), text(run_id)
    if not document_id:
        return []
    display_names = report_display_filename_lookup()
    registration = registration_lookup().get(document_id, {})
    names = [
        display_names.get("by_pair", {}).get((run_id, document_id)) if run_id else "",
        display_names.get("by_document", {}).get(document_id),
        display_names.get("by_run", {}).get(run_id) if run_id else "",
        registration.get("file_name"),
    ]
    file_name = next((Path(text(name)).name for name in names
                      if text(name).lower().endswith(".pdf") and not re.fullmatch(
                          r"[0-9a-f-]{32,36}(?:\.pdf)?", Path(text(name)).name, re.IGNORECASE)), "")
    if not file_name:
        return []

    pdf_bytes, source_name = b"", ""
    try:
        folder = dataiku.Folder(reports_folder_id())
        match = next((path for path in folder.list_paths_in_partition()
                      if Path(text(path)).name.casefold() == file_name.casefold()), "")
        if match:
            with folder.get_download_stream(match) as stream:
                pdf_bytes = stream.read()
            source_name = "EXACT_MANAGED_PDF"
    except Exception as exc:
        print(f"Historical managed-PDF hydration unavailable for {document_id}: {type(exc).__name__}: {exc}", flush=True)

    if not pdf_bytes:
        try:
            variables = dataiku.get_custom_variables()
        except Exception:
            variables = {}
        configured = text(variables.get("fsre_local_pdf_fallback_roots"))
        roots = [Path(value.strip()) for value in re.split(r"[;\n|]+", configured) if value.strip()]
        if not roots and os.name == "nt":
            roots = [Path(r"C:\Sciente_Harsh\Project_C\data")]
        for root in roots:
            if not root.is_dir():
                continue
            direct = root / file_name
            matches = [direct] if direct.is_file() else list(root.rglob(file_name))
            exact = next((path for path in matches
                          if path.is_file() and path.name.casefold() == file_name.casefold()), None)
            if exact:
                pdf_bytes = exact.read_bytes()
                source_name = "EXACT_LOCAL_PDF"
                break
    if not pdf_bytes.startswith(b"%PDF"):
        return []

    reader_class = None
    for module_name in ("pypdf", "PyPDF2"):
        try:
            reader_class = importlib.import_module(module_name).PdfReader
            break
        except Exception:
            continue
    if reader_class is None:
        return []
    reader = reader_class(io.BytesIO(pdf_bytes))
    pages = []
    for page_index, page in enumerate(reader.pages):
        try:
            content = text(page.extract_text() or "").strip()
        except Exception:
            content = ""
        if content:
            pages.append({"source_document_id": document_id, "page_number": page_index + 1,
                          "content_text": content, "evidence_source": source_name})
    if not pages:
        return []

    try:
        with postgres_connection() as connection:
            with connection.cursor() as cursor:
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS financial_risk_intelligence.webapp_report_evidence (
                        source_document_id TEXT NOT NULL,
                        assessment_run_id TEXT NOT NULL DEFAULT '',
                        file_name TEXT NOT NULL,
                        page_number INTEGER NOT NULL,
                        content_text TEXT NOT NULL,
                        content_sha256 TEXT NOT NULL,
                        evidence_source TEXT NOT NULL,
                        extracted_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                        PRIMARY KEY (source_document_id, page_number)
                    )
                """)
                for page in pages:
                    content = page["content_text"]
                    cursor.execute("""
                        INSERT INTO financial_risk_intelligence.webapp_report_evidence
                            (source_document_id,assessment_run_id,file_name,page_number,content_text,
                             content_sha256,evidence_source,extracted_at)
                        VALUES (%s,%s,%s,%s,%s,%s,%s,NOW())
                        ON CONFLICT (source_document_id,page_number) DO UPDATE SET
                            assessment_run_id=EXCLUDED.assessment_run_id,
                            file_name=EXCLUDED.file_name,
                            content_text=EXCLUDED.content_text,
                            content_sha256=EXCLUDED.content_sha256,
                            evidence_source=EXCLUDED.evidence_source,
                            extracted_at=NOW()
                    """, (document_id, run_id, file_name, page["page_number"], content,
                          hashlib.sha256(content.encode("utf-8")).hexdigest(), source_name))
            connection.commit()
    except Exception as exc:
        # Evidence remains usable for this request even if persistence is not
        # available; never discard an exact-report extraction.
        print(f"Historical report evidence persistence unavailable for {document_id}: {type(exc).__name__}: {exc}", flush=True)
    return pages


def report_statement_evidence_digest(document_id: str, run_id: str = "") -> Dict[str, Dict[str, Any]]:
    """Build and cache one compact, page-linked packet per financial statement."""
    document_id, run_id = text(document_id), text(run_id)
    evidence_document_ids = run_scoped_evidence_document_ids(run_id, document_id)
    cached = {}
    try:
        with postgres_connection() as connection:
            with connection.cursor() as cursor:
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS financial_risk_intelligence.report_statement_evidence_digest (
                        source_document_id TEXT NOT NULL,
                        assessment_run_id TEXT NOT NULL DEFAULT '',
                        statement_type TEXT NOT NULL,
                        digest_text TEXT NOT NULL,
                        page_numbers_json JSONB NOT NULL DEFAULT '[]'::jsonb,
                        evidence_hash TEXT NOT NULL,
                        digest_version TEXT NOT NULL DEFAULT 'V1',
                        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                        updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                        PRIMARY KEY (source_document_id,statement_type)
                    );
                    ALTER TABLE financial_risk_intelligence.report_statement_evidence_digest
                        ADD COLUMN IF NOT EXISTS digest_version TEXT NOT NULL DEFAULT 'V1';
                """)
                cursor.execute("""
                    SELECT source_document_id,statement_type,digest_text,page_numbers_json,evidence_hash
                      FROM financial_risk_intelligence.report_statement_evidence_digest
                     WHERE source_document_id = ANY(%s)
                       AND digest_version = 'V2'
                     ORDER BY CASE WHEN source_document_id=%s THEN 0 ELSE 1 END, updated_at DESC
                """, (evidence_document_ids, document_id))
                for source_id, statement_type, digest_text, pages, evidence_hash in cursor.fetchall():
                    cached.setdefault(text(statement_type), {
                        "statement_type": text(statement_type), "content": text(digest_text),
                        "page_numbers": list(pages or []), "evidence_hash": text(evidence_hash),
                        "evidence_source": ("POSTGRES_STATEMENT_EVIDENCE_DIGEST"
                                            if text(source_id) == document_id else
                                            "POSTGRES_STATEMENT_EVIDENCE_DIGEST_LEGACY_BINDING"),
                    })
        if {"INCOME_STATEMENT", "BALANCE_SHEET", "CASH_FLOW_STATEMENT"}.issubset(cached):
            return cached
    except Exception:
        pass

    pages = []
    try:
        with postgres_connection() as connection:
            with connection.cursor() as cursor:
                for table_name in ("webapp_report_evidence", "report_evidence"):
                    try:
                        cursor.execute(f"""
                            SELECT source_document_id,page_number,content_text
                              FROM financial_risk_intelligence.{table_name}
                             WHERE source_document_id = ANY(%s) AND BTRIM(content_text)<>''
                             ORDER BY CASE WHEN source_document_id=%s THEN 0 ELSE 1 END,page_number
                        """, (evidence_document_ids, document_id))
                        pages.extend({"source_document_id": source_id, "page_number": page,
                                      "content_text": content,
                                      "evidence_source": ("POSTGRES_" + table_name.upper()
                                                          if source_id == document_id else
                                                          "POSTGRES_" + table_name.upper() + "_LEGACY_RUN_BINDING")}
                                     for source_id, page, content in cursor.fetchall())
                    except Exception:
                        connection.rollback()
    except Exception:
        pages = []
    if not pages:
        pages = hydrate_report_evidence(document_id, run_id)
    # Historical runs may predate durable page fragments but retain validated
    # Income Statement, Balance Sheet and Cash Flow table JSON. Convert those
    # exact report-bound tables to page-cited evidence for the digest.
    if not pages:
        for evidence_document_id in evidence_document_ids:
            for table in raw_validated_tables(evidence_document_id):
                statement_type = canonical_statement(table.get("statement_type"))
                if statement_type not in {"INCOME_STATEMENT", "BALANCE_SHEET", "CASH_FLOW_STATEMENT"}:
                    continue
                rendered_rows = []
                for table_row in table.get("rows") or []:
                    cells = sorted(table_row.get("cells") or [],
                                   key=lambda cell: integer(cell.get("column_index"), 0))
                    rendered = " | ".join(text(cell.get("raw_text")) for cell in cells
                                          if text(cell.get("raw_text")))
                    if rendered:
                        rendered_rows.append(rendered)
                if rendered_rows:
                    pages.append({
                        "source_document_id": evidence_document_id,
                        "page_number": integer(table.get("page_number"), 0),
                        "content_text": "\n".join(rendered_rows),
                        "evidence_source": "VALIDATED_TABLE_JSON_LEGACY_FALLBACK",
                        "forced_statement_type": statement_type,
                    })
    deduped_pages, seen_pages = [], set()
    for page in pages:
        key = (integer(page.get("page_number"), 0),
               hashlib.sha256(text(page.get("content_text")).encode("utf-8")).hexdigest())
        if key in seen_pages:
            continue
        seen_pages.add(key)
        deduped_pages.append(page)

    statement_rows = collections.defaultdict(list)
    statement_pages = collections.defaultdict(set)
    for page in deduped_pages:
        page_number = integer(page.get("page_number"), 0)
        content = text(page.get("content_text"))
        normalized_page = content.lower()
        forced_statement_type = canonical_statement(page.get("forced_statement_type"))
        scores = {statement: sum(1 for anchor in anchors if anchor in normalized_page)
                  for statement, anchors in STATEMENT_EVIDENCE_ANCHORS.items()}
        if forced_statement_type:
            eligible_statements = [forced_statement_type]
        else:
            explicit_titles = {
                "BALANCE_SHEET": bool(re.search(r"\b(?:statement of financial position|balance sheet)\b", normalized_page)),
                "INCOME_STATEMENT": bool(re.search(r"\b(?:statement of comprehensive income|income statement|statement of profit or loss)\b", normalized_page)),
                "CASH_FLOW_STATEMENT": bool(re.search(r"\b(?:statement of cash flows|cash flow statement)\b", normalized_page)),
            }
            eligible_statements = [statement for statement, present in explicit_titles.items() if present]
            if not eligible_statements:
                best_statement, best_score = (max(scores.items(), key=lambda item: item[1])
                                              if scores else ("", 0))
                eligible_statements = [best_statement] if best_score > 0 else []
        if not eligible_statements:
            continue
        for raw_line in content.splitlines():
            line = re.sub(r"\s+", " ", text(raw_line)).strip()
            lower = line.lower()
            if len(line) < 5 or len(line) > 500 or not re.search(r"[a-zA-Z]", line):
                continue
            numeric_tokens = re.findall(r"(?<![A-Za-z])\(?-?\d[\d,]*(?:\.\d+)?\)?", line)
            if not numeric_tokens:
                continue
            if re.match(r"^(?:group\s+)?note\b", lower) or re.match(r"^(?:page|annual report)\s+\d+\b", lower):
                continue
            rendered = f"[page {page_number}] {line}"
            for statement_type in eligible_statements:
                if rendered not in statement_rows[statement_type]:
                    statement_rows[statement_type].append(rendered)
                    statement_pages[statement_type].add(page_number)

    digests = {}
    for statement_type, rows in statement_rows.items():
        # Retain statement order. The cap prevents repeated note disclosures
        # from consuming the model's context while preserving primary rows.
        content = "\n".join(rows[:180])[:14000]
        if not content:
            continue
        evidence_hash = hashlib.sha256(content.encode("utf-8")).hexdigest()
        digests[statement_type] = {
            "statement_type": statement_type, "content": content,
            "page_numbers": sorted(statement_pages[statement_type]),
            "evidence_hash": evidence_hash, "evidence_source": "PYTHON_STATEMENT_DIGEST",
        }
    if digests:
        try:
            with postgres_connection() as connection:
                with connection.cursor() as cursor:
                    cursor.execute("""
                        CREATE TABLE IF NOT EXISTS financial_risk_intelligence.report_statement_evidence_digest (
                            source_document_id TEXT NOT NULL,
                            assessment_run_id TEXT NOT NULL DEFAULT '',
                            statement_type TEXT NOT NULL,
                            digest_text TEXT NOT NULL,
                            page_numbers_json JSONB NOT NULL DEFAULT '[]'::jsonb,
                            evidence_hash TEXT NOT NULL,
                            digest_version TEXT NOT NULL DEFAULT 'V2',
                            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                            PRIMARY KEY (source_document_id,statement_type)
                        )
                    """)
                    cursor.execute("""ALTER TABLE financial_risk_intelligence.report_statement_evidence_digest
                                      ADD COLUMN IF NOT EXISTS digest_version TEXT NOT NULL DEFAULT 'V1'""")
                    for statement_type, digest in digests.items():
                        cursor.execute("""
                            INSERT INTO financial_risk_intelligence.report_statement_evidence_digest
                                (source_document_id,assessment_run_id,statement_type,digest_text,
                                 page_numbers_json,evidence_hash,digest_version,created_at,updated_at)
                            VALUES (%s,%s,%s,%s,%s::jsonb,%s,'V2',NOW(),NOW())
                            ON CONFLICT (source_document_id,statement_type) DO UPDATE SET
                                assessment_run_id=EXCLUDED.assessment_run_id,
                                digest_text=EXCLUDED.digest_text,
                                page_numbers_json=EXCLUDED.page_numbers_json,
                                evidence_hash=EXCLUDED.evidence_hash,
                                digest_version='V2',
                                updated_at=NOW()
                        """, (document_id, run_id, statement_type, digest["content"],
                              json.dumps(digest["page_numbers"]), digest["evidence_hash"]))
                connection.commit()
        except Exception as exc:
            print(f"STATEMENT DIGEST PERSISTENCE WARNING: {type(exc).__name__}: {exc}", flush=True)
    return {**cached, **digests}


def targeted_validated_table_evidence(document_id: str, statement_type: str,
                                        concept_key: str, concept_label: str,
                                        limit: int = 4) -> List[Dict[str, Any]]:
    """Catalog all validated tables and return only target-relevant tables."""
    frame = read_optional(TABLE_JSON_DATASET)
    if frame.empty or "table_json" not in frame.columns:
        frame = pd.DataFrame()
    elif "source_document_id" in frame.columns:
        frame = frame[frame["source_document_id"].fillna("").astype(str).eq(document_id)]
    aliases = set(concept_evidence_aliases(concept_key))
    aliases.update(token for token in re.findall(r"[a-z]{4,}", text(concept_label).lower())
                   if token not in {"total", "current", "prior", "financial", "statement"})
    requested_statement = canonical_statement(statement_type)
    catalog_rows = []
    all_catalog_rows = []
    for source_row in frame.to_dict(orient="records"):
        if text(source_row.get("validation_status")).upper() not in {"", "VALID"}:
            continue
        try:
            document = json.loads(text(source_row.get("table_json")))
        except (json.JSONDecodeError, TypeError):
            continue
        table = document.get("table") or {}
        source = document.get("source") or {}
        identity = document.get("identity") or {}
        rendered_rows = []
        for table_row in table.get("rows") or []:
            cells = sorted(table_row.get("cells") or [],
                           key=lambda cell: integer(cell.get("column_index"), 0))
            rendered = " | ".join(text(cell.get("raw_text")) for cell in cells
                                  if text(cell.get("raw_text")))
            if rendered:
                rendered_rows.append(rendered)
        if not rendered_rows:
            continue
        title = text(table.get("title") or source_row.get("table_title"))
        table_statement = canonical_statement(
            table.get("statement_type") or source_row.get("statement_type")
        )
        content = "\n".join(rendered_rows)[:18000]
        normalized = (title + "\n" + content).lower()
        hits = sorted(alias for alias in aliases if alias and alias in normalized)
        numeric_rows = sum(1 for row in rendered_rows
                           if re.search(r"(?<![A-Za-z])\(?-?\d[\d,]*(?:\.\d+)?\)?", row))
        score = len(hits) * 30 + min(numeric_rows, 20)
        if table_statement == requested_statement:
            score += 15
        if text(concept_key) == "shares_outstanding":
            if re.search(r"(?:number|no\.) of (?:issued|ordinary|treasury) shares|shares in issue", normalized):
                score += 80
            if "weighted average" in normalized and not re.search(
                    r"treasury shares|shares in issue|issued ordinary shares", normalized):
                score -= 60
        catalog_item = {
            "source_document_id": document_id,
            "table_artifact_id": (text(identity.get("table_artifact_id")
                                       or source_row.get("table_artifact_id"))
                                  or hashlib.sha256(
                                      f"{document_id}|{source.get('page_number')}|{title}|{content}".encode("utf-8")
                                  ).hexdigest()),
            "page_number": integer(source.get("page_number")
                                   or source_row.get("page_number"), 0),
            "statement_type": table_statement,
            "table_title": title,
            "content_text": content,
            "evidence_source": "VALIDATED_ALL_TABLE_CATALOG",
            "matched_terms": hits,
            "relevance_score": score,
        }
        all_catalog_rows.append(catalog_item)
        if hits or score >= 50:
            catalog_rows.append(catalog_item)
    # Persist every parsed table, not merely the selected evidence, so older
    # reports remain resolvable after recipe-owned datasets rotate.
    try:
        with postgres_connection() as connection:
            with connection.cursor() as cursor:
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS financial_risk_intelligence.report_table_evidence_catalog (
                        source_document_id TEXT NOT NULL,
                        table_artifact_id TEXT NOT NULL,
                        page_number INTEGER NOT NULL DEFAULT 0,
                        statement_type TEXT,
                        table_title TEXT,
                        content_text TEXT NOT NULL,
                        updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                        PRIMARY KEY (source_document_id,table_artifact_id)
                    )
                """)
                for item in all_catalog_rows:
                    cursor.execute("""
                        INSERT INTO financial_risk_intelligence.report_table_evidence_catalog
                            (source_document_id,table_artifact_id,page_number,statement_type,
                             table_title,content_text,updated_at)
                        VALUES (%s,%s,%s,%s,%s,%s,NOW())
                        ON CONFLICT (source_document_id,table_artifact_id) DO UPDATE SET
                            page_number=EXCLUDED.page_number,
                            statement_type=EXCLUDED.statement_type,
                            table_title=EXCLUDED.table_title,
                            content_text=EXCLUDED.content_text,
                            updated_at=NOW()
                    """, (item["source_document_id"], item["table_artifact_id"],
                          item["page_number"], item["statement_type"],
                          item["table_title"], item["content_text"]))
            connection.commit()
    except Exception as exc:
        print(f"TABLE EVIDENCE CATALOG WARNING: {type(exc).__name__}: {exc}", flush=True)
    if not catalog_rows:
        try:
            with postgres_connection() as connection:
                with connection.cursor() as cursor:
                    cursor.execute("""
                        SELECT table_artifact_id,page_number,statement_type,table_title,content_text
                          FROM financial_risk_intelligence.report_table_evidence_catalog
                         WHERE source_document_id = %s
                    """, (document_id,))
                    for table_id, page_number, table_statement, title, content in cursor.fetchall():
                        normalized = (text(title) + "\n" + text(content)).lower()
                        hits = sorted(alias for alias in aliases if alias and alias in normalized)
                        score = len(hits) * 30
                        if canonical_statement(table_statement) == requested_statement:
                            score += 15
                        if not hits:
                            continue
                        catalog_rows.append({
                            "source_document_id": document_id,
                            "table_artifact_id": text(table_id),
                            "page_number": integer(page_number, 0),
                            "statement_type": canonical_statement(table_statement),
                            "table_title": text(title), "content_text": text(content),
                            "evidence_source": "POSTGRES_ALL_TABLE_CATALOG",
                            "matched_terms": hits, "relevance_score": score,
                        })
        except Exception:
            pass
    catalog_rows.sort(key=lambda item: (-item["relevance_score"], item["page_number"]))
    return catalog_rows[:max(1, min(integer(limit, 4), 8))]


def statement_resolution_evidence(document_id: str, statement_type: str, concept_key: str,
                                  concept_label: str, settings: Dict[str, Any],
                                  run_id: str = "") -> List[Dict[str, Any]]:
    """Return only pages relevant to the target statement and missing concept."""
    # Persisted upload evidence is the durable source. The Dataiku fragments
    # dataset is refreshed by recipes and may no longer contain an older report
    # selected from analysis history. Merge both sources, scoped strictly to the
    # selected source_document_id, before reopening the exact registered PDF.
    fragment_rows: List[Dict[str, Any]] = []
    evidence_document_ids = run_scoped_evidence_document_ids(run_id, document_id)
    try:
        with postgres_connection() as connection:
            with connection.cursor() as cursor:
                for evidence_document_id in evidence_document_ids:
                    cursor.execute("""
                        SELECT page_number, content_text
                          FROM financial_risk_intelligence.report_evidence
                         WHERE source_document_id = %s
                           AND content_text IS NOT NULL
                           AND BTRIM(content_text) <> ''
                         ORDER BY page_number
                    """, (evidence_document_id,))
                    fragment_rows.extend({
                        "source_document_id": evidence_document_id,
                        "page_number": page_number,
                        "content_text": content,
                        "evidence_source": ("POSTGRES_REPORT_EVIDENCE" if evidence_document_id == document_id
                                            else "POSTGRES_REPORT_EVIDENCE_LEGACY_RUN_BINDING"),
                    } for page_number, content in cursor.fetchall())
    except Exception as exc:
        print(f"Persisted statement evidence unavailable for {document_id}: "
              f"{type(exc).__name__}: {exc}", flush=True)

    # Webapp-owned durable evidence survives recipe dataset rotation and is
    # populated automatically from the exact selected PDF for historical runs.
    try:
        with postgres_connection() as connection:
            with connection.cursor() as cursor:
                cursor.execute("""
                    SELECT source_document_id,page_number,content_text,evidence_source
                      FROM financial_risk_intelligence.webapp_report_evidence
                     WHERE source_document_id = ANY(%s)
                       AND BTRIM(content_text) <> ''
                     ORDER BY page_number
                """, (evidence_document_ids,))
                fragment_rows.extend({"source_document_id": source_id, "page_number": page_number,
                                      "content_text": content, "evidence_source": source}
                                     for source_id, page_number, content, source in cursor.fetchall())
    except Exception:
        # The table is created lazily during the first historical hydration.
        pass

    dataset_fragments = read_optional(DOCUMENT_FRAGMENTS_DATASET)
    if not dataset_fragments.empty:
        for row in dataset_fragments.to_dict(orient="records"):
            if text(row.get("source_document_id")) not in evidence_document_ids or not text(row.get("content_text")):
                continue
            fragment_rows.append({**row, "evidence_source": text(row.get("evidence_source"))
                                  or DOCUMENT_FRAGMENTS_DATASET})

    # Search every validated table—including supporting note tables—and add
    # only the best target-bearing tables to this concept's evidence packet.
    for evidence_document_id in evidence_document_ids:
        fragment_rows.extend(targeted_validated_table_evidence(
            evidence_document_id, statement_type, concept_key, concept_label, limit=4
        ))

    deduplicated_rows, seen_fragment_keys = [], set()
    for row in fragment_rows:
        fragment_key = (integer(row.get("page_number"), 0), text(row.get("content_text")).strip())
        if not fragment_key[1] or fragment_key in seen_fragment_keys:
            continue
        seen_fragment_keys.add(fragment_key)
        deduplicated_rows.append(row)
    fragment_rows = deduplicated_rows

    if not fragment_rows:
        fragment_rows.extend(hydrate_report_evidence(document_id, run_id))

    # A historical report can have validated table JSON even when its page
    # fragment recipe predates durable report_evidence. Convert only that
    # report's validated statement tables into compact, page-cited evidence.
    if not fragment_rows:
        requested_statement = canonical_statement(statement_type)
        for evidence_document_id in evidence_document_ids:
            for table in raw_validated_tables(evidence_document_id):
                table_statement = canonical_statement(table.get("statement_type"))
                if table_statement != requested_statement and not (
                        text(concept_key) == "shares_outstanding"
                        and text(table.get("recognition_status")) == "SUPPORTING_SHARE_NOTE"):
                    continue
                rendered_rows = []
                for table_row in table.get("rows") or []:
                    cells = sorted(table_row.get("cells") or [],
                                   key=lambda cell: integer(cell.get("column_index"), 0))
                    rendered = " | ".join(text(cell.get("raw_text")) for cell in cells
                                          if text(cell.get("raw_text")))
                    if rendered:
                        rendered_rows.append(rendered)
                if rendered_rows:
                    fragment_rows.append({
                        "source_document_id": evidence_document_id,
                        "page_number": integer(table.get("page_number"), 0),
                        "content_text": "\n".join(rendered_rows)[:16000],
                        "evidence_source": "VALIDATED_TABLE_JSON_LEGACY_FALLBACK",
                    })

    if not fragment_rows:
        return managed_pdf_evidence_fallback(
            document_id, statement_type, concept_key, concept_label,
            integer(settings.get("max_fragments"), 8), run_id=run_id,
        )
    anchors = STATEMENT_EVIDENCE_ANCHORS.get(text(statement_type).upper(), ())
    concept_phrase = text(concept_label).lower().strip()
    concept_tokens = {token for token in re.findall(r"[a-z]{3,}",
        (text(concept_key) + " " + concept_phrase).lower())
        if token not in {"total", "current", "value", "financial", "statement", "income", "cash", "flow"}}
    aliases = concept_evidence_aliases(concept_key)
    if not aliases and "depreciation" in text(concept_key).lower():
        aliases = concept_evidence_aliases("depreciation_amortization")
    candidates = []
    for row in fragment_rows:
        content = text(row.get("content_text"))
        if not content:
            continue
        normalized = content.lower()
        anchor_hits = [anchor for anchor in anchors if anchor in normalized]
        token_hits = sorted(token for token in concept_tokens if token in normalized)
        alias_hits = sorted(alias for alias in aliases if alias in normalized)
        exact_hit = bool(concept_phrase and len(concept_phrase) >= 4 and concept_phrase in normalized)
        numeric_count = len(re.findall(r"(?<![A-Za-z])\(?\d[\d,]*(?:\.\d+)?\)?", content))
        target_hit = bool(token_hits or alias_hits or exact_hit)
        score = len(anchor_hits) * 5 + len(token_hits) * 10 + len(alias_hits) * 12 + (20 if exact_hit else 0)
        if target_hit:
            score += min(numeric_count, 20)
        if target_hit and ("notes to the financial statements" in normalized or re.search(r"\bnote\s+\d+", normalized)):
            score += 10
        if target_hit and any(marker in normalized for marker in ("carrying amount", "at beginning of year",
                "at end of year", "charge for the year", "accumulated depreciation", "movement")):
            score += 15
        if any(marker in normalized for marker in ("corporate governance report", "directors' statement",
                "directors’ statement", "auditors’ responsibilities", "auditors' responsibilities")):
            score -= 50
        if score > 0:
            candidates.append((score, integer(row.get("page_number"), 0), content,
                               sorted(set(anchor_hits + token_hits + alias_hits)), target_hit, numeric_count,
                               text(row.get("evidence_source"))))
    candidates.sort(key=lambda item: (not item[4], -item[0], -item[5], item[1]))
    selected, seen_pages = [], set()
    max_fragments = max(8, min(14, settings["max_fragments"] + 4))
    rows_by_page = {integer(row.get("page_number"), 0): row
                    for row in fragment_rows}
    for score, page, content, hits, target_hit, numeric_count, evidence_source in candidates:
        if page in seen_pages:
            continue
        seen_pages.add(page)
        selected.append({"page_number": page, "statement_type": statement_type,
                         "matched_terms": hits, "relevance_score": score,
                         "contains_target_terms": target_hit, "numeric_token_count": numeric_count,
                         "evidence_source": evidence_source,
                         "content": content[:settings["max_fragment_characters"]]})
        # Financial note tables often continue onto the next page without repeating the note heading.
        if target_hit:
            for adjacent_page in (page - 1, page + 1):
                adjacent_row = rows_by_page.get(adjacent_page, {})
                adjacent_content = text(adjacent_row.get("content_text"))
                if adjacent_content and adjacent_page not in seen_pages and len(selected) < max_fragments:
                    seen_pages.add(adjacent_page)
                    selected.append({"page_number": adjacent_page, "statement_type": statement_type,
                        "matched_terms": ["adjacent continuation page"], "relevance_score": score - 1,
                        "contains_target_terms": False,
                        "numeric_token_count": len(re.findall(r"(?<![A-Za-z])\(?\d[\d,]*(?:\.\d+)?\)?", adjacent_content)),
                        "evidence_source": text(adjacent_row.get("evidence_source")),
                        "content": adjacent_content[:settings["max_fragment_characters"]]})
        if len(selected) >= max_fragments:
            break
    return selected or managed_pdf_evidence_fallback(
        document_id, statement_type, concept_key, concept_label,
        integer(settings.get("max_fragments"), 8), run_id=run_id,
    )


def compact_statement_resolution_evidence(evidence: List[Dict[str, Any]], concept_key: str,
                                          concept_label: str, limit: int = 6) -> List[Dict[str, Any]]:
    """Reduce long report pages to target-bearing numeric lines for small local models."""
    aliases = list(concept_evidence_aliases(concept_key))
    aliases.extend(re.findall(r"[a-z]{4,}", text(concept_label).lower()))
    aliases = sorted(set(aliases))
    compact = []
    for item in evidence:
        lines = [line.strip() for line in text(item.get("content")).splitlines() if line.strip()]
        selected_lines, best_line_score = [], 0
        for index, line in enumerate(lines):
            normalized = line.lower()
            alias_hits = sum(1 for alias in aliases if alias in normalized)
            large_numbers = len(re.findall(r"\(?\d{1,3}(?:,\d{3})+(?:\.\d+)?\)?", line))
            score = alias_hits * 10 + large_numbers * 8 + (25 if alias_hits and large_numbers else 0)
            if score <= 0:
                continue
            best_line_score = max(best_line_score, score)
            for nearby in lines[max(0, index - 1):min(len(lines), index + 2)]:
                if nearby not in selected_lines:
                    selected_lines.append(nearby)
        if not selected_lines:
            selected_lines = lines[:8]
        compact.append({"page_number": item.get("page_number"),
                        "statement_type": item.get("statement_type"),
                        "matched_terms": item.get("matched_terms", []),
                        "evidence_source": item.get("evidence_source"),
                        "numeric_evidence_score": best_line_score,
                        "content": "\n".join(selected_lines)[:1400]})
    compact.sort(key=lambda item: (-item["numeric_evidence_score"], integer(item.get("page_number"), 0)))
    return compact[:max(1, limit)]


def build_resolution_candidate_table(evidence: List[Dict[str, Any]], concept_key: str,
                                     concept_label: str = "") -> List[Dict[str, Any]]:
    """Turn target-bearing statement lines into explicit current/prior table rows."""
    aliases = concept_evidence_aliases(concept_key)
    if "depreciation" in text(concept_key).lower() or "amort" in text(concept_key).lower():
        aliases = ("depreciation", "amortisation", "amortization")
    if not aliases:
        aliases = tuple(token for token in re.findall(r"[a-z]{4,}", text(concept_label).lower())
                        if token not in {"total", "current", "prior", "income"})
    # Headings, note captions and subtotal rows must never be used as a
    # financial input. These concepts have unambiguous audited line labels.
    strict_lines = {
        "operating_income_ebit": ("operating income", "operating loss", "operating profit",
                                    "profit from operations", "loss from operations",
                                    "income from operations", "results from operating activities"),
        "revenue": ("net sales", "net revenue", "revenue", "operating revenue", "gross revenue",
                    "turnover", "revenue from contracts with customers",
                    "revenue from contracts with customers and other sources"),
        "cost_of_goods_sold": ("cost of sales", "cost of revenue", "cost of goods sold"),
        "sg_and_a_expense": ("general, administrative and selling expenses",
                              "selling, general and administrative expenses",
                              "general and administrative expenses", "administrative expenses",
                              "selling and distribution expenses", "selling expenses",
                              "marketing and distribution expenses", "marketing expenses",
                              "distribution costs"),
        "depreciation_amortization": ("depreciation", "depreciation for right-of-use asset",
                                        "amortization", "amortisation",
                                        "depreciation and amortization", "depreciation and amortisation"),
        "interest_expense": ("financial expense", "financial expenses", "finance expense",
                              "finance expenses", "finance costs", "finance cost",
                              "interest cost", "interest costs", "interest expense", "interest expenses"),
        "total_current_assets": ("total current assets",),
        "total_assets": ("total assets",),
        "total_current_liabilities": ("total current liabilities",),
        "total_liabilities": ("total liabilities",),
        "total_shareholders_equity": ("total equity", "total shareholders' equity", "total stockholders' equity",
                                       "equity attributable to owners"),
        "net_profit": ("loss for the year, attributable to owners", "profit for the year, attributable to owners",
                       "loss for the year", "profit for the year", "loss for the period", "profit for the period",
                       "loss for the year/period", "profit for the year/period", "net profit", "net income"),
        "trade_receivables_net": ("trade and other receivables", "trade receivables"),
        "inventory": ("inventory", "inventories"),
        "net_ppe": ("property, plant, and equipment, net", "property, plant and equipment, net",
                    "property plant and equipment, net", "property, plant and equipment",
                    "plant and equipment", "right-of-use assets", "right of use assets"),
        "long_term_debt": ("long-term financial debt", "long term financial debt",
                            "long-term debt", "long term debt", "loans and borrowings",
                            "borrowings", "bank loans",
                            "lease liabilities"),
        "retained_earnings": ("retained earnings", "accumulated losses", "accumulated deficit"),
        "operating_cash_flow": ("net cash generated from operating activities",
                                 "net cash used in operating activities",
                                 "net cash flows from operating activities",
                                 "net cash flows from/(used in) operating activities",
                                 "net cash (used in)/generated from operating activities",
                                 "net cash used in/generated from operating activities"),
        "investing_cash_flow": ("net cash flows used in investing activities",
                                 "net cash flows from/(used in) investing activities",
                                 "net cash used in investing activities",
                                 "net cash generated from investing activities",
                                 "net cash (used in)/generated from investing activities",
                                 "net cash used in/generated from investing activities"),
        "financing_cash_flow": ("net cash flows used in financing activities",
                                 "net cash used in financing activities",
                                 "net cash generated from financing activities",
                                 "net cash (used in)/generated from financing activities",
                                 "net cash used in/generated from financing activities"),
        "net_change_cash": ("net increase in cash and cash equivalents",
                             "net decrease in cash and cash equivalents",
                             "net change in cash and cash equivalents",
                             "net increase/(decrease) in cash and cash equivalents",
                             "net (increase)/decrease in cash and cash equivalents"),
        "ending_cash": ("cash and cash equivalents at the end of the year",
                         "cash and cash equivalents at end of the year",
                         "cash and cash equivalents at end of financial year",
                         "cash and cash equivalents at end of period",
                         "cash and bank balances at the end of the financial year",
                         "cash and bank balances at end of the financial year",
                         "cash and bank balances at end of financial year",
                         "cash and bank balances at end of the year",
                         "cash and bank balances at end of period"),
        "shares_outstanding": ("excluding treasury shares", "number of issued shares excluding treasury shares",
                               "number of issued ordinary shares", "number of ordinary shares",
                               "net number of issued shares",
                               "ordinary shares in issue", "shares in issue", "issued and fully paid shares",
                               "issued and fully paid ordinary shares", "weighted average outstanding shares"),
    }
    # Do not treat a PDF table's column separator as a thousands separator.
    # For example, "Note 4 | 158,797 | 190,835" used to be tokenised as
    # 4,158 and 797,190. Comma-grouped values are unambiguous; plain long
    # integers remain supported for reports that omit separators.
    amount_pattern = re.compile(r"\(?-?\d{1,3}(?:[,]\d{3})+(?:\.\d+)?\)?|\(?-?\d{4,}(?:\.\d+)?\)?|\(?-?\d{1,3}(?:\.\d+)?\)?")

    def parsed_amounts(value):
        parsed = []
        for raw in amount_pattern.findall(value):
            cleaned = raw.strip("()").replace(",", "")
            try:
                numeric = float(cleaned)
            except ValueError:
                continue
            # Bare four-digit year headings are periods, not statement values.
            if "," not in raw and 1900 <= abs(numeric) <= 2100:
                continue
            if raw.startswith("(") and raw.endswith(")"):
                numeric = -abs(numeric)
            parsed.append(numeric)
        return parsed

    candidates, seen = [], set()
    # A cash-flow reconciliation frequently discloses depreciation and
    # amortisation as separate two-period rows.  When both are explicitly
    # present on the same statement page, their sum is the governed D&A input
    # required by the scoring models.  Keep the component evidence alongside
    # the derived candidate; never estimate a missing component.
    da_components: Dict[int, Dict[str, Dict[str, Any]]] = collections.defaultdict(dict)
    sga_components: Dict[int, Dict[str, Dict[str, Any]]] = collections.defaultdict(dict)
    debt_components: Dict[int, Dict[str, Dict[str, Any]]] = collections.defaultdict(dict)
    receivable_components: Dict[int, Dict[str, Dict[str, Any]]] = collections.defaultdict(dict)
    receivable_net_components: Dict[int, Dict[str, Dict[str, Any]]] = collections.defaultdict(dict)
    ebit_components: Dict[int, Dict[str, Dict[str, Any]]] = collections.defaultdict(dict)
    ppe_components: Dict[int, Dict[str, Dict[str, Any]]] = collections.defaultdict(dict)
    issued_share_candidates: List[Dict[str, Any]] = []
    treasury_share_candidates: List[Dict[str, Any]] = []
    for item in evidence:
        lines = [line.strip() for line in text(item.get("content")).splitlines() if line.strip()]
        page_context = "\n".join(lines).lower()
        if text(concept_key) == "shares_outstanding":
            disclosed_net = re.search(
                r"excluding treasury shares\s+comprised\s+([\d,]+)\s+ordinary shares\s+"
                r"\(20\d{2}:\s*([\d,]+)\s+ordinary shares\)",
                page_context, re.IGNORECASE | re.DOTALL,
            )
            if disclosed_net:
                candidates.append({
                    "candidate_id": "SN" + str(len(candidates) + 1),
                    "page_number": item.get("page_number"),
                    "description": "Issued ordinary shares excluding treasury shares",
                    "current_value": parsed_amounts(disclosed_net.group(1))[0],
                    "prior_value": parsed_amounts(disclosed_net.group(2))[0],
                    "source_line": re.sub(r"\s+", " ", disclosed_net.group(0)).strip(),
                    "derivation_method": "ISSUED_LESS_TREASURY_SHARES",
                })
        share_movement_table = (
            text(concept_key) == "shares_outstanding"
            and any(marker in page_context for marker in (
                "share capital", "issued ordinary shares", "number of ordinary shares",
                "no. of ordinary shares", "ordinary shares in issue", "shares in issue"
            ))
        )
        for index, line in enumerate(lines):
            # Shared digest rows carry a page prefix for auditability. It is
            # metadata, not a note/value column and must not obstruct exact
            # financial-statement label matching.
            normalized = re.sub(r"^\[page\s+\d+\]\s*", "", line.lower()).strip()
            preceding_context_for_section = "\n".join(lines[:index]).lower()
            last_share_capital = preceding_context_for_section.rfind("share capital")
            last_treasury_shares = preceding_context_for_section.rfind("treasury shares")
            inside_treasury_section = last_treasury_shares > last_share_capital
            ending_share_label = bool(re.match(
                r"^(?:(?:at )?end of (?:the )?(?:financial )?(?:year|period)"
                r"|(?:at|balance at)\s+\d{1,2}\s+[a-z]+(?:\s+20\d{2})?"
                r"|(?:as at|balance as at)\s+\d{1,2}\s+[a-z]+(?:\s+20\d{2})?"
                r"|at\s+\d{1,2}\s+[a-z]+(?:\s+20\d{2})?\s+and\s+\d{1,2}\s+[a-z]+(?:\s+20\d{2})?"
                r"|(?:closing|ending) balance\b)\b",
                normalized,
            ))
            share_ending_row = bool(
                share_movement_table and ending_share_label and not inside_treasury_section
            )
            treasury_ending_row = bool(
                text(concept_key) == "shares_outstanding"
                and "treasury shares" in page_context
                and inside_treasury_section
                and (ending_share_label or re.match(
                    r"^at (?:the )?beginning and end(?:\s+of)?\b", normalized
                ))
            )
            share_excluding_treasury_row = bool(
                text(concept_key) == "shares_outstanding"
                and "excluding treasury shares" in normalized
                and "ordinary shares" in normalized
            )
            direct_share_count_row = bool(
                text(concept_key) == "shares_outstanding"
                and "weighted average" not in normalized
                and any(marker in normalized for marker in (
                    "number of issued ordinary shares", "number of ordinary shares",
                    "no. of ordinary shares", "net number of issued shares",
                    "ordinary shares in issue", "shares in issue",
                    "issued and fully paid ordinary shares", "issued and fully paid shares"
                ))
                and not re.search(r"(?:amount|value)\s+(?:of\s+)?share capital", normalized)
            )
            receivable_allowance_row = bool(
                text(concept_key) == "trade_receivables_net"
                and re.match(r"^less:\s*allowance for expected credit losses\b", normalized)
            )
            if aliases and not any(alias in normalized for alias in aliases) and not share_ending_row and not treasury_ending_row and not share_excluding_treasury_row and not direct_share_count_row and not receivable_allowance_row:
                continue
            required_lines = strict_lines.get(text(concept_key))
            if required_lines and not any(
                re.match(r"^\s*(?:note\s+\d+\s+)?" + re.escape(required) + r"\b", normalized)
                for required in required_lines
            ) and not share_ending_row and not treasury_ending_row and not share_excluding_treasury_row and not direct_share_count_row and not receivable_allowance_row:
                # EBIT is frequently not printed as a separate subtotal. Its
                # auditable components may instead be profit/loss before tax,
                # finance costs and finance income on the primary statement.
                if not (text(concept_key) == "operating_income_ebit" and re.match(
                    r"^(?:profit(?:/\(loss\))?|loss(?:/\(profit\))?) before (?:income )?tax\b"
                    r"|^(?:net )?finance (?:costs?|expenses?)\b|^(?:finance|interest) income\b",
                    normalized,
                )):
                    continue
            if text(concept_key) == "total_current_assets" and re.search(r"non[ -]?current assets", normalized):
                continue
            if text(concept_key) == "total_current_liabilities" and re.search(r"non[ -]?current liabilities", normalized):
                continue
            preceding_context = "\n".join(lines[:index]).lower()
            if text(concept_key) == "long_term_debt":
                last_non_current = preceding_context.rfind("non-current liabilities")
                current_only = re.sub(r"non-current liabilit(?:y|ies)", "", preceding_context)
                last_current = max(current_only.rfind("current liabilities"), current_only.rfind("current liability"))
                # Do not confuse current borrowings with the long-term debt
                # field when both carry the same label on a balance sheet.
                if last_non_current < last_current:
                    continue
            receivable_section = ""
            if text(concept_key) == "trade_receivables_net":
                current_only = re.sub(r"non-current assets", "", preceding_context)
                last_current_assets = current_only.rfind("current assets")
                last_non_current_assets = preceding_context.rfind("non-current assets")
                if max(last_current_assets, last_non_current_assets) < 0:
                    continue
                receivable_section = ("non_current" if last_non_current_assets > last_current_assets
                                      else "current")
            weighted_share_row = bool(
                text(concept_key) == "shares_outstanding" and "weighted average" in normalized
            )
            # PDF tables sometimes emit a label and its numeric cells on
            # adjacent lines. Prefer the exact labelled line whenever it has
            # two values, so the next statement row cannot contaminate it.
            # Preserve disclosed dash cells for every concept. Previously a
            # row such as "Revenue 4 2,974,565 —" became [4, 2,974,565],
            # shifting the Note reference into current and current into prior.
            cell_tokens = re.findall(
                r"(?<![\d])\(?-?\d{1,3}(?:,\d{3})+(?:\.\d+)?\)?(?![\d])"
                r"|(?<![\d])\(?-?\d{4,}(?:\.\d+)?\)?(?![\d])"
                r"|(?<![\d])\(?-?\d{1,3}(?:\.\d+)?\)?(?![\d])"
                r"|(?<!\w)[–—�-](?!\w)",
                line,
            )
            line_amounts = []
            for token in cell_tokens:
                if token in {"-", "–", "—", "�"}:
                    line_amounts.append(0.0)
                else:
                    parsed = parsed_amounts(token)
                    if parsed:
                        line_amounts.append(parsed[0])
            note_before_disclosed_dash = (
                len(line_amounts) >= 3 and line_amounts[1] == 0
                and looks_like_note_identifier(line_amounts[0], line_amounts[2])
            )
            explicit_alphanumeric_note = bool(re.search(r"\b\d+\s*\([a-z0-9]+\)", line, re.I))
            if (len(line_amounts) >= 2 and (
                    looks_like_note_identifier(line_amounts[0], line_amounts[1])
                    or note_before_disclosed_dash or explicit_alphanumeric_note)):
                # If the extractor omitted a disclosed dash, retain an
                # explicit zero comparative rather than losing the audited
                # current value after removing the Note identifier.
                line_amounts = (line_amounts[1:] if len(line_amounts) >= 3
                                else [line_amounts[1], 0.0])
            source_line = line if len(line_amounts) >= 2 else " | ".join(lines[index:min(len(lines), index + 3)])
            amounts = line_amounts if len(line_amounts) >= 2 else parsed_amounts(source_line)
            # A formal statement row commonly starts with a numeric note
            # reference followed by current and prior values. Discard only
            # that structurally unambiguous note token.
            if (text(concept_key) != "long_term_debt"
                    and len(amounts) >= 3 and abs(amounts[0]) <= 999
                    and abs(amounts[0] - round(amounts[0])) < .000001):
                amounts = amounts[1:]
            if len(amounts) < 2:
                continue
            # A statement summary may label its columns FY2024 FY2025 (prior,
            # current), while most formal statements use current then prior.
            # Preserve the disclosed column order so direct extraction never
            # swaps comparative revenue values for REIT/property issuers.
            header_context = " ".join(lines[max(0, index - 4):index + 1])
            fiscal_years = [integer(year, 0) for year in re.findall(r"\bFY\s*(20\d{2})\b", header_context, re.I)]
            current_value, prior_value = amounts[0], amounts[1]
            if text(concept_key) == "shares_outstanding" and (share_ending_row or treasury_ending_row or direct_share_count_row) and len(amounts) >= 4:
                # Issuer layouts vary: some interleave count/amount by period,
                # while others place both count columns before both monetary
                # columns. The two count cells are normally the values within
                # two orders of magnitude of the largest value on the row.
                interleaved_count_and_value = bool(
                    re.search(r"number of\s+(?:issued\s+)?ordinary\s+shares", page_context, re.I)
                    and (
                        re.search(
                            r"number of\s+(?:issued\s+)?ordinary\s+shares\s+(?:us\$|s\$|[$£€¥])"
                            r".*number of\s+(?:issued\s+)?ordinary\s+shares\s+(?:us\$|s\$|[$£€¥])",
                            page_context, re.I | re.DOTALL,
                        )
                        or re.search(r"(?:[$£€¥]|s\$)\s*[\ufffd'\u2019]?000", page_context, re.I)
                    )
                )
                if interleaved_count_and_value:
                    # Common note layout: current count, current monetary share
                    # capital, prior count, prior monetary share capital.
                    current_value, prior_value = amounts[0], amounts[2]
                else:
                    largest = max(abs(value) for value in amounts)
                    count_indexes = [position for position, value in enumerate(amounts)
                                     if abs(value) >= largest * 0.01]
                    if len(count_indexes) >= 2:
                        current_value, prior_value = amounts[count_indexes[0]], amounts[count_indexes[1]]
                    else:
                        current_value, prior_value = amounts[0], amounts[2]
            if len(amounts) == 2 and len(fiscal_years) >= 2 and fiscal_years[-2] < fiscal_years[-1]:
                current_value, prior_value = amounts[1], amounts[0]
            key = (integer(item.get("page_number"), 0), source_line)
            if key in seen:
                continue
            seen.add(key)
            candidate = {"candidate_id": "C" + str(len(candidates) + 1),
                "page_number": item.get("page_number"),
                "description": line,
                "current_value": current_value, "prior_value": prior_value,
                "source_line": source_line}
            if (text(concept_key) == "shares_outstanding"
                    and (share_ending_row or treasury_ending_row or direct_share_count_row)
                    and re.search(r"number of\s+(?:issued\s+)?ordinary\s+shares", page_context, re.I)
                    and re.search(r"[\ufffd'\u2019]000", page_context, re.I)):
                candidate["current_value"] *= 1000
                candidate["prior_value"] *= 1000
                candidate["share_count_unit"] = "THOUSANDS"
            primary_statement_markers = {
                "CASH_FLOW_STATEMENT": ("statement of cash flows", "cash flow statement"),
                "INCOME_STATEMENT": ("statement of comprehensive income", "income statement",
                                     "statement of profit or loss"),
                "BALANCE_SHEET": ("statement of financial position", "balance sheet"),
            }
            expected_statement = (
                "CASH_FLOW_STATEMENT" if text(concept_key) in {
                    "operating_cash_flow", "investing_cash_flow", "financing_cash_flow",
                    "net_change_cash", "ending_cash"
                } else "BALANCE_SHEET" if text(concept_key) in {
                    "total_current_assets", "trade_receivables_net", "inventory", "net_ppe",
                    "total_assets", "total_current_liabilities", "long_term_debt",
                    "total_liabilities", "retained_earnings", "total_shareholders_equity",
                    "shares_outstanding"
                } else "INCOME_STATEMENT"
            )
            if (any(marker in page_context for marker in primary_statement_markers[expected_statement])
                    and "notes to the financial statements" not in page_context):
                candidate["derivation_method"] = "VALIDATED_TABLE_DIRECT_EXTRACTION"
            if (text(concept_key) == "net_profit"
                    and re.match(r"^(?:profit|loss) for the (?:year|period|year/period)\b", normalized)
                    and re.search(r"consolidated statement of\s+(?:profit or loss|comprehensive income)",
                                  page_context, re.IGNORECASE)):
                candidate["derivation_method"] = "PRIMARY_STATEMENT_FINAL_RESULT"
            if share_excluding_treasury_row or direct_share_count_row:
                candidate["derivation_method"] = "ISSUED_LESS_TREASURY_SHARES"
            if weighted_share_row:
                # Use the disclosed weighted-average count only as a fallback
                # when a closing issued-share row is absent. Apply a scale only
                # when the row itself explicitly says the count is in thousands.
                multiplier = 1000 if re.search(r"weighted average outstanding shares\s*\(thousands\)",
                                               normalized) else 1
                candidate["current_value"] *= multiplier
                candidate["prior_value"] *= multiplier
                candidate["derivation_method"] = "WEIGHTED_AVERAGE_SHARES_PROXY"
            candidates.append(candidate)
            if text(concept_key) == "operating_income_ebit":
                page_components = ebit_components[integer(item.get("page_number"), 0)]
                if re.match(
                    r"^(?:profit(?:/\(loss\))?|loss(?:/\(profit\))?) before (?:income )?tax\b",
                    normalized,
                ):
                    page_components["profit_before_tax"] = candidate
                elif re.match(r"^(?:net )?finance (?:costs?|expenses?)\b", normalized):
                    page_components["finance_cost"] = candidate
                elif re.match(r"^finance income\b", normalized):
                    page_components["finance_income"] = candidate
                # Do not treat a cash-flow reconciliation or note-level
                # "interest income" row as finance income for EBIT. In many
                # issuers (including Addvalue) it is already included in other
                # operating income. Subtract only a primary statement row that
                # the issuer explicitly classifies as Finance income.
            if text(concept_key) in {"depreciation_amortization", "depreciation_amortisation"}:
                if re.match(r"^depreciation\b", normalized):
                    page_components = da_components[integer(item.get("page_number"), 0)]
                    existing_depreciation = page_components.get("depreciation")
                    if existing_depreciation:
                        candidate = {
                            **candidate,
                            "current_value": existing_depreciation["current_value"] + candidate["current_value"],
                            "prior_value": existing_depreciation["prior_value"] + candidate["prior_value"],
                            "source_line": existing_depreciation["source_line"] + " | " + candidate["source_line"],
                        }
                    page_components["depreciation"] = candidate
                elif re.match(r"^(?:amortisation|amortization)\b", normalized):
                    da_components[integer(item.get("page_number"), 0)]["amortisation"] = candidate
            if text(concept_key) == "sg_and_a_expense":
                if re.search(r"\b(?:selling(?: and distribution)? expenses|distribution costs|marketing(?: and distribution)? expenses)\b", normalized):
                    sga_components[integer(item.get("page_number"), 0)]["selling"] = candidate
                elif re.search(r"\b(?:general and )?administrative expenses\b", normalized):
                    sga_components[integer(item.get("page_number"), 0)]["general_and_administrative"] = candidate
            if text(concept_key) == "long_term_debt":
                if re.match(r"^(?:loans and )?borrowings\b", normalized):
                    debt_components[integer(item.get("page_number"), 0)]["borrowings"] = candidate
                elif re.match(r"^lease liabilities\b", normalized):
                    debt_components[integer(item.get("page_number"), 0)]["leases"] = candidate
            if text(concept_key) == "trade_receivables_net" and receivable_section:
                receivable_components[integer(item.get("page_number"), 0)][receivable_section] = candidate
            if text(concept_key) == "trade_receivables_net":
                page_receivables = receivable_net_components[integer(item.get("page_number"), 0)]
                if re.match(r"^trade receivables\b", normalized) and "trade and other" not in normalized:
                    page_receivables.setdefault("gross", candidate)
                elif receivable_allowance_row:
                    page_receivables["allowance"] = candidate
            if text(concept_key) == "net_ppe":
                page_ppe = ppe_components[integer(item.get("page_number"), 0)]
                if re.match(r"^(?:property,? plant and equipment|plant and equipment)\b", normalized):
                    page_ppe["ppe"] = candidate
                elif re.match(r"^right[- ]of[- ]use assets?\b", normalized):
                    page_ppe["right_of_use"] = candidate
            if text(concept_key) == "shares_outstanding":
                if share_ending_row:
                    issued_share_candidates.append(candidate)
                elif treasury_ending_row:
                    treasury_share_candidates.append(candidate)
    # Some formal statements print section subtotals without repeating the
    # section label. Recover the numeric subtotal immediately before the next
    # audited heading, preserving the first two Group columns.
    if text(concept_key) in {"total_current_assets", "total_current_liabilities"}:
        subtotal_candidates = []
        boundary = (r"^total assets\b" if text(concept_key) == "total_current_assets"
                    else r"^non[ -]?current liabilities\b")
        for item in evidence:
            lines = [line.strip() for line in text(item.get("content")).splitlines() if line.strip()]
            for index, line in enumerate(lines):
                if not re.match(boundary, line.lower()):
                    continue
                for previous in reversed(lines[max(0, index - 3):index]):
                    amounts = parsed_amounts(previous)
                    if len(amounts) < 2:
                        continue
                    subtotal_candidates.append({
                        "candidate_id": "T" + str(len(subtotal_candidates) + 1),
                        "page_number": item.get("page_number"),
                        "description": ("Current assets subtotal" if text(concept_key) == "total_current_assets"
                                        else "Current liabilities subtotal"),
                        "current_value": amounts[0], "prior_value": amounts[1],
                        "source_line": previous,
                        "derivation_method": "PRIMARY_STATEMENT_SECTION_SUBTOTAL",
                    })
                    break
        exact_total_pattern = (r"^total current assets\b" if text(concept_key) == "total_current_assets"
                               else r"^total current liabilities\b")
        # An exact audited total always outranks an inferred section subtotal.
        # Only use the boundary fallback when the statement omits a labelled total.
        if not any(re.match(exact_total_pattern, text(item.get("description")).lower()) for item in candidates):
            candidates = subtotal_candidates + candidates
    if text(concept_key) in {"depreciation_amortization", "depreciation_amortisation"}:
        derived_candidates = []
        page_text = {
            integer(item.get("page_number"), 0): text(item.get("content")).lower()
            for item in evidence
        }
        for page_number, components in da_components.items():
            depreciation, amortisation = components.get("depreciation"), components.get("amortisation")
            if not depreciation or not amortisation:
                continue
            derived_candidates.append({
                "candidate_id": "D" + str(len(derived_candidates) + 1),
                "page_number": page_number,
                "description": "Derived depreciation & amortisation: separately disclosed expenses summed",
                "current_value": abs(depreciation["current_value"]) + abs(amortisation["current_value"]),
                "prior_value": abs(depreciation["prior_value"]) + abs(amortisation["prior_value"]),
                "source_line": depreciation["source_line"] + " | " + amortisation["source_line"],
                "derivation_method": (
                    "PRIMARY_CASH_FLOW_COMPONENT_SUM"
                    if re.search(r"statements? of cash flows?|cash flow statements?",
                                 page_text.get(page_number, ""))
                    else "DIRECT_COMPONENT_SUM"
                ),
            })
        # Expense inputs use positive magnitudes. Exclude accounting-policy,
        # accumulated-balance and useful-life/rate rows, which describe the
        # asset note but are not the period expense used by DEPI/Montier.
        invalid_da = re.compile(
            r"accumulated (?:depreciation|amorti[sz]ation)|depreciation rates?"
            r"|useful li(?:fe|ves)|carrying amount|at (?:beginning|end) of"
            r"|opening balance|closing balance|cost at",
            re.IGNORECASE,
        )
        clean_candidates = []
        for candidate in candidates:
            candidate_text = text(candidate.get("source_line") or candidate.get("description"))
            if invalid_da.search(candidate_text):
                continue
            candidate = dict(candidate)
            candidate["current_value"] = abs(number(candidate.get("current_value")) or 0)
            candidate["prior_value"] = abs(number(candidate.get("prior_value")) or 0)
            clean_candidates.append(candidate)

        # Ranking: explicit combined disclosure, primary cash-flow component
        # sum, other audited component sum, then individual component rows.
        # This makes Addvalue 2023 resolve to 614,949 + 385,183 = 1,000,132
        # and 563,262 + 425,213 = 988,475 without issuer-specific values.
        def da_rank(candidate):
            candidate_text = text(candidate.get("source_line") or candidate.get("description")).lower()
            method = text(candidate.get("derivation_method"))
            explicit_combined = bool(re.search(
                r"depreciation\s*(?:&|and)\s*amorti[sz]ation", candidate_text
            )) and " | " not in candidate_text
            return (
                0 if explicit_combined else
                1 if method == "PRIMARY_CASH_FLOW_COMPONENT_SUM" else
                2 if method == "DIRECT_COMPONENT_SUM" else 3,
                integer(candidate.get("page_number"), 0),
            )

        candidates = sorted(derived_candidates + clean_candidates, key=da_rank)
    if text(concept_key) == "sg_and_a_expense":
        derived_candidates = []
        for page_number, components in sga_components.items():
            selling = components.get("selling")
            general_and_administrative = components.get("general_and_administrative")
            if not selling or not general_and_administrative:
                continue
            derived_candidates.append({
                "candidate_id": "S" + str(len(derived_candidates) + 1),
                "page_number": page_number,
                "description": "Derived SG&A: selling plus general and administrative expenses",
                "current_value": selling["current_value"] + general_and_administrative["current_value"],
                "prior_value": selling["prior_value"] + general_and_administrative["prior_value"],
                "source_line": selling["source_line"] + " | " + general_and_administrative["source_line"],
                "derivation_method": "DIRECT_COMPONENT_SUM",
            })
        candidates = derived_candidates + candidates
    if text(concept_key) == "operating_income_ebit":
        derived_candidates = []
        for page_number, components in ebit_components.items():
            before_tax, finance_cost = components.get("profit_before_tax"), components.get("finance_cost")
            finance_income = components.get("finance_income")
            if not before_tax or not finance_cost:
                continue
            def derive_ebit(role):
                result = number(before_tax.get(role + "_value"))
                cost = number(finance_cost.get(role + "_value"))
                income = number(finance_income.get(role + "_value")) if finance_income else 0
                return None if result is None or cost is None else result + abs(cost) - abs(income or 0)
            current_ebit, prior_ebit = derive_ebit("current"), derive_ebit("prior")
            if current_ebit is None or prior_ebit is None:
                continue
            derived_candidates.append({
                "candidate_id": "E" + str(len(derived_candidates) + 1),
                "page_number": page_number,
                "description": "Derived EBIT: profit/loss before tax plus finance costs less finance income",
                "current_value": current_ebit, "prior_value": prior_ebit,
                "source_line": before_tax["source_line"] + " | " + finance_cost["source_line"]
                               + ((" | " + finance_income["source_line"]) if finance_income else ""),
                "derivation_method": "GOVERNED_EBIT_RECONCILIATION",
            })
        direct = [item for item in candidates if re.match(
            r"^(?:operating income|operating profit|profit from operations)\b",
            text(item.get("description")).lower(),
        )]
        direct.sort(key=lambda item: (
            " before " in (" " + text(item.get("description")).lower() + " "),
            integer(item.get("page_number"), 0),
        ))
        other = [item for item in candidates if item not in direct]
        candidates = direct + derived_candidates + other
    if text(concept_key) == "long_term_debt":
        derived_candidates = []
        for page_number, components in debt_components.items():
            borrowings, leases = components.get("borrowings"), components.get("leases")
            if not borrowings or not leases:
                continue
            derived_candidates.append({
                "candidate_id": "L" + str(len(derived_candidates) + 1),
                "page_number": page_number,
                "description": "Derived long-term debt: non-current borrowings plus lease liabilities",
                "current_value": borrowings["current_value"] + leases["current_value"],
                "prior_value": borrowings["prior_value"] + leases["prior_value"],
                "source_line": borrowings["source_line"] + " | " + leases["source_line"],
                "derivation_method": "DIRECT_COMPONENT_SUM",
            })
        candidates = derived_candidates + candidates
    if text(concept_key) == "trade_receivables_net":
        derived_candidates = []
        for page_number, components in receivable_net_components.items():
            gross, allowance = components.get("gross"), components.get("allowance")
            if not gross or not allowance:
                continue
            derived_candidates.append({
                "candidate_id": "RN" + str(len(derived_candidates) + 1),
                "page_number": page_number,
                "description": "Net trade receivables: gross trade receivables less ECL allowance",
                "current_value": gross["current_value"] - abs(allowance["current_value"]),
                "prior_value": gross["prior_value"] - abs(allowance["prior_value"]),
                "source_line": gross["source_line"] + " | " + allowance["source_line"],
                "derivation_method": "DIRECT_COMPONENT_SUM",
            })
        for page_number, components in receivable_components.items():
            current_part, non_current_part = components.get("current"), components.get("non_current")
            if not current_part or not non_current_part:
                continue
            derived_candidates.append({
                "candidate_id": "R" + str(len(derived_candidates) + 1),
                "page_number": page_number,
                "description": "Derived net trade receivables: current plus non-current balances",
                "current_value": current_part["current_value"] + non_current_part["current_value"],
                "prior_value": current_part["prior_value"] + non_current_part["prior_value"],
                "source_line": current_part["source_line"] + " | " + non_current_part["source_line"],
                "derivation_method": "DIRECT_COMPONENT_SUM",
            })
        candidates = derived_candidates + candidates
    if text(concept_key) == "net_ppe":
        derived_candidates = []
        for page_number, components in ppe_components.items():
            ppe, right_of_use = components.get("ppe"), components.get("right_of_use")
            if not ppe or not right_of_use:
                continue
            derived_candidates.append({
                "candidate_id": "P" + str(len(derived_candidates) + 1),
                "page_number": page_number,
                "description": "Derived net PP&E: PPE plus right-of-use assets",
                "current_value": ppe["current_value"] + right_of_use["current_value"],
                "prior_value": ppe["prior_value"] + right_of_use["prior_value"],
                "source_line": ppe["source_line"] + " | " + right_of_use["source_line"],
                "derivation_method": "DIRECT_COMPONENT_SUM",
            })
        candidates = derived_candidates + candidates
    if text(concept_key) == "inventory" and not candidates:
        primary_balance_page = next((item for item in evidence
            if re.search(r"^total assets\b", text(item.get("content")).lower(), re.MULTILINE)
            and re.search(r"^total current liabilities\b", text(item.get("content")).lower(), re.MULTILINE)), None)
        if primary_balance_page and not re.search(
                r"^(?:inventory|inventories)\b", text(primary_balance_page.get("content")).lower(), re.MULTILINE):
            candidates = [{
                "candidate_id": "I0", "page_number": primary_balance_page.get("page_number"),
                "description": "Inventory omitted from confirmed primary balance sheet",
                "current_value": 0.0, "prior_value": 0.0,
                "source_line": "No inventory balance is presented on the primary statement of financial position.",
                "derivation_method": "PRIMARY_STATEMENT_CONFIRMED_ZERO",
            }]
    if text(concept_key) == "shares_outstanding" and issued_share_candidates and treasury_share_candidates:
        issued = max(issued_share_candidates, key=lambda item: max(
            abs(number(item.get("current_value")) or 0), abs(number(item.get("prior_value")) or 0)))
        treasury = max(treasury_share_candidates, key=lambda item: max(
            abs(number(item.get("current_value")) or 0), abs(number(item.get("prior_value")) or 0)))
        issued_current, issued_prior = number(issued.get("current_value")), number(issued.get("prior_value"))
        treasury_current, treasury_prior = number(treasury.get("current_value")), number(treasury.get("prior_value"))
        if None not in {issued_current, issued_prior, treasury_current, treasury_prior}:
            candidates = [{
                "candidate_id": "N1", "page_number": issued.get("page_number"),
                "description": "Outstanding ordinary shares: closing issued shares less treasury shares",
                "current_value": issued_current - abs(treasury_current),
                "prior_value": issued_prior - abs(treasury_prior),
                "source_line": issued["source_line"] + " | " + treasury["source_line"],
                "derivation_method": "ISSUED_LESS_TREASURY_SHARES",
            }] + candidates
    if text(concept_key) == "revenue":
        # Narrative summaries such as "turnover was US$7.5 million" can
        # otherwise yield 7.5 plus a nearby page/note number. An audited
        # primary-statement row is authoritative and must precede narrative
        # or note candidates. Exact row labels remain generic across issuers.
        revenue_label = (
            r"(?:net sales|net revenue|revenue|operating revenue|gross revenue|turnover|"
            r"revenue from contracts with customers(?: and other sources)?)"
        )
        exact_revenue = re.compile(
            r"^(?:note\s+\d+\s+)?" + revenue_label + r"\b",
            re.IGNORECASE,
        )
        numeric_revenue_row = re.compile(
            r"^(?:note\s+\d+\s+)?" + revenue_label
            + r"\s+(?:note\s+)?(?:\d{1,3}(?:\s*\([a-z0-9]+\))?\s+)?"
              r"(?:\(?-?\d[\d,]*(?:\.\d+)?\)?|[–—-])(?:\s+|$)",
            re.IGNORECASE,
        )

        def revenue_rank(candidate):
            method = text(candidate.get("derivation_method")).upper()
            source = re.sub(r"^\[page\s+\d+\]\s*", "",
                            text(candidate.get("source_line") or candidate.get("description"))).strip()
            exact = bool(exact_revenue.match(source))
            numeric_row = bool(numeric_revenue_row.match(source))
            magnitude = max(
                abs(number(candidate.get("current_value")) or 0),
                abs(number(candidate.get("prior_value")) or 0),
            )
            return (
                0 if method == "VALIDATED_TABLE_DIRECT_EXTRACTION" and numeric_row else
                1 if numeric_row else
                2 if method == "VALIDATED_TABLE_DIRECT_EXTRACTION" and exact else
                3 if exact else 4,
                -magnitude,
                integer(candidate.get("page_number"), 0),
            )

        candidates = sorted(candidates, key=revenue_rank)
    return candidates[:12]


def parse_partial_batch_results(content: str) -> Dict[str, Any]:
    """Recover complete result objects when a batch JSON response ends early."""
    cleaned = text(content).strip()
    match = re.search(r'"results"\s*:\s*\[', cleaned)
    if not match:
        return {"results": [], "existing_value_exceptions": []}
    results = []
    object_start = None
    depth = 0
    in_string = False
    escaped = False
    for index in range(match.end(), len(cleaned)):
        character = cleaned[index]
        if in_string:
            if escaped:
                escaped = False
            elif character == "\\":
                escaped = True
            elif character == '"':
                in_string = False
            continue
        if character == '"':
            in_string = True
        elif character == "{":
            if depth == 0:
                object_start = index
            depth += 1
        elif character == "}" and depth:
            depth -= 1
            if depth == 0 and object_start is not None:
                try:
                    candidate = json.loads(cleaned[object_start:index + 1])
                except json.JSONDecodeError:
                    candidate = None
                if isinstance(candidate, dict):
                    results.append(candidate)
                object_start = None
        elif character == "]" and depth == 0:
            break
    return {"results": results, "existing_value_exceptions": []}


def parse_ollama_json(content: str) -> Dict[str, Any]:
    cleaned = content.strip()
    fenced = re.search(r"```(?:json)?\s*(\{.*\})\s*```", cleaned, re.DOTALL | re.IGNORECASE)
    if fenced:
        cleaned = fenced.group(1)
    else:
        start = cleaned.find("{")
        if start >= 0:
            cleaned, _ = json.JSONDecoder().raw_decode(cleaned[start:])
            if isinstance(cleaned, dict):
                return cleaned
    parsed = json.loads(cleaned)
    if not isinstance(parsed, dict):
        raise ValueError("Ollama narrative must be a JSON object")
    return parsed


FORENSIC_COMPONENT_LABELS = {
    "incomeexceedscfo": "Net profit exceeds operating cash flow",
    "dsorising": "Days sales outstanding increased",
    "othercurrentassetsrising": "Other current assets increased relative to revenue",
    "risingothercurrentassets": "Other current assets increased relative to revenue",
    "depreciationratedeclining": "The depreciation rate declined",
    "assetgrowthabove20pct": "Asset growth exceeded 20%",
    "inventorydaysrising": "Inventory days increased",
    "positiveroa": "Return on assets was positive",
    "positivecfo": "Operating cash flow was positive",
    "improvingroa": "Return on assets improved",
    "lowaccruals": "Operating cash flow exceeded accounting profit",
    "fallingleverage": "Financial leverage declined",
    "improvingliquidity": "Short-term liquidity improved",
    "nodilution": "No share dilution was identified",
    "improvingmargin": "Gross margin improved",
    "improvingturnover": "Asset turnover improved",
}


def component_phrase_key(value: Any) -> str:
    return re.sub(r"(?:true|false)$", "", re.sub(r"[^a-z0-9]", "", text(value).lower()))


def humanize_forensic_text(value: Any) -> str:
    """Convert governed component identifiers into readable accounting labels."""
    original = text(value)
    key = component_phrase_key(original)
    if key in FORENSIC_COMPONENT_LABELS:
        return FORENSIC_COMPONENT_LABELS[key]
    spaced = original.replace("_", " ")
    spaced = re.sub(r"(?<=[a-z])(?=[A-Z])", " ", spaced)
    return re.sub(r"\s+", " ", spaced).strip()


def is_component_placeholder(value: Any) -> bool:
    """A boolean score component is not annual-report supporting evidence."""
    original = text(value).lower()
    return component_phrase_key(original) in FORENSIC_COMPONENT_LABELS and bool(re.search(r"\b(?:true|false)\b|\((?:true|false)\)", original))


def validate_narrative(payload: Dict[str, Any], allowed_pages: set, allowed_models: set = None) -> Dict[str, Any]:
    result = {
        "summary": text(payload.get("summary") or payload.get("executive_summary") or payload.get("executiveSummary")),
        "overall_assessment": text(payload.get("overall_assessment") or payload.get("overallAssessment") or payload.get("assessment")),
        "score_interpretations": [],
        "key_risk_signals": [],
        "recommended_actions": [],
        "limitations": [],
    }
    for item in payload.get("score_interpretations", []) if isinstance(payload.get("score_interpretations"), list) else []:
        model_key = text(item.get("model_key")) if isinstance(item, dict) else ""
        if isinstance(item, dict) and model_key and text(item.get("interpretation")) and (allowed_models is None or model_key in allowed_models):
            result["score_interpretations"].append({
                "model_key": model_key,
                "interpretation": text(item.get("interpretation")),
            })
    for item in payload.get("key_risk_signals", []) if isinstance(payload.get("key_risk_signals"), list) else []:
        if not isinstance(item, dict):
            continue
        pages = []
        for page in item.get("source_pages", []) if isinstance(item.get("source_pages"), list) else []:
            page_number = integer(page, -1)
            if page_number in allowed_pages and page_number not in pages:
                pages.append(page_number)
        if text(item.get("signal")) and text(item.get("evidence")) and pages and not is_component_placeholder(item.get("evidence")):
            severity = text(item.get("severity")).upper()
            result["key_risk_signals"].append({
                "severity": severity if severity in {"HIGH", "MED", "LOW"} else "MED",
                "category": text(item.get("category")) or "Financial",
                "signal": humanize_forensic_text(item.get("signal")),
                "evidence": humanize_forensic_text(item.get("evidence")),
                "source_pages": pages,
            })
    for field in ("recommended_actions", "limitations"):
        values = payload.get(field, [])
        if isinstance(values, list):
            result[field] = [text(item) for item in values if text(item)][:8]
    # Smaller local models occasionally return only one of the two headline
    # fields, despite otherwise producing a valid governed narrative. Recover
    # from the supplied narrative text without inventing scores or evidence.
    fallback_text = next(
        (item["interpretation"] for item in result["score_interpretations"] if item["interpretation"]),
        "",
    ) or next(
        (item["evidence"] for item in result["key_risk_signals"] if item["evidence"]),
        "",
    )
    result["summary"] = result["summary"] or result["overall_assessment"] or fallback_text
    result["overall_assessment"] = result["overall_assessment"] or result["summary"]
    if not result["summary"]:
        raise ValueError("Ollama response did not contain usable narrative text")
    return result


def narrative_spacing_is_readable(payload: Dict[str, Any]) -> bool:
    """Reject the run-together prose occasionally emitted by small models."""
    prose = [text(payload.get(key)) for key in ("summary", "overall_assessment")]
    for key, field in (("score_interpretations", "interpretation"), ("key_risk_signals", "signal"), ("key_risk_signals", "evidence")):
        values = payload.get(key, [])
        if isinstance(values, list):
            prose.extend(text(item.get(field)) for item in values if isinstance(item, dict))
    for key in ("recommended_actions", "limitations"):
        values = payload.get(key, [])
        if isinstance(values, list):
            prose.extend(text(item) for item in values)
    return all(
        not re.search(r"[A-Za-z]{20,}", value)
        and (len(value) < 40 or len(re.findall(r"\s+", value)) >= 3)
        for value in prose if value
    )


@app.route("/api/forensic-narrative", methods=["POST"])
def forensic_narrative():
    """Generate a grounded explanation; Dataiku scores remain authoritative."""
    body = request.get_json(silent=True) or {}
    run_id = text(body.get("assessment_run_id"))
    document_id = text(body.get("source_document_id"))
    if not run_id or not document_id:
        return jsonify({"error": "assessment_run_id and source_document_id are required"}), 400

    scores = rows_for_filing(read_optional(FORENSIC_SCORES_DATASET), run_id, document_id)
    if not scores:
        return jsonify({"error": "No Dataiku forensic scores are available for this filing. Run FRI_05_SCORE_SECTOR_FORENSICS first."}), 409
    fingerprint = score_fingerprint(scores)
    saved = load_saved_narrative(document_id, fingerprint)
    if saved:
        return jsonify(saved)
    if not llm_feature_enabled("fri_llm_narrative_enabled", False):
        return jsonify({"status": "LLM_FEATURE_DISABLED", "llm_skipped": True,
                        "assessment_run_id": run_id, "source_document_id": document_id,
                        "message": "Narrative generation is temporarily disabled to reserve provider capacity for missing financial values."})
    settings = financial_resolution_llm_configuration()
    if settings["provider"] not in {"bedrock", "gemini"}:
        return jsonify({"error": "Forensic narrative requires fri_llm_provider=bedrock or gemini"}), 409
    facts, fact_source = resolved_values()
    fact_rows = rows_for_filing(facts, run_id, document_id)
    registration = registration_lookup().get(document_id, {})
    sector = infer_sector(fact_rows)
    evidence = narrative_evidence(document_id, ollama_configuration())
    if not evidence:
        return jsonify({"error": "No annual-report evidence is available in FRI_DOCUMENT_FRAGMENTS for this filing."}), 409

    compact_facts = [{
        "concept_key": text(row.get("concept_key")),
        "current_period": text(row.get("current_period")),
        "prior_period": text(row.get("prior_period")),
        "current_value": number(row.get("current_value")),
        "prior_value": number(row.get("prior_value")),
        "currency": text(row.get("currency")),
        "unit": text(row.get("unit")),
        "resolution_method": text(row.get("resolution_method") or row.get("selection_method")),
    } for row in fact_rows if text(row.get("concept_key"))]
    score_contract = [{
        "model_key": text(row.get("model_key")),
        "model_name": text(row.get("model_name")),
        "status": text(row.get("status")),
        "score": number(row.get("score")),
        "risk_band": text(row.get("risk_band")),
        "components": row.get("components_json"),
        "configuration_version": text(row.get("configuration_version")),
    } for row in scores]
    source_package = {
        "company": registration.get("entity_key") or next((text(row.get("entity_name") or row.get("entity_id")) for row in fact_rows if text(row.get("entity_name") or row.get("entity_id"))), "Unknown entity"),
        "file_name": registration.get("file_name") or document_id,
        "sector": sector,
        "financial_facts": compact_facts,
        "dataiku_forensic_scores": score_contract,
        "annual_report_evidence": evidence,
    }
    system_prompt = (
        "You are the FSRE annual-report forensic narrative layer. Dataiku's supplied forensic scores and facts are authoritative. "
        "Never calculate, replace, adjust, or invent a score, risk band, company, period, or financial amount. Explain the scores and identify only risks directly supported by the supplied annual-report excerpts. "
        "Every key_risk_signal must include one or more source_pages present in the evidence package. If evidence is insufficient, state that in limitations. "
        "Return JSON only with this schema: {summary:string, overall_assessment:string, score_interpretations:[{model_key:string,interpretation:string}], "
        "key_risk_signals:[{severity:HIGH|MED|LOW,category:string,signal:string,evidence:string,source_pages:[integer]}], recommended_actions:[string], limitations:[string]}."
    )
    request_payload = {
        "model": settings["model"],
        "stream": False,
        "response_format": {"type": "json_object"},
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": json.dumps(source_package, default=str)},
        ],
        "temperature": 0.1,
    }
    try:
        response = requests.post(
            settings["base_url"].rstrip("/") + "/chat/completions",
            json=request_payload,
            headers={"Authorization": "Bearer " + settings["api_key"], "Content-Type": "application/json"},
            timeout=(5, settings["timeout_seconds"]),
        )
        response.raise_for_status()
        bedrock_payload = response.json()
        raw_content = text(((((bedrock_payload.get("choices") or [{}])[0]).get("message") or {}).get("content")))
        narrative = validate_narrative(
            parse_ollama_json(raw_content),
            {item["page_number"] for item in evidence},
            {item["model_key"] for item in score_contract if item["model_key"]},
        )
    except requests.RequestException as exc:
        return jsonify({"error": f"{settings['provider'].title()} request failed: {type(exc).__name__}: {exc}"}), 502
    except (ValueError, json.JSONDecodeError, TypeError) as exc:
        return jsonify({"error": f"{settings['provider'].title()} returned an invalid narrative: {exc}"}), 502

    result_payload = {
        "narrative": narrative,
        "authoritative_scores": score_contract,
        "company_context": {"company": source_package["company"], "file_name": source_package["file_name"], **sector},
        "evidence_pages": sorted(item["page_number"] for item in evidence),
        "provenance": {
            "model": settings["model"],
            "provider": "bedrock", "base_url": settings["base_url"],
            "score_source": FORENSIC_SCORES_DATASET,
            "fact_source": fact_source,
            "evidence_source": DOCUMENT_FRAGMENTS_DATASET,
            "score_values_generated_by_model": False,
        },
        "score_fingerprint": fingerprint,
    }
    save_narrative(run_id, document_id, fingerprint, result_payload)
    return jsonify(result_payload)


@app.route("/api/forensic-narrative/latest", methods=["GET"])
def latest_forensic_narrative():
    """Return the newest saved version, preferring the current score fingerprint."""
    run_id = text(request.args.get("assessment_run_id"))
    document_id = text(request.args.get("source_document_id"))
    if not document_id:
        return jsonify({"error": "source_document_id is required"}), 400
    scores = rows_for_filing(read_optional(FORENSIC_SCORES_DATASET), run_id, document_id) if run_id else []
    fingerprint = score_fingerprint(scores) if scores else ""
    saved = load_saved_narrative(document_id, fingerprint) if fingerprint else load_saved_narrative(document_id)
    try:
        configured_model = text(database_secret("fri_bedrock_model"))
    except Exception:
        configured_model = ""
    configured_model = configured_model or text(runtime_configuration_values().get("fri_bedrock_model")) or "openai.gpt-oss-20b"
    if saved and text((saved.get("provenance") or {}).get("model")) != configured_model:
        return jsonify({
            "found": False, "regeneration_required": True,
            "reason": "NARRATIVE_PROVIDER_CHANGED_TO_BEDROCK",
            "configured_model": configured_model,
        }), 409
    if not saved:
        previous = load_saved_narrative(document_id) if fingerprint else {}
        return jsonify({
            "found": False,
            "regeneration_required": bool(fingerprint),
            "reason": "CURRENT_SCORE_VALUES_NOT_SAVED" if previous else "REPORT_NOT_SAVED",
        }), 409 if fingerprint else 404
    saved["found"] = True
    saved["scores_current"] = not fingerprint or saved.get("score_fingerprint") == fingerprint
    return jsonify(saved)


def financial_news_engine():
    # Dataiku Project Libraries are added to the Python path automatically.
    # This is the production deployment path and avoids host-specific paths.
    import_failures = []
    for module_name in (
        "financial_risk_intelligence.fri_relevant_news_engine",
        "fri_relevant_news_engine",
    ):
        try:
            module = importlib.import_module(module_name)
            if hasattr(module, "structured_results"):
                print(f"RELEVANT_NEWS loaded engine module={module_name}", flush=True)
                return module
            import_failures.append(f"{module_name}: structured_results is missing")
        except Exception as exc:
            detail = f"{module_name}: {type(exc).__name__}: {exc}"
            import_failures.append(detail)
            print("RELEVANT_NEWS engine import failed:", detail, flush=True)
    variables = runtime_configuration_values()
    configured = text(
        variables.get("fri_relevant_news_engine_path")
        or variables.get("fri_financial_news_engine_path")
    )
    candidates = [
        Path(configured) if configured else None,
        Path(__file__).resolve().parents[3] / "Neha" / "fri_relevant_news_engine.py",
        Path("C:/Sciente_Harsh/Project_C/Neha/fri_relevant_news_engine.py"),
    ]
    engine_path = next((path for path in candidates if path and path.is_file()), None)
    if not engine_path:
        raise RuntimeError(
            "fri_relevant_news_engine.py is unavailable; add it to the Dataiku "
            "Project Python Library under python/financial_risk_intelligence/"
            "fri_relevant_news_engine.py "
            "or configure fri_relevant_news_engine_path. "
            f"Import detail: {' | '.join(import_failures) or 'module not found'}"
        )
    spec = importlib.util.spec_from_file_location("fri_relevant_news_engine", str(engine_path))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def saved_company_news(company_key: str, limit: int = 20) -> List[Dict[str, Any]]:
    with postgres_connection() as connection:
        with connection.cursor() as cursor:
            cursor.execute(
                """SELECT article_key, headline, summary, published_at, url, source_name,
                          sentiment_score, risk_impact, impacts_json, first_seen_at
                     FROM financial_risk_intelligence.company_relevant_news
                    WHERE company_key = %s
                    ORDER BY published_at DESC NULLS LAST, first_seen_at DESC
                    LIMIT %s""",
                (company_key, limit),
            )
            rows = cursor.fetchall()
    return [{
        "id": row[0], "article_key": row[0], "headline": row[1], "summary": row[2],
        "published_at": row[3].isoformat() if hasattr(row[3], "isoformat") else text(row[3]),
        "date": row[3].strftime("%d %b %Y") if hasattr(row[3], "strftime") else text(row[3]),
        "url": row[4], "source_name": row[5], "sentiment_score": row[6],
        "riskImpact": row[7], "risk_impact": row[7], "impacts": row[8] or {},
        "first_seen_at": row[9].isoformat() if row[9] else "",
    } for row in rows]


def persist_company_news(company_key: str, entity_name: str, articles: List[Dict[str, Any]]) -> int:
    inserted = 0
    with postgres_connection() as connection:
        with connection.cursor() as cursor:
            for article in articles:
                cursor.execute(
                    """INSERT INTO financial_risk_intelligence.company_relevant_news
                           (company_key, entity_name, article_key, provider_id, headline, summary,
                            published_at, url, source_name, sentiment_score, risk_impact, impacts_json)
                       VALUES (%s,%s,%s,%s,%s,%s,NULLIF(%s,'')::timestamptz,%s,%s,%s,%s,%s::jsonb)
                       ON CONFLICT (company_key, article_key) DO UPDATE SET
                            entity_name=EXCLUDED.entity_name, headline=EXCLUDED.headline,
                            summary=EXCLUDED.summary, published_at=EXCLUDED.published_at,
                            url=EXCLUDED.url, source_name=EXCLUDED.source_name,
                            sentiment_score=EXCLUDED.sentiment_score,
                            risk_impact=EXCLUDED.risk_impact, impacts_json=EXCLUDED.impacts_json,
                            last_seen_at=CURRENT_TIMESTAMP
                       RETURNING (xmax = 0)""",
                    (company_key, entity_name, article.get("article_key"), article.get("provider_id"),
                     article.get("headline"), article.get("summary"), article.get("published_at"),
                     article.get("url"), article.get("source_name"), article.get("sentiment_score"),
                     article.get("risk_impact"), json.dumps(article.get("impacts") or {})),
                )
                inserted += int(bool(cursor.fetchone()[0]))
            cursor.execute(
                """INSERT INTO financial_risk_intelligence.company_news_refresh_state
                           (company_key, last_refreshed_at, last_result_count, last_error)
                       VALUES (%s,CURRENT_TIMESTAMP,%s,'')
                       ON CONFLICT (company_key) DO UPDATE SET
                            last_refreshed_at=CURRENT_TIMESTAMP,
                            last_result_count=EXCLUDED.last_result_count,last_error=''""",
                (company_key, len(articles)),
            )
    return inserted


def company_name_from_annual_report(document_id: str, fact_rows: List[Dict[str, Any]],
                                    registration: Dict[str, str]) -> Dict[str, str]:
    """Resolve the legal company name, prioritising annual-report pages 1-3."""
    fragments = read_optional(DOCUMENT_FRAGMENTS_DATASET)
    candidates: List[str] = []
    if not fragments.empty:
        for row in fragments.to_dict(orient="records"):
            if text(row.get("source_document_id")) != document_id:
                continue
            page = integer(row.get("page_number") or row.get("page"), -1)
            if page not in {1, 2, 3}:
                continue
            content = re.sub(r"\s+", " ", text(
                row.get("content") or row.get("text") or row.get("fragment_text")
            )).strip()
            for match in re.findall(
                r"\b([A-Z][A-Za-z0-9&'.,()\- ]{1,75}?\s(?:Limited|Ltd\.?|Corporation|Corp\.?|PLC|Pte\.?\s+Ltd\.?|LLC|Inc\.?))\b",
                content,
            ):
                name = re.sub(r"\s+", " ", match).strip(" .,;:-")
                if 4 <= len(name) <= 90:
                    candidates.append(name)
    if candidates:
        company = collections.Counter(candidates).most_common(1)[0][0]
        return {"company": company, "source": "ANNUAL_REPORT_PAGES_1_TO_3"}

    registered = text(registration.get("entity_key"))
    if registered:
        return {"company": registered, "source": REGISTRATIONS_DATASET}
    fact_company = next((text(row.get("entity_name") or row.get("entity_id")) for row in fact_rows
                         if text(row.get("entity_name") or row.get("entity_id"))), "")
    if fact_company:
        return {"company": fact_company, "source": CANONICAL_FACTS_DATASET}
    return {"company": document_id, "source": "SOURCE_DOCUMENT_ID_FALLBACK"}


@app.route("/api/relevant-news", methods=["GET"])
def relevant_news():
    """Refresh and append company news; never discard the last saved result set."""
    request_id = str(uuid.uuid4())[:8]
    run_id = text(request.args.get("assessment_run_id"))
    document_id = text(request.args.get("source_document_id"))
    refresh_requested = text(request.args.get("refresh")).lower() in {"1", "true", "yes"}
    print(json.dumps({"event": "RELEVANT_NEWS_START", "request_id": request_id,
                      "assessment_run_id": run_id, "source_document_id": document_id,
                      "refresh_requested": refresh_requested}), flush=True)
    if not document_id:
        print(f"RELEVANT_NEWS[{request_id}] missing source_document_id", flush=True)
        return jsonify({"error": "source_document_id is required"}), 400
    facts, _ = resolved_values()
    fact_rows = rows_for_filing(facts, run_id, document_id) if run_id else []
    registration = registration_lookup().get(document_id, {})
    company_resolution = company_name_from_annual_report(document_id, fact_rows, registration)
    company = company_resolution["company"]
    print(json.dumps({"event": "RELEVANT_NEWS_COMPANY", "request_id": request_id,
                      "company": company, "company_name_source": company_resolution["source"],
                      "fact_count": len(fact_rows)}), flush=True)
    company_key = re.sub(r"[^a-z0-9]+", "-", company.lower()).strip("-") or document_id.lower()
    variables = runtime_configuration_values()
    limit = max(1, min(20, integer(variables.get("fri_relevant_news_limit"), 5)))
    appended = 0
    refresh_error = ""
    refresh_stage = "SAVED_NEWS"
    market_query = ""
    fetched_count = 0
    pool_size = 0
    query_attempts = []
    engine_location = ""
    provider = text(variables.get("fri_news_provider")).lower() or "newsdata"
    try:
        if not refresh_requested:
            raise StopIteration
        refresh_stage = "CONFIGURATION"
        if provider not in {"newsdata", "marketaux"}:
            raise ValueError("fri_news_provider must be newsdata or marketaux")
        secret_key = "fri_newsdata_api_key" if provider == "newsdata" else "fri_marketaux_api_key"
        environment_key = "NEWSDATA_API_KEY" if provider == "newsdata" else "MARKETAUX_API_KEY"
        api_key = database_secret(secret_key) or os.environ.get(environment_key, "")
        print(f"RELEVANT_NEWS[{request_id}] provider={provider} secret={secret_key} configured={bool(api_key)}", flush=True)
        if not api_key:
            raise ValueError(f"Database secret {secret_key} is not configured")
        refresh_stage = "ENGINE_LOADING"
        engine = financial_news_engine()
        engine_location = text(getattr(engine, "__file__", "")) or text(getattr(engine, "__name__", ""))
        print(f"RELEVANT_NEWS[{request_id}] engine={engine_location}", flush=True)
        market_query = f"top {limit} negative news on {company}"
        refresh_stage = "MARKETAUX_REQUEST"
        max_pages = max(1, min(5, integer(variables.get("fri_relevant_news_max_pages"), 3)))
        if hasattr(engine, "generate_relevant_news"):
            fetched = engine.generate_relevant_news(
                company_name=company,
                api_key=api_key,
                top_n=limit,
                max_pages=max_pages,
                direction="negative",
                provider=provider,
            )
            market_query = text(fetched.get("market_query")) or market_query
        else:
            # Backward-compatible fallback for a temporarily stale Dataiku
            # project-library copy during deployment.
            fetched = engine.structured_results(
                question=market_query,
                api_key=api_key,
                max_pages=max_pages,
                provider=provider,
            )
        fetched_count = len(fetched.get("articles") or [])
        pool_size = integer(fetched.get("pool_size"), 0)
        query_attempts = fetched.get("query_attempts") or []
        print(json.dumps({"event": "RELEVANT_NEWS_FETCHED", "request_id": request_id,
                          "query": market_query, "pool_size": pool_size,
                          "matching_article_count": fetched_count}), flush=True)
        refresh_stage = "DATABASE_SAVE"
        appended = persist_company_news(company_key, company, fetched.get("articles") or [])
        print(f"RELEVANT_NEWS[{request_id}] appended={appended} duplicates_or_updated={fetched_count-appended}", flush=True)
        refresh_stage = "COMPLETED"
    except StopIteration:
        pass
    except Exception as exc:
        refresh_error = f"{type(exc).__name__}: {exc}"
        print(f"RELEVANT_NEWS[{request_id}] failed stage={refresh_stage}: {refresh_error}", flush=True)
    try:
        news = saved_company_news(company_key, limit)
    except Exception as exc:
        print(f"RELEVANT_NEWS[{request_id}] database read failed: {type(exc).__name__}: {exc}", flush=True)
        return jsonify({"error": f"Relevant-news database is unavailable: {type(exc).__name__}: {exc}"}), 503
    print(f"RELEVANT_NEWS[{request_id}] completed saved_count={len(news)}", flush=True)
    return jsonify({
        "request_id": request_id,
        "company": company, "company_key": company_key, "news": news,
        "count": len(news), "appended_count": appended,
        "refresh_requested": refresh_requested,
        "refresh_stage": refresh_stage,
        "market_query": market_query,
        "pool_size": pool_size,
        "query_attempts": query_attempts,
        "fetched_count": fetched_count,
        "engine_location": engine_location,
        "provider": provider,
        "retained_existing": appended == 0 and bool(news),
        "company_name_source": company_resolution["source"],
        "refresh_error": refresh_error, "source": "POSTGRESQL + FRI_RELEVANT_NEWS_ENGINE",
    })


def narrative_stream_line(event: str, **payload: Any) -> str:
    return json.dumps({"event": event, **payload}, default=str) + "\n"


@app.route("/api/forensic-narrative-stream", methods=["POST"])
def forensic_narrative_stream():
    """Generate Bedrock narratives and stream backend progress as NDJSON."""
    body = request.get_json(silent=True) or {}
    run_id = text(body.get("assessment_run_id"))
    document_id = text(body.get("source_document_id"))

    @stream_with_context
    def generate():
        if not run_id or not document_id:
            yield narrative_stream_line("error", message="assessment_run_id and source_document_id are required")
            return
        if not llm_feature_enabled("fri_llm_narrative_enabled", False):
            yield narrative_stream_line("completed", status="LLM_FEATURE_DISABLED",
                                        llm_skipped=True,
                                        message="Narrative generation is temporarily disabled to reserve provider capacity for missing financial values.")
            return
        yield narrative_stream_line("stage", stage="configuration", message="Loading database runtime configuration")
        try:
            settings = financial_resolution_llm_configuration()
        except RuntimeError as exc:
            yield narrative_stream_line("error", message=str(exc))
            return
        if settings["provider"] not in {"bedrock", "gemini"}:
            yield narrative_stream_line("error", message="Forensic narrative requires fri_llm_provider=bedrock or gemini")
            return
        yield narrative_stream_line("configuration", model=settings["model"], base_url=settings["base_url"])

        scores = rows_for_filing(read_optional(FORENSIC_SCORES_DATASET), run_id, document_id)
        if not scores:
            yield narrative_stream_line("error", message="No Dataiku forensic scores are available. Run FRI_05_SCORE_SECTOR_FORENSICS first.")
            return
        fingerprint = score_fingerprint(scores)
        saved = load_saved_narrative(document_id, fingerprint)
        if saved and text((saved.get("provenance") or {}).get("model")) == settings["model"]:
            yield narrative_stream_line("stage", stage="persistence", message="Loaded saved narrative for the current score values")
            score_items = saved.get("authoritative_scores") or []
            interpretations = (saved.get("narrative") or {}).get("score_interpretations") or []
            for sequence, score_item in enumerate(score_items, start=1):
                key = text(score_item.get("model_key"))
                name = text(score_item.get("model_name")) or key
                matching = next((item for item in interpretations if key and key in text(item.get("model_key")).lower()), None)
                partial = {
                    "summary": (saved.get("narrative") or {}).get("summary", ""),
                    "overall_assessment": (matching or {}).get("interpretation", (saved.get("narrative") or {}).get("overall_assessment", "")),
                    "score_interpretations": [matching] if matching else [],
                    "key_risk_signals": [], "recommended_actions": [], "limitations": [],
                }
                yield narrative_stream_line("score_start", model_key=key, model_name=name, sequence=sequence, total=len(score_items), score=score_item)
                yield narrative_stream_line("score_complete", model_key=key, model_name=name, payload=partial)
            yield narrative_stream_line("final", payload=saved)
            return
        facts, fact_source = resolved_values()
        fact_rows = rows_for_filing(facts, run_id, document_id)
        registration = registration_lookup().get(document_id, {})
        sector = infer_sector(fact_rows)
        evidence = narrative_evidence(document_id, ollama_configuration())
        if not evidence:
            yield narrative_stream_line("error", message="No annual-report evidence is available in FRI_DOCUMENT_FRAGMENTS.")
            return
        yield narrative_stream_line(
            "stage", stage="evidence", message="Prepared governed source package",
            score_count=len(scores), fact_count=len(fact_rows),
            evidence_pages=sorted(item["page_number"] for item in evidence),
        )

        compact_facts = [{
            "concept_key": text(row.get("concept_key")), "current_period": text(row.get("current_period")),
            "prior_period": text(row.get("prior_period")), "current_value": number(row.get("current_value")),
            "prior_value": number(row.get("prior_value")), "currency": text(row.get("currency")),
            "unit": text(row.get("unit")),
            "resolution_method": text(row.get("resolution_method") or row.get("selection_method")),
        } for row in fact_rows if text(row.get("concept_key"))]
        score_contract = [{
            "model_key": text(row.get("model_key")), "model_name": text(row.get("model_name")),
            "status": text(row.get("status")), "score": number(row.get("score")),
            "risk_band": text(row.get("risk_band")), "components": row.get("components_json"),
            "configuration_version": text(row.get("configuration_version")),
        } for row in scores]
        source_package = {
            "company": registration.get("entity_key") or next((text(row.get("entity_name") or row.get("entity_id")) for row in fact_rows if text(row.get("entity_name") or row.get("entity_id"))), "Unknown entity"),
            "file_name": registration.get("file_name") or document_id, "sector": sector,
            "financial_facts": compact_facts,
            "annual_report_evidence": evidence,
        }
        model_sequence = [
            ("montier", "Montier C-Score"),
            ("altman", "Altman Z double-prime"),
            ("sloan", "Sloan Accruals Ratio"),
            ("beneish", "Beneish M-Score"),
            ("piotroski", "Piotroski F-Score"),
        ]
        model_fact_keys = {
            "montier": {"net_profit", "operating_cash_flow", "trade_receivables_net", "revenue", "total_current_assets", "inventory", "depreciation_amortization", "net_ppe", "total_assets", "cost_of_goods_sold"},
            "altman": {"total_current_assets", "total_current_liabilities", "total_assets", "retained_earnings", "operating_income_ebit", "total_shareholders_equity", "total_liabilities"},
            "sloan": {"net_profit", "operating_cash_flow", "total_assets"},
            "beneish": {"revenue", "trade_receivables_net", "cost_of_goods_sold", "total_current_assets", "net_ppe", "total_assets", "depreciation_amortization", "sg_and_a_expense", "total_current_liabilities", "long_term_debt", "net_profit", "operating_cash_flow"},
            "piotroski": {"net_profit", "total_assets", "operating_cash_flow", "long_term_debt", "total_current_assets", "total_current_liabilities", "shares_outstanding", "revenue", "cost_of_goods_sold"},
        }
        model_evidence_terms = {
            "montier": ("cash flow", "receivable", "inventory", "depreciation", "asset"),
            "altman": ("going concern", "debt", "borrow", "liquidity", "liabilit"),
            "sloan": ("cash flow", "accrual", "profit", "earnings"),
            "beneish": ("revenue", "receivable", "inventory", "depreciation", "audit", "management"),
            "piotroski": ("profit", "cash flow", "debt", "liquidity", "margin", "revenue"),
        }
        model_guidance = {
            "montier": "0 to <2 LOW, 2 to <4 ELEVATED, 4 to 6 HIGH. Screens earnings-quality warning signals such as cash conversion, receivables, inventory, depreciation and asset growth; it is not proof of manipulation.",
            "altman": ">2.6 LOW, 1.1 to 2.6 ELEVATED, <1.1 HIGH. Indicates relative solvency/distress risk from liquidity, retained earnings, operating return and equity-to-liabilities; it is a screening indicator, not a default prediction.",
            "sloan": "Ratio=(net profit-operating cash flow)/average total assets. >0.10 HIGH, >0.05 ELEVATED, otherwise LOW. A negative ratio generally means cash flow exceeds accounting profit and lowers accrual-quality concern; it does not by itself prove effective working-capital management.",
            "beneish": ">-1.78 HIGH, otherwise LOW. Screens for possible earnings manipulation using eight indices; a high result requires investigation but is not proof of manipulation.",
            "piotroski": "7-9 LOW, 4-6 ELEVATED, 0-3 HIGH. Measures fundamental financial strength across profitability, leverage/liquidity and operating efficiency; a middle score indicates mixed signals, not financial distress by itself.",
        }
        scores_by_key = {
            item["model_key"].lower(): item for item in score_contract
            if item["model_key"] and item["status"].upper().startswith("SCORED") and item["score"] is not None
        }
        ordered_scores = [(key, name, scores_by_key[key]) for key, name in model_sequence if key in scores_by_key]
        if not ordered_scores:
            yield narrative_stream_line("error", message="None of the configured forensic scores are available for narrative generation.")
            return

        system_prompt = (
            "You are a senior forensic-accounting reviewer. Explain one authoritative Dataiku score without recalculating or changing it. "
            "Follow score_guidance exactly. Do not infer financial distress, manipulation, trend, cause, or effectiveness beyond that guidance. "
            "Use facts only to explain components. Never invent differences or amounts. Add a risk signal only when an evidence excerpt explicitly supports it; otherwise use limitations. "
            "Write polished English with normal spaces between every word. Bad: 'Thecompanyhas'. Good: 'The company has'. "
            "Keep summary and assessment to 2 sentences each, interpretations to 3 sentences, risk signals to 2, actions to 3. "
            "Cite only supplied evidence page values. Return JSON only: {summary,overall_assessment,score_interpretations:[{model_key,interpretation}],"
            "key_risk_signals:[{severity,category,signal,evidence,source_pages}],recommended_actions,limitations}."
        )
        completed = []
        failed = []
        for sequence, (model_key, display_name, score_item) in enumerate(ordered_scores, start=1):
            components = score_item.get("components")
            if isinstance(components, str):
                try:
                    components = json.loads(components)
                except json.JSONDecodeError:
                    components = {}
            components = components if isinstance(components, dict) else {}
            governed_score = {**score_item, "components": {
                key: value for key, value in components.items()
                if key not in {"alias_input_fallbacks", "calculation_assumptions"}
            }}
            relevant_facts = []
            for fact in compact_facts:
                method = text(fact.get("resolution_method")).upper()
                if fact.get("concept_key") not in model_fact_keys[model_key]:
                    continue
                if "FALLBACK" in method or "ALIAS" in method:
                    continue
                relevant_facts.append(fact)
            terms = model_evidence_terms[model_key]
            ranked_evidence = []
            for item in evidence:
                content = re.sub(r"\s+", " ", text(item.get("content"))).strip()
                relevance = sum(content.lower().count(term) for term in terms)
                if relevance <= 0:
                    continue
                matching_sentences = [
                    sentence.strip() for sentence in re.split(r"(?<=[.!?;])\s+", content)
                    if any(term in sentence.lower() for term in terms)
                ]
                excerpt = " ".join(matching_sentences[:3])
                if not excerpt:
                    positions = [content.lower().find(term) for term in terms if term in content.lower()]
                    start = max(0, min(positions) - 180) if positions else 0
                    excerpt = content[start:start + 650]
                ranked_evidence.append((relevance, {
                    "page": item["page_number"], "excerpt": excerpt[:700],
                }))
            ranked_evidence.sort(key=lambda pair: (-pair[0], pair[1]["page"]))
            relevant_evidence = [item for _, item in ranked_evidence[:2]]
            period_pair = next((
                [fact.get("current_period"), fact.get("prior_period")] for fact in relevant_facts
                if fact.get("current_period") or fact.get("prior_period")
            ), [])
            compact_fact_values = {
                fact["concept_key"]: [fact.get("current_value"), fact.get("prior_value")]
                for fact in relevant_facts
            }
            compact_components = {
                key: round(value, 6) if isinstance(value, float) else value
                for key, value in governed_score["components"].items()
            }
            compact_score = {
                "model_key": governed_score["model_key"], "score": round(governed_score["score"], 6),
                "risk_band": governed_score["risk_band"], "components": compact_components,
            }
            score_package = {
                "company": source_package["company"], "filing": source_package["file_name"],
                "score_name": display_name, "score": compact_score,
                "score_guidance": model_guidance[model_key],
                "periods": period_pair, "fact_values_current_prior": compact_fact_values,
                "evidence": relevant_evidence,
                "request": "Comment on this score, related risk areas, cited evidence, and focused review actions.",
            }
            request_payload = {
                "model": settings["model"], "stream": False,
                "response_format": {"type": "json_object"}, "temperature": 0.1,
                "messages": [{"role": "system", "content": system_prompt}, {"role": "user", "content": json.dumps(score_package, default=str)}],
            }
            yield narrative_stream_line("score_start", model_key=model_key, model_name=display_name, sequence=sequence, total=len(ordered_scores), score=governed_score)
            yield narrative_stream_line("prompt", model_key=model_key, model_name=display_name, system_prompt=system_prompt, source_package=score_package)
            raw_parts = []
            try:
                response = requests.post(
                    settings["base_url"].rstrip("/") + "/chat/completions", json=request_payload,
                    headers={"Authorization": "Bearer " + settings["api_key"], "Content-Type": "application/json"},
                    timeout=(5, settings["timeout_seconds"]),
                )
                response.raise_for_status()
                response_body = response.json()
                token = text((((response_body.get("choices") or [{}])[0].get("message") or {}).get("content")))
                if token:
                    raw_parts.append(token)
                    yield narrative_stream_line("token", model_key=model_key, model_name=display_name, content=token)
            except (requests.RequestException, json.JSONDecodeError) as exc:
                failed.append(f"{display_name}: request failed ({type(exc).__name__})")
                yield narrative_stream_line("score_error", model_key=model_key, model_name=display_name, message=failed[-1])
                continue
            try:
                parsed_narrative = parse_ollama_json("".join(raw_parts))
                if not narrative_spacing_is_readable(parsed_narrative):
                    repair_payload = {
                        "model": settings["model"], "stream": False,
                        "response_format": {"type": "json_object"}, "temperature": 0,
                        "messages": [
                            {"role": "system", "content": "Restore normal English word spacing in this JSON. Preserve every key, number, page citation and meaning exactly. Return JSON only."},
                            {"role": "user", "content": json.dumps(parsed_narrative, default=str)},
                        ],
                    }
                    repair_response = requests.post(
                        settings["base_url"].rstrip("/") + "/chat/completions", json=repair_payload,
                        headers={"Authorization": "Bearer " + settings["api_key"], "Content-Type": "application/json"},
                        timeout=(5, settings["timeout_seconds"]),
                    )
                    repair_response.raise_for_status()
                    repair_body = repair_response.json()
                    parsed_narrative = parse_ollama_json(text(((((repair_body.get("choices") or [{}])[0]).get("message") or {}).get("content"))))
                    if not narrative_spacing_is_readable(parsed_narrative):
                        raise ValueError("response prose did not contain readable word spacing")
                relevant_pages = {item["page"] for item in relevant_evidence}
                score_narrative = validate_narrative(parsed_narrative, relevant_pages, {model_key})
                if not score_narrative["score_interpretations"]:
                    score_narrative["score_interpretations"] = [{"model_key": model_key, "interpretation": score_narrative["overall_assessment"]}]
                for interpretation in score_narrative["score_interpretations"]:
                    interpretation["model_key"] = f"{display_name} ({model_key})"
                completed.append((display_name, score_narrative))
                yield narrative_stream_line(
                    "score_complete", model_key=model_key, model_name=display_name,
                    payload=score_narrative,
                )
            except (requests.RequestException, ValueError, json.JSONDecodeError, TypeError) as exc:
                failed.append(f"{display_name}: invalid model response ({exc})")
                yield narrative_stream_line("score_error", model_key=model_key, model_name=display_name, message=failed[-1])

        if not completed:
            yield narrative_stream_line("error", message="Bedrock did not return a usable response for any forensic score.")
            return
        narrative = {
            "summary": "\n\n".join(f"{name}: {item['summary']}" for name, item in completed),
            "overall_assessment": "\n\n".join(f"{name}: {item['overall_assessment']}" for name, item in completed),
            "score_interpretations": [], "key_risk_signals": [],
            "recommended_actions": [], "limitations": failed[:],
        }
        for _, item in completed:
            narrative["score_interpretations"].extend(item["score_interpretations"])
            narrative["key_risk_signals"].extend(item["key_risk_signals"])
            for field in ("recommended_actions", "limitations"):
                for value in item[field]:
                    if value not in narrative[field]:
                        narrative[field].append(value)
        final_payload = {
            "narrative": narrative, "authoritative_scores": score_contract,
            "company_context": {"company": source_package["company"], "file_name": source_package["file_name"], **sector},
            "evidence_pages": sorted(item["page_number"] for item in evidence),
            "provenance": {"model": settings["model"], "provider": "bedrock", "base_url": settings["base_url"],
                           "score_source": FORENSIC_SCORES_DATASET, "fact_source": fact_source,
                           "evidence_source": DOCUMENT_FRAGMENTS_DATASET, "score_values_generated_by_model": False},
            "score_fingerprint": fingerprint,
        }
        save_narrative(run_id, document_id, fingerprint, final_payload)
        yield narrative_stream_line("final", payload=final_payload)

    return Response(
        generate(), mimetype="application/x-ndjson",
        headers={"Cache-Control": "no-cache, no-transform", "X-Accel-Buffering": "no"},
    )


@app.route("/api/debug", methods=["GET"])
def debug():
    values, source = resolved_values()

    statement_counts = {}

    if not values.empty and "statement_type" in values.columns:
        statement_counts = {
            str(key): int(value)
            for key, value in values["statement_type"]
            .map(canonical_statement)
            .value_counts()
            .to_dict()
            .items()
        }

    return jsonify(
        {
            "data_source": source,
            "total_rows": int(len(values)),
            "statement_counts": statement_counts,
            "balance_dataset": BALANCE_INPUTS_DATASET,
            "income_dataset": INCOME_INPUTS_DATASET,
            "canonical_dataset": CANONICAL_FACTS_DATASET,
            "sector_template_dataset": SECTOR_TEMPLATE_VALUES_DATASET,
            "table_json_dataset": TABLE_JSON_DATASET,
            "canonical_rows": int(len(read_optional(CANONICAL_FACTS_DATASET))),
            "sector_template_rows": int(len(read_optional(SECTOR_TEMPLATE_VALUES_DATASET))),
            "sample_columns": (
                values.columns.tolist()
                if not values.empty
                else []
            ),
        }
    )


@app.route("/", methods=["GET"])
def index():
    values, source = resolved_values()

    return jsonify(
        {
            "service": "FRI Financial Input Validation",
            "status": "running",
            "data_source": source,
            "row_count": int(len(values)),
            "endpoints": [
                "/api/health",
                "/api/contexts",
                "/api/statements",
                "/api/debug",
            ],
        }
    )

# Do not add app.run().
# Dataiku starts the webapp server automatically.
