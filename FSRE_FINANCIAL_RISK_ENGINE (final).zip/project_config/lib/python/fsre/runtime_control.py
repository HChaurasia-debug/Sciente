from __future__ import annotations

import hashlib
import json
import os
from typing import Any, Optional


def _fetchone(cur: Any, sql: str, params: tuple[Any, ...]) -> Optional[dict[str, Any]]:
    cur.execute(sql, params)
    row = cur.fetchone()
    return dict(row) if row else None


def load_runtime_request(
    cur: Any,
    request_type: str,
    request_id: Optional[str] = None,
    environment: Optional[str] = None,
    requested_by: Optional[str] = None,
    mark_running: bool = True,
) -> dict[str, Any]:
    if request_id:
        row = _fetchone(
            cur,
            """
            SELECT *
            FROM fsre_config.runtime_requests
            WHERE request_id = %s
              AND request_type = %s
            """,
            (request_id, request_type),
        )
    else:
        params: list[Any] = [request_type]
        environment_filter = ""
        if environment:
            environment_filter = "AND environment = %s"
            params.append(environment)
        requested_by_filter = ""
        if requested_by:
            requested_by_filter = "AND requested_by = %s"
            params.append(requested_by)
        row = _fetchone(
            cur,
            f"""
            SELECT *
            FROM fsre_config.runtime_requests
            WHERE request_type = %s
              AND status = 'pending'
              {environment_filter}
              {requested_by_filter}
            ORDER BY priority ASC, created_at ASC
            LIMIT 1
            """,
            tuple(params),
        )

    if not row:
        raise ValueError(
            f"No runtime request found for request_type={request_type}, "
            f"request_id={request_id}, environment={environment}"
        )

    if mark_running:
        cur.execute(
            """
            UPDATE fsre_config.runtime_requests
            SET status = 'running',
                started_at = COALESCE(started_at, now()),
                consumed_at = COALESCE(consumed_at, now())
            WHERE request_id = %s
            """,
            (row["request_id"],),
        )

    return row


def load_runtime_defaults(
    cur: Any,
    parameter_scope: str,
    environment: Optional[str] = None,
) -> dict[str, Any]:
    params: list[Any] = [parameter_scope]
    environment_filter = ""
    if environment:
        environment_filter = "AND environment = %s"
        params.append(environment)

    row = _fetchone(
        cur,
        f"""
        SELECT parameters_json
        FROM fsre_config.runtime_parameter_sets
        WHERE parameter_scope = %s
          AND status = 'active'
          AND is_default = TRUE
          {environment_filter}
        ORDER BY updated_at DESC, created_at DESC
        LIMIT 1
        """,
        tuple(params),
    )
    if not row:
        raise ValueError(
            f"No active default runtime parameter set found for scope={parameter_scope}"
        )

    parameters = row["parameters_json"]
    if isinstance(parameters, str):
        parameters = json.loads(parameters)
    if not isinstance(parameters, dict):
        raise ValueError(
            f"Runtime default parameters for scope={parameter_scope} must be a JSON object"
        )
    return parameters


def complete_runtime_request(
    cur: Any,
    request_id: str,
    run_id: Optional[str] = None,
    status: str = "completed",
    error_message: Optional[str] = None,
) -> None:
    cur.execute(
        """
        UPDATE fsre_config.runtime_requests
        SET status = %s,
            run_id = COALESCE(%s, run_id),
            error_message = %s,
            completed_at = now()
        WHERE request_id = %s
        """,
        (status, run_id, error_message, request_id),
    )


def create_runtime_request(
    cur: Any,
    request_type: str,
    request_json: dict[str, Any],
    request_name: Optional[str] = None,
    requested_by: Optional[str] = None,
    environment: Optional[str] = None,
    run_id: Optional[str] = None,
    profile_id: Optional[str] = None,
    profile_version: Optional[str] = None,
    parent_request_id: Optional[str] = None,
    priority: int = 100,
) -> dict[str, Any]:
    if not environment:
        raise ValueError("runtime request environment must be provided by database configuration")

    request_json_text = json.dumps(request_json, sort_keys=True, default=str)
    request_hash = hashlib.sha256(request_json_text.encode("utf-8")).hexdigest()
    cur.execute(
        """
        INSERT INTO fsre_config.runtime_requests (
            request_type,
            request_name,
            requested_by,
            environment,
            profile_id,
            profile_version,
            run_id,
            parent_request_id,
            priority,
            request_json,
            request_hash
        )
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s::jsonb, %s)
        RETURNING *
        """,
        (
            request_type,
            request_name,
            requested_by,
            environment,
            profile_id,
            profile_version,
            run_id,
            parent_request_id,
            priority,
            request_json_text,
            request_hash,
        ),
    )
    return dict(cur.fetchone())


def create_document_ingestion_request_from_registry(
    cur: Any,
    run_id: str,
    selected_entity_id: str,
    selected_document_id: str,
    requested_by: str,
    environment: str,
    parent_request_id: Optional[str] = None,
) -> dict[str, Any]:
    document = _fetchone(
        cur,
        """
        SELECT *
        FROM fsre_config.source_document_registry
        WHERE source_document_id = %s
          AND status = 'ready'
          AND (entity_id = %s OR entity_id IS NULL)
        ORDER BY
          CASE WHEN entity_id = %s THEN 0 ELSE 1 END,
          updated_at DESC,
          created_at DESC
        LIMIT 1
        """,
        (selected_document_id, selected_entity_id, selected_entity_id),
    )
    if not document:
        raise ValueError(
            "No ready source document registered for selected_document_id="
            f"{selected_document_id}, selected_entity_id={selected_entity_id}. "
            "Register the uploaded/selected financial statement in "
            "fsre_config.source_document_registry before running recipe 01."
        )

    request_json = {
        "run_id": run_id,
        "selected_entity_id": selected_entity_id,
        "source_document_id": document["source_document_id"],
        "document_type": document["document_type"],
        "document_name": document["document_name"],
        "reporting_period_label": document["reporting_period_label"],
        "document_date": str(document["document_date"]) if document["document_date"] else None,
        "managed_folder_id": document["managed_folder_id"],
        "file_name": document["file_name"],
        "document_path": document["document_path"],
        "source_url": document["source_url"],
        "storage_uri": document["storage_uri"],
        "connector_id": document["connector_id"],
        "connector_version": document["connector_version"],
        "requested_by": requested_by,
    }
    request_json = {
        key: value
        for key, value in request_json.items()
        if value not in (None, "")
    }

    return create_runtime_request(
        cur,
        request_type="document_ingestion",
        request_name=f"Document ingestion for {document['source_document_id']}",
        requested_by=requested_by,
        environment=environment,
        run_id=run_id,
        parent_request_id=parent_request_id,
        request_json=request_json,
    )


def get_bootstrap_request_id(variable_name: str) -> Optional[str]:
    try:
        import dataiku  # type: ignore

        variables = dataiku.get_custom_variables()
        value = variables.get(variable_name)
        if value:
            return str(value)
    except Exception:
        pass
    return os.getenv(variable_name)


def merge_parameter_defaults(request_row: dict[str, Any], payload: dict[str, Any]) -> dict[str, Any]:
    parameters = request_row.get("parameters_json")
    if isinstance(parameters, str):
        parameters = json.loads(parameters)
    if not isinstance(parameters, dict):
        parameters = {}
    merged = dict(parameters)
    merged.update(payload)
    return merged
