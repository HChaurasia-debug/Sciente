from __future__ import annotations

import os
from contextlib import contextmanager
from dataclasses import dataclass
from typing import Any, Iterator, Optional


@dataclass(frozen=True)
class PostgresConfig:
    host: str
    port: int
    database: str
    user: str
    password: Optional[str] = None

    @classmethod
    def from_env(cls) -> "PostgresConfig":
        dataiku_vars = _get_dataiku_variables()
        return cls(
            host=_get_config_value(dataiku_vars, "fsre_pg_host", "PGHOST", "fsre-postgres"),
            port=int(_get_config_value(dataiku_vars, "fsre_pg_port", "PGPORT", "5432")),
            database=_get_config_value(dataiku_vars, "fsre_pg_database", "PGDATABASE", "fsre"),
            user=_get_config_value(dataiku_vars, "fsre_pg_user", "PGUSER", "fsre_admin"),
            password=_get_config_value(dataiku_vars, "fsre_pg_password", "PGPASSWORD", None),
        )


def _get_dataiku_variables() -> dict[str, Any]:
    try:
        import dataiku  # type: ignore
    except ImportError:
        return {}

    try:
        return dataiku.get_custom_variables()
    except Exception:
        return {}


def _get_config_value(
    dataiku_vars: dict[str, Any],
    dataiku_key: str,
    env_key: str,
    default: Optional[str],
) -> Optional[str]:
    value = dataiku_vars.get(dataiku_key)
    if value not in (None, ""):
        return str(value)
    return os.getenv(env_key, default)


@contextmanager
def connect(config: Optional[PostgresConfig] = None) -> Iterator[object]:
    """Open a PostgreSQL connection using psycopg2.

    Dataiku code environments can install psycopg2-binary. The rest of the
    application is kept separate from this adapter so Dataiku SQLExecutor2 can
    be introduced later without changing product logic.
    """
    try:
        import psycopg2
        import psycopg2.extras
    except ImportError as exc:
        raise RuntimeError(
            "psycopg2 is required for local PostgreSQL execution. "
            "Install psycopg2-binary in the Dataiku code environment or run "
            "this from an environment that already includes psycopg2."
        ) from exc

    cfg = config or PostgresConfig.from_env()
    kwargs = {
        "host": cfg.host,
        "port": cfg.port,
        "dbname": cfg.database,
        "user": cfg.user,
        "cursor_factory": psycopg2.extras.RealDictCursor,
    }
    if cfg.password:
        kwargs["password"] = cfg.password

    conn = psycopg2.connect(**kwargs)
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
