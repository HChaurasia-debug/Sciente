from __future__ import annotations

import json
import re
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from difflib import SequenceMatcher
from inspect import signature
from typing import Any, Callable, Optional

from fsre.extraction_foundation import (
    get_run_context,
    json_dumps,
    next_period_label,
    normalize_period_label,
    prior_period_label,
    split_required_field_path,
)


SEVERITY_ORDER = {
    "NONE": 0,
    "LOW": 1,
    "MEDIUM": 2,
    "HIGH": 3,
    "CRITICAL": 4,
}


@dataclass(frozen=True)
class RuleCalculation:
    triggered: bool
    severity: str
    computed_value: Optional[Decimal]
    metric: str
    explanation: str
    result_json: dict[str, Any]


def _fetchone(cur: Any, sql: str, params: tuple[Any, ...]) -> Optional[dict[str, Any]]:
    cur.execute(sql, params)
    row = cur.fetchone()
    return dict(row) if row else None


def _fetchall(cur: Any, sql: str, params: tuple[Any, ...]) -> list[dict[str, Any]]:
    cur.execute(sql, params)
    return [dict(row) for row in cur.fetchall()]


def to_decimal(value: Any) -> Optional[Decimal]:
    if value in (None, ""):
        return None
    try:
        return Decimal(str(value))
    except (InvalidOperation, ValueError):
        return None


def load_rules_for_run(cur: Any, run_id: str) -> list[dict[str, Any]]:
    return _fetchall(
        cur,
        """
        SELECT
            m.rule_id,
            m.rule_version,
            max(m.rule_name) AS rule_name,
            min(m.execution_order) AS execution_order,
            rr.category,
            rr.implementation_key,
            rr.threshold_config_json,
            rr.explanation_template
        FROM fsre_rules.run_required_field_manifest m
        JOIN fsre_rules.rule_registry rr
          ON rr.rule_id = m.rule_id
         AND rr.rule_version = m.rule_version
        WHERE m.run_id = %s
          AND rr.status = 'active'
        GROUP BY
            m.rule_id,
            m.rule_version,
            rr.category,
            rr.implementation_key,
            rr.threshold_config_json,
            rr.explanation_template
        ORDER BY min(m.execution_order) NULLS LAST, m.rule_id
        """,
        (run_id,),
    )


def load_validation_rows(cur: Any, run_id: str, rule_id: str, rule_version: str) -> list[dict[str, Any]]:
    return _fetchall(
        cur,
        """
        SELECT *
        FROM fsre_rules.rule_input_validation_results
        WHERE run_id = %s
          AND rule_id = %s
          AND rule_version = %s
        ORDER BY required_field_path
        """,
        (run_id, rule_id, rule_version),
    )


def load_resolved_inputs(cur: Any, validation_rows: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    resolved_ids = [
        str(row["resolved_field_id"])
        for row in validation_rows
        if row.get("resolved_field_id")
    ]
    if not resolved_ids:
        return {}

    rows = _fetchall(
        cur,
        """
        SELECT *
        FROM fsre_ingestion.resolved_fields
        WHERE resolved_field_id::text = ANY(%s)
        """,
        (resolved_ids,),
    )
    by_id = {str(row["resolved_field_id"]): row for row in rows}
    inputs: dict[str, dict[str, Any]] = {}
    for validation in validation_rows:
        resolved_id = validation.get("resolved_field_id")
        if not resolved_id or str(resolved_id) not in by_id:
            continue
        inputs[str(validation["required_field_path"])] = {
            "validation": validation,
            "field": by_id[str(resolved_id)],
        }
    return inputs


def load_optional_rule_inputs(
    cur: Any,
    context: Any,
    rule: dict[str, Any],
    inputs: dict[str, dict[str, Any]],
) -> dict[str, dict[str, Any]]:
    config = rule_config(rule)
    optional_fields = config.get("optional_fields") or []
    if isinstance(optional_fields, str):
        optional_fields = [optional_fields]
    if not isinstance(optional_fields, list) or not optional_fields:
        return inputs

    current_period = normalize_period_label(context.reporting_period_label)
    prior_period = prior_period_label(current_period)
    next_period = next_period_label(current_period)
    merged = dict(inputs)
    for optional_path in optional_fields:
        required_path = str(optional_path)
        if required_path in merged:
            continue
        canonical_path, period_role = split_required_field_path(required_path)
        expected_period = expected_period_for_role(
            period_role,
            current_period,
            prior_period,
            next_period,
        )
        resolved = load_resolved_field(
            cur,
            context,
            canonical_path,
            expected_period,
            period_role,
        )
        if not resolved:
            continue
        merged[required_path] = {
            "validation": {
                "required_field_path": required_path,
                "canonical_field_path": canonical_path,
                "period_role": period_role,
                "expected_period_label": expected_period,
                "validation_status": "optional",
            },
            "field": resolved,
        }
    return merged


def expected_period_for_role(
    period_role: str,
    current_period: Optional[str],
    prior_period: Optional[str],
    next_period: Optional[str],
) -> Optional[str]:
    if period_role == "current":
        return current_period
    if period_role == "prior":
        return prior_period
    if period_role == "next_period":
        return next_period
    return None


def load_resolved_field(
    cur: Any,
    context: Any,
    field_path: str,
    expected_period: Optional[str],
    period_role: str,
) -> Optional[dict[str, Any]]:
    params: list[Any] = [context.run_id, field_path]
    period_filter = ""
    if expected_period:
        period_filter = "AND period_label = %s"
        params.append(expected_period)
    elif period_role not in {"unspecified", "any"}:
        period_filter = "AND period_role = %s"
        params.append(period_role)

    raw_document_filter = ""
    if not expected_period:
        raw_document_filter = "AND raw_document_id = %s"
        params.append(context.raw_document_id)

    entity_filter = ""
    if context.entity_id:
        entity_filter = "AND (entity_id = %s OR entity_id IS NULL)"
        params.append(context.entity_id)

    return _fetchone(
        cur,
        f"""
        SELECT *
        FROM fsre_ingestion.resolved_fields
        WHERE run_id = %s
          AND field_path = %s
          AND is_accepted = TRUE
          {period_filter}
          {raw_document_filter}
          {entity_filter}
        ORDER BY
          CASE WHEN raw_document_id = %s THEN 0 ELSE 1 END,
          confidence_score DESC NULLS LAST,
          created_at DESC
        LIMIT 1
        """,
        tuple(params + [context.raw_document_id]),
    )


def validation_summary(validation_rows: list[dict[str, Any]]) -> dict[str, int]:
    summary = {"pass": 0, "warn": 0, "fail": 0, "blocked": 0}
    for row in validation_rows:
        status = str(row.get("validation_status") or "")
        if status in summary:
            summary[status] += 1
    return summary


def blocking_rows(validation_rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [
        row
        for row in validation_rows
        if row.get("validation_status") in {"fail", "blocked"}
    ]


def get_input_value(inputs: dict[str, dict[str, Any]], required_path: str) -> Decimal:
    item = inputs.get(required_path)
    if not item:
        raise ValueError(f"Missing resolved input: {required_path}")
    value = to_decimal(item["field"].get("normalized_value_numeric"))
    if value is None:
        raise ValueError(f"Resolved input is not numeric: {required_path}")
    return value


def get_optional_input_value(
    inputs: dict[str, dict[str, Any]],
    required_path: str,
) -> Optional[Decimal]:
    item = inputs.get(required_path)
    if not item:
        return None
    return to_decimal(item["field"].get("normalized_value_numeric"))


def get_input_text(inputs: dict[str, dict[str, Any]], required_path: str) -> str:
    item = inputs.get(required_path)
    if not item:
        raise ValueError(f"Missing resolved input: {required_path}")
    field = item["field"]
    # Preserve the value exactly as captured from the financial statement.
    # normalized_value_text is retained only as a legacy fallback for records
    # created before raw source values were persisted.
    value = field.get("raw_value_text") or field.get("normalized_value_text")
    text = str(value or "").strip()
    if not text:
        raise ValueError(f"Resolved input text is empty: {required_path}")
    return text


def get_optional_input_text(
    inputs: dict[str, dict[str, Any]],
    required_path: str,
) -> Optional[str]:
    item = inputs.get(required_path)
    if not item:
        return None
    field = item["field"]
    value = field.get("raw_value_text") or field.get("normalized_value_text")
    text = str(value or "").strip()
    return text or None


def get_resolved_numeric(
    cur: Any,
    context: Any,
    field_path: str,
    period_role: str,
) -> Optional[Decimal]:
    current_period = normalize_period_label(context.reporting_period_label)
    prior_period = prior_period_label(current_period)
    next_period = next_period_label(current_period)
    expected_period = expected_period_for_role(
        period_role,
        current_period,
        prior_period,
        next_period,
    )
    resolved = load_resolved_field(
        cur,
        context,
        field_path,
        expected_period,
        period_role,
    )
    if not resolved:
        return None
    return to_decimal(resolved.get("normalized_value_numeric"))


def required_resolved_numeric(
    cur: Any,
    context: Any,
    field_path: str,
    period_role: str,
) -> Decimal:
    value = get_resolved_numeric(cur, context, field_path, period_role)
    if value is None:
        raise ValueError(f"Missing numeric resolved field: {field_path}.{period_role}")
    return value


def first_available_resolved_numeric(
    cur: Any,
    context: Any,
    candidates: list[tuple[str, str, str]],
) -> tuple[Optional[Decimal], Optional[str]]:
    for field_path, period_role, source_label in candidates:
        value = get_resolved_numeric(cur, context, field_path, period_role)
        if value is not None:
            return value, source_label
    return None, None


def safe_ratio(numerator: Decimal, denominator: Decimal) -> Optional[Decimal]:
    if denominator == 0:
        return None
    return numerator / denominator


def safe_growth(current: Decimal, prior: Decimal) -> Optional[Decimal]:
    if prior == 0:
        return None
    return (current - prior) / abs(prior)


def normalize_ratio_or_percent(value: Decimal) -> Decimal:
    if abs(value) > 1 and abs(value) <= 100:
        return value / Decimal("100")
    return value


def extract_money_amount_from_text(text: str) -> Optional[Decimal]:
    patterns = (
        r"S\$\s*([0-9][0-9,.]*)\s*(?:million|mil|m)\b",
        r"US\$\s*([0-9][0-9,.]*)\s*(?:million|mil|m)\b",
        r"USD\s*([0-9][0-9,.]*)\s*(?:million|mil|m)\b",
        r"(?<![A-Za-z$0-9.])([0-9][0-9,.]*)\s*(?:million|mil|m)\b",
    )
    for pattern in patterns:
        match = re.search(pattern, text, flags=re.IGNORECASE)
        if not match:
            continue
        value = to_decimal(match.group(1).replace(",", ""))
        if value is not None:
            return value * Decimal("1000000")
    return None


def infer_text_amount_multiplier(text: str) -> Decimal:
    normalized = text.lower()
    if re.search(r"\b(million|millions|mil)\b|(?:s|us)?\$\s*m\b", normalized):
        return Decimal("1000000")
    if re.search(r"\b(thousand|thousands)\b|(?:s|us)?\$?\s*['’]?\s*000\b", normalized):
        return Decimal("1000")
    return Decimal("1")


def extract_current_amount_after_label(text: str, label_pattern: str) -> Optional[Decimal]:
    patterns = (
        rf"{label_pattern}\s+(?:[A-Z]{{0,3}}\$)?\s*([0-9][0-9,.]*)\s+[0-9][0-9,.]*",
        rf"{label_pattern}[^0-9]{{0,80}}(?:[A-Z]{{0,3}}\$)?\s*([0-9][0-9,.]*)",
    )
    for pattern in patterns:
        match = re.search(pattern, text, flags=re.IGNORECASE | re.DOTALL)
        if not match:
            continue
        value = to_decimal(match.group(1).replace(",", ""))
        if value is not None:
            return value * infer_text_amount_multiplier(text)
    return None


def extract_related_party_revenue_millions(text: str) -> Decimal:
    segment = text
    income_match = re.search(r"\bIncome\b(.+?)\bExpenses\b", text, flags=re.IGNORECASE | re.DOTALL)
    if income_match:
        segment = income_match.group(1)

    total = Decimal("0")
    for label in (
        r"Subsidiaries of ultimate holding company\s+Telecommunications",
        r"Associates\s+Telecommunications",
        r"Joint ventures\s+Telecommunications",
    ):
        value = extract_current_amount_after_label(segment, label)
        if value is not None:
            total += value
    return total


def extract_related_party_payables_millions(text: str) -> Optional[Decimal]:
    return extract_current_amount_after_label(
        text,
        r"Due to subsidiaries of ultimate holding company",
    )


def extract_related_party_advances_millions(text: str) -> Optional[Decimal]:
    return extract_current_amount_after_label(
        text,
        r"Due from subsidiaries of ultimate holding company",
    )


def related_party_classes(text: str) -> set[str]:
    normalized = text.lower()
    classes: set[str] = set()
    if "subsidiaries of ultimate holding company" in normalized:
        classes.add("subsidiaries_of_ultimate_holding_company")
    if "associate" in normalized:
        classes.add("associates")
    if "joint venture" in normalized:
        classes.add("joint_ventures")
    return classes


def extract_related_party_entity_names(text: str) -> set[str]:
    names: set[str] = set()
    normalized = re.sub(r"\s+", " ", text)
    explicit_patterns = (
        r"\bLJM(?:\s+Cayman)?(?:,\s*L\.P\.)?\b",
        r"\bLJM2(?:\s+Co-Investment)?(?:,\s*L\.P\.)?\b",
        r"\bChewco\b",
        r"\bJEDI\b",
        r"\bWhitewing\b",
        r"\bRaptor\b",
    )
    for pattern in explicit_patterns:
        for match in re.finditer(pattern, normalized, flags=re.IGNORECASE):
            names.add(re.sub(r"[^A-Z0-9]+", "", match.group(0).upper()))

    for match in re.finditer(
        r"\b([A-Z][A-Za-z0-9&.-]+(?:\s+[A-Z][A-Za-z0-9&.-]+){0,4})\s+"
        r"(?:L\.P\.|LLC|Ltd\.|Inc\.|Corp\.|Partnership|Co-Investment)\b",
        normalized,
    ):
        names.add(re.sub(r"[^A-Z0-9]+", "", match.group(0).upper()))
    return names


def evaluate_numeric_bands(value: Decimal, bands: list[dict[str, Any]]) -> str:
    selected = "NONE"
    for band in bands:
        severity = str(band.get("severity") or "NONE").upper()
        if severity not in SEVERITY_ORDER:
            continue
        if numeric_band_matches(value, band) and SEVERITY_ORDER[severity] > SEVERITY_ORDER[selected]:
            selected = severity
    return selected


def numeric_band_matches(value: Decimal, band: dict[str, Any]) -> bool:
    has_numeric_comparator = False
    for key, comparator in (
        ("gt", lambda actual, threshold: actual > threshold),
        ("gte", lambda actual, threshold: actual >= threshold),
        ("lt", lambda actual, threshold: actual < threshold),
        ("lte", lambda actual, threshold: actual <= threshold),
    ):
        if key in band:
            has_numeric_comparator = True
            threshold = to_decimal(band[key])
            if threshold is None or not comparator(value, threshold):
                return False
    return has_numeric_comparator


def calculate_fin_rev_001(
    rule: dict[str, Any],
    inputs: dict[str, dict[str, Any]],
) -> RuleCalculation:
    revenue_current = get_input_value(inputs, "financials.revenue.current")
    revenue_prior = get_input_value(inputs, "financials.revenue.prior")
    receivables_current = get_input_value(inputs, "financials.accounts_receivable.current")
    receivables_prior = get_input_value(inputs, "financials.accounts_receivable.prior")
    if revenue_current == 0 or revenue_prior == 0:
        raise ValueError("Revenue must be non-zero to calculate DSO.")

    dso_current = receivables_current / (revenue_current / Decimal("365"))
    dso_prior = receivables_prior / (revenue_prior / Decimal("365"))
    dso_change = dso_current - dso_prior
    revenue_growth = safe_growth(revenue_current, revenue_prior)
    receivables_growth = safe_growth(receivables_current, receivables_prior)
    growth_spread: Optional[Decimal] = None
    if revenue_growth is not None and receivables_growth is not None:
        growth_spread = receivables_growth - revenue_growth
    config = rule_config(rule)
    dso_severity = evaluate_numeric_bands(dso_change, config.get("bands") or [])
    growth_severity = evaluate_fin_rev_001_growth_severity(
        growth_spread,
        receivables_growth,
        config.get("bands") or [],
    )
    severity = max_severity(dso_severity, growth_severity)
    triggered = severity != "NONE"
    growth_is_primary = (
        growth_spread is not None
        and SEVERITY_ORDER.get(growth_severity, 0) > SEVERITY_ORDER.get(dso_severity, 0)
    )
    computed_metric = (
        "receivables_growth_excess_pct"
        if growth_is_primary
        else str(config.get("metric") or "dso_change_days")
    )
    computed_value = growth_spread if growth_is_primary else dso_change
    return RuleCalculation(
        triggered=triggered,
        severity=severity,
        computed_value=computed_value,
        metric=computed_metric,
        explanation=(
            f"DSO changed by {dso_change:.2f} days "
            f"(current {dso_current:.2f}, prior {dso_prior:.2f}); "
            f"receivables growth spread is "
            f"{growth_spread:.2%}." if growth_spread is not None else
            f"DSO changed by {dso_change:.2f} days "
            f"(current {dso_current:.2f}, prior {dso_prior:.2f})."
        ),
        result_json={
            "status": "calculated",
            "metric": config.get("metric") or "dso_change_days",
            "formula": config.get("formula"),
            "values": {
                "dso_current": str(dso_current),
                "dso_prior": str(dso_prior),
                "dso_change_days": str(dso_change),
                "revenue_growth_pct": str(revenue_growth) if revenue_growth is not None else None,
                "receivables_growth_pct": str(receivables_growth) if receivables_growth is not None else None,
                "receivables_growth_excess_pct": str(growth_spread) if growth_spread is not None else None,
                "dso_severity": dso_severity,
                "growth_spread_severity": growth_severity,
                "primary_computed_metric": computed_metric,
            },
        },
    )


def evaluate_fin_rev_001_growth_severity(
    growth_spread: Optional[Decimal],
    receivables_growth: Optional[Decimal],
    bands: list[dict[str, Any]],
) -> str:
    if growth_spread is None:
        return "NONE"
    selected = "NONE"
    for band in bands:
        severity = str(band.get("severity") or "NONE").upper()
        if severity not in SEVERITY_ORDER:
            continue
        threshold = to_decimal(
            band.get("receivable_growth_excess_gt")
            if "receivable_growth_excess_gt" in band
            else band.get("receivables_growth_excess_gt")
        )
        if threshold is None or growth_spread <= threshold:
            continue
        min_growth = to_decimal(band.get("receivables_growth_gt"))
        if min_growth is not None and (receivables_growth is None or receivables_growth <= min_growth):
            continue
        selected = max_severity(selected, severity)
    return selected


def calculate_fin_csh_001(
    rule: dict[str, Any],
    inputs: dict[str, dict[str, Any]],
) -> RuleCalculation:
    net_profit_current = get_input_value(inputs, "financials.net_profit.current")
    ocf_current = get_input_value(inputs, "financials.operating_cash_flow.current")
    net_profit_prior = get_input_value(inputs, "financials.net_profit.prior")
    ocf_prior = get_input_value(inputs, "financials.operating_cash_flow.prior")
    if net_profit_current == 0:
        raise ValueError("Current net profit must be non-zero to calculate cash conversion.")

    ratio_current = ocf_current / net_profit_current
    ratio_prior: Optional[Decimal] = None
    if net_profit_prior != 0:
        ratio_prior = ocf_prior / net_profit_prior
    profit_growth = safe_growth(net_profit_current, net_profit_prior)
    ocf_growth = safe_growth(ocf_current, ocf_prior)
    profit_cash_growth_gap: Optional[Decimal] = None
    if profit_growth is not None and ocf_growth is not None:
        profit_cash_growth_gap = profit_growth - ocf_growth

    config = rule_config(rule)
    severity = evaluate_numeric_bands(ratio_current, config.get("bands") or [])
    severity = max_severity(
        severity,
        evaluate_fin_csh_001_growth_severity(
            profit_cash_growth_gap,
            ratio_current,
            config.get("bands") or [],
        ),
    )
    threshold = first_band_threshold(config.get("bands") or [], "lt") or Decimal("0.5")
    if ratio_current < threshold and ratio_prior is not None and ratio_prior < threshold:
        severity = max_severity(severity, "CRITICAL")
    if ocf_current < 0 and net_profit_current > 0:
        severity = max_severity(severity, "CRITICAL")

    triggered = severity != "NONE"
    return RuleCalculation(
        triggered=triggered,
        severity=severity,
        computed_value=ratio_current,
        metric=str(config.get("metric") or "cash_conversion_ratio"),
        explanation=(
            f"Cash conversion ratio is {ratio_current:.4f} "
            f"against configured threshold {threshold}."
        ),
        result_json={
            "status": "calculated",
            "metric": config.get("metric") or "cash_conversion_ratio",
            "formula": config.get("formula"),
            "values": {
                "cash_conversion_ratio_current": str(ratio_current),
                "cash_conversion_ratio_prior": str(ratio_prior) if ratio_prior is not None else None,
                "net_profit_current": str(net_profit_current),
                "operating_cash_flow_current": str(ocf_current),
                "net_profit_growth_pct": str(profit_growth) if profit_growth is not None else None,
                "operating_cash_flow_growth_pct": str(ocf_growth) if ocf_growth is not None else None,
                "profit_cash_growth_gap_pct": (
                    str(profit_cash_growth_gap)
                    if profit_cash_growth_gap is not None
                    else None
                ),
            },
        },
    )


def evaluate_fin_csh_001_growth_severity(
    profit_cash_growth_gap: Optional[Decimal],
    ratio_current: Decimal,
    bands: list[dict[str, Any]],
) -> str:
    if profit_cash_growth_gap is None:
        return "NONE"
    selected = "NONE"
    for band in bands:
        severity = str(band.get("severity") or "NONE").upper()
        if severity not in SEVERITY_ORDER:
            continue
        gap_threshold = to_decimal(
            band.get("profit_cash_growth_gap_gt")
            if "profit_cash_growth_gap_gt" in band
            else band.get("cash_conversion_drop_gt")
        )
        if gap_threshold is None or profit_cash_growth_gap <= gap_threshold:
            continue
        max_ratio = to_decimal(band.get("cash_conversion_ratio_lt"))
        if max_ratio is not None and ratio_current >= max_ratio:
            continue
        selected = max_severity(selected, severity)
    return selected


def calculate_fin_csh_002(
    rule: dict[str, Any],
    inputs: dict[str, dict[str, Any]],
) -> RuleCalculation:
    cash_current = get_input_value(inputs, "financials.cash_and_equivalents.current")
    cash_prior = get_input_value(inputs, "financials.cash_and_equivalents.prior")
    financing_cash_flow = get_input_value(inputs, "financials.financing_cash_flow.current")
    operating_cash_flow = get_input_value(inputs, "financials.operating_cash_flow.current")
    if cash_prior == 0:
        raise ValueError("Prior cash and equivalents must be non-zero.")

    cash_increase_ratio = (cash_current - cash_prior) / abs(cash_prior)
    financing_positive = financing_cash_flow > 0
    operating_cash_flow_negative = operating_cash_flow < 0
    config = rule_config(rule)
    severity = evaluate_fin_csh_002_severity(
        cash_increase_ratio,
        financing_positive,
        config.get("bands") or [],
    )
    if severity == "NONE" and cash_increase_ratio > Decimal("0.30") and operating_cash_flow_negative:
        severity = "MEDIUM"
    triggered = severity != "NONE"
    return RuleCalculation(
        triggered=triggered,
        severity=severity,
        computed_value=cash_increase_ratio,
        metric=str(config.get("metric") or "cash_increase_from_financing"),
        explanation=(
            f"Cash increased by {cash_increase_ratio:.2%}; "
            f"financing cash flow positive: {financing_positive}."
        ),
        result_json={
            "status": "calculated",
            "metric": config.get("metric") or "cash_increase_from_financing",
            "formula": "(cash_current - cash_prior) / abs(cash_prior)",
            "values": {
                "cash_current": str(cash_current),
                "cash_prior": str(cash_prior),
                "cash_increase_ratio": str(cash_increase_ratio),
                "financing_cash_flow_current": str(financing_cash_flow),
                "operating_cash_flow_current": str(operating_cash_flow),
                "financing_positive": financing_positive,
                "operating_cash_flow_negative": operating_cash_flow_negative,
                "next_period_reversal_policy": "not_applied_when_next_period_inputs_are_warn_or_missing",
            },
        },
    )


def evaluate_fin_csh_002_severity(
    cash_increase_ratio: Decimal,
    financing_positive: bool,
    bands: list[dict[str, Any]],
) -> str:
    selected = "NONE"
    for band in bands:
        severity = str(band.get("severity") or "NONE").upper()
        if severity not in SEVERITY_ORDER:
            continue
        threshold = to_decimal(band.get("cash_increase_gt"))
        if threshold is None or cash_increase_ratio <= threshold:
            continue
        if band.get("increase_attributable_to_financing") and not financing_positive:
            continue
        if band.get("next_period_reversal_and_repayment_within_days") is not None:
            continue
        selected = max_severity(selected, severity)
    return selected


def calculate_fin_ast_001(
    rule: dict[str, Any],
    inputs: dict[str, dict[str, Any]],
) -> RuleCalculation:
    cogs_current = get_input_value(inputs, "financials.cost_of_goods_sold.current")
    inventory_current = get_input_value(inputs, "financials.inventory.current")
    inventory_prior = get_input_value(inputs, "financials.inventory.prior")
    if inventory_current == 0 or inventory_prior == 0:
        raise ValueError("Inventory values must be non-zero to calculate turnover decline.")

    average_inventory = (inventory_current + inventory_prior) / Decimal("2")
    if average_inventory == 0:
        raise ValueError("Average inventory must be non-zero to calculate inventory turnover.")

    turnover_current = cogs_current / average_inventory
    cogs_prior = get_optional_input_value(inputs, "financials.cost_of_goods_sold.prior")
    prior_cogs_for_turnover = cogs_prior if cogs_prior is not None else cogs_current
    prior_turnover_source = (
        "financials.cost_of_goods_sold.prior"
        if cogs_prior is not None
        else "financials.cost_of_goods_sold.current_proxy"
    )
    turnover_prior_proxy = prior_cogs_for_turnover / inventory_prior
    decline_ratio = (turnover_prior_proxy - turnover_current) / abs(turnover_prior_proxy)

    gross_margin_current = get_optional_input_value(inputs, "financials.gross_margin.current")
    gross_margin_prior = get_optional_input_value(inputs, "financials.gross_margin.prior")
    gross_margin_stable_or_expanding = (
        gross_margin_current is not None
        and gross_margin_prior is not None
        and gross_margin_current >= gross_margin_prior
    )

    config = rule_config(rule)
    severity = evaluate_fin_ast_001_severity(
        decline_ratio,
        config.get("bands") or [],
        gross_margin_stable_or_expanding,
    )
    triggered = severity != "NONE"
    return RuleCalculation(
        triggered=triggered,
        severity=severity,
        computed_value=decline_ratio,
        metric=str(config.get("metric") or "inventory_turnover_decline_pct"),
        explanation=(
            f"Inventory turnover decline proxy is {decline_ratio:.2%} "
            f"(current turnover {turnover_current:.4f}, prior proxy {turnover_prior_proxy:.4f})."
        ),
        result_json={
            "status": "calculated",
            "metric": config.get("metric") or "inventory_turnover_decline_pct",
            "formula": config.get("formula") or (
                "cogs_current / average_inventory_current_period versus "
                "cogs_prior_or_current_proxy / inventory_prior"
            ),
            "values": {
                "inventory_turnover_current": str(turnover_current),
                "inventory_turnover_prior_proxy": str(turnover_prior_proxy),
                "inventory_turnover_decline_pct": str(decline_ratio),
                "cost_of_goods_sold_current": str(cogs_current),
                "cost_of_goods_sold_prior": str(cogs_prior) if cogs_prior is not None else None,
                "prior_turnover_source": prior_turnover_source,
                "average_inventory": str(average_inventory),
                "inventory_current": str(inventory_current),
                "inventory_prior": str(inventory_prior),
                "gross_margin_current": str(gross_margin_current) if gross_margin_current is not None else None,
                "gross_margin_prior": str(gross_margin_prior) if gross_margin_prior is not None else None,
                "gross_margin_stable_or_expanding": gross_margin_stable_or_expanding,
            },
        },
    )


def calculate_fin_rev_004(
    rule: dict[str, Any],
    inputs: dict[str, dict[str, Any]],
) -> RuleCalculation:
    revenue_current = get_input_value(inputs, "financials.revenue.current")
    revenue_prior = get_input_value(inputs, "financials.revenue.prior")
    policy_current = get_input_text(inputs, "notes.revenue_recognition_policy.current")
    policy_prior = get_input_text(inputs, "notes.revenue_recognition_policy.prior")
    if revenue_prior == 0:
        raise ValueError("Prior revenue must be non-zero to calculate revenue growth.")

    similarity = text_similarity(policy_current, policy_prior)
    revenue_growth_pct = (revenue_current - revenue_prior) / abs(revenue_prior)
    config = rule_config(rule)
    bands = config.get("bands") or []
    severity = evaluate_fin_rev_004_severity(similarity, revenue_growth_pct, bands)
    threshold = to_decimal(config.get("similarity_threshold")) or first_band_threshold(bands, "lt")
    triggered = severity != "NONE"
    threshold_text = str(threshold) if threshold is not None else "configured bands"

    return RuleCalculation(
        triggered=triggered,
        severity=severity,
        computed_value=similarity,
        metric=str(config.get("metric") or "revenue_policy_text_similarity"),
        explanation=(
            f"Revenue recognition policy similarity is {similarity:.4f} "
            f"against threshold {threshold_text}; revenue growth is {revenue_growth_pct:.2%}."
        ),
        result_json={
            "status": "calculated",
            "metric": config.get("metric") or "revenue_policy_text_similarity",
            "formula": "text_similarity(current_policy, prior_policy)",
            "values": {
                "revenue_current": str(revenue_current),
                "revenue_prior": str(revenue_prior),
                "revenue_growth_pct": str(revenue_growth_pct),
                "policy_similarity": str(similarity),
                "similarity_threshold": str(threshold) if threshold is not None else None,
                "policy_current_length": len(policy_current),
                "policy_prior_length": len(policy_prior),
            },
        },
    )


def calculate_fin_rev_002(
    rule: dict[str, Any],
    inputs: dict[str, dict[str, Any]],
) -> RuleCalculation:
    revenue_current = get_input_value(inputs, "financials.revenue.current")
    related_party_text = get_input_text(inputs, "related_party_transactions.revenue_transactions")
    related_party_register_text = get_optional_input_text(inputs, "related_party_register")
    approval_text = get_optional_input_text(inputs, "sgx_announcements.shareholder_approval")
    if revenue_current == 0:
        raise ValueError("Current revenue must be non-zero to calculate related-party revenue percentage.")

    related_party_revenue = extract_related_party_revenue_millions(related_party_text)
    ratio = related_party_revenue / abs(revenue_current)
    approval_found = approval_text_contains_approval(approval_text)
    config = rule_config(rule)
    severity = evaluate_fin_rev_002_severity(
        ratio,
        approval_found,
        config.get("bands") or [],
    )
    triggered = severity != "NONE"
    approval_status = "resolved_approved" if approval_found else "not_connected_or_not_resolved"
    return RuleCalculation(
        triggered=triggered,
        severity=severity,
        computed_value=ratio,
        metric=str(config.get("metric") or "related_party_revenue_pct"),
        explanation=(
            f"Related-party revenue is {ratio:.2%} of total revenue. "
            f"Shareholder approval evidence status: {approval_status}."
        ),
        result_json={
            "status": "calculated",
            "metric": config.get("metric") or "related_party_revenue_pct",
            "formula": "related_party_revenue / total_revenue",
            "values": {
                "related_party_revenue": str(related_party_revenue),
                "revenue_current": str(revenue_current),
                "related_party_revenue_pct": str(ratio),
                "approval_found": approval_found,
                "approval_status": approval_status,
                "related_party_register_evidence_present": bool(related_party_register_text),
                "approval_policy": "missing_sgx_approval_evidence_is_warn_not_pass",
            },
        },
    )


def calculate_fin_rev_003(
    rule: dict[str, Any],
    inputs: dict[str, dict[str, Any]],
) -> RuleCalculation:
    revenue_current = get_input_value(inputs, "financials.revenue.current")
    quarterly_text = get_optional_input_text(inputs, "financials.quarterly_revenue")
    q4_revenue = extract_q4_revenue_from_text(quarterly_text)
    config = rule_config(rule)

    if q4_revenue is None:
        return RuleCalculation(
            triggered=False,
            severity="NONE",
            computed_value=None,
            metric=str(config.get("metric") or "q4_revenue_concentration_delta_pct_points"),
            explanation=(
                "Quarterly revenue was not resolved from financial-statement or historical-summary evidence; "
                "rule remains reviewable and no revenue-concentration trigger is asserted."
            ),
            result_json={
                "status": "calculated_with_missing_quarterly_evidence",
                "metric": config.get("metric") or "q4_revenue_concentration_delta_pct_points",
                "formula": "q4_revenue / full_year_revenue when quarterly revenue is resolved",
                "values": {
                    "revenue_current": str(revenue_current),
                    "q4_revenue": None,
                    "q4_revenue_concentration": None,
                    "next_period_receivable_or_returns_policy": "not_applied_when_next_period_inputs_are_warn_or_missing",
                },
            },
        )

    if revenue_current == 0:
        raise ValueError("Current revenue must be non-zero to calculate Q4 revenue concentration.")
    q4_concentration = q4_revenue / abs(revenue_current)
    severity = evaluate_fin_rev_003_severity(q4_concentration, config.get("bands") or [])
    triggered = severity != "NONE"
    return RuleCalculation(
        triggered=triggered,
        severity=severity,
        computed_value=q4_concentration,
        metric=str(config.get("metric") or "q4_revenue_concentration"),
        explanation=f"Q4 revenue concentration is {q4_concentration:.2%} of full-year revenue.",
        result_json={
            "status": "calculated",
            "metric": config.get("metric") or "q4_revenue_concentration",
            "formula": "q4_revenue / full_year_revenue",
            "values": {
                "q4_revenue": str(q4_revenue),
                "revenue_current": str(revenue_current),
                "q4_revenue_concentration": str(q4_concentration),
            },
        },
    )


def extract_q4_revenue_from_text(text: Optional[str]) -> Optional[Decimal]:
    if not text:
        return None
    multiplier = infer_text_amount_multiplier(text)
    patterns = (
        r"\bq4\b[^0-9]{0,60}(?:[A-Z]{0,3}\$)?\s*([0-9][0-9,.]*)",
        r"\bfourth\s+quarter\b[^0-9]{0,80}(?:[A-Z]{0,3}\$)?\s*([0-9][0-9,.]*)",
        r"\bquarter\s+4\b[^0-9]{0,60}(?:[A-Z]{0,3}\$)?\s*([0-9][0-9,.]*)",
    )
    for pattern in patterns:
        match = re.search(pattern, text, flags=re.IGNORECASE)
        if not match:
            continue
        value = to_decimal(match.group(1).replace(",", ""))
        if value is not None:
            return value * multiplier
    return None


def evaluate_fin_rev_003_severity(
    q4_concentration: Decimal,
    bands: list[dict[str, Any]],
) -> str:
    selected = evaluate_numeric_bands(q4_concentration, bands)
    for band in bands:
        severity = str(band.get("severity") or "NONE").upper()
        if severity not in SEVERITY_ORDER:
            continue
        threshold = to_decimal(
            band.get("q4_revenue_concentration_gt")
            if "q4_revenue_concentration_gt" in band
            else band.get("period_end_revenue_concentration_gt")
        )
        if threshold is not None and q4_concentration > threshold:
            selected = max_severity(selected, severity)
    return selected


def evaluate_fin_rev_002_severity(
    ratio: Decimal,
    approval_found: bool,
    bands: list[dict[str, Any]],
) -> str:
    selected = "NONE"
    for band in bands:
        severity = str(band.get("severity") or "NONE").upper()
        if severity not in SEVERITY_ORDER:
            continue
        if not numeric_band_matches(ratio, band):
            continue
        if "approval_found" in band and bool(band.get("approval_found")) != approval_found:
            continue
        selected = max_severity(selected, severity)
    return selected


def approval_text_contains_approval(text: Optional[str]) -> bool:
    if not text:
        return False
    normalized = text.lower()
    reject_terms = (
        "subject to approval",
        "will seek approval",
        "may require approval",
        "approval may be required",
    )
    if any(term in normalized for term in reject_terms):
        return False
    approval_terms = (
        "shareholders approved",
        "approval of shareholders",
        "ordinary resolution",
        "shareholders' mandate",
        "shareholder mandate",
        "general mandate",
    )
    return any(term in normalized for term in approval_terms)


def text_similarity(left: str, right: str) -> Decimal:
    left_normalized = normalize_policy_text(left)
    right_normalized = normalize_policy_text(right)
    if not left_normalized or not right_normalized:
        return Decimal("0")

    sequence_ratio = Decimal(
        str(SequenceMatcher(None, left_normalized, right_normalized).ratio())
    )
    left_tokens = set(left_normalized.split())
    right_tokens = set(right_normalized.split())
    if left_tokens or right_tokens:
        token_ratio = Decimal(
            len(left_tokens & right_tokens)
        ) / Decimal(len(left_tokens | right_tokens))
    else:
        token_ratio = Decimal("0")
    return ((sequence_ratio + token_ratio) / Decimal("2")).quantize(Decimal("0.000001"))


def normalize_policy_text(text: str) -> str:
    normalized = text.lower()
    normalized = re.sub(r"[^a-z0-9]+", " ", normalized)
    return re.sub(r"\s+", " ", normalized).strip()


def evaluate_fin_rev_004_severity(
    similarity: Decimal,
    revenue_growth_pct: Decimal,
    bands: list[dict[str, Any]],
) -> str:
    selected = "NONE"
    for band in bands:
        severity = str(band.get("severity") or "NONE").upper()
        if severity not in SEVERITY_ORDER:
            continue
        if not numeric_band_matches(similarity, band):
            continue
        if band.get("revenue_growth_gt_historical_stddev") is not None:
            continue
        revenue_growth_threshold = to_decimal(band.get("revenue_growth_gt"))
        if revenue_growth_threshold is not None and revenue_growth_pct <= revenue_growth_threshold:
            continue
        if SEVERITY_ORDER[severity] > SEVERITY_ORDER[selected]:
            selected = severity
    return selected


def evaluate_fin_ast_001_severity(
    decline_ratio: Decimal,
    bands: list[dict[str, Any]],
    gross_margin_stable_or_expanding: bool,
) -> str:
    selected = "NONE"
    first_trigger_severity: Optional[str] = None
    for band in bands:
        severity = str(band.get("severity") or "NONE").upper()
        if severity not in SEVERITY_ORDER:
            continue
        if not numeric_band_matches(decline_ratio, band):
            continue
        if first_trigger_severity is None:
            first_trigger_severity = severity
        if band.get("gross_margin_stable_or_expanding") and not gross_margin_stable_or_expanding:
            continue
        if SEVERITY_ORDER[severity] > SEVERITY_ORDER[selected]:
            selected = severity

    if selected == "NONE" and first_trigger_severity:
        return "MEDIUM" if SEVERITY_ORDER[first_trigger_severity] > SEVERITY_ORDER["MEDIUM"] else first_trigger_severity
    return selected


def calculate_fin_ast_002(
    rule: dict[str, Any],
    inputs: dict[str, dict[str, Any]],
) -> RuleCalculation:
    intangible_current = get_input_value(inputs, "financials.intangible_assets.current")
    intangible_prior = get_input_value(inputs, "financials.intangible_assets.prior")
    revenue_current = get_input_value(inputs, "financials.revenue.current")
    if revenue_current == 0:
        raise ValueError("Current revenue must be non-zero to calculate intangible asset increase ratio.")

    increase = intangible_current - intangible_prior
    capitalised_cost_ratio = max(increase, Decimal("0")) / abs(revenue_current)
    acquisition_evidence = get_optional_input_text(inputs, "notes.acquisitions")
    rd_evidence = get_optional_input_text(inputs, "notes.rd_projects")
    config = rule_config(rule)
    severity = evaluate_numeric_bands(capitalised_cost_ratio, config.get("bands") or [])
    triggered = severity != "NONE"
    return RuleCalculation(
        triggered=triggered,
        severity=severity,
        computed_value=capitalised_cost_ratio,
        metric=str(config.get("metric") or "capitalised_cost_ratio"),
        explanation=(
            f"Intangible asset increase ratio is {capitalised_cost_ratio:.2%}. "
            "The ratio is unadjusted for acquisition/R&D amounts unless those amounts are separately resolved."
        ),
        result_json={
            "status": "calculated",
            "metric": config.get("metric") or "capitalised_cost_ratio",
            "formula": "max(intangible_assets_current - intangible_assets_prior, 0) / revenue_current",
            "values": {
                "intangible_assets_current": str(intangible_current),
                "intangible_assets_prior": str(intangible_prior),
                "intangible_asset_increase": str(increase),
                "revenue_current": str(revenue_current),
                "capitalised_cost_ratio": str(capitalised_cost_ratio),
                "acquisition_evidence_present": bool(acquisition_evidence),
                "rd_project_evidence_present": bool(rd_evidence),
                "adjustment_policy": "unadjusted_ratio_with_review_when_optional_notes_missing",
            },
        },
    )


def calculate_fin_ast_003(
    rule: dict[str, Any],
    inputs: dict[str, dict[str, Any]],
) -> RuleCalculation:
    intangible_goodwill = get_input_value(inputs, "financials.intangible_assets_and_goodwill.current")
    total_assets = get_input_value(inputs, "financials.total_assets.current")
    total_equity = get_input_value(inputs, "financials.total_equity.current")
    operating_profit = get_optional_input_value(inputs, "financials.operating_profit.current")
    impairment_charge = get_optional_input_value(inputs, "financials.impairment_charge.current")
    market_cap = get_optional_input_value(inputs, "market_data.market_capitalisation.current")
    if total_assets == 0 or total_equity == 0:
        raise ValueError("Total assets and total equity must be non-zero for goodwill impairment analysis.")

    goodwill_ratio = intangible_goodwill / abs(total_assets)
    market_discount = (total_equity - market_cap) / abs(total_equity) if market_cap is not None else None
    operating_loss = operating_profit is not None and operating_profit < 0
    no_impairment_charge = impairment_charge is not None and impairment_charge == 0
    config = rule_config(rule)
    severity = "NONE"
    for band in config.get("bands") or []:
        band_severity = str(band.get("severity") or "NONE").upper()
        if band_severity not in SEVERITY_ORDER:
            continue
        goodwill_threshold = to_decimal(band.get("goodwill_ratio_gt"))
        if goodwill_threshold is not None and goodwill_ratio <= goodwill_threshold:
            continue
        discount_threshold = to_decimal(band.get("market_discount_gt"))
        if discount_threshold is not None and (market_discount is None or market_discount <= discount_threshold):
            continue
        if band.get("operating_loss") and not operating_loss:
            continue
        if band.get("no_impairment_charge") and not no_impairment_charge:
            continue
        severity = max_severity(severity, band_severity)

    triggered = severity != "NONE"
    return RuleCalculation(
        triggered=triggered,
        severity=severity,
        computed_value=goodwill_ratio,
        metric=str(config.get("metric") or "goodwill_ratio_and_market_discount"),
        explanation=(
            f"Goodwill/intangibles are {goodwill_ratio:.2%} of assets; "
            f"market discount to equity is {market_discount:.2%}."
            if market_discount is not None
            else f"Goodwill/intangibles are {goodwill_ratio:.2%} of assets; market data was not resolved."
        ),
        result_json={
            "status": "calculated",
            "metric": config.get("metric") or "goodwill_ratio_and_market_discount",
            "formula": "intangible_assets_and_goodwill / total_assets; (total_equity - market_capitalisation) / total_equity",
            "values": {
                "intangible_assets_and_goodwill": str(intangible_goodwill),
                "total_assets": str(total_assets),
                "total_equity": str(total_equity),
                "market_capitalisation": str(market_cap) if market_cap is not None else None,
                "operating_profit": str(operating_profit) if operating_profit is not None else None,
                "impairment_charge": str(impairment_charge) if impairment_charge is not None else None,
                "goodwill_ratio": str(goodwill_ratio),
                "market_discount": str(market_discount) if market_discount is not None else None,
                "operating_loss": operating_loss,
                "no_impairment_charge": no_impairment_charge,
                "market_data_policy": "market discount bands require market capitalisation; goodwill-ratio and impairment-loss bands still run without it",
            },
        },
    )


def calculate_fin_lia_002(
    rule: dict[str, Any],
    inputs: dict[str, dict[str, Any]],
) -> RuleCalculation:
    provision_current = get_input_value(
        inputs,
        "financials.provisions_and_contingent_liabilities.current",
    )
    provision_prior = get_input_value(
        inputs,
        "financials.provisions_and_contingent_liabilities.prior",
    )
    litigation_text = get_optional_input_text(inputs, "events.litigation")
    if provision_prior == 0:
        raise ValueError("Prior provisions/contingent liabilities must be non-zero.")

    decrease_ratio = (provision_prior - provision_current) / abs(provision_prior)
    config = rule_config(rule)
    severity = evaluate_fin_lia_002_severity(
        decrease_ratio,
        bool(litigation_text),
        config.get("bands") or [],
    )
    triggered = severity != "NONE"
    return RuleCalculation(
        triggered=triggered,
        severity=severity,
        computed_value=decrease_ratio,
        metric=str(config.get("metric") or "provision_decrease_ratio"),
        explanation=(
            f"Provision/contingent exposure decreased by {decrease_ratio:.2%}; "
            "litigation/contingency evidence is present in the financial statement notes."
        ),
        result_json={
            "status": "calculated",
            "metric": config.get("metric") or "provision_decrease_ratio",
            "formula": "(prior_provisions_and_contingencies - current_provisions_and_contingencies) / abs(prior_provisions_and_contingencies)",
            "values": {
                "provisions_and_contingencies_current": str(provision_current),
                "provisions_and_contingencies_prior": str(provision_prior),
                "provision_decrease_ratio": str(decrease_ratio),
                "litigation_or_contingency_evidence_present": bool(litigation_text),
                "sector_benchmark_policy": "not_applied_when_sector_benchmark_input_is_warn_or_missing",
            },
        },
    )


def calculate_fin_lia_001(
    rule: dict[str, Any],
    inputs: dict[str, dict[str, Any]],
) -> RuleCalculation:
    total_liabilities = get_input_value(inputs, "financials.total_liabilities.current")
    payables_text = get_input_text(inputs, "related_party_transactions.payables_and_loans")
    related_party_register_text = get_optional_input_text(inputs, "related_party_register")
    if total_liabilities == 0:
        raise ValueError("Current total liabilities must be non-zero.")

    related_party_payables = extract_related_party_payables_millions(payables_text)
    if related_party_payables is None:
        config = rule_config(rule)
        return RuleCalculation(
            triggered=False,
            severity="NONE",
            computed_value=None,
            metric=str(config.get("metric") or "related_party_liability_ratio"),
            explanation=(
                "Related-party payable note evidence was resolved, but no payable amount "
                "could be extracted for concentration calculation."
            ),
            result_json={
                "status": "calculated_with_missing_related_party_payable_amount",
                "metric": config.get("metric") or "related_party_liability_ratio",
                "formula": "related_party_payables_and_loans / total_liabilities when amount is resolved",
                "values": {
                    "related_party_payables_and_loans": None,
                    "total_liabilities": str(total_liabilities),
                    "related_party_register_evidence_present": bool(related_party_register_text),
                    "payables_evidence_present": bool(payables_text),
                    "extraction_scope": "annual_report_related_party_note",
                },
            },
        )

    ratio = related_party_payables / abs(total_liabilities)
    config = rule_config(rule)
    severity = evaluate_numeric_bands(ratio, config.get("bands") or [])
    triggered = severity != "NONE"
    return RuleCalculation(
        triggered=triggered,
        severity=severity,
        computed_value=ratio,
        metric=str(config.get("metric") or "related_party_liability_ratio"),
        explanation=f"Related-party payable balance is {ratio:.2%} of total liabilities.",
        result_json={
            "status": "calculated",
            "metric": config.get("metric") or "related_party_liability_ratio",
            "formula": "related_party_payables_and_loans / total_liabilities",
            "values": {
                "related_party_payables_and_loans": str(related_party_payables),
                "total_liabilities": str(total_liabilities),
                "related_party_liability_ratio": str(ratio),
                "related_party_register_evidence_present": bool(related_party_register_text),
                "extraction_scope": "annual_report_note_14_due_to_balance",
            },
        },
    )


def evaluate_fin_lia_002_severity(
    decrease_ratio: Decimal,
    litigation_present: bool,
    bands: list[dict[str, Any]],
) -> str:
    selected = "NONE"
    for band in bands:
        severity = str(band.get("severity") or "NONE").upper()
        if severity not in SEVERITY_ORDER:
            continue
        threshold = to_decimal(band.get("provision_decrease_gt"))
        if threshold is not None:
            if decrease_ratio <= threshold:
                continue
            if band.get("prior_event_unresolved") and not litigation_present:
                continue
            selected = max_severity(selected, severity)
    return selected


def calculate_fin_rev_005(
    rule: dict[str, Any],
    inputs: dict[str, dict[str, Any]],
) -> RuleCalculation:
    related_party_register_text = get_optional_input_text(inputs, "related_party_register")
    revenue_text = get_input_text(inputs, "related_party_transactions.revenue_transactions")
    advances_text = get_input_text(inputs, "related_party_transactions.loans_investments_advances")
    revenue_classes = related_party_classes(revenue_text)
    advances_classes = related_party_classes(advances_text)
    overlapping_classes = sorted(revenue_classes & advances_classes)
    revenue_names = extract_related_party_entity_names(revenue_text)
    advances_names = extract_related_party_entity_names(advances_text)
    overlapping_names = sorted(revenue_names & advances_names)
    advances_amount = extract_related_party_advances_millions(advances_text)
    config = rule_config(rule)

    exact_entity_match = bool(overlapping_names)
    class_level_overlap = bool(overlapping_classes)
    triggered = exact_entity_match
    severity = "CRITICAL" if triggered else "NONE"
    computed_value = Decimal("1") if triggered else Decimal("0")
    return RuleCalculation(
        triggered=triggered,
        severity=severity,
        computed_value=computed_value,
        metric=str(config.get("metric") or "round_tripping_match"),
        explanation=(
            (
                "Exact same-entity circular fund-flow evidence was found in annual-report note evidence. "
                if exact_entity_match
                else "No exact same-entity circular fund-flow match was proven from annual-report note evidence. "
            )
            + f"Class-level overlap present: {class_level_overlap}."
        ),
        result_json={
            "status": "calculated",
            "metric": config.get("metric") or "round_tripping_match",
            "formula": "exact connected-entity appears as both revenue source and fund recipient",
            "values": {
                "exact_entity_match": exact_entity_match,
                "class_level_overlap": class_level_overlap,
                "overlapping_related_party_names": overlapping_names,
                "overlapping_counterparty_classes": overlapping_classes,
                "related_party_advances": str(advances_amount) if advances_amount is not None else None,
                "related_party_register_evidence_present": bool(related_party_register_text),
                "trigger_policy": "trigger_on_same_named_related_party_in_revenue_and_fund_flow_evidence",
            },
        },
    )


def calculate_fin_cmp_001(
    rule: dict[str, Any],
    inputs: dict[str, dict[str, Any]],
    cur: Any,
    context: Any,
) -> RuleCalculation:
    revenue_current = required_resolved_numeric(cur, context, "financials.revenue", "current")
    revenue_prior = required_resolved_numeric(cur, context, "financials.revenue", "prior")
    receivables_current = required_resolved_numeric(cur, context, "financials.accounts_receivable", "current")
    receivables_prior = required_resolved_numeric(cur, context, "financials.accounts_receivable", "prior")
    total_assets_current = required_resolved_numeric(cur, context, "financials.total_assets", "current")
    total_assets_prior = required_resolved_numeric(cur, context, "financials.total_assets", "prior")
    total_liabilities_current = required_resolved_numeric(cur, context, "financials.total_liabilities", "current")
    total_liabilities_prior = required_resolved_numeric(cur, context, "financials.total_liabilities", "prior")
    net_profit_current = required_resolved_numeric(cur, context, "financials.net_profit", "current")
    operating_cash_flow_current = required_resolved_numeric(cur, context, "financials.operating_cash_flow", "current")

    if min(abs(revenue_current), abs(revenue_prior), abs(total_assets_current), abs(total_assets_prior)) == 0:
        raise ValueError("Revenue and total assets must be non-zero for Beneish proxy calculation.")

    dsri = (receivables_current / revenue_current) / (receivables_prior / revenue_prior)
    sgi = revenue_current / revenue_prior
    lvgi = (total_liabilities_current / total_assets_current) / (
        total_liabilities_prior / total_assets_prior
    )
    tata = (net_profit_current - operating_cash_flow_current) / total_assets_current

    gross_margin_current = get_resolved_numeric(cur, context, "financials.gross_margin", "current")
    gross_margin_prior = get_resolved_numeric(cur, context, "financials.gross_margin", "prior")
    gmi: Optional[Decimal] = None
    if gross_margin_current and gross_margin_prior and gross_margin_current != 0:
        gmi = gross_margin_prior / gross_margin_current

    m_score_proxy = (
        Decimal("-4.84")
        + Decimal("0.920") * dsri
        + Decimal("0.528") * (gmi if gmi is not None else Decimal("1"))
        + Decimal("0.404") * Decimal("1")
        + Decimal("0.892") * sgi
        + Decimal("0.115") * Decimal("1")
        - Decimal("0.172") * Decimal("1")
        + Decimal("4.679") * tata
        - Decimal("0.327") * lvgi
    )
    config = rule_config(rule)
    threshold = to_decimal(config.get("threshold")) or Decimal("-1.78")
    severity = evaluate_numeric_bands(m_score_proxy, config.get("bands") or [])
    triggered = m_score_proxy > threshold
    if triggered and severity == "NONE":
        severity = "HIGH"
    return RuleCalculation(
        triggered=triggered,
        severity=severity,
        computed_value=m_score_proxy,
        metric=str(config.get("metric") or "beneish_m_score_proxy"),
        explanation=(
            f"Beneish proxy score is {m_score_proxy:.4f} against threshold {threshold}. "
            "Unavailable Beneish factors are neutralized and result requires review."
        ),
        result_json={
            "status": "calculated_proxy",
            "metric": config.get("metric") or "beneish_m_score",
            "formula": "Beneish M-score proxy using available audited financial statement fields",
            "values": {
                "m_score_proxy": str(m_score_proxy),
                "threshold": str(threshold),
                "dsri": str(dsri),
                "gmi": str(gmi) if gmi is not None else None,
                "aqi": "neutral_1_missing_asset_quality_components",
                "sgi": str(sgi),
                "depi": "neutral_1_missing_depreciation_components",
                "sgai": "neutral_1_missing_sga_components",
                "tata": str(tata),
                "lvgi": str(lvgi),
                "proxy_policy": "missing full Beneish components are neutralized; manual review required",
            },
        },
    )


def calculate_fin_lia_003(
    rule: dict[str, Any],
    inputs: dict[str, dict[str, Any]],
) -> RuleCalculation:
    total_equity = get_input_value(inputs, "financials.total_equity.current")
    contingent_text = get_input_text(inputs, "notes.contingent_liabilities_and_guarantees")
    related_party_register_text = get_optional_input_text(inputs, "related_party_register")
    if total_equity == 0:
        raise ValueError("Current total equity must be non-zero.")

    guarantee_amount = extract_money_amount_from_text(contingent_text)
    if guarantee_amount is None:
        config = rule_config(rule)
        return RuleCalculation(
            triggered=False,
            severity="NONE",
            computed_value=None,
            metric=str(config.get("metric") or "guarantees_to_equity"),
            explanation="Contingent-liability note evidence was resolved, but no guarantee amount was extracted.",
            result_json={
                "status": "calculated_with_missing_guarantee_amount",
                "metric": config.get("metric") or "guarantees_to_equity",
                "formula": "guarantee_amount_from_contingent_liability_note / total_equity when amount is resolved",
                "values": {
                    "guarantee_amount_reported_millions": None,
                    "total_equity": str(total_equity),
                    "related_party_register_evidence_present": bool(related_party_register_text),
                },
            },
        )

    ratio = guarantee_amount / abs(total_equity)
    config = rule_config(rule)
    severity = evaluate_numeric_bands(ratio, config.get("bands") or [])
    triggered = severity != "NONE"
    return RuleCalculation(
        triggered=triggered,
        severity=severity,
        computed_value=ratio,
        metric=str(config.get("metric") or "guarantees_to_equity"),
        explanation=f"Guarantees identified in notes are {ratio:.2%} of total equity.",
        result_json={
            "status": "calculated",
            "metric": config.get("metric") or "guarantees_to_equity",
            "formula": "guarantee_amount_from_contingent_liability_note / total_equity",
            "values": {
                "guarantee_amount_reported_millions": str(guarantee_amount),
                "total_equity": str(total_equity),
                "guarantees_to_equity": str(ratio),
                "related_party_register_evidence_present": bool(related_party_register_text),
                "related_party_guarantee_specificity": "review_required_if_note_does_not_identify_all_beneficiaries_as_related_parties",
            },
        },
    )


def calculate_fin_own_001(
    rule: dict[str, Any],
    inputs: dict[str, dict[str, Any]],
) -> RuleCalculation:
    layers = get_input_value(inputs, "ownership_graph.layers")
    jurisdictions_text = get_input_text(inputs, "ownership_graph.jurisdictions")
    rationale_text = get_optional_input_text(inputs, "notes.commercial_rationale")
    normalized_jurisdictions = jurisdictions_text.lower()
    opaque_terms = ("bvi", "british virgin", "cayman", "seychelles", "panama", "bermuda")
    opaque_jurisdiction_present = any(term in normalized_jurisdictions for term in opaque_terms)
    commercial_rationale_missing = not bool(rationale_text)
    config = rule_config(rule)
    severity = "NONE"
    for band in config.get("bands") or []:
        band_severity = str(band.get("severity") or "NONE").upper()
        if band_severity not in SEVERITY_ORDER:
            continue
        threshold = to_decimal(band.get("gt"))
        if threshold is not None and layers <= threshold:
            continue
        if band.get("opaque_jurisdiction_present") and not opaque_jurisdiction_present:
            continue
        if band.get("commercial_rationale_missing") and not commercial_rationale_missing:
            continue
        severity = max_severity(severity, band_severity)

    triggered = severity != "NONE"
    return RuleCalculation(
        triggered=triggered,
        severity=severity,
        computed_value=layers,
        metric=str(config.get("metric") or "ownership_chain_layers"),
        explanation=(
            f"Ownership chain has {layers} layer(s); "
            f"opaque jurisdiction present: {opaque_jurisdiction_present}."
        ),
        result_json={
            "status": "calculated",
            "metric": config.get("metric") or "ownership_chain_layers",
            "formula": "ownership_chain_layer_count with opaque jurisdiction and rationale checks",
            "values": {
                "ownership_chain_layers": str(layers),
                "opaque_jurisdiction_present": opaque_jurisdiction_present,
                "commercial_rationale_missing": commercial_rationale_missing,
                "jurisdictions_evidence": jurisdictions_text,
            },
        },
    )


def calculate_fin_own_002(
    rule: dict[str, Any],
    inputs: dict[str, dict[str, Any]],
) -> RuleCalculation:
    raw_effective_control_pct = get_input_value(inputs, "ownership.effective_control_pct")
    effective_control_pct = normalize_ratio_or_percent(raw_effective_control_pct)
    independent_directors = get_input_value(inputs, "governance.independent_director_count")
    total_board_members = get_input_value(inputs, "governance.total_board_members")
    if total_board_members == 0:
        raise ValueError("Total board members must be non-zero for board independence ratio.")

    independent_ratio = independent_directors / total_board_members
    config = rule_config(rule)
    control_threshold = Decimal("0.70")
    independence_threshold = Decimal("0.333")
    severity = "NONE"
    control_triggered = False
    independence_triggered = False
    for band in config.get("bands") or []:
        band_severity = str(band.get("severity") or "NONE").upper()
        if band_severity not in SEVERITY_ORDER:
            continue
        control_gt = to_decimal(band.get("effective_control_pct_gt"))
        independent_lt = to_decimal(band.get("independent_director_ratio_lt"))
        if control_gt is not None:
            control_threshold = control_gt
            if effective_control_pct > control_gt:
                control_triggered = True
                severity = max_severity(severity, band_severity)
        if independent_lt is not None:
            independence_threshold = independent_lt
            if independent_ratio < independent_lt:
                independence_triggered = True
                severity = max_severity(severity, band_severity)
        if band.get("both_conditions") and control_triggered and independence_triggered:
            severity = max_severity(severity, band_severity)

    triggered = severity != "NONE"
    return RuleCalculation(
        triggered=triggered,
        severity=severity,
        computed_value=effective_control_pct,
        metric=str(config.get("metric") or "control_and_independent_oversight"),
        explanation=(
            f"Effective control is {effective_control_pct:.2%} against {control_threshold:.2%}; "
            f"independent director ratio is {independent_ratio:.2%} against {independence_threshold:.2%}."
        ),
        result_json={
            "status": "calculated",
            "metric": config.get("metric") or "control_and_independent_oversight",
            "formula": "effective_control_pct and independent_directors / total_board_members",
            "values": {
                "effective_control_pct": str(effective_control_pct),
                "raw_effective_control_pct": str(raw_effective_control_pct),
                "independent_director_count": str(independent_directors),
                "total_board_members": str(total_board_members),
                "independent_director_ratio": str(independent_ratio),
                "control_triggered": control_triggered,
                "independence_triggered": independence_triggered,
            },
        },
    )


def calculate_fin_cmp_002(
    rule: dict[str, Any],
    inputs: dict[str, dict[str, Any]],
    cur: Any,
    context: Any,
) -> RuleCalculation:
    total_assets = required_resolved_numeric(cur, context, "financials.total_assets", "current")
    total_liabilities = required_resolved_numeric(cur, context, "financials.total_liabilities", "current")
    revenue = required_resolved_numeric(cur, context, "financials.revenue", "current")

    working_capital = get_resolved_numeric(cur, context, "financials.working_capital", "current")
    working_capital_source = "financials.working_capital.current"
    if working_capital is None:
        current_assets = get_resolved_numeric(cur, context, "financials.current_assets", "current")
        current_liabilities = get_resolved_numeric(cur, context, "financials.current_liabilities", "current")
        if current_assets is not None and current_liabilities is not None:
            working_capital = current_assets - current_liabilities
            working_capital_source = "derived_current_assets_minus_current_liabilities"
    if working_capital is None:
        raise ValueError("Working capital or current assets/current liabilities are required for Altman Z-score.")

    retained_earnings, retained_earnings_source = first_available_resolved_numeric(
        cur,
        context,
        [
            ("financials.retained_earnings", "current", "financials.retained_earnings.current"),
            ("financials.accumulated_losses", "current", "financials.accumulated_losses.current"),
        ],
    )
    if retained_earnings is None:
        retained_earnings = Decimal("0")
        retained_earnings_source = "neutral_zero_missing_retained_earnings"
    elif retained_earnings_source == "financials.accumulated_losses.current":
        retained_earnings = -abs(retained_earnings)
        retained_earnings_source = "financials.accumulated_losses.current_negative_retained_earnings_proxy"

    ebit, ebit_source = first_available_resolved_numeric(
        cur,
        context,
        [
            ("financials.ebit", "current", "financials.ebit.current"),
            ("financials.operating_profit", "current", "financials.operating_profit.current"),
            ("financials.profit_before_tax", "current", "financials.profit_before_tax.current_proxy"),
            ("financials.net_profit", "current", "financials.net_profit.current_conservative_proxy"),
        ],
    )
    if ebit is None:
        raise ValueError("EBIT, operating profit, profit before tax, or net profit is required for Altman Z-score.")

    market_value_equity = get_optional_input_value(inputs, "market_data.market_value_of_equity.current")
    market_value_source = "market_data.market_value_of_equity.current"
    if market_value_equity is None:
        market_value_equity = get_resolved_numeric(cur, context, "financials.total_equity", "current")
        market_value_source = "financials.total_equity.current_book_value_proxy"
    if market_value_equity is None:
        market_value_equity = total_assets - total_liabilities
        market_value_source = "derived_total_assets_minus_total_liabilities_book_value_proxy"
    if market_value_equity is None:
        raise ValueError("Market value of equity or book equity proxy is required for Altman Z-score.")
    if total_assets == 0 or total_liabilities == 0:
        raise ValueError("Total assets and total liabilities must be non-zero for Altman Z-score.")

    a = working_capital / total_assets
    b = retained_earnings / total_assets
    c = ebit / total_assets
    d = market_value_equity / total_liabilities
    e = revenue / total_assets
    z_score = (
        Decimal("1.2") * a
        + Decimal("1.4") * b
        + Decimal("3.3") * c
        + Decimal("0.6") * d
        + Decimal("1.0") * e
    )
    config = rule_config(rule)
    severity = evaluate_numeric_bands(z_score, config.get("bands") or [])
    triggered = severity != "NONE"
    return RuleCalculation(
        triggered=triggered,
        severity=severity,
        computed_value=z_score,
        metric=str(config.get("metric") or "altman_z_score"),
        explanation=f"Altman Z-score is {z_score:.4f}; lower values indicate financial distress.",
        result_json={
            "status": "calculated",
            "metric": config.get("metric") or "altman_z_score",
            "formula": "1.2*A + 1.4*B + 3.3*C + 0.6*D + 1.0*E",
            "values": {
                "working_capital_to_assets": str(a),
                "retained_earnings_to_assets": str(b),
                "ebit_to_assets": str(c),
                "market_value_equity_to_liabilities": str(d),
                "revenue_to_assets": str(e),
                "altman_z_score": str(z_score),
                "working_capital_source": working_capital_source,
                "retained_earnings_source": retained_earnings_source,
                "ebit_source": ebit_source,
                "market_value_equity_source": market_value_source,
                "proxy_policy": "market value is preferred; audited book equity and derived annual-report subtotals are used when market data is unavailable",
            },
        },
    )


def rule_config(rule: dict[str, Any]) -> dict[str, Any]:
    config = rule.get("threshold_config_json") or {}
    if isinstance(config, str):
        config = json.loads(config)
    return config if isinstance(config, dict) else {}


def first_band_threshold(bands: list[dict[str, Any]], key: str) -> Optional[Decimal]:
    for band in bands:
        if key in band:
            return to_decimal(band[key])
    return None


def max_severity(left: str, right: str) -> str:
    return left if SEVERITY_ORDER.get(left, 0) >= SEVERITY_ORDER.get(right, 0) else right


def calculator_accepts_context(calculator: Callable[..., RuleCalculation]) -> bool:
    return len(signature(calculator).parameters) >= 4


def run_calculator(
    calculator: Callable[..., RuleCalculation],
    rule: dict[str, Any],
    inputs: dict[str, dict[str, Any]],
    cur: Any,
    context: Any,
) -> RuleCalculation:
    if calculator_accepts_context(calculator):
        return calculator(rule, inputs, cur, context)
    return calculator(rule, inputs)


CALCULATORS: dict[str, Callable[..., RuleCalculation]] = {
    "rules.fin_rev_001": calculate_fin_rev_001,
    "rules.fin_rev_002": calculate_fin_rev_002,
    "rules.fin_rev_003": calculate_fin_rev_003,
    "rules.fin_rev_004": calculate_fin_rev_004,
    "rules.fin_rev_005": calculate_fin_rev_005,
    "rules.fin_csh_001": calculate_fin_csh_001,
    "rules.fin_csh_002": calculate_fin_csh_002,
    "rules.fin_ast_001": calculate_fin_ast_001,
    "rules.fin_ast_002": calculate_fin_ast_002,
    "rules.fin_ast_003": calculate_fin_ast_003,
    "rules.fin_lia_001": calculate_fin_lia_001,
    "rules.fin_lia_002": calculate_fin_lia_002,
    "rules.fin_lia_003": calculate_fin_lia_003,
    "rules.fin_own_001": calculate_fin_own_001,
    "rules.fin_own_002": calculate_fin_own_002,
    "rules.fin_cmp_001": calculate_fin_cmp_001,
    "rules.fin_cmp_002": calculate_fin_cmp_002,
}


def execute_rules(
    cur: Any,
    run_id: str,
    raw_document_id: Optional[str] = None,
    execution_config: Optional[dict[str, Any]] = None,
) -> dict[str, Any]:
    context = get_run_context(cur, run_id, raw_document_id)
    execution_config = execution_config or {}
    period_label = context.reporting_period_label
    rules = load_rules_for_run(cur, run_id)
    if not rules:
        raise ValueError(f"No active rule manifest found for run_id={run_id}")

    cur.execute(
        "DELETE FROM fsre_rules.rule_results WHERE run_id = %s",
        (run_id,),
    )

    counts = {
        "calculated": 0,
        "triggered": 0,
        "not_triggered": 0,
        "blocked": 0,
        "failed": 0,
        "unsupported": 0,
    }
    result_ids: list[str] = []

    for rule in rules:
        validation_rows = load_validation_rows(cur, run_id, rule["rule_id"], rule["rule_version"])
        if not validation_rows:
            result_id = insert_skipped_rule_result(
                cur,
                context,
                rule,
                period_label,
                "failed",
                "Rule input validation rows are missing.",
                [],
                {},
            )
            result_ids.append(result_id)
            counts["failed"] += 1
            continue

        summary = validation_summary(validation_rows)
        blockers = blocking_rows(validation_rows)
        if blockers:
            result_id = insert_skipped_rule_result(
                cur,
                context,
                rule,
                period_label,
                "blocked",
                "Rule calculation skipped because required inputs are blocked or failed.",
                blockers,
                summary,
            )
            result_ids.append(result_id)
            counts["blocked"] += 1
            continue

        calculator = CALCULATORS.get(str(rule["implementation_key"]))
        if not calculator:
            result_id = insert_skipped_rule_result(
                cur,
                context,
                rule,
                period_label,
                "unsupported",
                "Rule implementation is not enabled in this increment.",
                [],
                summary,
            )
            result_ids.append(result_id)
            counts["unsupported"] += 1
            continue

        inputs = load_optional_rule_inputs(
            cur,
            context,
            rule,
            load_resolved_inputs(cur, validation_rows),
        )
        try:
            calculation = run_calculator(calculator, rule, inputs, cur, context)
        except Exception as exc:
            result_id = insert_skipped_rule_result(
                cur,
                context,
                rule,
                period_label,
                "failed",
                f"Rule calculation failed: {exc}",
                [],
                summary,
            )
            result_ids.append(result_id)
            counts["failed"] += 1
            continue

        result_id = insert_calculated_rule_result(
            cur,
            context,
            rule,
            period_label,
            calculation,
            validation_rows,
            inputs,
            summary,
            needs_review=summary.get("warn", 0) > 0,
        )
        result_ids.append(result_id)
        counts["calculated"] += 1
        if calculation.triggered:
            counts["triggered"] += 1
        else:
            counts["not_triggered"] += 1

    log_rule_execution(cur, run_id, counts, result_ids, execution_config)
    return {
        "run_id": run_id,
        "raw_document_id": context.raw_document_id,
        "rule_result_count": len(result_ids),
        **counts,
    }


def insert_skipped_rule_result(
    cur: Any,
    context: Any,
    rule: dict[str, Any],
    period_label: Optional[str],
    status: str,
    explanation: str,
    blockers: list[dict[str, Any]],
    summary: dict[str, int],
) -> str:
    result_json = {
        "status": status,
        "implementation_key": rule["implementation_key"],
        "validation_summary": summary,
        "blockers": [
            {
                "required_field_path": row.get("required_field_path"),
                "canonical_field_path": row.get("canonical_field_path"),
                "period_role": row.get("period_role"),
                "expected_period_label": row.get("expected_period_label"),
                "validation_status": row.get("validation_status"),
                "message": row.get("message"),
            }
            for row in blockers
        ],
    }
    cur.execute(
        """
        INSERT INTO fsre_rules.rule_results (
            run_id,
            entity_id,
            rule_id,
            rule_version,
            period_label,
            triggered,
            severity,
            computed_value,
            threshold_value,
            needs_review,
            review_status,
            source_documents,
            result_json,
            explanation
        )
        VALUES (%s, %s, %s, %s, %s, FALSE, 'NONE', NULL, %s::jsonb,
                TRUE, 'pending', %s::jsonb, %s::jsonb, %s)
        RETURNING rule_result_id
        """,
        (
            context.run_id,
            context.entity_id or "",
            rule["rule_id"],
            rule["rule_version"],
            period_label,
            json_dumps(rule_config(rule)),
            json_dumps(source_documents(context)),
            json_dumps(result_json),
            explanation,
        ),
    )
    return str(cur.fetchone()["rule_result_id"])


def insert_calculated_rule_result(
    cur: Any,
    context: Any,
    rule: dict[str, Any],
    period_label: Optional[str],
    calculation: RuleCalculation,
    validation_rows: list[dict[str, Any]],
    inputs: dict[str, dict[str, Any]],
    summary: dict[str, int],
    needs_review: bool,
) -> str:
    result_json = dict(calculation.result_json)
    result_json.update(
        {
            "implementation_key": rule["implementation_key"],
            "validation_summary": summary,
            "input_fields": [
                {
                    "required_field_path": required_path,
                    "resolved_field_id": str(item["field"].get("resolved_field_id"))
                    if item["field"].get("resolved_field_id")
                    else None,
                    "raw_document_id": str(item["field"].get("raw_document_id"))
                    if item["field"].get("raw_document_id")
                    else None,
                    "field_path": item["field"].get("field_path"),
                    "period_label": item["field"].get("period_label"),
                    "raw_value_text": item["field"].get("raw_value_text"),
                    "normalized_value_numeric": item["field"].get("normalized_value_numeric"),
                    "confidence_score": item["field"].get("confidence_score"),
                    "page_number": item["field"].get("page_number"),
                }
                for required_path, item in sorted(inputs.items())
            ],
        }
    )
    cur.execute(
        """
        INSERT INTO fsre_rules.rule_results (
            run_id,
            entity_id,
            rule_id,
            rule_version,
            period_label,
            triggered,
            severity,
            computed_value,
            threshold_value,
            needs_review,
            review_status,
            source_documents,
            result_json,
            explanation
        )
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s::jsonb,
                %s, %s, %s::jsonb, %s::jsonb, %s)
        RETURNING rule_result_id
        """,
        (
            context.run_id,
            context.entity_id or "",
            rule["rule_id"],
            rule["rule_version"],
            period_label,
            calculation.triggered,
            calculation.severity,
            calculation.computed_value,
            json_dumps(rule_config(rule)),
            needs_review,
            "pending" if needs_review else "not_required",
            json_dumps(source_documents(context)),
            json_dumps(result_json),
            calculation.explanation,
        ),
    )
    rule_result_id = str(cur.fetchone()["rule_result_id"])
    evidence_refs = insert_evidence_logs(cur, context, rule_result_id, validation_rows, inputs)
    cur.execute(
        """
        UPDATE fsre_rules.rule_results
        SET evidence_refs = %s::jsonb
        WHERE rule_result_id = %s
        """,
        (json_dumps(evidence_refs), rule_result_id),
    )
    return rule_result_id


def insert_evidence_logs(
    cur: Any,
    context: Any,
    rule_result_id: str,
    validation_rows: list[dict[str, Any]],
    inputs: dict[str, dict[str, Any]],
) -> list[dict[str, Any]]:
    evidence_refs: list[dict[str, Any]] = []
    for required_path, item in sorted(inputs.items()):
        field = item["field"]
        source_ref = field.get("source_ref_json") or {}
        if isinstance(source_ref, str):
            source_ref = json.loads(source_ref)
        # A calculated/normalized rule input is not a captured source value.
        # Keep it available to the calculation, but never write it to the
        # source-evidence log. Its underlying verbatim inputs are the evidence.
        if (
            field.get("extraction_method") == "derived_formula_v1"
            or (isinstance(source_ref, dict) and source_ref.get("source") == "derived_formula")
            or field.get("raw_value_text") in (None, "")
        ):
            continue
        source_ref = dict(source_ref)
        period_role = ""
        for suffix in ("current", "prior", "next_period", "historical"):
            if str(required_path).endswith(f".{suffix}"):
                period_role = suffix
                break
        source_ref.update(
            {
                "resolved_field_id": str(field.get("resolved_field_id")),
                "required_field_path": required_path,
                "period_label": field.get("period_label"),
                "period_role": field.get("period_role") or period_role or None,
                "evidence_source": "resolved_fields",
            }
        )
        cur.execute(
            """
            INSERT INTO fsre_audit.evidence_log (
                run_id,
                rule_result_id,
                raw_document_id,
                evidence_type,
                field_path,
                raw_value,
                normalized_value,
                page_number,
                confidence_score,
                source_ref_json
            )
            VALUES (%s, %s, %s, 'rule_input', %s, %s, %s, %s, %s, %s::jsonb)
            RETURNING evidence_id
            """,
            (
                context.run_id,
                rule_result_id,
                field.get("raw_document_id") or context.raw_document_id,
                field.get("field_path"),
                field.get("raw_value_text"),
                None,
                field.get("page_number"),
                field.get("confidence_score"),
                json_dumps(source_ref),
            ),
        )
        evidence_id = str(cur.fetchone()["evidence_id"])
        evidence_refs.append(
            {
                "evidence_id": evidence_id,
                "resolved_field_id": str(field.get("resolved_field_id")),
                "required_field_path": required_path,
                "field_path": field.get("field_path"),
                "period_label": field.get("period_label"),
                "raw_document_id": str(field.get("raw_document_id"))
                if field.get("raw_document_id")
                else None,
                "page_number": field.get("page_number"),
            }
        )
    return evidence_refs


def minimum_input_confidence(inputs: dict[str, dict[str, Any]]) -> Optional[Decimal]:
    values = [
        to_decimal(item["field"].get("confidence_score"))
        for item in inputs.values()
        if item["field"].get("confidence_score") is not None
    ]
    values = [value for value in values if value is not None]
    return min(values) if values else None


def source_documents(context: Any) -> list[dict[str, Any]]:
    return [
        {
            "raw_document_id": context.raw_document_id,
            "file_name": context.file_name,
            "storage_uri": context.storage_uri,
        }
    ]


def log_rule_execution(
    cur: Any,
    run_id: str,
    counts: dict[str, int],
    result_ids: list[str],
    execution_config: dict[str, Any],
) -> None:
    cur.execute(
        """
        INSERT INTO fsre_audit.validation_results (
            run_id,
            validation_scope,
            object_type,
            object_id,
            validation_name,
            status,
            message,
            details_json
        )
        VALUES (%s, 'rule_execution', 'run', %s, 'rule_execution_completed',
                %s, %s, %s::jsonb)
        """,
        (
            run_id,
            run_id,
            "pass" if counts.get("failed", 0) == 0 else "fail",
            "Rule execution completed.",
            json_dumps(
                {
                    **counts,
                    "rule_result_ids": result_ids,
                    "execution_config": execution_config,
                }
            ),
        ),
    )
