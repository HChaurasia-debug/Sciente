-- FSRE forensic formula registry.
-- Mirrors the arithmetic in recipe FRI_05_SCORE_SECTOR_FORENSICS.
-- This table is an auditable formula contract; the current recipe remains the execution engine.

CREATE SCHEMA IF NOT EXISTS financial_risk_intelligence;

CREATE TABLE IF NOT EXISTS financial_risk_intelligence.forensic_model_formula_configuration (
    model_key TEXT PRIMARY KEY REFERENCES financial_risk_intelligence.forensic_models(model_key),
    formula_name TEXT NOT NULL,
    formula_expression TEXT NOT NULL,
    component_formulas JSONB NOT NULL DEFAULT '{}'::jsonb,
    risk_band_rules JSONB NOT NULL DEFAULT '[]'::jsonb,
    score_direction TEXT NOT NULL,
    implementation_recipe TEXT NOT NULL DEFAULT 'FRI_05_SCORE_SECTOR_FORENSICS',
    configuration_version TEXT NOT NULL DEFAULT '2026.1',
    active BOOLEAN NOT NULL DEFAULT TRUE,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

INSERT INTO financial_risk_intelligence.forensic_model_formula_configuration
    (model_key, formula_name, formula_expression, component_formulas,
     risk_band_rules, score_direction, configuration_version)
VALUES
('altman', 'Altman Z double-prime',
 'Z'''' = 6.56*X1 + 3.26*X2 + 6.72*X3 + 1.05*X4',
 '{
   "X1":"(total_current_assets-total_current_liabilities)/total_assets",
   "X2":"retained_earnings/total_assets",
   "X3":"operating_income_ebit/total_assets",
   "X4":"total_shareholders_equity/total_liabilities"
 }'::jsonb,
 '[
   {"band":"LOW","condition":"score > 2.6"},
   {"band":"ELEVATED","condition":"1.1 <= score <= 2.6"},
   {"band":"HIGH","condition":"score < 1.1"}
 ]'::jsonb, 'HIGHER_IS_BETTER', '2026.1'),

('sloan', 'Sloan Accruals Ratio',
 '(net_profit-operating_cash_flow)/((current_total_assets+prior_total_assets)/2)',
 '{"average_total_assets":"(current_total_assets+prior_total_assets)/2",
   "accrual_amount":"net_profit-operating_cash_flow"}'::jsonb,
 '[
   {"band":"HIGH","condition":"score > 0.10"},
   {"band":"ELEVATED","condition":"0.05 < score <= 0.10"},
   {"band":"LOW","condition":"score <= 0.05"}
 ]'::jsonb, 'LOWER_IS_BETTER', '2026.1'),

('beneish', 'Beneish M-Score',
 '-4.84 + 0.92*DSRI + 0.528*GMI + 0.404*AQI + 0.892*SGI + 0.115*DEPI - 0.172*SGAI + 4.679*TATA - 0.327*LVGI',
 '{
   "DSRI":"(current_receivables/current_revenue)/(prior_receivables/prior_revenue)",
   "GMI":"prior_gross_margin/current_gross_margin",
   "gross_margin":"(revenue-abs(cost_of_goods_sold))/revenue",
   "AQI":"current_asset_quality/prior_asset_quality",
   "asset_quality":"1-((total_current_assets+net_ppe)/total_assets)",
   "SGI":"current_revenue/prior_revenue",
   "DEPI":"prior_depreciation_rate/current_depreciation_rate",
   "depreciation_rate":"abs(depreciation_amortization)/(abs(depreciation_amortization)+net_ppe)",
   "SGAI":"(current_abs_sga/current_revenue)/(prior_abs_sga/prior_revenue)",
   "TATA":"(current_net_profit-current_operating_cash_flow)/current_total_assets",
   "LVGI":"current_leverage/prior_leverage",
   "leverage":"(total_current_liabilities+long_term_debt)/total_assets"
 }'::jsonb,
 '[
   {"band":"HIGH","condition":"score > -1.78"},
   {"band":"LOW","condition":"score <= -1.78"}
 ]'::jsonb, 'LOWER_IS_BETTER', '2026.1'),

('piotroski', 'Piotroski F-Score',
 'positive_roa + positive_cfo + improving_roa + low_accruals + falling_leverage + improving_liquidity + no_dilution + improving_margin + improving_turnover',
 '{
   "positive_roa":"current_net_profit/current_total_assets > 0",
   "positive_cfo":"current_operating_cash_flow > 0",
   "improving_roa":"current_roa > prior_roa",
   "low_accruals":"current_operating_cash_flow/current_total_assets > current_roa",
   "falling_leverage":"current_long_term_debt/current_total_assets < prior_long_term_debt/prior_total_assets",
   "improving_liquidity":"current_current_assets/current_current_liabilities > prior_current_assets/prior_current_liabilities",
   "no_dilution":"current_shares_outstanding <= prior_shares_outstanding",
   "improving_margin":"current_gross_margin > prior_gross_margin",
   "improving_turnover":"current_revenue/current_total_assets > prior_revenue/prior_total_assets"
 }'::jsonb,
 '[
   {"band":"LOW","condition":"score >= 7"},
   {"band":"ELEVATED","condition":"4 <= score < 7"},
   {"band":"HIGH","condition":"score < 4"}
 ]'::jsonb, 'HIGHER_IS_BETTER', '2026.1'),

('montier', 'Montier C-Score',
 '(sum_of_triggered_signals/number_of_enabled_signals)*6',
 '{
   "income_exceeds_cfo":"current_net_profit > current_operating_cash_flow",
   "dso_rising":"current_receivables/current_revenue > prior_receivables/prior_revenue",
   "other_current_assets_rising":"(current_current_assets-current_receivables-current_inventory)/current_revenue > (prior_current_assets-prior_receivables-prior_inventory)/prior_revenue",
   "depreciation_rate_declining":"current_depreciation_rate < prior_depreciation_rate",
   "depreciation_rate":"abs(depreciation_amortization)/(abs(depreciation_amortization)+net_ppe)",
   "asset_growth_above_20pct":"current_total_assets/prior_total_assets-1 > 0.20",
   "inventory_days_rising":"current_inventory/abs(current_cogs) > prior_inventory/abs(prior_cogs)",
   "inventory_signal_note":"Inventory signal is included only when enabled and current/prior inventory are available"
 }'::jsonb,
 '[
   {"band":"HIGH","condition":"score >= 4"},
   {"band":"ELEVATED","condition":"2 <= score < 4"},
   {"band":"LOW","condition":"score < 2"}
 ]'::jsonb, 'LOWER_IS_BETTER', '2026.1')
ON CONFLICT (model_key) DO UPDATE SET
    formula_name = EXCLUDED.formula_name,
    formula_expression = EXCLUDED.formula_expression,
    component_formulas = EXCLUDED.component_formulas,
    risk_band_rules = EXCLUDED.risk_band_rules,
    score_direction = EXCLUDED.score_direction,
    configuration_version = EXCLUDED.configuration_version,
    active = TRUE,
    updated_at = NOW();

-- Audit view: formula, required inputs, period requirements and sector settings.
CREATE OR REPLACE VIEW financial_risk_intelligence.forensic_model_calculation_settings AS
SELECT
    model.model_key,
    model.model_name,
    model.model_version,
    formula.formula_expression,
    formula.component_formulas,
    formula.risk_band_rules,
    formula.score_direction,
    input.concept_key,
    input.period_requirement,
    input.required,
    input.input_order,
    binding.input_key,
    sector.sector_key,
    sector.enabled,
    sector.weight,
    sector.parameters,
    sector.configuration_version
FROM financial_risk_intelligence.forensic_models model
JOIN financial_risk_intelligence.forensic_model_formula_configuration formula
  ON formula.model_key = model.model_key AND formula.active
LEFT JOIN financial_risk_intelligence.forensic_model_inputs input
  ON input.model_key = model.model_key AND input.active
LEFT JOIN financial_risk_intelligence.forensic_input_bindings binding
  ON binding.concept_key = input.concept_key AND binding.active
LEFT JOIN financial_risk_intelligence.sector_model_configuration sector
  ON sector.model_key = model.model_key AND sector.active
WHERE model.active;

-- Verification query.
SELECT *
FROM financial_risk_intelligence.forensic_model_calculation_settings
WHERE model_key IN ('montier','altman','sloan','beneish','piotroski')
ORDER BY model_key, sector_key, input_order;
