-- Incremental database-only configuration fix.
-- Applies to AMOS wording and equivalent commercial/industrial filings.
-- Prerequisites:
--   FRI_FINANCIAL_SYNONYM_REGISTRY.sql
--   FRI_MANUFACTURING_GENERIC_TEMPLATE_MAPPING.sql
--   FRI_MANUFACTURING_DERIVATION_CONFIGURATION.sql
--
-- This script does NOT store filing values and does NOT change any Python recipe.

BEGIN;

-- Ensure every cash-flow output concept is present and active.
INSERT INTO financial_risk_intelligence.financial_concepts
    (concept_key, statement_type, canonical_label, is_required, active)
VALUES
    ('investing_cash_flow', 'CASH_FLOW_STATEMENT', 'Cash flow from investing activities', true, true),
    ('financing_cash_flow', 'CASH_FLOW_STATEMENT', 'Cash flow from financing activities', true, true),
    ('net_change_cash', 'CASH_FLOW_STATEMENT', 'Net change in cash and cash equivalents', true, true),
    ('ending_cash', 'CASH_FLOW_STATEMENT', 'Cash and cash equivalents at end of period', true, true)
ON CONFLICT (concept_key) DO UPDATE SET
    statement_type = EXCLUDED.statement_type,
    canonical_label = EXCLUDED.canonical_label,
    active = true,
    updated_at = now();

-- AMOS confirms these statement titles; upsert makes the terms reusable.
SELECT financial_risk_intelligence.upsert_statement_alias(
    'BALANCE_SHEET',
    'Consolidated Statements of Financial Position',
    'COMMERCIAL', 1, 'AMOS_2026_VALIDATION'
);

SELECT financial_risk_intelligence.upsert_statement_alias(
    'INCOME_STATEMENT',
    'Consolidated Statement of Comprehensive Income',
    'COMMERCIAL', 1, 'AMOS_2026_VALIDATION'
);

SELECT financial_risk_intelligence.upsert_statement_alias(
    'CASH_FLOW_STATEMENT',
    'Consolidated Statement of Cash Flows',
    'COMMERCIAL', 1, 'AMOS_2026_VALIDATION'
);

-- Income-statement and financial-position aliases. These map source labels,
-- not values. Component expense aliases support approved database derivations.
SELECT financial_risk_intelligence.upsert_concept_alias(
    'cost_of_goods_sold', 'Cost of sales', 'COMMERCIAL', NULL, 1,
    'AMOS_FY26_AR', 100, 'AMOS_2026_VALIDATION'
);
SELECT financial_risk_intelligence.upsert_concept_alias(
    'distribution_expense', 'Distribution costs', 'COMMERCIAL', NULL, 1,
    'AMOS_FY26_AR', 100, 'AMOS_2026_VALIDATION'
);
SELECT financial_risk_intelligence.upsert_concept_alias(
    'administrative_expenses', 'Administrative expenses', 'COMMERCIAL', NULL, 1,
    'AMOS_FY26_AR', 100, 'AMOS_2026_VALIDATION'
);
SELECT financial_risk_intelligence.upsert_concept_alias(
    'interest_expense', 'Finance costs', 'COMMERCIAL', NULL, 1,
    'AMOS_FY26_AR', 100, 'AMOS_2026_VALIDATION'
);
SELECT financial_risk_intelligence.upsert_concept_alias(
    'net_profit', 'Loss for the financial year', 'COMMERCIAL', NULL, 1,
    'AMOS_FY26_AR', 100, 'AMOS_2026_VALIDATION'
);
SELECT financial_risk_intelligence.upsert_concept_alias(
    'total_current_assets', 'Current assets', 'COMMERCIAL', NULL, 10,
    'AMOS_FY26_AR', 100, 'AMOS_2026_VALIDATION'
);
SELECT financial_risk_intelligence.upsert_concept_alias(
    'total_current_liabilities', 'Current liabilities', 'COMMERCIAL', NULL, 10,
    'AMOS_FY26_AR', 100, 'AMOS_2026_VALIDATION'
);
SELECT financial_risk_intelligence.upsert_concept_alias(
    'total_shareholders_equity', 'Equity attributable to owners of the Company',
    'COMMERCIAL', NULL, 1, 'AMOS_FY26_AR', 100, 'AMOS_2026_VALIDATION'
);

-- Individual expense lines must remain components.  A legacy direct mapping
-- of “Administrative expenses” to SG&A would otherwise suppress the governed
-- Distribution costs + Administrative expenses calculation.
UPDATE financial_risk_intelligence.financial_concept_aliases
SET active = false, updated_at = now()
WHERE concept_key = 'sg_and_a_expense'
  AND normalized_alias_text IN (
      financial_risk_intelligence.normalize_financial_alias_text('Administrative expenses'),
      financial_risk_intelligence.normalize_financial_alias_text('General and administrative expenses'),
      financial_risk_intelligence.normalize_financial_alias_text('Selling expenses')
  );

-- Cash-flow aliases. The resolver keeps source signs: “used in” remains
-- negative and “generated” remains positive.
SELECT financial_risk_intelligence.upsert_concept_alias(
    'operating_cash_flow', 'Net cash (used in)/generated from operating activities',
    'COMMERCIAL', NULL, 1, 'AMOS_FY26_AR', 100, 'AMOS_2026_VALIDATION'
);
SELECT financial_risk_intelligence.upsert_concept_alias(
    'investing_cash_flow', 'Net cash generated from investing activities',
    'COMMERCIAL', NULL, 1, 'AMOS_FY26_AR', 100, 'AMOS_2026_VALIDATION'
);
SELECT financial_risk_intelligence.upsert_concept_alias(
    'investing_cash_flow', 'Net cash used in investing activities',
    'COMMERCIAL', NULL, 2, 'AMOS_FY26_AR', 100, 'AMOS_2026_VALIDATION'
);
SELECT financial_risk_intelligence.upsert_concept_alias(
    'financing_cash_flow', 'Net cash used in financing activities',
    'COMMERCIAL', NULL, 1, 'AMOS_FY26_AR', 100, 'AMOS_2026_VALIDATION'
);
SELECT financial_risk_intelligence.upsert_concept_alias(
    'financing_cash_flow', 'Net cash generated from financing activities',
    'COMMERCIAL', NULL, 2, 'AMOS_FY26_AR', 100, 'AMOS_2026_VALIDATION'
);
SELECT financial_risk_intelligence.upsert_concept_alias(
    'net_change_cash', 'Net decrease in cash and bank balances',
    'COMMERCIAL', NULL, 1, 'AMOS_FY26_AR', 100, 'AMOS_2026_VALIDATION'
);
SELECT financial_risk_intelligence.upsert_concept_alias(
    'net_change_cash', 'Net increase in cash and bank balances',
    'COMMERCIAL', NULL, 2, 'AMOS_FY26_AR', 100, 'AMOS_2026_VALIDATION'
);
SELECT financial_risk_intelligence.upsert_concept_alias(
    'ending_cash', 'Cash and bank balances at end of financial year',
    'COMMERCIAL', NULL, 1, 'AMOS_FY26_AR', 100, 'AMOS_2026_VALIDATION'
);
SELECT financial_risk_intelligence.upsert_concept_alias(
    'ending_cash', 'Cash and cash equivalents at end of financial year',
    'COMMERCIAL', NULL, 2, 'AMOS_FY26_AR', 100, 'AMOS_2026_VALIDATION'
);

-- Expand the existing Manufacturing & Industrials UI profile.  The old
-- configuration exposed only operating cash flow, which is why the webapp
-- showed 1 of 1 cash-flow fields.
INSERT INTO financial_risk_intelligence.financial_template_fields
    (template_key, field_key, concept_key, display_label, statement_type,
     display_order, required, active)
VALUES
    ('MANUFACTURING_INDUSTRIALS_GENERIC', 'cash_flow_from_investing',
     'investing_cash_flow', 'Cash flow from investing activities',
     'CASH_FLOW_STATEMENT', 320, true, true),
    ('MANUFACTURING_INDUSTRIALS_GENERIC', 'cash_flow_from_financing',
     'financing_cash_flow', 'Cash flow from financing activities',
     'CASH_FLOW_STATEMENT', 330, true, true),
    ('MANUFACTURING_INDUSTRIALS_GENERIC', 'net_change_in_cash',
     'net_change_cash', 'Net change in cash',
     'CASH_FLOW_STATEMENT', 340, true, true),
    ('MANUFACTURING_INDUSTRIALS_GENERIC', 'ending_cash_and_equivalents',
     'ending_cash', 'Cash and cash equivalents at end of period',
     'CASH_FLOW_STATEMENT', 350, true, true)
ON CONFLICT (template_key, field_key) DO UPDATE SET
    concept_key = EXCLUDED.concept_key,
    display_label = EXCLUDED.display_label,
    statement_type = EXCLUDED.statement_type,
    display_order = EXCLUDED.display_order,
    required = EXCLUDED.required,
    active = true,
    updated_at = now();

-- A lease liability is not automatically “long-term debt”. Remove legacy
-- direct mappings that cause a lease-only balance to populate that field.
-- Long-term debt may still resolve from a reported non-current borrowing or
-- a separately governed debt derivation rule.
UPDATE financial_risk_intelligence.financial_concept_aliases
SET active = false, updated_at = now()
WHERE concept_key = 'long_term_debt'
  AND normalized_alias_text IN (
      financial_risk_intelligence.normalize_financial_alias_text('Lease liabilities'),
      financial_risk_intelligence.normalize_financial_alias_text('Loans and borrowings')
  );

DELETE FROM financial_risk_intelligence.financial_rule_components
WHERE rule_key = 'LTD_SUM'
  AND component_concept_key = 'non_current_lease_liabilities';

-- Avoid incorrectly using Total equity when non-controlling interests exist.
-- The direct “Equity attributable to owners” alias remains the preferred
-- shareholder-equity source.
UPDATE financial_risk_intelligence.financial_concept_aliases
SET active = false, updated_at = now()
WHERE concept_key = 'total_shareholders_equity'
  AND normalized_alias_text = financial_risk_intelligence.normalize_financial_alias_text('Total equity');

COMMIT;

-- Validation: all aliases below must be active and approved.
SELECT concept_key, alias_text, sector_key, priority, active, approval_status
FROM financial_risk_intelligence.approved_financial_concept_aliases
WHERE source_document_id = 'AMOS_FY26_AR'
ORDER BY concept_key, priority, alias_text;

-- Expected result: five active cash-flow fields in the UI profile.
SELECT field_key, concept_key, display_label, required, active
FROM financial_risk_intelligence.financial_template_fields
WHERE template_key = 'MANUFACTURING_INDUSTRIALS_GENERIC'
  AND statement_type = 'CASH_FLOW_STATEMENT'
ORDER BY display_order;
