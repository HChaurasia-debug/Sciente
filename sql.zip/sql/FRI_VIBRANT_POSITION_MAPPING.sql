-- Generic aliases and derivations observed in consolidated statements of
-- financial position (e.g. VIBRANT page 48). Safe for all sectors using the
-- generic commercial/manufacturing template.
BEGIN;

INSERT INTO financial_risk_intelligence.financial_concept_aliases
 (concept_key, alias_text, normalized_alias_text, sector_key, priority, active, approval_status, approved_by, approved_at)
SELECT v.concept_key, v.alias_text,
       financial_risk_intelligence.normalize_financial_alias_text(v.alias_text),
       NULL, v.priority, true, 'APPROVED', 'POSITION_MAPPING', now()
FROM (VALUES
 ('inventory','Inventories',1),
 ('net_ppe','Property, plant and equipment',1),
 ('net_ppe','Net property, plant and equipment',2),
 ('total_assets','Total assets',1),
 ('total_liabilities','Total liabilities',1),
 ('total_shareholders_equity','Equity attributable to owners of the Company',1),
 ('total_shareholders_equity','Total equity',2),
 ('retained_earnings','Reserves',5),
 ('non_current_borrowings','Loans and borrowings',1),
 ('non_current_lease_liabilities','Lease liabilities',1),
 ('long_term_debt','Loans and borrowings',5),
 ('long_term_debt','Non-current loans and borrowings',1),
 ('trade_receivables_net','Trade and other receivables',5),
 ('total_current_assets','Total current assets',1),
 ('total_current_liabilities','Total current liabilities',1)
) v(concept_key,alias_text,priority)
ON CONFLICT DO NOTHING;

-- Long-term debt is the non-current borrowing plus non-current lease
-- liability total when no single total debt row is reported.
INSERT INTO financial_risk_intelligence.financial_template_rules
 (rule_key, template_key, target_concept_key, operator, priority, output_sign, active, approval_status)
VALUES ('LTD_POSITION_COMPONENTS','MANUFACTURING_INDUSTRIALS_GENERIC','long_term_debt',
        'LINEAR_COMBINATION',5,'ABSOLUTE',true,'APPROVED')
ON CONFLICT (rule_key) DO UPDATE SET priority=5, active=true, approval_status='APPROVED';

INSERT INTO financial_risk_intelligence.financial_rule_components
 (rule_key, component_concept_key, coefficient, component_sign, component_order)
VALUES
 ('LTD_POSITION_COMPONENTS','non_current_borrowings',1,'ABSOLUTE',1),
 ('LTD_POSITION_COMPONENTS','non_current_lease_liabilities',1,'ABSOLUTE',2)
ON CONFLICT (rule_key, component_concept_key) DO UPDATE
 SET coefficient=EXCLUDED.coefficient, component_sign=EXCLUDED.component_sign;

COMMIT;
