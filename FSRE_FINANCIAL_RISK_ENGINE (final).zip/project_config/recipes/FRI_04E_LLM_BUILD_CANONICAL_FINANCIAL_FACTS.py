"""Database-only canonical financial fact resolver.

Deploy financial_resolver_engine in the project Python library before running.
"""
import uuid
import json
import math
import re
from datetime import datetime, timezone
import dataiku
import pandas as pd
from financial_risk_intelligence.financial_resolver_engine import resolve

SOURCE = "FRI_STANDARDIZED_STATEMENT_VALUES"
MANIFEST = "FRI_REQUIRED_FIELD_MANIFEST"
CONFIGURATION = "FRI_FINANCIAL_CONCEPT_CONFIGURATION"
APPROVED_ALIASES = "FRI_APPROVED_FINANCIAL_CONCEPT_ALIASES"
ASSIGNMENTS = "FRI_ENTITY_SECTOR_ASSIGNMENTS"
OUTPUT = "FRI_RESOLVED_FINANCIAL_FACTS"


def numeric(value):
    try:
        result = float(str(value).replace(",", ""))
        return result if math.isfinite(result) else None
    except (TypeError, ValueError):
        return None


def recover_split_balance_subtotals(records):
    """Repair numeric-only subtotal pairs before the project-library resolver.

    A single financial-statement page can be emitted as several table
    artifacts (for example headings, values, and totals in separate
    fragments).  Recover at page scope when a page number is available so the
    numeric-only subtotal rows can see their Total assets / Total liabilities
    anchors.  Retain table scope as the fallback for sources without pages.
    """
    rows = [dict(record) for record in records]
    scopes = {}
    for row in rows:
        if str(row.get("statement_type") or "").upper() != "BALANCE_SHEET":
            continue
        page = numeric(row.get("page_number"))
        table = str(row.get("table_artifact_id") or row.get("source_table_id") or "")
        if page is not None:
            scope = ("page", int(page))
        elif table:
            scope = ("table", table)
        else:
            continue
        scopes.setdefault(scope, []).append(row)
    for table_rows in scopes.values():
        by_index = {}
        for row in table_rows:
            try:
                index = int(float(row.get("row_index")))
            except (TypeError, ValueError):
                continue
            by_index.setdefault(index, []).append(row)
        normalized_labels = {
            index: {
                re.sub(r"[^a-z0-9]+", " ", str(row.get("row_label") or "").lower()).strip()
                for row in indexed
            }
            for index, indexed in by_index.items()
        }
        total_assets = next((index for index, labels in normalized_labels.items() if "total assets" in labels), None)
        total_liabilities = next((index for index, labels in normalized_labels.items() if "total liabilities" in labels), None)
        if total_assets is None or total_liabilities is None or total_assets >= total_liabilities:
            continue
        numeric_rows = sorted({
            index for index, indexed in by_index.items()
            if any(
                numeric(row.get("numeric_value")) is not None
                and numeric(row.get("row_label")) is not None
                for row in indexed
            )
        })
        pairs = [
            (left, right) for left, right in zip(numeric_rows, numeric_rows[1:])
            if right == left + 1
        ]
        asset_pairs = [pair for pair in pairs if pair[1] < total_assets]
        liability_pairs = [pair for pair in pairs if total_assets < pair[0] and pair[1] < total_liabilities]
        repairs = []
        if len(asset_pairs) >= 2:
            repairs.extend(((asset_pairs[-2], "Total non-current assets"), (asset_pairs[-1], "Total current assets")))
        elif asset_pairs:
            repairs.append((asset_pairs[-1], "Total current assets"))
        if len(liability_pairs) >= 2:
            repairs.extend(((liability_pairs[0], "Total current liabilities"), (liability_pairs[-1], "Total non-current liabilities")))
        elif liability_pairs:
            repairs.append((liability_pairs[0], "Total current liabilities"))
        for (current_index, prior_index), label in repairs:
            for row in by_index[current_index]:
                if numeric(row.get("numeric_value")) is not None:
                    row.update(row_label=label, period_label="CURRENT", period_end="CURRENT", entity_scope="GROUP")
            for row in by_index[prior_index]:
                if numeric(row.get("numeric_value")) is not None:
                    row.update(row_label=label, period_label="PRIOR", period_end="PRIOR", entity_scope="GROUP")
    return rows


def period_sort_key(value):
    """Keep recovered CURRENT/PRIOR labels in reporting order.

    Lexical sorting puts PRIOR before CURRENT and made a correctly selected
    current value appear under the wrong UI heading. Explicit years still sort
    newest first, while any unrecognised label remains a last-resort fallback.
    """
    raw = str(value or "").strip()
    match = re.search(r"\b(?:19|20)\d{2}\b", raw)
    if match:
        return (3, int(match.group(0)))
    normalized = raw.upper()
    if normalized == "CURRENT":
        return (2, 0)
    if normalized == "PRIOR":
        return (1, 0)
    return (0, 0)


def disclosed_depreciation_amortization(group):
    """Return a current/prior D&A pair from exact disclosed Group rows.

    Prefer a direct D&A or total PP&E depreciation disclosure. Separate ROU
    and intangible components are used only when no total is present, which
    prevents double-counting leases already included in PP&E depreciation.
    """
    direct_labels = {
        "depreciation and amortisation", "depreciation and amortization",
        "depreciation amortisation", "depreciation amortization",
        "depreciation of property plant and equipment",
    }
    component_labels = {
        "depreciation of right of use assets",
        "amortisation of intangible assets", "amortization of intangible assets",
    }

    def normalized(value):
        return re.sub(r"[^a-z0-9]+", " ", str(value or "").lower()).strip()

    selected = group.copy()
    if "entity_scope" in selected.columns:
        scope = selected["entity_scope"].fillna("").astype(str).str.upper()
        consolidated = selected[scope.str.contains("GROUP|CONSOLIDATED", regex=True)]
        if not consolidated.empty:
            selected = consolidated
    records = []
    for row in selected.to_dict(orient="records"):
        label = normalized(row.get("row_label"))
        value = numeric(row.get("numeric_value"))
        if value is None or label not in direct_labels | component_labels:
            continue
        period = str(row.get("period_label") or row.get("period_end") or "").strip()
        records.append({"label": label, "value": abs(value), "period": period})
    periods = sorted({item["period"] for item in records if item["period"]}, key=period_sort_key, reverse=True)
    if len(periods) < 2:
        return None
    resolved = []
    lineage = []
    for period in periods[:2]:
        rows = [item for item in records if item["period"] == period]
        direct = [item for item in rows if item["label"] in direct_labels]
        if direct:
            chosen = max(direct, key=lambda item: item["value"])
            resolved.append(chosen["value"])
            lineage.append(chosen["label"])
            continue
        components = [item for item in rows if item["label"] in component_labels]
        if not components:
            return None
        resolved.append(sum(item["value"] for item in components))
        lineage.append(" + ".join(item["label"] for item in components))
    return {
        "concept_key": "depreciation_amortization",
        "current_value": resolved[0],
        "prior_value": resolved[1],
        "confidence": 1.0,
        "resolution_method": "DISCLOSED_DA_ON_THE_FLY",
        "current_source_label": lineage[0],
        "prior_source_label": lineage[1],
    }


def governed_statement_overrides(group):
    """Resolve recurring audited structures before any LLM fallback.

    Rules are issuer-agnostic and depend only on statement type, consolidated
    scope, audited section, period and exact row role. They cover facts that
    often have no single canonical label on the face of a report.
    """
    def normalized(value):
        return re.sub(r"[^a-z0-9]+", " ", str(value or "").lower()).strip()

    rows = group.to_dict(orient="records")
    consolidated = [row for row in rows if normalized(row.get("entity_scope")) in {"group", "consolidated", "reported", ""}]
    if consolidated:
        rows = consolidated
    periods = sorted({
        str(row.get("period_label") or row.get("period_end") or "").strip()
        for row in rows
        if str(row.get("period_label") or row.get("period_end") or "").strip()
    }, key=period_sort_key, reverse=True)
    if len(periods) < 2:
        return []
    current_period, prior_period = periods[:2]

    def period(row):
        return str(row.get("period_label") or row.get("period_end") or "").strip()

    def value(row):
        return numeric(row.get("numeric_value"))

    def rows_for(statement, predicate):
        return [row for row in rows
                if str(row.get("statement_type") or "").upper() == statement
                and value(row) is not None and predicate(normalized(row.get("row_label")), row)]

    def pair(candidates, prefer=None):
        selected = []
        for target_period in (current_period, prior_period):
            eligible = [row for row in candidates if period(row) == target_period]
            if not eligible:
                return None
            if prefer:
                eligible.sort(key=lambda row: prefer(normalized(row.get("row_label")), row), reverse=True)
            selected.append(eligible[0])
        return selected

    def fact(key, selected, current_value=None, prior_value=None, method="GOVERNED_STATEMENT_ROW"):
        current, prior = selected
        return {
            "concept_key": key,
            "statement_type": str(current.get("statement_type") or ""),
            "table_artifact_id": str(current.get("table_artifact_id") or ""),
            "source_table_id": str(current.get("source_table_id") or ""),
            "source_page_number": numeric(current.get("page_number")),
            "current_source_row_index": numeric(current.get("row_index")),
            "current_source_column_index": numeric(current.get("column_index")),
            "prior_source_row_index": numeric(prior.get("row_index")),
            "prior_source_column_index": numeric(prior.get("column_index")),
            "scope": "GROUP",
            "currency": str(current.get("currency") or ""),
            "unit": str(current.get("unit") or ""),
            "current_period": current_period,
            "prior_period": prior_period,
            "current_value": value(current) if current_value is None else current_value,
            "prior_value": value(prior) if prior_value is None else prior_value,
            "current_source_label": str(current.get("row_label") or ""),
            "prior_source_label": str(prior.get("row_label") or ""),
            "resolution_method": method,
        }

    overrides = []

    net_rows = rows_for("INCOME_STATEMENT", lambda label, _:
        label in {"profit for the year", "loss for the year", "profit loss for the year",
                  "loss profit for the year", "net profit", "net income"})
    net_pair = pair(net_rows, lambda label, row: 100 if "consolidated" in normalized(row.get("statement_title")) else 0)
    if net_pair:
        overrides.append(fact("net_profit", net_pair, method="PRIMARY_STATEMENT_FINAL_RESULT"))

    ppe_rows = rows_for("BALANCE_SHEET", lambda label, _:
        label in {"plant and equipment", "property plant and equipment",
                  "property and equipment", "net property plant and equipment"})
    ppe_pair = pair(ppe_rows, lambda label, row:
        (100 if "statement" in normalized(row.get("statement_title")) else 0)
        + (20 if label in {"property plant and equipment", "plant and equipment"} else 0))
    if ppe_pair:
        rou_rows = rows_for("BALANCE_SHEET", lambda label, _:
            label in {"right of use assets", "right of use asset"})
        rou_pair = pair(rou_rows)
        same_presentation = bool(
            rou_pair
            and (
                str(ppe_pair[0].get("table_artifact_id") or ppe_pair[0].get("source_table_id") or "")
                == str(rou_pair[0].get("table_artifact_id") or rou_pair[0].get("source_table_id") or "")
                or numeric(ppe_pair[0].get("page_number")) == numeric(rou_pair[0].get("page_number"))
            )
        )
        if same_presentation:
            overrides.append(fact("net_ppe", ppe_pair,
                value(ppe_pair[0]) + value(rou_pair[0]),
                value(ppe_pair[1]) + value(rou_pair[1]),
                "SEPARATE_PPE_AND_ROU_COMPONENT_SUM"))
        else:
            overrides.append(fact("net_ppe", ppe_pair, method="PRIMARY_BALANCE_SHEET_CARRYING_AMOUNT"))

    pbt_rows = rows_for("INCOME_STATEMENT", lambda label, _:
        label.startswith(("profit before tax", "loss before tax", "profit before income tax",
                          "loss before income tax", "profit loss before income tax",
                          "loss profit before income tax"))
        and "discontinued" not in label)
    finance_rows = rows_for("INCOME_STATEMENT", lambda label, _:
        label in {"finance cost", "finance costs", "finance expense", "finance expenses", "interest expense"})
    pbt_pair, finance_pair = pair(pbt_rows), pair(finance_rows)
    if pbt_pair and finance_pair:
        current_ebit = value(pbt_pair[0]) + abs(value(finance_pair[0]))
        prior_ebit = value(pbt_pair[1]) + abs(value(finance_pair[1]))
        overrides.append(fact("operating_income_ebit", pbt_pair, current_ebit, prior_ebit,
                              "GOVERNED_EBIT_PBT_PLUS_FINANCE_COST"))

    debt_rows = rows_for("BALANCE_SHEET", lambda label, row:
        ("non current" in normalized(row.get("statement_section")) or label.startswith("non current"))
        and any(term in label for term in ("borrowings", "loans", "lease liabilities"))
        and not label.startswith("total"))
    debt_by_period = []
    for target_period in (current_period, prior_period):
        components = [row for row in debt_rows if period(row) == target_period]
        if not components:
            debt_by_period = []
            break
        debt_by_period.append((components, sum(abs(value(row)) for row in components)))
    if debt_by_period:
        selected = [debt_by_period[0][0][0], debt_by_period[1][0][0]]
        overrides.append(fact("long_term_debt", selected, debt_by_period[0][1], debt_by_period[1][1],
                              "NON_CURRENT_DEBT_COMPONENT_SUM"))

    net_share_rows = rows_for("BALANCE_SHEET", lambda label, _:
        label in {"net number of issued shares", "shares outstanding",
                  "number of issued shares excluding treasury shares"})
    net_share_pair = pair(net_share_rows)
    if net_share_pair:
        overrides.append(fact("shares_outstanding", net_share_pair,
                              abs(value(net_share_pair[0])), abs(value(net_share_pair[1])),
                              "ISSUED_LESS_TREASURY_SHARES"))
    else:
        issued_rows = rows_for("BALANCE_SHEET", lambda label, _:
            label in {"issued shares at end", "total number of issued shares", "issued ordinary shares"})
        treasury_rows = rows_for("BALANCE_SHEET", lambda label, _:
            label in {"treasury shares count at end", "number of treasury shares"})
        issued_pair, treasury_pair = pair(issued_rows), pair(treasury_rows)
        if issued_pair and treasury_pair:
            overrides.append(fact("shares_outstanding", issued_pair,
                abs(value(issued_pair[0])) - abs(value(treasury_pair[0])),
                abs(value(issued_pair[1])) - abs(value(treasury_pair[1])),
                "ISSUED_LESS_TREASURY_SHARES"))
    return overrides


def read(name):
    return dataiku.Dataset(name).get_dataframe()


def read_optional(name):
    try:
        return read(name)
    except Exception as exc:
        print("Optional resolver dataset unavailable:", name, exc)
        return pd.DataFrame()


def column(df, name, default=None):
    return df[name] if name in df.columns else pd.Series(default, index=df.index)


def resolver_configuration(item):
    """Read resolver controls from either view columns or JSON configuration.

    The PostgreSQL dataset is an aggregated view. Its underlying governed
    table stores durable resolver controls in validation_definition, while
    newer versions of the view may also project them as individual columns.
    """
    definition = item.get("validation_definition")
    if isinstance(definition, str):
        try:
            definition = json.loads(definition or "{}")
        except json.JSONDecodeError:
            definition = {}
    definition = definition if isinstance(definition, dict) else {}
    enriched = dict(item)
    for key in ("resolver_statement_type", "statement_section", "scope_preference", "selection_rule", "resolver_priority"):
        value = enriched.get(key)
        if value is None or str(value).strip().lower() in {"", "none", "nan", "null"}:
            enriched[key] = definition.get(key)
    return enriched


def aliases_from_configuration(configuration):
    """Expand the existing PostgreSQL configuration's pipe-delimited aliases."""
    records = []
    for item in configuration.to_dict(orient="records"):
        item = resolver_configuration(item)
        if str(item.get("active", True)).strip().lower() in {"false", "0", "no"}:
            continue
        values = [item.get("canonical_label", "")]
        values.extend(str(item.get("aliases", "")).split("|"))
        for alias_text in values:
            alias_text = str(alias_text).strip()
            if alias_text:
                records.append({
                    "concept_key": item.get("concept_key"),
                    "alias_text": alias_text,
                    "priority": item.get("resolver_priority", 100),
                    "statement_type": item.get("resolver_statement_type") or item.get("statement_type"),
                    "scope_preference": item.get("scope_preference"),
                    "selection_rule": item.get("selection_rule"),
                })
    return pd.DataFrame(records)


def aliases_for_sector(approved, fallback, sector):
    """Use governed sector aliases, retaining global aliases as shared terms."""
    if approved.empty or "sector_key" not in approved.columns:
        return fallback
    profile = "BANK" if sector in {"banking", "nbfc", "financial_institution_base"} else "COMMERCIAL"
    active = approved.copy()
    if "active" in active.columns:
        active = active[active["active"].astype(str).str.lower().isin({"true", "1", "yes", "y"})]
    if "approval_status" in active.columns:
        active = active[active["approval_status"].astype(str).str.upper().eq("APPROVED")]
    configured_sector = active["sector_key"].fillna("").astype(str).str.upper().str.strip()
    active = active[configured_sector.isin({"", profile})]
    if active.empty:
        return fallback
    records = pd.DataFrame({
        "concept_key": active["concept_key"],
        "alias_text": active["alias_text"],
        "priority": active["priority"] if "priority" in active.columns else 100,
        "statement_type": active["statement_type"] if "statement_type" in active.columns else "",
    })
    return pd.concat([records, fallback], ignore_index=True).drop_duplicates(
        ["concept_key", "alias_text"], keep="first"
    )


def main():
    source = read(SOURCE)
    manifest = read(MANIFEST)
    configuration = read(CONFIGURATION)
    approved_aliases = read_optional(APPROVED_ALIASES)
    assignments = read_optional(ASSIGNMENTS)
    if source.empty:
        raise RuntimeError(f"{SOURCE} is empty")
    if manifest.empty:
        raise RuntimeError(f"{MANIFEST} is empty")
    if configuration.empty:
        raise RuntimeError(f"{CONFIGURATION} is empty")
    # This exported project has no separate alias/rule/component datasets.
    # FRI_FINANCIAL_CONCEPT_CONFIGURATION is the declared PostgreSQL source of
    # truth for direct concept aliases. Sector-level derivations are applied by
    # FRI_04F using FRI_SECTOR_DERIVATION_CONFIGURATION.
    configuration = pd.DataFrame(
        [resolver_configuration(item) for item in configuration.to_dict(orient="records")]
    )
    aliases = aliases_from_configuration(configuration)
    concepts = configuration.copy()
    if "active" in concepts.columns:
        concepts = concepts[
            concepts["active"].fillna(False).astype(str).str.lower()
            .isin({"true", "1", "yes", "y"})
        ]
    concepts = concepts.drop_duplicates("concept_key").copy()
    if concepts.empty:
        raise RuntimeError("No concept_key values found in resolver configuration or required-field manifest")

    identity = [c for c in ["tenant_id", "entity_id", "assessment_run_id", "source_document_id"] if c in source.columns]
    sector_by_entity = {}
    if not assignments.empty and {"entity_id", "sector_key"}.issubset(assignments.columns):
        active = assignments
        if "active" in active.columns:
            active = active[active["active"].astype(str).str.lower().isin({"true", "1", "yes", "y"})]
        if "valid_from" in active.columns:
            active = active.sort_values("valid_from")
        sector_by_entity = dict(zip(active["entity_id"].astype(str), active["sector_key"].astype(str)))
    results = []
    groups = source.groupby(identity, dropna=False) if identity else [((), source)]
    for key, group in groups:
        standardized_records = recover_split_balance_subtotals(
            group.to_dict(orient="records")
        )
        entity = str(group["entity_id"].iloc[0]) if "entity_id" in group.columns else ""
        sector = sector_by_entity.get(entity, "")
        selected_aliases = aliases_for_sector(approved_aliases, aliases, sector)
        facts = resolve(
            standardized_records,
            concepts.to_dict(orient="records"),
            selected_aliases.to_dict(orient="records"),
            rules=[],
            rule_components=[],
        )
        if not any(fact.get("concept_key") == "depreciation_amortization" and numeric(fact.get("current_value")) is not None and numeric(fact.get("prior_value")) is not None for fact in facts):
            disclosed_da = disclosed_depreciation_amortization(group)
            if disclosed_da:
                facts = [fact for fact in facts if fact.get("concept_key") != "depreciation_amortization"]
                facts.append(disclosed_da)
        for override in governed_statement_overrides(group):
            facts = [fact for fact in facts if fact.get("concept_key") != override.get("concept_key")]
            facts.append(override)
        context = dict(zip(identity, key if isinstance(key, tuple) else (key,)))
        for fact in facts:
            fact.update(context)
            fact["sector_key"] = sector
            # Required canonical-fact contract consumed by recipe 04F.
            fact.setdefault("currency", group["currency"].dropna().iloc[0] if "currency" in group.columns and not group["currency"].dropna().empty else None)
            fact.setdefault("unit", group["unit"].dropna().iloc[0] if "unit" in group.columns and not group["unit"].dropna().empty else None)
            fact.setdefault("scope", "GROUP")
            periods = (
                sorted(
                    group.get("period_label", pd.Series(dtype=str)).dropna().astype(str).unique().tolist(),
                    key=period_sort_key,
                    reverse=True,
                )
                if "period_label" in group.columns else []
            )
            fact.setdefault("current_period", periods[0] if periods else "")
            fact.setdefault("prior_period", periods[1] if len(periods) > 1 else "")
            fact["statement_value_id"] = uuid.uuid4().hex
            fact["created_at"] = datetime.now(timezone.utc).isoformat()
            results.append(fact)

    output = pd.DataFrame(results)
    required_columns = ["currency", "current_period", "prior_period", "scope", "unit"]
    for name in required_columns:
        if name not in output.columns:
            output[name] = None
    if output.empty:
        output = pd.DataFrame(columns=["statement_value_id", *identity, "concept_key", "current_value", "prior_value", "resolution_method", "created_at"])
        output = pd.DataFrame(columns=["statement_value_id", *identity, "concept_key", "current_value", "prior_value", *required_columns, "resolution_method", "created_at"])
    dataiku.Dataset(OUTPUT).write_with_schema(output)


main()
