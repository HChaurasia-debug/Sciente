"""FRI_00_LOAD_DATABASE_VARIABLES

Input:  FRI_DATABASE_VARIABLES_INPUT
Output: FRI_VARIABLE_LOAD_LOG
"""

from __future__ import annotations

import json
import math
import os
import sys
from typing import Any

import dataiku
import pandas as pd


# Use Dataiku project libraries when installed; retain the POC filesystem fallback.
project_folder = os.getenv("FRI_PROJECT_FOLDER", "/fsre_project")
source_folder = os.path.join(project_folder, "src")
if source_folder not in sys.path:
    sys.path.insert(0, source_folder)

from financial_risk_intelligence.database_variable_service import store_variable


INPUT_DATASET = "FRI_DATABASE_VARIABLES_INPUT"
OUTPUT_DATASET = "FRI_VARIABLE_LOAD_LOG"

REQUIRED_COLUMNS = {
    "tenant_id",
    "variable_scope",
    "scope_key",
    "variable_key",
    "value_type",
    "value_json",
    "lifecycle_state",
    "version",
}


def nullable(value: Any) -> Any:
    if value is None:
        return None
    try:
        if pd.isna(value):
            return None
    except (TypeError, ValueError):
        pass
    if isinstance(value, str) and not value.strip():
        return None
    return value


def parse_value(raw_value: Any, value_type: str) -> Any:
    raw_value = nullable(raw_value)
    normalized_type = value_type.strip().lower()

    if normalized_type == "string":
        if isinstance(raw_value, str):
            try:
                decoded = json.loads(raw_value)
                return decoded if isinstance(decoded, str) else str(decoded)
            except json.JSONDecodeError:
                return raw_value
        return str(raw_value)

    if normalized_type == "number":
        if raw_value is None:
            return None
        number = float(raw_value)
        return int(number) if number.is_integer() else number

    if normalized_type == "boolean":
        if isinstance(raw_value, bool):
            return raw_value
        text = str(raw_value).strip().lower()
        if text in {"true", "1", "yes", "y"}:
            return True
        if text in {"false", "0", "no", "n"}:
            return False
        raise ValueError(f"Invalid boolean value: {raw_value}")

    if normalized_type in {"json", "array", "object"}:
        if isinstance(raw_value, str):
            return json.loads(raw_value)
        return raw_value

    raise ValueError(f"Unsupported value_type: {value_type}")


def timestamp_or_none(value: Any):
    value = nullable(value)
    if value is None:
        return None
    return pd.Timestamp(value).to_pydatetime()


input_frame = dataiku.Dataset(INPUT_DATASET).get_dataframe()
missing_columns = sorted(REQUIRED_COLUMNS - set(input_frame.columns))
if missing_columns:
    raise RuntimeError("Missing input columns: " + ", ".join(missing_columns))

results = []
failure_count = 0

for row_number, row in input_frame.iterrows():
    tenant_id = str(row.get("tenant_id") or "").strip()
    variable_key = str(row.get("variable_key") or "").strip()
    version_value = nullable(row.get("version"))

    try:
        if not tenant_id:
            raise ValueError("tenant_id is required")
        if not variable_key:
            raise ValueError("variable_key is required")
        if version_value is None:
            raise ValueError("version is required")

        variable_id = store_variable(
            tenant_id=tenant_id,
            variable_scope=str(row["variable_scope"]).strip(),
            scope_key=str(row["scope_key"]).strip(),
            variable_key=variable_key,
            value=parse_value(row["value_json"], str(row["value_type"])),
            value_type=str(row["value_type"]).strip().lower(),
            lifecycle_state=str(row["lifecycle_state"]).strip(),
            version=int(version_value),
            created_by=(
                str(nullable(row.get("created_by")))
                if nullable(row.get("created_by")) is not None
                else None
            ),
            description=(
                str(nullable(row.get("description")))
                if nullable(row.get("description")) is not None
                else None
            ),
            effective_from=timestamp_or_none(row.get("effective_from")),
            effective_to=timestamp_or_none(row.get("effective_to")),
        )
        results.append({
            "tenant_id": tenant_id,
            "variable_key": variable_key,
            "version": int(version_value),
            "variable_id": variable_id,
            "status": "loaded",
            "message": None,
            "source_row_number": int(row_number) + 1,
        })
    except Exception as exc:
        failure_count += 1
        results.append({
            "tenant_id": tenant_id or None,
            "variable_key": variable_key or None,
            "version": int(version_value) if version_value is not None else None,
            "variable_id": None,
            "status": "failed",
            "message": str(exc),
            "source_row_number": int(row_number) + 1,
        })

output_frame = pd.DataFrame(results, columns=[
    "tenant_id",
    "variable_key",
    "version",
    "variable_id",
    "status",
    "message",
    "source_row_number",
])
dataiku.Dataset(OUTPUT_DATASET).write_with_schema(output_frame)

print(json.dumps({
    "input_rows": len(input_frame),
    "loaded_rows": len(input_frame) - failure_count,
    "failed_rows": failure_count,
}, indent=2))

if failure_count:
    raise RuntimeError(
        f"{failure_count} database-variable row(s) failed; inspect {OUTPUT_DATASET}"
    )
