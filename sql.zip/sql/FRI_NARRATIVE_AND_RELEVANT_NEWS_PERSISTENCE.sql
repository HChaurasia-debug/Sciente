CREATE SCHEMA IF NOT EXISTS financial_risk_intelligence;

CREATE TABLE IF NOT EXISTS financial_risk_intelligence.forensic_narrative_versions (
    narrative_version_id BIGSERIAL PRIMARY KEY,
    assessment_run_id TEXT NOT NULL,
    source_document_id TEXT NOT NULL,
    score_fingerprint CHAR(64) NOT NULL,
    narrative_json JSONB NOT NULL,
    authoritative_scores_json JSONB NOT NULL DEFAULT '[]'::jsonb,
    company_context_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    evidence_pages_json JSONB NOT NULL DEFAULT '[]'::jsonb,
    provenance_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (source_document_id, score_fingerprint)
);

CREATE INDEX IF NOT EXISTS ix_forensic_narrative_latest
    ON financial_risk_intelligence.forensic_narrative_versions
       (source_document_id, created_at DESC);

CREATE TABLE IF NOT EXISTS financial_risk_intelligence.company_relevant_news (
    company_news_id BIGSERIAL PRIMARY KEY,
    company_key TEXT NOT NULL,
    entity_name TEXT NOT NULL,
    article_key CHAR(64) NOT NULL,
    provider_id TEXT,
    headline TEXT NOT NULL,
    summary TEXT NOT NULL DEFAULT '',
    published_at TIMESTAMPTZ,
    url TEXT NOT NULL DEFAULT '',
    source_name TEXT NOT NULL DEFAULT '',
    sentiment_score INTEGER,
    risk_impact TEXT NOT NULL DEFAULT 'medium'
        CHECK (risk_impact IN ('high', 'medium', 'low')),
    impacts_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    first_seen_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_seen_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (company_key, article_key)
);

CREATE INDEX IF NOT EXISTS ix_company_relevant_news_latest
    ON financial_risk_intelligence.company_relevant_news
       (company_key, published_at DESC, first_seen_at DESC);

CREATE TABLE IF NOT EXISTS financial_risk_intelligence.company_news_refresh_state (
    company_key TEXT PRIMARY KEY,
    last_refreshed_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_result_count INTEGER NOT NULL DEFAULT 0,
    last_error TEXT NOT NULL DEFAULT ''
);

INSERT INTO financial_risk_intelligence.runtime_settings
    (setting_key, setting_value, is_secret, active)
VALUES
    ('fri_relevant_news_limit', '5', FALSE, TRUE),
    ('fri_relevant_news_max_pages', '3', FALSE, TRUE),
    ('fri_news_provider', 'newsdata', FALSE, TRUE)
ON CONFLICT (setting_key) DO UPDATE SET
    setting_value = EXCLUDED.setting_value,
    active = TRUE,
    updated_at = CURRENT_TIMESTAMP;

-- Configure the Marketaux credential separately so it remains backend-only:
-- INSERT INTO financial_risk_intelligence.runtime_settings
--   (setting_key, setting_value, is_secret, active)
-- VALUES ('fri_marketaux_api_key', '<secret>', TRUE, TRUE)
-- ON CONFLICT (setting_key) DO UPDATE SET setting_value=EXCLUDED.setting_value,
--   is_secret=TRUE, active=TRUE, updated_at=CURRENT_TIMESTAMP;
-- NewsData.io alternative (recommended when fri_news_provider='newsdata'):
-- INSERT INTO financial_risk_intelligence.runtime_settings
--   (setting_key, setting_value, is_secret, active)
-- VALUES ('fri_newsdata_api_key', '<secret>', TRUE, TRUE)
-- ON CONFLICT (setting_key) DO UPDATE SET setting_value=EXCLUDED.setting_value,
--   is_secret=TRUE, active=TRUE, updated_at=CURRENT_TIMESTAMP;
