-- Addvalue Technologies Ltd Annual Report 2026
-- Primary statements: PDF pages 86-89 (printed pages 84-87).
--
-- This migration creates an isolated Addvalue profile/template, adds exact
-- report captions, and applies controlled accounting fallbacks only to that
-- profile.  It is idempotent and does not change the generic Manufacturing &
-- Industrials template used by other annual reports.
--
-- Run after:
--   FRI_FINANCIAL_SYNONYM_REGISTRY.sql
--   FRI_MANUFACTURING_DERIVATION_CONFIGURATION.sql
--   FRI_ENABLE_RAW_FACT_AND_CASH_RECONCILIATION.sql
--   FRI_ALL_SECTOR_CONFIGURATION.sql

BEGIN;

-- Supporting facts disclosed by this filing.  These remain separate from the
-- seven displayed income-statement fields so every derivation has auditable
-- source lineage.
INSERT INTO financial_risk_intelligence.financial_concepts
    (concept_key, statement_type, canonical_label, is_required, active)
VALUES
    ('income_tax_credit', 'INCOME_STATEMENT', 'Income tax credit', false, true),
    ('beginning_cash', 'CASH_FLOW_STATEMENT', 'Cash and cash equivalents at beginning of period', false, true),
    ('total_non_current_assets', 'BALANCE_SHEET', 'Total non-current assets', false, true),
    ('total_non_current_liabilities', 'BALANCE_SHEET', 'Total non-current liabilities', false, true)
ON CONFLICT (concept_key) DO UPDATE SET
    canonical_label = EXCLUDED.canonical_label,
    active = true,
    updated_at = now();

-- Cleanup for an earlier draft of this migration, if it was already run.
-- That draft attached two Addvalue rules and its aliases to the generic
-- template.  Removing only rows carrying the exact Addvalue identifiers makes
-- the final migration regression-safe without touching baseline mappings.
DELETE FROM financial_risk_intelligence.financial_template_rules
WHERE template_key = 'MANUFACTURING_INDUSTRIALS_GENERIC'
  AND rule_key IN (
      'NET_INCOME_FROM_PBT_TAX_CREDIT',
      'NET_CHANGE_FROM_CASH_SECTIONS'
  );

DELETE FROM financial_risk_intelligence.financial_concept_aliases
WHERE sector_key = 'MANUFACTURING_INDUSTRIALS_GENERIC'
  AND approved_by = 'ADDVALUE_AR2026_PRIMARY_STATEMENTS';

-- Isolated template and sector profile.  Copying the field contract preserves
-- the existing UI layout while allowing Addvalue-only derivation rules.
INSERT INTO financial_risk_intelligence.financial_templates
    (template_key, template_name, sector_key, active)
VALUES
    ('MANUFACTURING_ADDVALUE_AR',
     'Financial inputs - Addvalue annual-report format',
     'COMMERCIAL', true)
ON CONFLICT (template_key) DO UPDATE SET
    template_name = EXCLUDED.template_name,
    sector_key = EXCLUDED.sector_key,
    active = true,
    updated_at = now();

INSERT INTO financial_risk_intelligence.financial_template_fields
    (template_key, field_key, concept_key, display_label, statement_type,
     display_order, required, active)
SELECT
    'MANUFACTURING_ADDVALUE_AR', field_key, concept_key, display_label,
    statement_type, display_order, required, active
FROM financial_risk_intelligence.financial_template_fields
WHERE template_key = 'MANUFACTURING_INDUSTRIALS_GENERIC'
ON CONFLICT (template_key, field_key) DO UPDATE SET
    concept_key = EXCLUDED.concept_key,
    display_label = EXCLUDED.display_label,
    statement_type = EXCLUDED.statement_type,
    display_order = EXCLUDED.display_order,
    required = EXCLUDED.required,
    active = EXCLUDED.active,
    updated_at = now();

INSERT INTO financial_risk_intelligence.sector_profiles
    (sector_key, sector_name, parent_sector_key, template_key, profile_type,
     description, active)
VALUES
    ('manufacturing_addvalue', 'Manufacturing - Addvalue report format',
     'manufacturing', 'MANUFACTURING_ADDVALUE_AR', 'COMMERCIAL',
     'Isolated mapping for the Addvalue multi-column SGX annual-report layout',
     true)
ON CONFLICT (sector_key) DO UPDATE SET
    sector_name = EXCLUDED.sector_name,
    parent_sector_key = EXCLUDED.parent_sector_key,
    template_key = EXCLUDED.template_key,
    profile_type = EXCLUDED.profile_type,
    description = EXCLUDED.description,
    active = true,
    updated_at = now();

-- Preserve the generic rule set without sharing mutable rule rows.  Rule keys
-- are prefixed because financial_template_rules.rule_key is globally unique.
INSERT INTO financial_risk_intelligence.financial_template_rules
    (rule_key, template_key, target_concept_key, operator, priority,
     output_sign, active, approval_status)
SELECT
    'ADDVALUE_' || rule_key,
    'MANUFACTURING_ADDVALUE_AR',
    target_concept_key, operator, priority, output_sign, active,
    approval_status
FROM financial_risk_intelligence.financial_template_rules
WHERE template_key = 'MANUFACTURING_INDUSTRIALS_GENERIC'
ON CONFLICT (template_key, target_concept_key, priority) DO UPDATE SET
    operator = EXCLUDED.operator,
    output_sign = EXCLUDED.output_sign,
    active = EXCLUDED.active,
    approval_status = EXCLUDED.approval_status,
    updated_at = now();

INSERT INTO financial_risk_intelligence.financial_rule_components
    (rule_key, component_concept_key, coefficient, component_sign,
     component_order)
SELECT
    'ADDVALUE_' || component.rule_key,
    component.component_concept_key,
    component.coefficient,
    component.component_sign,
    component.component_order
FROM financial_risk_intelligence.financial_rule_components component
JOIN financial_risk_intelligence.financial_template_rules source_rule
  ON source_rule.rule_key = component.rule_key
WHERE source_rule.template_key = 'MANUFACTURING_INDUSTRIALS_GENERIC'
ON CONFLICT (rule_key, component_concept_key) DO UPDATE SET
    coefficient = EXCLUDED.coefficient,
    component_sign = EXCLUDED.component_sign,
    component_order = EXCLUDED.component_order;

-- Copy forensic enablement from the parent manufacturing profile so changing
-- the entity's mapping profile does not change which scoring models run.
INSERT INTO financial_risk_intelligence.sector_model_configuration
    (sector_key, model_key, enabled, weight, parameters, disabled_reason,
     configuration_version, active)
SELECT
    'manufacturing_addvalue', model_key, enabled, weight, parameters,
    disabled_reason, configuration_version, active
FROM financial_risk_intelligence.sector_model_configuration
WHERE sector_key = 'manufacturing'
ON CONFLICT (sector_key, model_key) DO UPDATE SET
    enabled = EXCLUDED.enabled,
    weight = EXCLUDED.weight,
    parameters = EXCLUDED.parameters,
    disabled_reason = EXCLUDED.disabled_reason,
    configuration_version = EXCLUDED.configuration_version,
    active = EXCLUDED.active;

-- Recipe FRI_00B_CLASSIFY_ENTITY_SECTOR assigns this profile automatically
-- from the audited statement signature.  No entity UUID or filename is stored
-- in configuration.

-- Exact captions from the primary statements.  Punctuation is intentionally
-- retained in alias_text; normalize_financial_alias_text supplies stable
-- punctuation-insensitive matching.
SELECT financial_risk_intelligence.upsert_concept_alias(
    concept_key,
    alias_text,
    'manufacturing_addvalue',
    NULL,
    priority,
    NULL,
    100,
    'ADDVALUE_AR2026_PRIMARY_STATEMENTS'
)
FROM (VALUES
    -- Consolidated statement of profit or loss and OCI, page 86.
    ('revenue', 'Revenue', 1),
    ('cost_of_goods_sold', 'Cost of sales', 1),
    ('gross_profit', 'Gross profit', 1),
    ('other_income', 'Other operating income', 2),
    ('distribution_expense', 'Selling and distribution expenses', 1),
    ('administrative_expenses', 'Administrative expenses', 1),
    ('finance_costs', 'Finance expenses', 1),
    ('interest_expense', 'Finance expenses', 2),
    ('profit_before_tax', 'Profit before income tax', 1),
    ('income_tax_credit', 'Income tax credit', 1),
    ('net_profit', 'Profit for the year, representing total comprehensive income for the year, net of tax', 1),
    ('net_profit', 'Profit for the year representing total comprehensive income for the year net of tax', 2),
    ('net_profit', 'Profit for the year, representing total comprehensive income for the year', 3),
    -- Coordinate extraction can lose the final word "year" at the wrap.
    ('net_profit', 'Profit for the year, representing total comprehensive income for the net of tax', 4),

    -- Statement of financial position, page 87.  The extractor assigns the
    -- Total prefix to numeric-only section subtotal rows.
    ('total_non_current_assets', 'Total non-current assets', 1),
    ('total_current_assets', 'Total current assets', 1),
    ('inventory', 'Inventories', 1),
    ('trade_receivables_net', 'Trade receivables', 1),
    ('net_ppe', 'Property, plant and equipment', 1),
    ('total_assets', 'Total assets', 1),
    ('total_current_liabilities', 'Total current liabilities', 1),
    ('total_non_current_liabilities', 'Total non-current liabilities', 1),
    ('non_current_borrowings', 'Non-current borrowings', 1),
    ('long_term_debt', 'Non-current borrowings', 2),
    ('total_liabilities', 'Total liabilities', 1),
    ('retained_earnings', 'Accumulated losses', 1),
    ('total_shareholders_equity', 'Total equity', 1),
    -- Note 33 is normalized by recipe 04A from "At end of financial year"
    -- to this unambiguous quantity label.
    ('issued_shares', 'Issued shares at end', 1),
    ('shares_outstanding', 'Issued shares at end', 1),
    ('shares_outstanding', 'Number of ordinary shares at end of financial year', 2),

    -- Consolidated statement of cash flows, page 89.
    ('amortization_intangibles', 'Amortisation of intangible assets', 1),
    ('depreciation_ppe', 'Depreciation of property, plant and equipment', 1),
    ('cash_generated_from_operations', 'Cash generated from operations', 1),
    ('operating_tax_paid', 'Income tax paid', 1),
    ('operating_cash_flow', 'Net cash generated from operating activities', 1),
    ('investing_cash_flow', 'Net cash used in investing activities', 1),
    ('financing_cash_flow', 'Net cash generated from/(used in) financing activities', 1),
    ('net_change_cash', 'Net increase in cash and cash equivalents', 1),
    ('beginning_cash', 'Cash and cash equivalents at beginning of the financial year', 1),
    ('ending_cash', 'Cash and cash equivalents at end of the financial year', 1)
) AS addvalue_alias(concept_key, alias_text, priority);

-- If the wrapped net-profit caption is unavailable after extraction, the
-- filing's positive tax credit is added to profit before tax:
--   4,092 + 741 = 4,833; 1,631 + 322 = 1,953.
INSERT INTO financial_risk_intelligence.financial_template_rules
    (rule_key, template_key, target_concept_key, operator, priority,
     output_sign, active, approval_status)
VALUES
    ('ADDVALUE_NET_INCOME_FROM_PBT_TAX_CREDIT', 'MANUFACTURING_ADDVALUE_AR',
     'net_profit', 'LINEAR_COMBINATION', 21, 'AS_REPORTED', true, 'APPROVED'),
    ('ADDVALUE_NET_CHANGE_FROM_CASH_SECTIONS', 'MANUFACTURING_ADDVALUE_AR',
     'net_change_cash', 'LINEAR_COMBINATION', 20, 'AS_REPORTED', true, 'APPROVED'),
    -- Self-contained balance-sheet rules.  These do not depend on the
    -- generic reconciliation migration having completed successfully.
    ('ADDVALUE_TCA_DIRECT', 'MANUFACTURING_ADDVALUE_AR',
     'total_current_assets', 'DIRECT', 10, 'ABSOLUTE', true, 'APPROVED'),
    ('ADDVALUE_TCA_FROM_ASSET_SPLIT', 'MANUFACTURING_ADDVALUE_AR',
     'total_current_assets', 'LINEAR_COMBINATION', 20, 'ABSOLUTE', true, 'APPROVED'),
    ('ADDVALUE_TCL_DIRECT', 'MANUFACTURING_ADDVALUE_AR',
     'total_current_liabilities', 'DIRECT', 10, 'ABSOLUTE', true, 'APPROVED'),
    ('ADDVALUE_TCL_FROM_LIABILITY_SPLIT', 'MANUFACTURING_ADDVALUE_AR',
     'total_current_liabilities', 'LINEAR_COMBINATION', 20, 'ABSOLUTE', true, 'APPROVED')
ON CONFLICT (template_key, target_concept_key, priority) DO UPDATE SET
    operator = EXCLUDED.operator,
    output_sign = EXCLUDED.output_sign,
    active = true,
    approval_status = 'APPROVED',
    updated_at = now();

INSERT INTO financial_risk_intelligence.financial_rule_components
    (rule_key, component_concept_key, coefficient, component_sign, component_order)
VALUES
    ('ADDVALUE_NET_INCOME_FROM_PBT_TAX_CREDIT', 'profit_before_tax', 1, 'AS_REPORTED', 1),
    ('ADDVALUE_NET_INCOME_FROM_PBT_TAX_CREDIT', 'income_tax_credit', 1, 'AS_REPORTED', 2),
    -- Net change = operating + investing + financing, preserving reported
    -- negative signs for investing and financing outflows.
    ('ADDVALUE_NET_CHANGE_FROM_CASH_SECTIONS', 'operating_cash_flow', 1, 'AS_REPORTED', 1),
    ('ADDVALUE_NET_CHANGE_FROM_CASH_SECTIONS', 'investing_cash_flow', 1, 'AS_REPORTED', 2),
    ('ADDVALUE_NET_CHANGE_FROM_CASH_SECTIONS', 'financing_cash_flow', 1, 'AS_REPORTED', 3),
    -- Audited balance-sheet identities used only when the printed section
    -- subtotal cannot be labelled by the PDF table extractor.
    ('ADDVALUE_TCA_FROM_ASSET_SPLIT', 'total_assets', 1, 'ABSOLUTE', 1),
    ('ADDVALUE_TCA_FROM_ASSET_SPLIT', 'total_non_current_assets', -1, 'ABSOLUTE', 2),
    ('ADDVALUE_TCL_FROM_LIABILITY_SPLIT', 'total_liabilities', 1, 'ABSOLUTE', 1),
    ('ADDVALUE_TCL_FROM_LIABILITY_SPLIT', 'total_non_current_liabilities', -1, 'ABSOLUTE', 2)
ON CONFLICT (rule_key, component_concept_key) DO UPDATE SET
    coefficient = EXCLUDED.coefficient,
    component_sign = EXCLUDED.component_sign,
    component_order = EXCLUDED.component_order;

-- In this filing, a direct D&A candidate is only the depreciation line
-- (500/407).  Disable that direct rule only in the isolated template so the
-- component rule calculates depreciation + intangible amortisation:
-- 500 + 895 = 1,395 and 407 + 941 = 1,348.
UPDATE financial_risk_intelligence.financial_template_rules
SET active = false,
    updated_at = now()
WHERE template_key = 'MANUFACTURING_ADDVALUE_AR'
  AND target_concept_key = 'depreciation_amortization'
  AND operator = 'DIRECT';

-- Make the preferred source for operating cash flow explicit.  The subtotal
-- "Cash generated from operations" remains a component fact only; it must not
-- replace the post-tax net cash-flow line shown to users.
UPDATE financial_risk_intelligence.financial_concept_aliases
SET priority = 1,
    updated_at = now()
WHERE concept_key = 'operating_cash_flow'
  AND sector_key = 'manufacturing_addvalue'
  AND normalized_alias_text = financial_risk_intelligence.normalize_financial_alias_text(
      'Net cash generated from operating activities'
  );

COMMIT;

-- Configuration verification.  These queries are read-only and should show
-- the same field count as the generic UI contract and an isolated rule set.
SELECT template_key, count(*) AS active_field_count
FROM financial_risk_intelligence.financial_template_fields
WHERE template_key IN (
    'MANUFACTURING_INDUSTRIALS_GENERIC', 'MANUFACTURING_ADDVALUE_AR'
)
  AND active = true
GROUP BY template_key
ORDER BY template_key;

SELECT template_key, target_concept_key, operator, priority, active
FROM financial_risk_intelligence.financial_template_rules
WHERE template_key = 'MANUFACTURING_ADDVALUE_AR'
ORDER BY target_concept_key, priority;

-- Expected Group values after rerunning recipes 03B through 04F:
-- Income: revenue 24833/15528; COGS -11883/-7432; SG&A 6105/4402;
-- D&A 1395/1348; EBIT 4213/2097; interest 121/466; net profit 4833/1953.
-- Balance: TCA 22547/14825; receivables 7040/3699; inventory 6796/8688;
-- PP&E 1671/1058; assets 33767/24722; TCL 14158/11693;
-- long-term debt 0/3484; liabilities 15557/16684; accumulated losses
-- -77359/-82192; equity 18210/8038; shares 3683375063/3242032092.
-- Cash flow: CFO 8494/3561; investing -2764/-1621; financing 24/-969;
-- net change 5754/971; ending cash 7260/1506.
