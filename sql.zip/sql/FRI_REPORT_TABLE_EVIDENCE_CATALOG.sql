BEGIN;

CREATE SCHEMA IF NOT EXISTS financial_risk_intelligence;

CREATE TABLE IF NOT EXISTS financial_risk_intelligence.report_table_evidence_catalog (
    source_document_id TEXT NOT NULL,
    table_artifact_id TEXT NOT NULL,
    page_number INTEGER NOT NULL DEFAULT 0,
    statement_type TEXT,
    table_title TEXT,
    content_text TEXT NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (source_document_id, table_artifact_id)
);

CREATE INDEX IF NOT EXISTS ix_report_table_evidence_document_page
    ON financial_risk_intelligence.report_table_evidence_catalog
       (source_document_id, page_number);

COMMIT;
