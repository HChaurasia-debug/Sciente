-- Generic period-end share-count mapping.
-- Monetary share-capital balances must never resolve to share quantities.
BEGIN;

DELETE FROM financial_risk_intelligence.financial_concept_aliases
WHERE concept_key='treasury_shares_count'
  AND normalized_alias_text IN (
    financial_risk_intelligence.normalize_financial_alias_text('Treasury shares'),
    financial_risk_intelligence.normalize_financial_alias_text('Treasury share')
  );

INSERT INTO financial_risk_intelligence.financial_concept_aliases
 (concept_key,alias_text,normalized_alias_text,sector_key,priority,active,
  approval_status,approved_by,approved_at)
SELECT v.concept_key,v.alias_text,
       financial_risk_intelligence.normalize_financial_alias_text(v.alias_text),
       NULL,v.priority,true,'APPROVED','SHARES_GENERIC_FIX',now()
FROM (VALUES
 ('issued_shares','Issued shares at end',1),
 ('issued_shares','Issued ordinary shares at end',2),
 ('issued_shares','Number of issued shares at end',3),
 ('issued_shares','Number of ordinary shares at end of the financial year',4),
 ('issued_shares','Number of ordinary shares at end of the financial period',5),
 ('issued_shares','Number of ordinary shares in issue at the end of the financial year',6),
 ('issued_shares','Number of ordinary shares in issue at the end of the financial period',7),
 ('treasury_shares_count','Treasury shares count at end',1),
 ('treasury_shares_count','Number of treasury shares at end',2),
 ('treasury_shares_count','Treasury shares at end of the financial year',3),
 ('treasury_shares_count','Treasury shares at end of the financial period',4),
 ('treasury_shares_count','Treasury shares (number)',5)
) v(concept_key,alias_text,priority)
ON CONFLICT DO NOTHING;

-- The component identity is preferred over any direct shares_outstanding row.
UPDATE financial_risk_intelligence.financial_template_rules
SET priority=5,active=true,approval_status='APPROVED',updated_at=now()
WHERE rule_key='SHARES_NET'
  AND template_key='MANUFACTURING_INDUSTRIALS_GENERIC';

COMMIT;

SELECT r.rule_key,r.target_concept_key,r.priority,
       c.component_concept_key,c.coefficient,c.component_sign,c.component_order
FROM financial_risk_intelligence.financial_template_rules r
JOIN financial_risk_intelligence.financial_rule_components c USING(rule_key)
WHERE r.rule_key='SHARES_NET'
ORDER BY c.component_order;
