-- Commercial concept configuration for FRI_04E.
-- financial_concept_configuration_v2 is a GROUP BY view and is read-only.
-- This migration updates financial_concepts and financial_concept_aliases.

BEGIN;

CREATE TEMP TABLE fsre_alias_seed (
    concept_key text NOT NULL,
    alias_text text NOT NULL,
    normalized_alias_text text NOT NULL,
    priority integer NOT NULL,
    PRIMARY KEY (concept_key, normalized_alias_text)
) ON COMMIT DROP;

INSERT INTO fsre_alias_seed (concept_key, alias_text, normalized_alias_text, priority)
SELECT concept_key, alias_text,
       financial_risk_intelligence.normalize_financial_alias_text(alias_text),
       priority
FROM (VALUES
    ('revenue', 'Revenue', 1), ('revenue', 'Net revenue', 2),
    ('revenue', 'Sales', 3), ('revenue', 'Net sales', 4),
    ('revenue', 'Turnover', 5), ('revenue', 'Revenue from contracts with customers', 6),
    ('cost_of_goods_sold', 'Cost of goods sold', 1), ('cost_of_goods_sold', 'Cost of sales', 2),
    ('cost_of_goods_sold', 'Cost of revenue', 3), ('cost_of_goods_sold', 'Cost of inventories sold', 4),
    ('sg_and_a_expense', 'SG&A expense', 1),
    ('sg_and_a_expense', 'Selling, general and administrative expenses', 2),
    ('administrative_expenses', 'Administrative expenses', 1),
    ('administrative_expenses', 'General and administrative expenses', 2),
    ('distribution_expense', 'Distribution costs', 1), ('distribution_expense', 'Distribution expenses', 2),
    ('depreciation_amortization', 'Depreciation and amortisation', 1),
    ('depreciation_amortization', 'Depreciation and amortization', 2),
    ('depreciation_amortization', 'Depreciation & amortisation', 3),
    ('depreciation_ppe', 'Depreciation of property, plant and equipment', 1),
    ('depreciation_rou', 'Depreciation of right-of-use assets', 1),
    ('amortization_intangibles', 'Amortization of intangible assets', 1),
    ('amortization_intangibles', 'Amortisation of intangible assets', 2),
    ('operating_income_ebit', 'Operating profit', 1), ('operating_income_ebit', 'Operating income', 2),
    ('operating_income_ebit', 'Profit from operations', 3),
    ('operating_income_ebit', 'Income from operations', 4),
    ('operating_income_ebit', 'Results from operating activities', 5), ('operating_income_ebit', 'EBIT', 6),
    ('interest_expense', 'Interest expense', 1), ('interest_expense', 'Interest expenses', 2),
    ('interest_expense', 'Finance cost', 3), ('interest_expense', 'Finance costs', 4),
    ('interest_expense', 'Finance expense', 5), ('interest_expense', 'Finance expenses', 6), ('interest_expense', 'Interest cost', 7),
    ('net_profit', 'Net income', 1), ('net_profit', 'Net profit', 2),
    ('net_profit', 'Profit for the year', 3), ('net_profit', 'Loss for the year', 4),
    ('net_profit', 'Profit after tax', 5), ('net_profit', 'Loss after tax', 6),
    ('total_shareholders_equity', 'Total shareholders equity', 1),
    ('total_shareholders_equity', 'Shareholders equity', 2), ('total_shareholders_equity', 'Shareholders funds', 3),
    ('total_shareholders_equity', 'Equity attributable to owners of the Company', 4),
    ('total_shareholders_equity', 'Equity attributable to owners', 5),
    ('long_term_debt', 'Long-term debt', 1),
    ('long_term_debt', 'Non-current borrowings', 2), ('long_term_debt', 'Non-current loans and borrowings', 3)
) AS seed(concept_key, alias_text, priority);

UPDATE financial_risk_intelligence.financial_concepts AS concept
SET scope_preference = 'GROUP_THEN_REPORTED_THEN_COMPANY',
    validation_definition = COALESCE(concept.validation_definition, '{}'::jsonb)
        || jsonb_build_object(
            'resolver_statement_type', CASE
                WHEN concept.concept_key IN ('depreciation_ppe', 'depreciation_rou', 'amortization_intangibles') THEN 'CASH_FLOW_STATEMENT'
                WHEN concept.concept_key IN ('revenue', 'cost_of_goods_sold', 'sg_and_a_expense', 'administrative_expenses', 'distribution_expense', 'depreciation_amortization', 'operating_income_ebit', 'interest_expense', 'net_profit') THEN 'INCOME_STATEMENT'
                ELSE 'BALANCE_SHEET'
            END,
            'selection_rule', CASE WHEN concept.concept_key = 'long_term_debt' THEN 'NON_CURRENT_OR_ZERO_IF_UNREPORTED' ELSE 'PRIMARY_STATEMENT_ONLY' END,
            'resolver_priority', 10
        ),
    active = true, updated_at = now()
WHERE concept.concept_key IN (SELECT DISTINCT concept_key FROM fsre_alias_seed);

UPDATE financial_risk_intelligence.financial_concept_aliases AS alias
SET active = false, updated_at = now()
WHERE alias.concept_key IN (SELECT DISTINCT concept_key FROM fsre_alias_seed)
  AND COALESCE(alias.sector_key, '') = 'COMMERCIAL'
  AND COALESCE(alias.country_code, '') = '';

UPDATE financial_risk_intelligence.financial_concept_aliases AS target
SET alias_text = seed.alias_text, priority = seed.priority, active = true,
    approval_status = 'APPROVED', approved_by = 'COMMERCIAL_CONFIGURATION_FIX', approved_at = now(), updated_at = now()
FROM fsre_alias_seed AS seed
WHERE target.concept_key = seed.concept_key
  AND target.normalized_alias_text = seed.normalized_alias_text
  AND COALESCE(target.sector_key, '') = 'COMMERCIAL'
  AND COALESCE(target.country_code, '') = '';

INSERT INTO financial_risk_intelligence.financial_concept_aliases
    (concept_key, alias_text, normalized_alias_text, sector_key, country_code, priority, active, approval_status, approved_by, approved_at)
SELECT seed.concept_key, seed.alias_text, seed.normalized_alias_text,
       'COMMERCIAL', NULL, seed.priority, true, 'APPROVED', 'COMMERCIAL_CONFIGURATION_FIX', now()
FROM fsre_alias_seed AS seed
WHERE NOT EXISTS (
    SELECT 1 FROM financial_risk_intelligence.financial_concept_aliases AS existing
    WHERE existing.concept_key = seed.concept_key
      AND existing.normalized_alias_text = seed.normalized_alias_text
      AND COALESCE(existing.sector_key, '') = 'COMMERCIAL'
      AND COALESCE(existing.country_code, '') = ''
);

COMMIT;

SELECT concept.concept_key,
       concept.validation_definition ->> 'resolver_statement_type' AS resolver_statement_type,
       concept.validation_definition ->> 'selection_rule' AS selection_rule,
       alias.alias_text, alias.priority
FROM financial_risk_intelligence.financial_concepts AS concept
LEFT JOIN financial_risk_intelligence.financial_concept_aliases AS alias
  ON alias.concept_key = concept.concept_key AND alias.active = true
 AND alias.approval_status = 'APPROVED' AND COALESCE(alias.sector_key, '') = 'COMMERCIAL'
WHERE concept.concept_key IN (
    'revenue', 'cost_of_goods_sold', 'sg_and_a_expense',
    'administrative_expenses', 'distribution_expense',
    'depreciation_amortization', 'depreciation_ppe', 'depreciation_rou',
    'amortization_intangibles', 'operating_income_ebit',
    'interest_expense', 'net_profit', 'total_shareholders_equity',
    'long_term_debt'
)
ORDER BY concept.concept_key, alias.priority;
