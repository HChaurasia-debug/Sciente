-- Read-only deployment check for the Manufacturing & Industrials template.
-- Run this after FRI_ENABLE_CONFIGURED_FORENSIC_FALLBACKS.sql.

-- 1. Confirm the actual sector key used by the template. This avoids relying
--    on a display name such as "Manufacturing & Industrials".
SELECT sector_key, sector_name, profile_type, template_key, active
FROM financial_risk_intelligence.sector_profiles
WHERE template_key = 'MANUFACTURING_INDUSTRIALS_GENERIC'
ORDER BY sector_key;

-- 2. Confirm the recipe will receive the policy via its source view.
SELECT sector_key, template_key, model_key, model_name, enabled,
       configuration_version, parameters,
       input_concept_key, period_requirement, input_required, input_order
FROM financial_risk_intelligence.sector_scoring_configuration
WHERE template_key = 'MANUFACTURING_INDUSTRIALS_GENERIC'
ORDER BY model_key, input_order;

-- 3. The two model policy rows must show configuration_version 2026.2 and:
--    Beneish:   calculation_mode = EVIDENCE_DERIVED_ONLY
--    Piotroski: optional_signal_inputs = shares_outstanding
-- Long-term debt itself is emitted by the resolver only when a primary
-- balance sheet proves that no non-current borrowing line is reported.
SELECT profile.sector_key, profile.template_key, configuration.model_key,
       configuration.configuration_version,
       configuration.parameters -> 'missing_input_defaults' AS missing_input_defaults,
       configuration.parameters -> 'optional_signal_inputs' AS optional_signal_inputs,
       configuration.parameters ->> 'calculation_mode' AS calculation_mode
FROM financial_risk_intelligence.sector_model_configuration AS configuration
JOIN financial_risk_intelligence.sector_profiles AS profile
  ON profile.sector_key = configuration.sector_key
WHERE profile.template_key = 'MANUFACTURING_INDUSTRIALS_GENERIC'
  AND configuration.model_key IN ('beneish', 'piotroski')
ORDER BY profile.sector_key, configuration.model_key;
