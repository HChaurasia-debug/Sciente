"""Placeholder for FRI_16_APPLY_EVENT_OVERLAY."""
raise NotImplementedError("Install the implementation for FRI_16_APPLY_EVENT_OVERLAY")
