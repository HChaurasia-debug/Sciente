"""Publish active PostgreSQL runtime settings for Dataiku consumers.

Output: FRI_RUNTIME_SETTINGS

The webapps and downstream recipes read this dataset instead of embedding
environment-specific Ollama endpoints or models. Secret-valued settings are
intentionally excluded from the published dataset.
"""
from __future__ import annotations

import datetime as dt

import dataiku
import pandas as pd
import psycopg2

from financial_risk_intelligence.database import DatabaseSettings


OUTPUT_DATASET = "FRI_RUNTIME_SETTINGS"
OUTPUT_COLUMNS = [
    "setting_key",
    "setting_value",
    "active",
    "configuration_source",
    "database_updated_at",
    "published_at",
]


def load_active_settings() -> pd.DataFrame:
    settings = DatabaseSettings.from_runtime()
    connection = psycopg2.connect(
        host=settings.host,
        port=settings.port,
        dbname=settings.database,
        user=settings.user,
        password=settings.password,
        application_name=settings.application_name,
        connect_timeout=30,
    )
    try:
        with connection.cursor() as cursor:
            cursor.execute(
                """
                SELECT setting_key, setting_value, active, updated_at
                  FROM financial_risk_intelligence.runtime_settings
                 WHERE active = TRUE
                   AND is_secret = FALSE
                 ORDER BY setting_key
                """
            )
            rows = cursor.fetchall()
    finally:
        connection.close()

    published_at = dt.datetime.now(dt.timezone.utc).isoformat()
    return pd.DataFrame(
        [
            {
                "setting_key": str(key),
                "setting_value": str(value),
                "active": bool(active),
                "configuration_source": "POSTGRESQL_RUNTIME_SETTINGS",
                "database_updated_at": updated_at.isoformat() if updated_at else "",
                "published_at": published_at,
            }
            for key, value, active, updated_at in rows
        ],
        columns=OUTPUT_COLUMNS,
    )


runtime_settings = load_active_settings()
if runtime_settings.empty:
    raise RuntimeError(
        "No active, non-secret rows exist in "
        "financial_risk_intelligence.runtime_settings"
    )

required = {"fri_ollama_base_url", "fri_ollama_model"}
available = set(runtime_settings["setting_key"].astype(str))
missing = sorted(required - available)
if missing:
    raise RuntimeError("Required runtime settings are missing: " + ", ".join(missing))

dataiku.Dataset(OUTPUT_DATASET).write_with_schema(runtime_settings)
print(
    f"Published {len(runtime_settings)} active runtime setting(s) "
    f"from PostgreSQL to {OUTPUT_DATASET}."
)
