-- Enables a narrowly-scoped, disclosed Piotroski share-count fallback.
--
-- This does NOT make arbitrary missing financial inputs optional. Long-term
-- debt is now populated only by the evidence-driven resolver rule
-- NON_CURRENT_OR_ZERO_IF_UNREPORTED; therefore it is never defaulted here.
-- The only remaining fallback is an unavailable share-count signal, which
-- conservatively receives zero Piotroski points.
--
-- Required companion code:
--   FRI_05_SCORE_SECTOR_FORENSICS.py version with
--   `missing_input_defaults` and `optional_signal_inputs` support.
--
-- Result labels remain auditable: SCORED_WITH_ASSUMPTIONS, with the exact
-- assumption included in components_json.

BEGIN;

-- Remove the earlier sector-wide debt default if this migration has already
-- been applied. The resolver will emit zero only when the primary balance
-- sheet proves there is no non-current borrowing line.
UPDATE financial_risk_intelligence.sector_model_configuration AS configuration
SET parameters = (COALESCE(parameters, '{}'::jsonb) - 'missing_input_defaults')
    || jsonb_build_object(
        'calculation_mode', 'EVIDENCE_DERIVED_ONLY'
    ),
    configuration_version = '2026.2'
FROM financial_risk_intelligence.sector_profiles AS profile
WHERE configuration.sector_key = profile.sector_key
  AND profile.template_key = 'MANUFACTURING_INDUSTRIALS_GENERIC'
  AND configuration.model_key = 'beneish'
  AND configuration.active = true;

-- Piotroski: if the share-count disclosure cannot be extracted, the
-- no-dilution signal contributes zero; it must never be awarded merely
-- because the input is missing.
UPDATE financial_risk_intelligence.sector_model_configuration AS configuration
SET parameters = (COALESCE(parameters, '{}'::jsonb) - 'missing_input_defaults')
    || jsonb_build_object(
        'optional_signal_inputs', jsonb_build_array('shares_outstanding'),
        'calculation_mode', 'PROVISIONAL_IF_CONFIGURED_FALLBACK_USED'
    ),
    configuration_version = '2026.2'
FROM financial_risk_intelligence.sector_profiles AS profile
WHERE configuration.sector_key = profile.sector_key
  AND profile.template_key = 'MANUFACTURING_INDUSTRIALS_GENERIC'
  AND configuration.model_key = 'piotroski'
  AND configuration.active = true;

COMMIT;

-- Verify exactly the policy used by the scoring recipe.
SELECT profile.sector_key, profile.template_key, configuration.model_key,
       configuration.enabled, configuration.configuration_version,
       configuration.parameters
FROM financial_risk_intelligence.sector_model_configuration AS configuration
JOIN financial_risk_intelligence.sector_profiles AS profile
  ON profile.sector_key = configuration.sector_key
WHERE profile.template_key = 'MANUFACTURING_INDUSTRIALS_GENERIC'
  AND configuration.model_key IN ('beneish', 'piotroski')
ORDER BY profile.sector_key, configuration.model_key;
