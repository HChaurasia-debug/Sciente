"""Hybrid financial line-item extraction for Dataiku.

Inputs: FRI_DOCUMENT_FRAGMENTS, FRI_REQUIRED_FIELD_MANIFEST
Output: FRI_EXTRACTED_LINE_ITEMS
"""
from __future__ import annotations

import json
import re
import uuid
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from typing import Any, Dict, List, Optional, Tuple

import dataiku
import pandas as pd
import requests


FRAGMENTS_DATASET = "FRI_DOCUMENT_FRAGMENTS"
MANIFEST_DATASET = "FRI_REQUIRED_FIELD_MANIFEST"
OUTPUT_DATASET = "FRI_EXTRACTED_LINE_ITEMS"

OUTPUT_COLUMNS = [
    "tenant_id", "entity_id", "assessment_run_id", "source_document_id",
    "line_item_id", "configuration_item_id", "statement_key", "concept_key",
    "period_key", "source_label", "raw_value", "numeric_value", "currency",
    "unit", "unit_multiplier", "normalized_value", "source_page_number",
    "source_fragment_id", "source_text", "extraction_method", "model_provider",
    "model_name", "confidence_score", "needs_review", "extraction_status",
    "error_message", "created_at",
]

NUMBER_PATTERN = re.compile(
    r"(?<![A-Za-z0-9])(?:\(?[-+]?\s*(?:[$€£₹]\s*)?"
    r"(?:\d{1,3}(?:[ ,]\d{3})+|\d+)(?:\.\d+)?\)?)(?![A-Za-z0-9])"
)
YEAR_PATTERN = re.compile(r"\b(?:19|20)\d{2}\b")
STOP_TOKENS = {"and", "the", "of", "total", "net", "current", "closing"}


def variable(name: str, default: Any = None) -> Any:
    values = dataiku.get_custom_variables()
    value = values.get(name)
    return default if value in (None, "") else value


def text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except (TypeError, ValueError):
        pass
    return str(value).strip()


def parse_json(value: Any) -> Dict[str, Any]:
    if isinstance(value, dict):
        return value
    raw = text(value)
    if not raw:
        return {}
    try:
        parsed = json.loads(raw)
        return parsed if isinstance(parsed, dict) else {}
    except json.JSONDecodeError:
        return {}


def normalize_label(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", value.lower()).strip()


def concept_tokens(manifest: pd.Series) -> List[str]:
    definition = parse_json(manifest.get("configuration_definition"))
    aliases = definition.get("aliases") or definition.get("synonyms") or []
    if isinstance(aliases, str):
        aliases = [aliases]
    phrases = [text(manifest.get("concept_key")).replace("_", " "), *aliases]
    tokens: List[str] = []
    for phrase in phrases:
        for token in normalize_label(str(phrase)).split():
            if len(token) > 2 and token not in STOP_TOKENS and token not in tokens:
                tokens.append(token)
    return tokens


def fragment_score(fragment: pd.Series, manifest: pd.Series) -> float:
    content = normalize_label(text(fragment.get("content_text")))
    tokens = concept_tokens(manifest)
    if not content or not tokens:
        return 0.0
    score = sum(1 for token in tokens if token in content) / len(tokens)
    statement = normalize_label(text(manifest.get("statement_key")))
    statement_tokens = [token for token in statement.split() if len(token) > 2]
    if statement_tokens and all(token in content for token in statement_tokens):
        score += 0.15
    return min(score, 1.0)


def select_fragments(
    fragments: pd.DataFrame,
    manifest: pd.Series,
    maximum: int,
) -> pd.DataFrame:
    selected = fragments[
        fragments["extraction_status"].astype(str).str.upper().eq("EXTRACTED")
    ].copy()
    selected["_score"] = selected.apply(
        lambda row: fragment_score(row, manifest), axis=1
    )
    selected = selected[selected["_score"] > 0].sort_values(
        ["_score", "page_number"], ascending=[False, True]
    )
    return selected.head(maximum)


def decimal_value(raw: Any) -> Optional[Decimal]:
    value = text(raw)
    if not value or value.lower() in {"nil", "n/a", "na", "none", "null", "-"}:
        return None
    negative = value.startswith("(") and value.endswith(")")
    cleaned = re.sub(r"[$€£₹,\s]", "", value.strip("()"))
    try:
        number = Decimal(cleaned)
        return -number if negative else number
    except InvalidOperation:
        return None


def infer_currency(content: str) -> str:
    lower = content.lower()
    for pattern, code in (
        (r"\bsgd\b|s\$", "SGD"), (r"\busd\b|us\$", "USD"),
        (r"\binr\b|₹", "INR"), (r"\beur\b|€", "EUR"),
        (r"\bgbp\b|£", "GBP"),
    ):
        if re.search(pattern, lower):
            return code
    return ""


def infer_unit(content: str) -> Tuple[str, Decimal]:
    lower = content.lower()
    if re.search(r"\bmillions?\b|\bmn\b|\$m\b", lower):
        return "million", Decimal("1000000")
    if re.search(r"\bthousands?\b|\b'000\b|\b000s\b", lower):
        return "thousand", Decimal("1000")
    if re.search(r"\bbillions?\b|\bbn\b", lower):
        return "billion", Decimal("1000000000")
    return "unit", Decimal("1")


def period_index(period_key: str) -> int:
    value = period_key.lower()
    return 1 if "prior" in value or "previous" in value else 0


def deterministic_extract(
    candidates: pd.DataFrame,
    manifest: pd.Series,
) -> Optional[Dict[str, Any]]:
    tokens = concept_tokens(manifest)
    wanted_index = period_index(text(manifest.get("period_key")))
    for _, fragment in candidates.iterrows():
        for line in text(fragment.get("content_text")).splitlines():
            normalized = normalize_label(line)
            if not normalized or not tokens:
                continue
            matched = sum(1 for token in tokens if token in normalized)
            if matched / len(tokens) < 0.75:
                continue
            values = [value for value in NUMBER_PATTERN.findall(line) if not YEAR_PATTERN.fullmatch(value.strip("() "))]
            parsed = [(raw, decimal_value(raw)) for raw in values]
            parsed = [(raw, value) for raw, value in parsed if value is not None]
            if len(parsed) <= wanted_index:
                continue
            raw, number = parsed[wanted_index]
            currency = infer_currency(line + " " + text(fragment.get("content_text"))[:500])
            unit, multiplier = infer_unit(text(fragment.get("content_text"))[:1000])
            return {
                "source_label": line[:500], "raw_value": raw,
                "numeric_value": number, "currency": currency, "unit": unit,
                "unit_multiplier": multiplier,
                "normalized_value": number * multiplier,
                "source_page_number": fragment.get("page_number"),
                "source_fragment_id": text(fragment.get("fragment_id")),
                "source_text": line[:2000], "extraction_method": "deterministic_text_v1",
                "model_provider": "", "model_name": "", "confidence_score": 0.82,
            }
    return None


def ollama_settings() -> Dict[str, Any]:
    return {
        "base_url": text(variable("fsre_ollama_base_url", variable("ollama_base_url", ""))),
        "model": text(variable("fsre_ollama_model", variable("ollama_model", ""))),
        "timeout": int(variable("fsre_ollama_timeout_seconds", 600)),
        "max_context": int(variable("fsre_llm_max_context_chars", 24000)),
        "max_fragments": int(variable("fsre_llm_max_fragments", 8)),
    }


def parse_llm_json(raw: str) -> Dict[str, Any]:
    value = raw.strip()
    value = re.sub(r"^```(?:json)?", "", value, flags=re.IGNORECASE).strip()
    value = re.sub(r"```$", "", value).strip()
    try:
        result = json.loads(value)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", value, flags=re.DOTALL)
        if not match:
            raise
        result = json.loads(match.group(0))
    if not isinstance(result, dict):
        raise ValueError("LLM response must be a JSON object")
    return result


def llm_extract(candidates: pd.DataFrame, manifest: pd.Series) -> Optional[Dict[str, Any]]:
    settings = ollama_settings()
    if not settings["base_url"] or not settings["model"] or candidates.empty:
        return None
    blocks, used = [], 0
    for _, fragment in candidates.head(settings["max_fragments"]).iterrows():
        content = text(fragment.get("content_text"))
        block = f"[fragment_id={fragment.get('fragment_id')} page={fragment.get('page_number')}]\n{content}"
        if blocks and used + len(block) > settings["max_context"]:
            break
        blocks.append(block)
        used += len(block)
    prompt = f"""Extract one financial value from the supplied annual-report evidence.
Return only one JSON object with keys:
found, source_label, raw_value, numeric_value, currency, unit, unit_multiplier,
source_page_number, source_fragment_id, source_text, confidence_score.

Rules:
- Never calculate, infer, or invent a missing value.
- found must be false when the exact concept and requested period are not evidenced.
- numeric_value is the displayed number before unit multiplication.
- source_text must be a short verbatim evidence excerpt.
- confidence_score must be between 0 and 1.

Target concept: {manifest.get('concept_key')}
Statement: {manifest.get('statement_key')}
Requested period role: {manifest.get('period_key')}

Evidence:
{chr(10).join(blocks)}"""
    response = requests.post(
        settings["base_url"].rstrip("/") + "/api/generate",
        json={"model": settings["model"], "prompt": prompt, "stream": False, "format": "json"},
        timeout=settings["timeout"],
    )
    response.raise_for_status()
    payload = parse_llm_json(response.json().get("response", ""))
    if payload.get("found") is not True:
        return None
    number = decimal_value(payload.get("numeric_value"))
    if number is None:
        return None
    multiplier = decimal_value(payload.get("unit_multiplier")) or Decimal("1")
    confidence = min(max(float(payload.get("confidence_score") or 0), 0.0), 1.0)
    return {
        "source_label": text(payload.get("source_label")),
        "raw_value": text(payload.get("raw_value")), "numeric_value": number,
        "currency": text(payload.get("currency")), "unit": text(payload.get("unit")),
        "unit_multiplier": multiplier, "normalized_value": number * multiplier,
        "source_page_number": payload.get("source_page_number"),
        "source_fragment_id": text(payload.get("source_fragment_id")),
        "source_text": text(payload.get("source_text"))[:2000],
        "extraction_method": "ollama_structured_v1", "model_provider": "ollama",
        "model_name": settings["model"], "confidence_score": confidence,
    }


def output_row(manifest: pd.Series, result: Optional[Dict[str, Any]], error: str = "") -> Dict[str, Any]:
    found = result is not None
    result = result or {}
    confidence = float(result.get("confidence_score") or 0)
    def number(name):
        value = result.get(name)
        return float(value) if isinstance(value, Decimal) else value
    return {
        "tenant_id": text(manifest.get("tenant_id")), "entity_id": text(manifest.get("entity_id")),
        "assessment_run_id": text(manifest.get("assessment_run_id")),
        "source_document_id": text(manifest.get("source_document_id")),
        "line_item_id": str(uuid.uuid4()),
        "configuration_item_id": text(manifest.get("configuration_item_id")),
        "statement_key": text(manifest.get("statement_key")),
        "concept_key": text(manifest.get("concept_key")), "period_key": text(manifest.get("period_key")),
        "source_label": text(result.get("source_label")), "raw_value": text(result.get("raw_value")),
        "numeric_value": number("numeric_value"), "currency": text(result.get("currency")),
        "unit": text(result.get("unit")), "unit_multiplier": number("unit_multiplier"),
        "normalized_value": number("normalized_value"),
        "source_page_number": result.get("source_page_number"),
        "source_fragment_id": text(result.get("source_fragment_id")),
        "source_text": text(result.get("source_text")),
        "extraction_method": text(result.get("extraction_method")),
        "model_provider": text(result.get("model_provider")), "model_name": text(result.get("model_name")),
        "confidence_score": confidence, "needs_review": (not found) or confidence < 0.80,
        "extraction_status": "EXTRACTED" if found else ("FAILED" if error else "NOT_FOUND"),
        "error_message": error, "created_at": datetime.now(timezone.utc),
    }


def main():
    fragments = dataiku.Dataset(FRAGMENTS_DATASET).get_dataframe()
    manifest = dataiku.Dataset(MANIFEST_DATASET).get_dataframe()
    rows: List[Dict[str, Any]] = []
    for _, requirement in manifest.iterrows():
        document_fragments = fragments[
            fragments["source_document_id"].astype(str).eq(text(requirement.get("source_document_id")))
        ]
        candidates = select_fragments(document_fragments, requirement, 12)
        try:
            result = deterministic_extract(candidates, requirement)
            if result is None:
                result = llm_extract(candidates, requirement)
            rows.append(output_row(requirement, result))
        except Exception as exc:
            rows.append(output_row(requirement, None, f"{type(exc).__name__}: {exc}"))

    output = pd.DataFrame(rows, columns=OUTPUT_COLUMNS)
    dataiku.Dataset(OUTPUT_DATASET).write_with_schema(output)
    print(json.dumps({
        "manifest_rows": len(manifest), "output_rows": len(output),
        "extracted": int((output["extraction_status"] == "EXTRACTED").sum()) if not output.empty else 0,
        "not_found": int((output["extraction_status"] == "NOT_FOUND").sum()) if not output.empty else 0,
        "failed": int((output["extraction_status"] == "FAILED").sum()) if not output.empty else 0,
    }, indent=2))


main()
