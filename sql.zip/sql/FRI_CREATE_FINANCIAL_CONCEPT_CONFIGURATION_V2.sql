-- Non-destructive compatibility view for the Dataiku dataset
-- FRI_FINANCIAL_CONCEPT_CONFIGURATION.
--
-- The base governed view exposes eight columns. Dataiku's v2 dataset contract
-- additionally expects four resolver controls projected from JSON.

CREATE OR REPLACE VIEW financial_risk_intelligence.financial_concept_configuration_v2 AS
SELECT configuration.concept_key,
       configuration.canonical_label,
       configuration.statement_type,
       configuration.is_required,
       configuration.active,
       configuration.scope_preference,
       configuration.validation_definition,
       configuration.aliases,
       configuration.validation_definition ->> 'resolver_statement_type' AS resolver_statement_type,
       configuration.validation_definition ->> 'statement_section' AS statement_section,
       configuration.validation_definition ->> 'selection_rule' AS selection_rule,
       CASE
           WHEN COALESCE(configuration.validation_definition ->> 'resolver_priority', '') ~ '^[0-9]+$'
           THEN (configuration.validation_definition ->> 'resolver_priority')::integer
           ELSE 100
       END AS resolver_priority
FROM financial_risk_intelligence.financial_concept_configuration AS configuration;

