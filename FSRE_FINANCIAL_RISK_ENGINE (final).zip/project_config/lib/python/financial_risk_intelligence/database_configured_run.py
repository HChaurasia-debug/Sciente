from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .database import DatabaseSettings, tenant_connection
from .database_variables import VariableContext, require_variables, resolve_variables
from .run_service import CreateRunRequest, create_run


@dataclass(frozen=True)
class RunIntake:
    tenant_id: str
    customer_id: str
    report_id: str
    configuration_set_id: str
    requested_by: str | None
    idempotency_key: str
    variable_lifecycle_state: str
    variable_scopes: tuple[tuple[str, str], ...]
    request_payload: dict[str, Any]


def create_database_configured_run(
    intake: RunIntake, settings: DatabaseSettings | None = None
) -> dict[str, Any]:
    with tenant_connection(intake.tenant_id, settings) as cursor:
        variables = resolve_variables(
            cursor,
            intake.tenant_id,
            VariableContext(intake.variable_scopes, intake.variable_lifecycle_state),
        )

    require_variables(
        variables,
        (
            "engine_release",
            "workflow_item_type",
            "run_initial_state",
            "job_initial_state",
        ),
    )
    return create_run(
        CreateRunRequest(
            tenant_id=intake.tenant_id,
            customer_id=intake.customer_id,
            report_id=intake.report_id,
            configuration_set_id=intake.configuration_set_id,
            requested_by=intake.requested_by,
            idempotency_key=intake.idempotency_key,
            engine_release=str(variables["engine_release"]),
            workflow_item_type=str(variables["workflow_item_type"]),
            run_initial_state=str(variables["run_initial_state"]),
            job_initial_state=str(variables["job_initial_state"]),
            request_payload=intake.request_payload,
        ),
        settings,
    )
