-- Batch 1 generic configuration.  This is deliberately data-driven: new
-- report layouts are added here instead of adding company-specific Python.
BEGIN;

CREATE TABLE IF NOT EXISTS financial_risk_intelligence.financial_statement_layout_patterns (
  pattern_key text PRIMARY KEY,
  statement_type text NOT NULL,
  header_pattern text NOT NULL,
  group_column_rule text NOT NULL,
  prior_column_rule text NOT NULL,
  company_column_rule text,
  note_column_rule text,
  priority integer NOT NULL DEFAULT 100,
  active boolean NOT NULL DEFAULT true,
  approval_status text NOT NULL DEFAULT 'APPROVED',
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(statement_type, header_pattern)
);

INSERT INTO financial_risk_intelligence.financial_statement_layout_patterns
 (pattern_key, statement_type, header_pattern, group_column_rule,
  prior_column_rule, company_column_rule, note_column_rule, priority)
VALUES
 ('GROUP_COMPANY_FOUR_PERIODS','ALL','GROUP.*COMPANY',
  'FIRST_NUMERIC_PERIOD_COLUMNS_EXCLUDING_COMPANY',
  'SECOND_NUMERIC_PERIOD_COLUMN',
  'COLUMNS_UNDER_COMPANY_HEADER',
  'EXCLUDE_LOW_NUMERIC_DENSITY_NOTE_COLUMNS',10),
 ('GROUP_TWO_PERIODS','ALL','GROUP.*202[0-9].*202[0-9]',
  'FIRST_GROUP_PERIOD_COLUMN',
  'SECOND_GROUP_PERIOD_COLUMN',
  NULL,
  'EXCLUDE_NOTE_REFERENCE_COLUMNS',20),
 ('CURRENT_PRIOR','ALL','CURRENT.*PRIOR|CURRENT.*PREVIOUS',
  'CURRENT_COLUMN',
  'PRIOR_COLUMN',
  NULL,
  'EXCLUDE_NOTE_REFERENCE_COLUMNS',30),
 ('YEAR_ENDED_TWO_PERIODS','ALL','YEAR ENDED.*YEAR ENDED',
  'FIRST_YEAR_ENDED_COLUMN',
  'SECOND_YEAR_ENDED_COLUMN',
  NULL,
  'EXCLUDE_NOTE_REFERENCE_COLUMNS',40)
ON CONFLICT (pattern_key) DO UPDATE SET
  header_pattern=EXCLUDED.header_pattern,
  group_column_rule=EXCLUDED.group_column_rule,
  prior_column_rule=EXCLUDED.prior_column_rule,
  note_column_rule=EXCLUDED.note_column_rule,
  active=true,
  approval_status='APPROVED';

-- Reusable labels observed across commercial, industrial and investment
-- reports.  Scope/section logic remains responsible for disambiguation.
INSERT INTO financial_risk_intelligence.financial_concept_aliases
 (concept_key, alias_text, normalized_alias_text, sector_key, priority,
  active, approval_status, approved_by, approved_at)
SELECT v.concept_key, v.alias_text,
       financial_risk_intelligence.normalize_financial_alias_text(v.alias_text),
       NULL, v.priority, true, 'APPROVED', 'BATCH1_GENERIC', now()
FROM (VALUES
 ('revenue','Revenue',1),('revenue','Sales',2),('revenue','Turnover',3),
 ('cost_of_goods_sold','Cost of sales',1),('cost_of_goods_sold','Cost of goods sold',2),
 ('sg_and_a_expense','Administrative expenses',1),('sg_and_a_expense','Administrative',2),
 ('sg_and_a_expense','Selling, general and administrative expenses',3),
 ('interest_expense','Finance costs',1),('interest_expense','Finance expense',2),
 ('net_profit','Profit for the year',1),('net_profit','Profit for the period',2),
 ('net_profit','Loss for the year',3),('net_profit','Net profit or loss',4),
 ('inventory','Inventory',1),('inventory','Inventories',2),
 ('trade_receivables_net','Trade receivables',1),('trade_receivables_net','Trade and other receivables',2),
 ('net_ppe','Property, plant and equipment',1),('net_ppe','Net PP&E',2),
 ('total_assets','Total assets',1),('total_liabilities','Total liabilities',1),
 ('total_current_assets','Total current assets',1),
 ('total_current_liabilities','Total current liabilities',1),
 ('total_shareholders_equity','Equity attributable to owners of the Company',1),
 ('total_shareholders_equity','Total shareholders equity',2),
 ('long_term_debt','Long-term debt',1),('long_term_debt','Loans and borrowings',2),
 ('long_term_debt','Non-current borrowings',3),
 ('operating_cash_flow','Operating cash flow',1),
 ('operating_cash_flow','Net cash flows generated from operating activities',2),
 ('operating_cash_flow','Cash generated from operations',3),
 ('depreciation_ppe','Depreciation of property, plant and equipment',1),
 ('depreciation_rou','Depreciation of right-of-use assets',1),
 ('amortization_intangibles','Amortisation of intangible assets',1),
 ('shares_outstanding','Shares outstanding',1),
 ('shares_outstanding','Number of ordinary shares',2)
) v(concept_key,alias_text,priority)
ON CONFLICT DO NOTHING;

COMMIT;
