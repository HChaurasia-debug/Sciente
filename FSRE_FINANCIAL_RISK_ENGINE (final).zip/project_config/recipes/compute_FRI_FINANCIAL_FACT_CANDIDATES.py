"""FRI_04_RESOLVE_FINANCIAL_FACTS.

Inputs:
    FRI_REQUIRED_FIELD_MANIFEST
    FRI_VALIDATED_TABLE_ARTIFACTS
    FRI_VALIDATED_TABLE_CELLS
Outputs:
    FRI_FINANCIAL_FACT_CANDIDATES
    FRI_RESOLVED_FINANCIAL_FACTS
    FRI_FINANCIAL_FACT_EXCEPTIONS
"""

from __future__ import annotations

import difflib
import hashlib
import json
import math
import re
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Sequence, Tuple

import dataiku
import pandas as pd


INPUT_MANIFEST = "FRI_REQUIRED_FIELD_MANIFEST"
INPUT_TABLES = "FRI_VALIDATED_TABLE_ARTIFACTS"
INPUT_CELLS = "FRI_VALIDATED_TABLE_CELLS"
OUTPUT_CANDIDATES = "FRI_FINANCIAL_FACT_CANDIDATES"
OUTPUT_FACTS = "FRI_RESOLVED_FINANCIAL_FACTS"
OUTPUT_EXCEPTIONS = "FRI_FINANCIAL_FACT_EXCEPTIONS"

VERSION = "fri-financial-fact-resolver-1.0.0"
ACCEPTED_STATUSES = {"VALIDATED", "VALIDATED_WITH_WARNINGS"}

CANDIDATE_COLUMNS = [
    "candidate_id", "tenant_id", "entity_id", "assessment_run_id",
    "source_document_id", "configuration_set_id", "configuration_item_id",
    "concept_key", "requested_statement_key", "requested_period_key",
    "resolved_period_label", "requested_entity_scope", "table_artifact_id",
    "source_table_id", "source_page_number", "source_row_index",
    "source_column_index", "source_row_label", "source_header_path",
    "source_statement_type", "source_entity_scope", "source_period_label",
    "raw_value", "numeric_value", "normalized_value", "currency", "unit",
    "unit_multiplier", "label_match_method", "matched_alias",
    "label_similarity", "statement_score", "period_score", "scope_score",
    "structure_score", "resolution_score", "candidate_rank",
    "selected_candidate", "candidate_status", "resolver_version", "created_at",
]

FACT_COLUMNS = [
    "fact_id", "tenant_id", "entity_id", "assessment_run_id", "run_id",
    "source_document_id", "configuration_set_id", "configuration_version",
    "configuration_item_id", "concept_key", "statement_key", "period_key",
    "resolved_period_label", "entity_scope", "data_type", "raw_value",
    "numeric_value", "normalized_value", "currency", "unit",
    "unit_multiplier", "table_artifact_id", "source_table_id",
    "source_page_number", "source_row_index", "source_column_index",
    "source_row_label", "source_header_path", "resolution_method",
    "resolution_confidence", "resolution_status", "resolver_version",
    "resolved_at",
]

EXCEPTION_COLUMNS = [
    "exception_id", "tenant_id", "entity_id", "assessment_run_id",
    "source_document_id", "configuration_set_id", "configuration_item_id",
    "concept_key", "statement_key", "period_key", "is_required",
    "exception_code", "severity", "candidate_count", "best_candidate_score",
    "message", "recommended_action", "resolver_version", "created_at",
]


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def missing(value: Any) -> bool:
    if value is None:
        return True
    try:
        result = pd.isna(value)
        if isinstance(result, bool) and result:
            return True
    except (TypeError, ValueError):
        pass
    return str(value).strip().lower() in {"", "nan", "none", "null", "nat"}


def text(value: Any, default: str = "") -> str:
    return default if missing(value) else str(value).strip()


def boolean(value: Any, default: bool = False) -> bool:
    if missing(value):
        return default
    if isinstance(value, bool):
        return value
    return text(value).lower() in {"true", "1", "yes", "y"}


def numeric(value: Any) -> Optional[float]:
    if missing(value):
        return None
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        try:
            result = float(value)
            return None if math.isnan(result) else result
        except (TypeError, ValueError):
            return None

    candidate = text(value)
    if candidate in {"-", "--", "\u2013", "\u2014", "\u2212"}:
        return None
    negative = candidate.startswith("(") and candidate.endswith(")")
    candidate = candidate.strip("()").replace(",", "").replace("\u2212", "-")
    candidate = re.sub(r"[$\u20ac\u00a3\u20b9%]", "", candidate).strip()
    try:
        result = float(candidate)
        return -result if negative else result
    except ValueError:
        return None


def object_value(value: Any) -> Dict[str, Any]:
    if isinstance(value, dict):
        return value
    if missing(value):
        return {}
    try:
        parsed = json.loads(str(value))
        return parsed if isinstance(parsed, dict) else {}
    except (json.JSONDecodeError, TypeError, ValueError):
        return {}


def identifier(parts: Sequence[Any]) -> str:
    material = "|".join(text(part) for part in parts)
    return hashlib.sha256(material.encode("utf-8")).hexdigest()[:32]


def normalize(value: Any) -> str:
    result = text(value).lower().replace("&", " and ")
    result = re.sub(r"['\u2019]s\b", "", result)
    result = re.sub(r"[^a-z0-9]+", " ", result)
    return re.sub(r"\s+", " ", result).strip()


def statement_name(value: Any) -> str:
    value = normalize(value)
    aliases = {
        "statement of financial position": "balance sheet",
        "financial position": "balance sheet",
        "profit and loss": "income statement",
        "statement of income": "income statement",
        "statement of cash flows": "cash flow statement",
        "cash flows": "cash flow statement",
    }
    return aliases.get(value, value)


def scope_name(value: Any) -> str:
    value = normalize(value)
    if value in {"group", "consolidated", "the group"}:
        return "group"
    if value in {"company", "standalone", "parent", "the company"}:
        return "company"
    return value


def multiplier_for(unit: Any) -> float:
    return {
        "unit": 1.0, "units": 1.0,
        "thousand": 1000.0, "thousands": 1000.0, "000": 1000.0,
        "million": 1000000.0, "millions": 1000000.0, "mn": 1000000.0,
        "billion": 1000000000.0, "billions": 1000000000.0,
        "bn": 1000000000.0,
    }.get(normalize(unit), 1.0)


def configured_values(definition: Dict[str, Any], keys: Sequence[str]) -> List[str]:
    values: List[Any] = []
    for container in (definition, definition.get("extraction")):
        if not isinstance(container, dict):
            continue
        for key in keys:
            configured = container.get(key)
            if isinstance(configured, list):
                values.extend(configured)
            elif not missing(configured):
                values.append(configured)
    return list(dict.fromkeys(text(value) for value in values if text(value)))


def aliases_for(manifest: Dict[str, Any]) -> List[str]:
    definition = object_value(manifest.get("configuration_definition"))
    result = configured_values(
        definition,
        ("aliases", "source_labels", "row_labels", "labels", "synonyms"),
    )
    concept = text(manifest.get("concept_key"))
    result.extend([concept, concept.replace("_", " "), text(definition.get("display_name"))])
    return list(dict.fromkeys(value for value in result if value))


def desired_scope(manifest: Dict[str, Any]) -> str:
    definition = object_value(manifest.get("configuration_definition"))
    for container in (definition, definition.get("extraction")):
        if not isinstance(container, dict):
            continue
        for key in ("entity_scope", "scope", "column_scope"):
            if not missing(container.get(key)):
                return scope_name(container.get(key))
    return ""


def period_years(cells: List[Dict[str, Any]]) -> List[str]:
    years = set()
    for cell in cells:
        source = " ".join([
            text(cell.get("period_label")),
            text(cell.get("header_path")),
            text(cell.get("raw_text")),
        ])
        years.update(re.findall(r"\b(?:19|20)\d{2}\b", source))
    return sorted(years, reverse=True)


def desired_period(
    period_key: Any,
    definition: Dict[str, Any],
    years: List[str],
) -> str:
    requested = text(period_key)
    if re.fullmatch(r"(?:19|20)\d{2}", requested):
        return requested

    mapping = definition.get("period_mapping")
    if isinstance(mapping, dict) and not missing(mapping.get(requested)):
        return text(mapping.get(requested))

    key = normalize(requested)
    if key in {
        "current", "current period", "current year", "latest",
        "reporting period", "reporting year",
    }:
        return years[0] if years else ""
    if key in {
        "prior", "prior period", "prior year", "previous",
        "previous period", "previous year",
    }:
        return years[1] if len(years) > 1 else ""
    return requested


def match_label(row_label: str, aliases: List[str]) -> Tuple[float, str, str]:
    label = normalize(row_label)
    best = (0.0, "", "NO_MATCH")
    for alias in aliases:
        normalized_alias = normalize(alias)
        if not normalized_alias:
            continue
        if label == normalized_alias:
            score, method = 1.0, "EXACT_ALIAS"
        elif (
            len(normalized_alias) >= 5
            and re.search(
                r"(^|\s)" + re.escape(normalized_alias) + r"($|\s)", label
            )
        ):
            score, method = 0.92, "CONTAINED_ALIAS"
        else:
            score = difflib.SequenceMatcher(None, label, normalized_alias).ratio()
            method = "FUZZY_ALIAS"
        if score > best[0]:
            best = (score, alias, method)
    return round(best[0], 6), best[1], best[2]


def read_dataset(name: str) -> pd.DataFrame:
    try:
        return dataiku.Dataset(name).get_dataframe(infer_with_pandas=False)
    except TypeError:
        return dataiku.Dataset(name).get_dataframe()


variables = dataiku.get_custom_variables()
min_label = float(variables.get("fri_fact_min_label_similarity", 0.72))
min_resolution = float(variables.get("fri_fact_min_resolution_score", 0.78))
ambiguity_margin = float(variables.get("fri_fact_ambiguity_margin", 0.04))

manifest_df = read_dataset(INPUT_MANIFEST)
tables_df = read_dataset(INPUT_TABLES)
cells_df = read_dataset(INPUT_CELLS)

print(json.dumps({
    "manifest_rows": len(manifest_df),
    "validated_table_rows": len(tables_df),
    "validated_cell_rows": len(cells_df),
}, indent=2))

if manifest_df.empty:
    raise RuntimeError("FRI_REQUIRED_FIELD_MANIFEST is empty; run Recipe 01A.")
if tables_df.empty or cells_df.empty:
    raise RuntimeError("Validated tables or cells are empty; run Recipes 03B and 03C.")

tables: Dict[str, Dict[str, Any]] = {}
for row in tables_df.to_dict(orient="records"):
    table_id = text(row.get("table_artifact_id") or row.get("source_table_id"))
    if table_id:
        tables[table_id] = row

cells_by_document: Dict[Tuple[str, str, str], List[Dict[str, Any]]] = {}
for row in cells_df.to_dict(orient="records"):
    if text(row.get("validation_status")).upper() not in ACCEPTED_STATUSES:
        continue

    table_id = text(row.get("table_artifact_id") or row.get("source_table_id"))
    table = tables.get(table_id, {})
    table_status = text(table.get("validation_status")).upper()
    if table_status and table_status not in ACCEPTED_STATUSES:
        continue

    value = numeric(row.get("numeric_value"))
    if value is None:
        value = numeric(row.get("raw_text"))
    row_label = text(row.get("row_label"))
    tenant_id = text(row.get("tenant_id"))
    run_id = text(row.get("assessment_run_id") or row.get("run_id"))
    document_id = text(row.get("source_document_id"))

    if value is None or not row_label or not tenant_id or not run_id or not document_id:
        continue

    enriched = dict(row)
    enriched["_numeric"] = value
    enriched["_table"] = table
    cells_by_document.setdefault((tenant_id, run_id, document_id), []).append(enriched)

candidate_rows: List[Dict[str, Any]] = []
fact_rows: List[Dict[str, Any]] = []
exception_rows: List[Dict[str, Any]] = []

for manifest in manifest_df.to_dict(orient="records"):
    tenant_id = text(manifest.get("tenant_id"))
    entity_id = text(manifest.get("entity_id"))
    run_id = text(manifest.get("assessment_run_id") or manifest.get("run_id"))
    document_id = text(manifest.get("source_document_id"))
    configuration_set_id = text(manifest.get("configuration_set_id"))
    item_id = text(manifest.get("configuration_item_id"))
    concept = text(manifest.get("concept_key"))
    requested_statement = statement_name(manifest.get("statement_key"))
    period_key = text(manifest.get("period_key"))
    is_required = boolean(manifest.get("is_required"), True)
    definition = object_value(manifest.get("configuration_definition"))
    requested_scope = desired_scope(manifest)
    aliases = aliases_for(manifest)

    document_cells = cells_by_document.get((tenant_id, run_id, document_id), [])
    requested_period = desired_period(
        period_key, definition, period_years(document_cells)
    )
    matches: List[Dict[str, Any]] = []

    for cell in document_cells:
        table = cell["_table"]
        label_score, matched_alias, method = match_label(
            text(cell.get("row_label")), aliases
        )
        if label_score < min_label:
            continue

        source_statement = statement_name(
            table.get("statement_type") or cell.get("statement_type")
        )
        if not requested_statement:
            statement_score = 1.0
        elif source_statement in {"", "unclassified"}:
            statement_score = 0.55
        elif source_statement == requested_statement:
            statement_score = 1.0
        else:
            statement_score = difflib.SequenceMatcher(
                None, source_statement, requested_statement
            ).ratio()
            if statement_score < 0.60:
                continue

        source_header = text(cell.get("header_path"))
        source_period = text(cell.get("period_label"))
        if not source_period:
            years = re.findall(r"\b(?:19|20)\d{2}\b", source_header)
            source_period = years[-1] if years else ""

        if not requested_period:
            period_score = 0.65
        elif source_period == requested_period:
            period_score = 1.0
        elif not source_period:
            period_score = 0.40
        else:
            continue

        source_scope = scope_name(
            cell.get("entity_scope") or cell.get("column_scope")
        )
        if not requested_scope:
            scope_score = 1.0
        elif source_scope == requested_scope:
            scope_score = 1.0
        elif not source_scope:
            scope_score = 0.45
        else:
            continue

        raw_structure = numeric(table.get("structure_score"))
        structure_score = (
            max(0.0, min(1.0, raw_structure / 100.0))
            if raw_structure is not None else 0.70
        )
        score = (
            label_score * 0.68 + statement_score * 0.12
            + period_score * 0.08 + scope_score * 0.04
            + structure_score * 0.08
        )

        value = cell["_numeric"]
        unit = text(cell.get("unit") or table.get("presentation_unit"))
        multiplier = multiplier_for(unit)
        table_id = text(cell.get("table_artifact_id"))
        source_table_id = text(
            cell.get("source_table_id") or table.get("source_table_id")
        )
        page = int(numeric(cell.get("page_number")) or 0)
        row_index = int(numeric(cell.get("row_index")) or 0)
        column_index = int(numeric(cell.get("column_index")) or 0)

        matches.append({
            "candidate_id": identifier([
                tenant_id, run_id, document_id, item_id, period_key,
                table_id, page, row_index, column_index,
            ]),
            "tenant_id": tenant_id,
            "entity_id": entity_id,
            "assessment_run_id": run_id,
            "source_document_id": document_id,
            "configuration_set_id": configuration_set_id,
            "configuration_item_id": item_id,
            "concept_key": concept,
            "requested_statement_key": requested_statement,
            "requested_period_key": period_key,
            "resolved_period_label": requested_period,
            "requested_entity_scope": requested_scope,
            "table_artifact_id": table_id,
            "source_table_id": source_table_id,
            "source_page_number": page,
            "source_row_index": row_index,
            "source_column_index": column_index,
            "source_row_label": text(cell.get("row_label")),
            "source_header_path": source_header,
            "source_statement_type": source_statement,
            "source_entity_scope": source_scope,
            "source_period_label": source_period,
            "raw_value": text(cell.get("raw_text")),
            "numeric_value": value,
            "normalized_value": value * multiplier,
            "currency": text(
                cell.get("currency") or table.get("presentation_currency")
            ),
            "unit": unit,
            "unit_multiplier": multiplier,
            "label_match_method": method,
            "matched_alias": matched_alias,
            "label_similarity": label_score,
            "statement_score": round(statement_score, 6),
            "period_score": round(period_score, 6),
            "scope_score": round(scope_score, 6),
            "structure_score": round(structure_score, 6),
            "resolution_score": round(score, 6),
            "candidate_rank": 0,
            "selected_candidate": False,
            "candidate_status": "CANDIDATE",
            "resolver_version": VERSION,
            "created_at": now(),
        })

    matches.sort(key=lambda row: (
        -row["resolution_score"], row["source_page_number"],
        row["source_row_index"], row["source_column_index"],
    ))
    for rank, match in enumerate(matches, 1):
        match["candidate_rank"] = rank

    selected = None
    exception_code = ""
    message = ""

    if not matches:
        exception_code = (
            "REQUIRED_FACT_NOT_FOUND" if is_required else "OPTIONAL_FACT_NOT_FOUND"
        )
        message = f"No validated cell matched concept '{concept}' and period '{period_key}'."
    elif matches[0]["resolution_score"] < min_resolution:
        exception_code = "LOW_CONFIDENCE_MATCH"
        message = (
            f"Best score {matches[0]['resolution_score']:.4f} is below "
            f"threshold {min_resolution:.4f}."
        )
    elif (
        len(matches) > 1
        and abs(matches[0]["resolution_score"] - matches[1]["resolution_score"])
        < ambiguity_margin
        and matches[0]["normalized_value"] != matches[1]["normalized_value"]
    ):
        exception_code = "AMBIGUOUS_FACT_MATCH"
        message = "Similar-confidence candidates contain different values."
    else:
        selected = matches[0]
        selected["selected_candidate"] = True
        selected["candidate_status"] = "SELECTED"

    candidate_rows.extend(matches)

    if selected:
        fact_rows.append({
            "fact_id": identifier([
                tenant_id, run_id, document_id, item_id, period_key
            ]),
            "tenant_id": tenant_id,
            "entity_id": entity_id,
            "assessment_run_id": run_id,
            "run_id": run_id,
            "source_document_id": document_id,
            "configuration_set_id": configuration_set_id,
            "configuration_version": text(manifest.get("configuration_version")),
            "configuration_item_id": item_id,
            "concept_key": concept,
            "statement_key": requested_statement,
            "period_key": period_key,
            "resolved_period_label": (
                selected["source_period_label"] or requested_period
            ),
            "entity_scope": (
                selected["source_entity_scope"] or requested_scope
            ),
            "data_type": text(manifest.get("data_type")),
            "raw_value": selected["raw_value"],
            "numeric_value": selected["numeric_value"],
            "normalized_value": selected["normalized_value"],
            "currency": selected["currency"],
            "unit": selected["unit"],
            "unit_multiplier": selected["unit_multiplier"],
            "table_artifact_id": selected["table_artifact_id"],
            "source_table_id": selected["source_table_id"],
            "source_page_number": selected["source_page_number"],
            "source_row_index": selected["source_row_index"],
            "source_column_index": selected["source_column_index"],
            "source_row_label": selected["source_row_label"],
            "source_header_path": selected["source_header_path"],
            "resolution_method": selected["label_match_method"],
            "resolution_confidence": selected["resolution_score"],
            "resolution_status": "RESOLVED",
            "resolver_version": VERSION,
            "resolved_at": now(),
        })
    else:
        exception_rows.append({
            "exception_id": identifier([
                tenant_id, run_id, document_id, item_id, period_key,
                exception_code,
            ]),
            "tenant_id": tenant_id,
            "entity_id": entity_id,
            "assessment_run_id": run_id,
            "source_document_id": document_id,
            "configuration_set_id": configuration_set_id,
            "configuration_item_id": item_id,
            "concept_key": concept,
            "statement_key": requested_statement,
            "period_key": period_key,
            "is_required": is_required,
            "exception_code": exception_code,
            "severity": "ERROR" if is_required else "WARNING",
            "candidate_count": len(matches),
            "best_candidate_score": (
                matches[0]["resolution_score"] if matches else None
            ),
            "message": message,
            "recommended_action": (
                "Review configured aliases, table status, period/scope headers, "
                "or route the fact to assisted resolution."
            ),
            "resolver_version": VERSION,
            "created_at": now(),
        })

candidate_df = pd.DataFrame(candidate_rows, columns=CANDIDATE_COLUMNS)
fact_df = pd.DataFrame(fact_rows, columns=FACT_COLUMNS)
exception_df = pd.DataFrame(exception_rows, columns=EXCEPTION_COLUMNS)

dataiku.Dataset(OUTPUT_CANDIDATES).write_with_schema(candidate_df)
dataiku.Dataset(OUTPUT_FACTS).write_with_schema(fact_df)
dataiku.Dataset(OUTPUT_EXCEPTIONS).write_with_schema(exception_df)

print(json.dumps({
    "resolver_version": VERSION,
    "manifest_row_count": len(manifest_df),
    "eligible_document_count": len(cells_by_document),
    "candidate_count": len(candidate_df),
    "resolved_fact_count": len(fact_df),
    "exception_count": len(exception_df),
    "exception_codes": (
        exception_df["exception_code"].value_counts().to_dict()
        if not exception_df.empty else {}
    ),
}, indent=2, default=str))
