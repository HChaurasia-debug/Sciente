-- Make the Manufacturing & Industrials template consume validated raw-table
-- facts first, then use only auditable accounting identities as fallbacks.
-- Run after FRI_FINANCIAL_SYNONYM_REGISTRY.sql and
-- FRI_MANUFACTURING_DERIVATION_CONFIGURATION.sql.
BEGIN;

-- A lease-only non-current-liability section is evidence that long-term debt
-- is zero, not missing.  The canonical resolver emits that zero only after
-- it verifies a paired, titled Group balance sheet with no debt/borrowing row.
UPDATE financial_risk_intelligence.financial_concepts
SET validation_definition = COALESCE(validation_definition, '{}'::jsonb)
    || jsonb_build_object(
        'resolver_statement_type', 'BALANCE_SHEET',
        'scope_preference', 'GROUP_THEN_REPORTED_THEN_COMPANY',
        'selection_rule', 'NON_CURRENT_OR_ZERO_IF_UNREPORTED'
    ),
    updated_at = now()
WHERE concept_key = 'long_term_debt';

-- Inventory is zero only when a paired, titled primary balance sheet contains
-- no inventory line. This does not convert an extraction failure into zero.
UPDATE financial_risk_intelligence.financial_concepts
SET validation_definition = COALESCE(validation_definition, '{}'::jsonb)
    || jsonb_build_object('resolver_statement_type', 'BALANCE_SHEET',
                          'selection_rule', 'ZERO_IF_ABSENT_PRIMARY'),
    updated_at = now()
WHERE concept_key = 'inventory';

-- These variants occur in primary statements.  They are aliases, not values:
-- the canonical resolver still selects a paired Group current/prior source.
SELECT financial_risk_intelligence.upsert_concept_alias(
    concept_key, alias_text, 'MANUFACTURING_INDUSTRIALS_GENERIC', NULL,
    priority, NULL, 100, 'RAW_FACT_RECONCILIATION_2026'
)
FROM (VALUES
    ('total_current_assets', 'Current assets', 2),
    ('total_current_assets', 'Total current asset', 3),
    ('total_non_current_assets', 'Non-current assets', 2),
    ('total_non_current_assets', 'Total non-current asset', 3),
    ('total_current_liabilities', 'Current liabilities', 2),
    ('total_current_liabilities', 'Total current liability', 3),
    ('inventory', 'Inventories, net', 3),
    ('inventory', 'Merchandise inventory', 4),
    ('inventory', 'Merchandise inventories', 5),
    ('inventory', 'Stock-in-trade', 6),
    ('inventory', 'Stocks', 7),
    -- Core primary-statement captions, retained alongside all existing
    -- aliases. These are exact labels, so they cannot turn note prose into
    -- a financial fact.
    ('revenue', 'Revenue', 1),
    ('cost_of_goods_sold', 'Cost of sales', 1),
    ('net_ppe', 'Property, plant and equipment', 2),
    ('total_shareholders_equity', 'Total Equity', 2),
    ('total_shareholders_equity', 'Equity attributable to owners of the Company', 3),
    ('ending_cash', 'Cash and cash equivalents at the end of the year', 1),
    -- Cash-flow primary-statement variants. These all retain the reported
    -- sign; the UI may display a magnitude, but scoring lineage stays signed.
    ('investing_cash_flow', 'Net cash flows from/(used in) investing activities', 1),
    ('investing_cash_flow', 'Net cash flow from/(used in) investing activities', 2),
    ('investing_cash_flow', 'Net cash flows provided by/(used in) investing activities', 3),
    ('investing_cash_flow', 'Net cash flow provided by/(used in) investing activities', 4),
    ('investing_cash_flow', 'Net cash provided by investing activities', 5),
    ('investing_cash_flow', 'Net cash used in investing activities', 6),
    ('investing_cash_flow', 'Net cash (outflow)/inflow from investing activities', 7),
    ('investing_cash_flow', 'Net cash inflow/(outflow) from investing activities', 8),
    ('investing_cash_flow', 'Net cash flows from investing activities', 9),
    -- Primary-statement wording used by Accrelist and comparable SFRS(I)
    -- filings. Component expenses remain distinct so SG&A stays auditable.
    ('distribution_expense', 'Marketing and distribution', 5),
    ('administrative_expenses', 'Administrative', 5),
    ('net_profit', 'Loss for the year, net of tax', 5),
    ('operating_cash_flow', 'Net cash generated from/(used in) operating activities', 3),
    ('operating_cash_flow', 'Net cash (used in)/generated from operating activities', 4),
    ('investing_cash_flow', 'Net cash (used in)/generated from investing activities', 10),
    ('investing_cash_flow', 'Net cash generated from/(used in) investing activities', 11),
    ('financing_cash_flow', 'Net cash used in financing activities', 3),
    ('financing_cash_flow', 'Net cash generated from/(used in) financing activities', 4),
    ('financing_cash_flow', 'Net cash (used in)/generated from financing activities', 5),
    ('operating_cash_flow', 'Net cash used in operating activities', 5),
    ('investing_cash_flow', 'Net cash used in investing activities', 12),
    ('net_change_cash', 'Net increase in cash and cash equivalents', 5),
    ('net_change_cash', 'Net decrease in cash and cash equivalents', 6),
    ('ending_cash', 'Cash and cash equivalents at the end of the year', 6),
    ('total_non_current_liabilities', 'Non-current liabilities', 2),
    ('total_non_current_liabilities', 'Total non-current liability', 3),
    ('long_term_debt', 'Non-current loans and borrowings', 2),
    ('long_term_debt', 'Long-term borrowings', 3),
    ('long_term_debt', 'Non-current borrowings', 4),
    ('distribution_expense', 'Distribution costs', 2),
    ('distribution_expense', 'Marketing and distribution expenses', 3),
    ('distribution_expense', 'Selling and distribution expenses', 4),
    ('administrative_expenses', 'Administrative costs', 2),
    ('administrative_expenses', 'Administrative and general expenses', 3),
    ('shares_outstanding', 'Number of ordinary shares in issue', 2),
    ('shares_outstanding', 'Number of issued ordinary shares', 3),
    -- A weighted share count is an approved fallback only when it is the
    -- filing's disclosed ordinary-share count for both periods.  It is below
    -- a direct outstanding/issued-at-end alias in priority.
    ('shares_outstanding', 'Number of ordinary shares for purpose of loss per share', 20),
    ('beginning_cash', 'Cash and bank balances at beginning of financial year', 1),
    ('beginning_cash', 'Cash and cash equivalents at beginning of year', 2),
    ('beginning_cash', 'Cash and cash equivalents at beginning of the year', 3),
    ('ending_cash', 'Cash and bank balances at end of year', 2),
    ('ending_cash', 'Cash and cash equivalents at end of year', 3),
    ('net_change_cash', 'Net increase/(decrease) in cash and cash equivalents', 3),
    ('net_change_cash', 'Net (decrease)/increase in cash and cash equivalents', 4)
) AS raw_alias(concept_key, alias_text, priority);

-- Preserve every existing SG&A rule and add the specific two-component path
-- needed when the raw primary statement discloses Distribution costs and
-- Administrative expenses. It has a higher priority than the legacy
-- three-component rule, but does not alter or remove that rule.
INSERT INTO financial_risk_intelligence.financial_template_rules
    (rule_key, template_key, target_concept_key, operator, priority, output_sign, active, approval_status)
VALUES
    ('SGA_DISTRIBUTION_ADMIN', 'MANUFACTURING_INDUSTRIALS_GENERIC', 'sg_and_a_expense', 'LINEAR_COMBINATION', 19, 'ABSOLUTE', true, 'APPROVED')
ON CONFLICT (rule_key) DO UPDATE SET
    priority=EXCLUDED.priority, output_sign=EXCLUDED.output_sign,
    active=true, approval_status='APPROVED', updated_at=now();

INSERT INTO financial_risk_intelligence.financial_rule_components
    (rule_key, component_concept_key, coefficient, component_sign, component_order)
VALUES
    ('SGA_DISTRIBUTION_ADMIN', 'distribution_expense', 1, 'ABSOLUTE', 1),
    ('SGA_DISTRIBUTION_ADMIN', 'administrative_expenses', 1, 'ABSOLUTE', 2)
ON CONFLICT (rule_key, component_concept_key) DO UPDATE SET
    coefficient=EXCLUDED.coefficient, component_sign=EXCLUDED.component_sign,
    component_order=EXCLUDED.component_order;

-- Every configured cash-flow field needs a direct rule.  Previously the
-- resolver had one only for operating cash flow, so raw investing, financing,
-- net-change and ending-cash facts could be displayed as a UI fallback but
-- were never persisted in FRI_SECTOR_TEMPLATE_VALUES.
INSERT INTO financial_risk_intelligence.financial_template_rules
    (rule_key, template_key, target_concept_key, operator, priority, output_sign, active, approval_status)
VALUES
    ('INVESTING_CASH_DIRECT', 'MANUFACTURING_INDUSTRIALS_GENERIC', 'investing_cash_flow', 'DIRECT', 10, 'AS_REPORTED', true, 'APPROVED'),
    ('FINANCING_CASH_DIRECT', 'MANUFACTURING_INDUSTRIALS_GENERIC', 'financing_cash_flow', 'DIRECT', 10, 'AS_REPORTED', true, 'APPROVED'),
    ('NET_CHANGE_CASH_DIRECT', 'MANUFACTURING_INDUSTRIALS_GENERIC', 'net_change_cash', 'DIRECT', 10, 'AS_REPORTED', true, 'APPROVED'),
    ('ENDING_CASH_DIRECT', 'MANUFACTURING_INDUSTRIALS_GENERIC', 'ending_cash', 'DIRECT', 10, 'AS_REPORTED', true, 'APPROVED'),
    ('ENDING_CASH_FROM_BEGINNING', 'MANUFACTURING_INDUSTRIALS_GENERIC', 'ending_cash', 'LINEAR_COMBINATION', 20, 'AS_REPORTED', true, 'APPROVED'),
    ('TCA_FROM_ASSET_SPLIT', 'MANUFACTURING_INDUSTRIALS_GENERIC', 'total_current_assets', 'LINEAR_COMBINATION', 20, 'ABSOLUTE', true, 'APPROVED'),
    ('TCL_FROM_LIABILITY_SPLIT', 'MANUFACTURING_INDUSTRIALS_GENERIC', 'total_current_liabilities', 'LINEAR_COMBINATION', 20, 'ABSOLUTE', true, 'APPROVED')
ON CONFLICT (rule_key) DO UPDATE SET
    priority=EXCLUDED.priority, output_sign=EXCLUDED.output_sign,
    active=true, approval_status='APPROVED', updated_at=now();

-- A non-current lease liability is a disclosed debt-like obligation. Use it
-- only after an explicit non-current borrowing/component derivation.
INSERT INTO financial_risk_intelligence.financial_template_rules
    (rule_key, template_key, target_concept_key, operator, priority, output_sign, active, approval_status)
VALUES
    ('LTD_FROM_NON_CURRENT_LEASE', 'MANUFACTURING_INDUSTRIALS_GENERIC', 'long_term_debt', 'LINEAR_COMBINATION', 6, 'ABSOLUTE', true, 'APPROVED')
ON CONFLICT (rule_key) DO UPDATE SET
    priority=EXCLUDED.priority, output_sign=EXCLUDED.output_sign,
    active=true, approval_status='APPROVED', updated_at=now();

INSERT INTO financial_risk_intelligence.financial_rule_components
    (rule_key, component_concept_key, coefficient, component_sign, component_order)
VALUES
    ('ENDING_CASH_FROM_BEGINNING', 'beginning_cash', 1, 'AS_REPORTED', 1),
    ('ENDING_CASH_FROM_BEGINNING', 'net_change_cash', 1, 'AS_REPORTED', 2),
    ('TCA_FROM_ASSET_SPLIT', 'total_assets', 1, 'ABSOLUTE', 1),
    ('TCA_FROM_ASSET_SPLIT', 'total_non_current_assets', -1, 'ABSOLUTE', 2),
    ('TCL_FROM_LIABILITY_SPLIT', 'total_liabilities', 1, 'ABSOLUTE', 1),
    ('TCL_FROM_LIABILITY_SPLIT', 'total_non_current_liabilities', -1, 'ABSOLUTE', 2),
    ('LTD_FROM_NON_CURRENT_LEASE', 'non_current_lease_liabilities', 1, 'ABSOLUTE', 1)
ON CONFLICT (rule_key, component_concept_key) DO UPDATE SET
    coefficient=EXCLUDED.coefficient, component_sign=EXCLUDED.component_sign,
    component_order=EXCLUDED.component_order;

COMMIT;
