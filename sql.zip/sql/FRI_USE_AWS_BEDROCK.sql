BEGIN;

CREATE SCHEMA IF NOT EXISTS financial_risk_intelligence;

CREATE TABLE IF NOT EXISTS financial_risk_intelligence.runtime_settings (
    setting_key TEXT PRIMARY KEY,
    setting_value TEXT NOT NULL,
    is_secret BOOLEAN NOT NULL DEFAULT FALSE,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Remove the previous Groq runtime configuration and credential.
DELETE FROM financial_risk_intelligence.runtime_settings
 WHERE setting_key IN (
    'fri_groq_api_key',
    'fri_groq_base_url',
    'fri_groq_model',
    'fri_groq_timeout_seconds'
 );

INSERT INTO financial_risk_intelligence.runtime_settings
    (setting_key, setting_value, is_secret, active, updated_at)
VALUES
    ('fri_llm_provider', 'bedrock', FALSE, TRUE, CURRENT_TIMESTAMP),
    ('fri_bedrock_region', 'ap-south-1', FALSE, TRUE, CURRENT_TIMESTAMP),
    ('fri_bedrock_model', 'amazon.nova-pro-v1:0', FALSE, TRUE, CURRENT_TIMESTAMP),
    ('fri_bedrock_timeout_seconds', '120', FALSE, TRUE, CURRENT_TIMESTAMP),
    -- Replace this placeholder immediately before executing the SQL recipe.
    -- Do not commit the real key to source control.
    ('fri_bedrock_api_key', '<ROTATED_BEDROCK_API_KEY>', TRUE, TRUE, CURRENT_TIMESTAMP)
ON CONFLICT (setting_key) DO UPDATE SET
    setting_value = EXCLUDED.setting_value,
    is_secret = EXCLUDED.is_secret,
    active = EXCLUDED.active,
    updated_at = CURRENT_TIMESTAMP;

COMMIT;

-- Verification deliberately masks secret values.
SELECT setting_key,
       CASE WHEN is_secret THEN '[SECRET PRESENT]' ELSE setting_value END AS effective_value,
       is_secret,
       active,
       updated_at
  FROM financial_risk_intelligence.runtime_settings
 WHERE setting_key LIKE 'fri_bedrock_%'
    OR setting_key = 'fri_llm_provider'
 ORDER BY setting_key;
